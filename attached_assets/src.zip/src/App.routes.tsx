
import { Navigate, RouteObject } from "react-router-dom";
import Index from "./pages/Index";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";
import Leads from "./pages/Leads";
import Clients from "./pages/Clients";
import Settings from "./pages/Settings";
import Orders from "./pages/Orders";
import OrderView from "./pages/OrderView";
import OrderCreate from "./pages/OrderCreate";
import OrderEdit from "./pages/OrderEdit";
import Catalog from "./pages/Catalog";
import Reports from "./pages/Reports";
import Design from "./pages/Design";
import Manufacturing from "./pages/Manufacturing";
import Data from "./pages/Data";
import ClientPortal from "./pages/ClientPortal";
import Wholesale from "./pages/Wholesale";
import ClientEmails from "./pages/ClientEmails";
import SalesPeople from "./pages/SalesPeople";
import CampManagement from "./pages/CampManagement";
import Finance from "./pages/Finance";
import Account from "./pages/Account";
import SalesAccount from "./pages/SalesAccount";
import SalesOrders from "./pages/SalesOrders";
import ManufacturingSubmission from "./pages/ManufacturingSubmission";
import SalesDesignView from "./pages/SalesDesignView";
import SalesDesignManagement from "./pages/SalesDesignManagement";
import SalesManufacturingManagement from "./pages/SalesManufacturingManagement";
import SalesFinance from "./pages/SalesFinance";
import AdminDesignTeam from "./pages/AdminDesignTeam";
import AdminManufacturingTeam from "./pages/AdminManufacturingTeam";
import AdminData from "./pages/AdminData";
import AdminClientEmails from "./pages/AdminClientEmails";
import AdminSalesTeam from "./pages/AdminSalesTeam";
import AdminCampManagement from "./pages/AdminCampManagement";
import { RequireAuth } from "./components/RequireAuth";

// Define all application routes
export const routes: RouteObject[] = [
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/",
    element: (
      <RequireAuth>
        <Index />
      </RequireAuth>
    ),
  },
  {
    path: "/account",
    element: (
      <RequireAuth>
        <Account />
      </RequireAuth>
    ),
  },
  {
    path: "/sales-account",
    element: (
      <RequireAuth>
        <SalesAccount />
      </RequireAuth>
    ),
  },
  {
    path: "/orders",
    element: (
      <RequireAuth>
        <Orders />
      </RequireAuth>
    ),
  },
  {
    path: "/sales-orders",
    element: (
      <RequireAuth>
        <SalesOrders />
      </RequireAuth>
    ),
  },
  {
    path: "/sales-design-management",
    element: (
      <RequireAuth>
        <SalesDesignManagement />
      </RequireAuth>
    ),
  },
  {
    path: "/sales-manufacturing-management",
    element: (
      <RequireAuth>
        <SalesManufacturingManagement />
      </RequireAuth>
    ),
  },
  {
    path: "/sales-finance",
    element: (
      <RequireAuth>
        <SalesFinance />
      </RequireAuth>
    ),
  },
  {
    path: "/manufacturing-submission/:orderId",
    element: (
      <RequireAuth>
        <ManufacturingSubmission />
      </RequireAuth>
    ),
  },
  {
    path: "/sales-design/:designId",
    element: (
      <RequireAuth>
        <SalesDesignView />
      </RequireAuth>
    ),
  },
  {
    path: "/orders/new",
    element: (
      <RequireAuth>
        <OrderCreate />
      </RequireAuth>
    ),
  },
  {
    path: "/orders/:id",
    element: (
      <RequireAuth>
        <OrderView />
      </RequireAuth>
    ),
  },
  {
    path: "/orders/:id/edit",
    element: (
      <RequireAuth>
        <OrderEdit />
      </RequireAuth>
    ),
  },
  {
    path: "/catalog",
    element: (
      <RequireAuth>
        <Catalog />
      </RequireAuth>
    ),
  },
  {
    path: "/leads",
    element: (
      <RequireAuth>
        <Leads />
      </RequireAuth>
    ),
  },
  {
    path: "/client-portal",
    element: (
      <RequireAuth>
        <ClientPortal />
      </RequireAuth>
    ),
  },
  {
    path: "/clients",
    element: (
      <RequireAuth>
        <Clients />
      </RequireAuth>
    ),
  },
  {
    path: "/reports",
    element: (
      <RequireAuth>
        <Reports />
      </RequireAuth>
    ),
  },
  {
    path: "/settings",
    element: (
      <RequireAuth>
        <Settings />
      </RequireAuth>
    ),
  },
  {
    path: "/design",
    element: (
      <RequireAuth>
        <Design />
      </RequireAuth>
    ),
  },
  {
    path: "/manufacturing",
    element: (
      <RequireAuth>
        <Manufacturing />
      </RequireAuth>
    ),
  },
  // Admin-specific routes
  {
    path: "/admin/design-team",
    element: (
      <RequireAuth>
        <AdminDesignTeam />
      </RequireAuth>
    ),
  },
  {
    path: "/admin/manufacturing-team",
    element: (
      <RequireAuth>
        <AdminManufacturingTeam />
      </RequireAuth>
    ),
  },
  {
    path: "/admin/data",
    element: (
      <RequireAuth>
        <AdminData />
      </RequireAuth>
    ),
  },
  {
    path: "/admin/client-emails",
    element: (
      <RequireAuth>
        <AdminClientEmails />
      </RequireAuth>
    ),
  },
  {
    path: "/admin/sales-team",
    element: (
      <RequireAuth>
        <AdminSalesTeam />
      </RequireAuth>
    ),
  },
  {
    path: "/admin/camp-management",
    element: (
      <RequireAuth>
        <AdminCampManagement />
      </RequireAuth>
    ),
  },
  {
    path: "/data",
    element: (
      <RequireAuth>
        <Data />
      </RequireAuth>
    ),
  },
  {
    path: "/wholesale",
    element: (
      <RequireAuth>
        <Wholesale />
      </RequireAuth>
    ),
  },
  {
    path: "/client-emails",
    element: (
      <RequireAuth>
        <ClientEmails />
      </RequireAuth>
    ),
  },
  {
    path: "/sales-people",
    element: (
      <RequireAuth>
        <SalesPeople />
      </RequireAuth>
    ),
  },
  {
    path: "/camp-management",
    element: (
      <RequireAuth>
        <CampManagement />
      </RequireAuth>
    ),
  },
  {
    path: "/finance",
    element: (
      <RequireAuth>
        <Finance />
      </RequireAuth>
    ),
  },
  {
    path: "*",
    element: <Navigate to="/404" />,
  },
  {
    path: "/404",
    element: <NotFound />,
  },
];
