
import { AppProviders } from "./components/layout/AppProviders";
import { AppRoutes } from "./components/layout/AppRoutes";

function App() {
  return (
    <AppProviders>
      <AppRoutes />
    </AppProviders>
  );
}

export default App;
