
import React, { useState } from "react";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Product } from "@/lib/api";
import { Label } from "@/components/ui/label";
import { Edit, Save, X } from "lucide-react";

interface AdminProductCardProps {
  product: Product;
  onSave: (updatedProduct: Product) => void;
}

const AdminProductCard = ({ product, onSave }: AdminProductCardProps) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedProduct, setEditedProduct] = useState<Product>({ ...product });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setEditedProduct((prev) => ({
      ...prev,
      [name]: name === "price" || name === "inventory" ? Number(value) : value,
    }));
  };

  const handleSave = () => {
    onSave(editedProduct);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditedProduct({ ...product });
    setIsEditing(false);
  };

  return (
    <Card className="overflow-hidden neon-card h-full flex flex-col">
      {isEditing ? (
        <CardContent className="p-4 flex-grow space-y-3">
          <div className="space-y-1">
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              name="name"
              value={editedProduct.name}
              onChange={handleInputChange}
            />
          </div>
          
          <div className="space-y-1">
            <Label htmlFor="category">Category</Label>
            <Input
              id="category"
              name="category"
              value={editedProduct.category}
              onChange={handleInputChange}
            />
          </div>
          
          <div className="space-y-1">
            <Label htmlFor="sport">Sport</Label>
            <Input
              id="sport"
              name="sport"
              value={editedProduct.sport}
              onChange={handleInputChange}
            />
          </div>
          
          <div className="space-y-1">
            <Label htmlFor="price">Price</Label>
            <Input
              id="price"
              name="price"
              type="number"
              value={editedProduct.price}
              onChange={handleInputChange}
            />
          </div>
          
          <div className="space-y-1">
            <Label htmlFor="inventory">Inventory</Label>
            <Input
              id="inventory"
              name="inventory"
              type="number"
              value={editedProduct.inventory}
              onChange={handleInputChange}
            />
          </div>
          
          <div className="space-y-1">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              name="description"
              value={editedProduct.description}
              onChange={handleInputChange}
              rows={3}
            />
          </div>
          
          <div className="space-y-1">
            <Label htmlFor="imageUrl">Image URL</Label>
            <Input
              id="imageUrl"
              name="imageUrl"
              value={editedProduct.imageUrl}
              onChange={handleInputChange}
            />
          </div>
        </CardContent>
      ) : (
        <>
          <div className="aspect-square overflow-hidden">
            <img
              src={product.imageUrl}
              alt={product.name}
              className="w-full h-full object-cover transition-transform hover:scale-105"
            />
          </div>
          <CardContent className="p-4 flex-grow">
            <div className="mb-2">
              <h3 className="font-semibold text-lg">{product.name}</h3>
              <p className="text-muted-foreground text-sm">{product.category} - {product.sport}</p>
            </div>
            <p className="text-lg font-bold mb-2">${product.price.toFixed(2)}</p>
            <p className="text-sm text-muted-foreground line-clamp-3">{product.description}</p>
            <p className="text-sm mt-2">
              <span className={product.inventory > 10 ? "text-green-600" : "text-amber-600"}>
                {product.inventory > 0
                  ? `${product.inventory} in stock`
                  : "Out of stock"}
              </span>
            </p>
          </CardContent>
        </>
      )}
      <CardFooter className="p-4 border-t bg-muted/50">
        {isEditing ? (
          <div className="flex gap-2 w-full">
            <Button variant="default" onClick={handleSave} className="flex-1">
              <Save className="h-4 w-4 mr-2" />
              Save
            </Button>
            <Button variant="outline" onClick={handleCancel} className="flex-1">
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
          </div>
        ) : (
          <Button
            variant="outline"
            className="w-full"
            onClick={() => setIsEditing(true)}
          >
            <Edit className="h-4 w-4 mr-2" />
            Edit Product
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default AdminProductCard;
