import { useState, useEffect } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { airtableService } from "@/services/airtableService";
import { api } from "@/lib/api";
import { adminService } from "@/services/adminService";
import { formatFieldsForAirtable } from "@/services/airtableUtils";

// Import refactored components
import AirtableSyncHeader from "./airtable/AirtableSyncHeader";
import AirtableSyncErrors from "./airtable/AirtableSyncErrors";
import AirtableDebugInfo from "./airtable/AirtableDebugInfo";
import AirtableSyncControls from "./airtable/AirtableSyncControls";
import AirtableSyncButtons from "./airtable/AirtableSyncButtons";
import AirtableSyncLogs from "./airtable/AirtableSyncLogs";
import AirtableConfigSummary from "./airtable/AirtableConfigSummary";
import AirtableTroubleshooting from "./airtable/AirtableTroubleshooting";
import AirtableNotConfigured from "./airtable/AirtableNotConfigured";
import { TableMapping } from "@/services/airtableConfig";

interface AirtableSyncProps {
  tableType?: string;
}

const AirtableSync: React.FC<AirtableSyncProps> = ({ tableType }) => {
  const [isSyncingLeads, setIsSyncingLeads] = useState(false);
  const [isSyncingProducts, setIsSyncingProducts] = useState(false);
  const [isSyncingOrders, setIsSyncingOrders] = useState(false);
  const [syncErrors, setSyncErrors] = useState<{[key: string]: string}>({});
  const [showDebugInfo, setShowDebugInfo] = useState(false);
  const [showDetailedLogs, setShowDetailedLogs] = useState(false);
  const [syncLogs, setSyncLogs] = useState<string[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<{
    checked: boolean;
    success: boolean;
    message: string;
    details?: any;
  }>({ checked: false, success: false, message: "" });
  
  const isInitialized = airtableService.isInitialized();
  const tableMapping = airtableService.getTableMapping();
  
  // Validate Airtable connection on component mount
  useEffect(() => {
    if (isInitialized) {
      validateConnection();
      
      // Also check for any existing sync errors in the service
      const existingErrors = airtableService.getLastSyncError();
      if (existingErrors && typeof existingErrors === 'object') {
        setSyncErrors(existingErrors);
      }
      
      // If a specific tableType is provided, add a log entry
      if (tableType) {
        addLog(`Viewing configuration for table type: ${tableType}`);
      }
    }
  }, [isInitialized, tableType]);

  // Add a log entry
  const addLog = (message: string) => {
    setSyncLogs(prev => [
      `[${new Date().toLocaleTimeString()}] ${message}`, 
      ...prev.slice(0, 19)
    ]);
  };

  // Validate the Airtable connection
  const validateConnection = async () => {
    try {
      addLog("Testing Airtable connection...");
      const result = await airtableService.validateConnection();
      setConnectionStatus({
        checked: true,
        success: result.success,
        message: result.message,
        details: result.details
      });
      
      addLog(`Connection test result: ${result.success ? 'Success' : 'Failed'} - ${result.message}`);
      
      if (!result.success) {
        setSyncErrors(prev => ({
          ...prev, 
          connection: `Connection issue: ${result.message}`
        }));
      } else {
        // Clear connection error if validation succeeds
        setSyncErrors(prev => {
          const newErrors = {...prev};
          delete newErrors.connection;
          return newErrors;
        });
      }
    } catch (error) {
      console.error("Error validating connection:", error);
      addLog(`Connection test error: ${error instanceof Error ? error.message : 'Unknown error'}`);
      setConnectionStatus({
        checked: true,
        success: false,
        message: "Failed to validate connection",
      });
      setSyncErrors(prev => ({
        ...prev, 
        connection: "Failed to validate connection"
      }));
    }
  };
  
  // Clear error for a specific type
  const clearError = (type: string) => {
    setSyncErrors(prev => {
      const newErrors = {...prev};
      delete newErrors[type];
      return newErrors;
    });
  };
  
  // Handler for syncing leads
  const handleSyncLeads = async () => {
    if (!isInitialized || !tableMapping.leads) {
      const errorMsg = "Leads table not configured in Airtable settings";
      toast.error(errorMsg);
      setSyncErrors(prev => ({...prev, leads: errorMsg}));
      return;
    }
    
    clearError('leads');
    setIsSyncingLeads(true);
    try {
      addLog("Fetching leads from API...");
      const leads = await api.getLeads();
      addLog(`Fetched ${leads.length} leads, now syncing to Airtable...`);
      
      // Simplified approach - just attempt the sync directly
      addLog(`Attempting to sync leads to table '${tableMapping.leads}'...`);
      
      const result = await airtableService.syncLeads(leads);
      
      if (result.success) {
        addLog(`Successfully synced ${leads.length} leads to Airtable`);
        toast.success(`Successfully synced ${leads.length} leads to Airtable`);
        
        // If there were computed fields detected, update the UI to show this info
        if (result.computedFields && result.computedFields.length > 0) {
          addLog(`Detected ${result.computedFields.length} computed fields that were skipped during sync`);
        }
      } else {
        const errorMsg = "Failed to sync leads to Airtable";
        addLog(`Error: ${errorMsg}`);
        toast.error(errorMsg);
        
        // Check if there's a specific error stored in the service
        const specificError = airtableService.getLastSyncError('leads');
        setSyncErrors(prev => ({
          ...prev, 
          leads: typeof specificError === 'string' 
            ? specificError 
            : `${errorMsg}. Check console for details.`
        }));
      }
    } catch (error) {
      console.error("Error syncing leads:", error);
      const errorMsg = `Error: ${error instanceof Error ? error.message : "Unknown error"}`;
      addLog(`Sync failed: ${errorMsg}`);
      toast.error("Failed to sync leads to Airtable");
      setSyncErrors(prev => ({...prev, leads: errorMsg}));
    } finally {
      setIsSyncingLeads(false);
    }
  };
  
  // Handler for syncing products
  const handleSyncProducts = async () => {
    if (!isInitialized || !tableMapping.products) {
      const errorMsg = "Products table not configured in Airtable settings";
      toast.error(errorMsg);
      setSyncErrors(prev => ({...prev, products: errorMsg}));
      return;
    }
    
    clearError('products');
    setIsSyncingProducts(true);
    try {
      addLog("Fetching products from API...");
      const products = await api.getProducts();
      addLog(`Fetched ${products.length} products from API`);
      
      // First validate the table exists (no structure validation)
      addLog(`Validating Airtable table '${tableMapping.products}'...`);
      const validationResult = await airtableService.validateTableExists(tableMapping.products);
      
      if (!validationResult.success) {
        throw new Error(`Table validation failed: ${validationResult.message}`);
      }
      
      // For admin products, also include any edited products
      try {
        const adminProducts = await adminService.getAdminProducts();
        if (adminProducts && adminProducts.length > 0) {
          // Replace any existing products with admin edited versions
          for (const adminProduct of adminProducts) {
            const index = products.findIndex(p => p.id === adminProduct.id);
            if (index >= 0) {
              products[index] = adminProduct;
            } else {
              products.push(adminProduct);
            }
          }
          addLog(`Added ${adminProducts.length} admin-edited products to sync`);
        }
      } catch (adminError) {
        console.error("Error fetching admin products:", adminError);
        addLog(`Warning: Could not fetch admin products: ${adminError instanceof Error ? adminError.message : 'Unknown error'}`);
      }
      
      // Format products for Airtable - properly handling image attachments
      addLog("Formatting products for Airtable...");
      const formattedProducts = products.map(product => {
        const formattedFields = formatFieldsForAirtable('products', product);
        addLog(`Prepared product ${product.id} with properly formatted fields`);
        return { fields: formattedFields };
      });
      
      addLog(`Syncing ${products.length} total products to Airtable...`);
      const success = await airtableService.syncProducts(products);
      
      if (success) {
        addLog(`Successfully synced ${products.length} products to Airtable`);
        toast.success(`Successfully synced ${products.length} products to Airtable`);
      } else {
        const errorMsg = "Failed to sync products to Airtable";
        addLog(`Error: ${errorMsg}`);
        toast.error(errorMsg);
        
        // Check if there's a specific error stored in the service
        const specificError = airtableService.getLastSyncError('products');
        setSyncErrors(prev => ({
          ...prev, 
          products: typeof specificError === 'string'
            ? specificError
            : `${errorMsg}. Check console for details.`
        }));
      }
    } catch (error) {
      console.error("Error syncing products:", error);
      const errorMsg = `Error: ${error instanceof Error ? error.message : "Unknown error"}`;
      addLog(`Sync failed: ${errorMsg}`);
      toast.error("Failed to sync products to Airtable");
      setSyncErrors(prev => ({...prev, products: errorMsg}));
    } finally {
      setIsSyncingProducts(false);
    }
  };
  
  // Handler for syncing orders
  const handleSyncOrders = async () => {
    if (!isInitialized || !tableMapping.orders) {
      const errorMsg = "Orders table not configured in Airtable settings";
      toast.error(errorMsg);
      setSyncErrors(prev => ({...prev, orders: errorMsg}));
      return;
    }
    
    clearError('orders');
    setIsSyncingOrders(true);
    try {
      addLog("Fetching orders from API...");
      const orders = await api.getOrders();
      addLog(`Fetched ${orders.length} orders, now syncing to Airtable...`);
      
      // First validate the table exists (no structure validation)
      addLog(`Validating Airtable table '${tableMapping.orders}'...`);
      const validationResult = await airtableService.validateTableExists(tableMapping.orders);
      
      if (!validationResult.success) {
        throw new Error(`Table validation failed: ${validationResult.message}`);
      }
      
      addLog("Table exists, proceeding with sync...");
      const success = await airtableService.syncOrders(orders);
      
      if (success) {
        addLog(`Successfully synced ${orders.length} orders to Airtable`);
        toast.success(`Successfully synced ${orders.length} orders to Airtable`);
      } else {
        const errorMsg = "Failed to sync orders to Airtable";
        addLog(`Error: ${errorMsg}`);
        toast.error(errorMsg);
        
        // Check if there's a specific error stored in the service
        const specificError = airtableService.getLastSyncError('orders');
        setSyncErrors(prev => ({
          ...prev, 
          orders: typeof specificError === 'string'
            ? specificError
            : `${errorMsg}. Check console for details.`
        }));
      }
    } catch (error) {
      console.error("Error syncing orders:", error);
      const errorMsg = `Error: ${error instanceof Error ? error.message : "Unknown error"}`;
      addLog(`Sync failed: ${errorMsg}`);
      toast.error("Failed to sync orders to Airtable");
      setSyncErrors(prev => ({...prev, orders: errorMsg}));
    } finally {
      setIsSyncingOrders(false);
    }
  };
  
  // Handler for syncing all data
  const handleSyncAll = async () => {
    toast.info("Starting full data sync...");
    setSyncErrors({});
    addLog("Starting full data sync operation");
    
    // Sync leads
    if (tableMapping.leads) {
      await handleSyncLeads();
    }
    
    // Sync products
    if (tableMapping.products) {
      await handleSyncProducts();
    }
    
    // Sync orders
    if (tableMapping.orders) {
      await handleSyncOrders();
    }
    
    addLog("Full data sync completed");
    toast.success("Full data sync completed");
  };
  
  const toggleDebugInfo = () => setShowDebugInfo(!showDebugInfo);
  const toggleDetailedLogs = () => setShowDetailedLogs(!showDetailedLogs);

  // If we have a tableType, focus the UI on just that table type
  const focusedTable = tableType || null;

  if (!isInitialized) {
    return (
      <Card>
        <CardHeader>
          <AirtableSyncHeader 
            connectionStatus={{ checked: false, success: false, message: "Not configured" }} 
          />
        </CardHeader>
        <CardContent>
          <AirtableNotConfigured 
            showDebugInfo={showDebugInfo} 
            toggleDebugInfo={toggleDebugInfo} 
          />
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <AirtableSyncHeader 
          connectionStatus={connectionStatus} 
          tableType={focusedTable}
        />
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <AirtableSyncErrors 
            syncErrors={focusedTable ? 
              (syncErrors[focusedTable] ? { [focusedTable]: syncErrors[focusedTable] } : {}) : 
              syncErrors} 
          />
          
          <AirtableDebugInfo showDebugInfo={showDebugInfo} />
          
          {!focusedTable && (
            <AirtableSyncControls 
              handleSyncAll={handleSyncAll}
              connectionSuccess={connectionStatus.success}
              toggleLogs={toggleDetailedLogs}
              toggleDebugInfo={toggleDebugInfo}
            />
          )}
          
          <AirtableSyncButtons 
            tableMapping={tableMapping}
            isSyncingLeads={isSyncingLeads}
            isSyncingProducts={isSyncingProducts}
            isSyncingOrders={isSyncingOrders}
            syncErrors={syncErrors}
            connectionSuccess={connectionStatus.success}
            handleSyncLeads={handleSyncLeads}
            handleSyncProducts={handleSyncProducts}
            handleSyncOrders={handleSyncOrders}
            focusedTable={focusedTable}
          />
          
          <AirtableSyncLogs 
            showDetailedLogs={showDetailedLogs || !!focusedTable}
            syncLogs={syncLogs}
          />
          
          <AirtableConfigSummary 
            tableMapping={tableMapping as Record<string, string>} 
            focusedTable={focusedTable}
          />
          
          <AirtableTroubleshooting 
            showTroubleshooting={Object.keys(syncErrors).length > 0 || showDetailedLogs} 
          />
          
          <div className="text-center text-xs text-muted-foreground pt-2">
            <Button 
              variant="link" 
              size="sm" 
              className="h-auto p-0 text-xs" 
              onClick={validateConnection}
            >
              Validate Connection
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AirtableSync;
