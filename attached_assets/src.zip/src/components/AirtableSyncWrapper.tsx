
import React from 'react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Database } from "lucide-react";

interface AirtableSyncWrapperProps {
  tableType: string;
}

// This is a compatibility component that has been updated to work with Supabase
// instead of Airtable. It simply shows a message that we've migrated to Supabase.
const AirtableSyncWrapper: React.FC<AirtableSyncWrapperProps> = ({ tableType }) => {
  return (
    <Alert>
      <Database className="h-4 w-4" />
      <AlertTitle>Data Sync Updated</AlertTitle>
      <AlertDescription>
        We've migrated from Airtable to Supabase for better data management. 
        Your {tableType} data is now being stored securely in Supabase.
      </AlertDescription>
    </Alert>
  );
};

export default AirtableSyncWrapper;
