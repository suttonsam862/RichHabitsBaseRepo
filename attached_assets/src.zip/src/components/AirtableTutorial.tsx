
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronRight, ExternalLink, FileText, Key, Database, Table } from "lucide-react";

const AirtableTutorial = () => {
  const [expandedSection, setExpandedSection] = useState<string | null>("getToken");

  const toggleSection = (section: string) => {
    if (expandedSection === section) {
      setExpandedSection(null);
    } else {
      setExpandedSection(section);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Airtable Sync Tutorial</CardTitle>
        <CardDescription>
          Learn how to set up and use the Airtable integration
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <Tabs defaultValue="setup">
          <TabsList className="mb-4">
            <TabsTrigger value="setup">Setup Guide</TabsTrigger>
            <TabsTrigger value="usage">Usage Guide</TabsTrigger>
            <TabsTrigger value="troubleshooting">Troubleshooting</TabsTrigger>
          </TabsList>
          
          <TabsContent value="setup" className="space-y-4">
            <div>
              <div 
                className="flex items-center justify-between cursor-pointer px-4 py-2 bg-muted rounded-md hover:bg-muted/80 transition-colors"
                onClick={() => toggleSection("getToken")}
              >
                <div className="flex items-center gap-2">
                  <Key size={16} />
                  <h3 className="font-medium">1. Get your Personal Access Token</h3>
                </div>
                {expandedSection === "getToken" ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
              </div>
              
              {expandedSection === "getToken" && (
                <div className="mt-2 ml-6 p-4 border rounded-md space-y-2">
                  <p className="text-sm">To connect to Airtable, you'll need a Personal Access Token:</p>
                  <ol className="list-decimal list-inside text-sm space-y-2">
                    <li>Log in to your Airtable account</li>
                    <li>Go to your <a href="https://airtable.com/account" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline inline-flex items-center">Account page <ExternalLink size={12} className="ml-1" /></a></li>
                    <li>Click on "Developer Hub" in the sidebar</li>
                    <li>Under "Personal access tokens", click "Create new token"</li>
                    <li>Name your token (e.g., "SportSales Integration")</li>
                    <li>Set the appropriate scopes: data.records:read, data.records:write</li>
                    <li>Click "Create token" and copy the generated token</li>
                  </ol>
                  <div className="mt-2 p-2 bg-muted/50 rounded text-xs font-mono border">
                    Note: The token will only be shown once. Make sure to copy it immediately.
                  </div>
                </div>
              )}
            </div>
            
            <div>
              <div 
                className="flex items-center justify-between cursor-pointer px-4 py-2 bg-muted rounded-md hover:bg-muted/80 transition-colors"
                onClick={() => toggleSection("getBaseId")}
              >
                <div className="flex items-center gap-2">
                  <Database size={16} />
                  <h3 className="font-medium">2. Find your Base ID</h3>
                </div>
                {expandedSection === "getBaseId" ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
              </div>
              
              {expandedSection === "getBaseId" && (
                <div className="mt-2 ml-6 p-4 border rounded-md space-y-2">
                  <p className="text-sm">To identify which Airtable base to connect to:</p>
                  <ol className="list-decimal list-inside text-sm space-y-2">
                    <li>Open the Airtable base you want to use</li>
                    <li>Look at the URL in your browser, it will look like:<br/> <code className="text-xs bg-muted/50 p-1 rounded">https://airtable.com/<span className="text-primary font-bold">appXXXXXXXXXXXXXX</span>/tblYYYYYYYYYYYYYY/viwZZZZZZZZZZZZZZ</code></li>
                    <li>The Base ID is the part that starts with "app" (highlighted above)</li>
                    <li>Copy this ID to use in your integration settings</li>
                  </ol>
                </div>
              )}
            </div>
            
            <div>
              <div 
                className="flex items-center justify-between cursor-pointer px-4 py-2 bg-muted rounded-md hover:bg-muted/80 transition-colors"
                onClick={() => toggleSection("setupTables")}
              >
                <div className="flex items-center gap-2">
                  <Table size={16} />
                  <h3 className="font-medium">3. Set up your Airtable Tables</h3>
                </div>
                {expandedSection === "setupTables" ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
              </div>
              
              {expandedSection === "setupTables" && (
                <div className="mt-2 ml-6 p-4 border rounded-md space-y-4">
                  <p className="text-sm">Create tables in your Airtable base to match the data structure:</p>
                  
                  <div>
                    <h4 className="text-sm font-bold">Leads Table</h4>
                    <p className="text-xs text-muted-foreground">Recommended fields:</p>
                    <ul className="list-disc list-inside text-xs ml-2 space-y-1">
                      <li>Name (Single line text)</li>
                      <li>Email (Email)</li>
                      <li>Phone (Phone number)</li>
                      <li>Company (Single line text)</li>
                      <li>Status (Single select: new, contacted, qualified, proposal, negotiation, converted, lost)</li>
                      <li>Source (Single select)</li>
                      <li>Notes (Long text)</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-bold">Products Table</h4>
                    <p className="text-xs text-muted-foreground">Recommended fields:</p>
                    <ul className="list-disc list-inside text-xs ml-2 space-y-1">
                      <li>Product ID (Single line text)</li>
                      <li>Name (Single line text)</li>
                      <li>Description (Long text)</li>
                      <li>Category (Single select)</li>
                      <li>Price (Currency)</li>
                      <li>Cost (Currency)</li>
                      <li>Inventory (Number)</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-bold">Orders Table</h4>
                    <p className="text-xs text-muted-foreground">Recommended fields:</p>
                    <ul className="list-disc list-inside text-xs ml-2 space-y-1">
                      <li>Order ID (Single line text)</li>
                      <li>Customer (Single line text)</li>
                      <li>Email (Email)</li>
                      <li>Date (Date)</li>
                      <li>Status (Single select: pending, processing, shipped, delivered, cancelled)</li>
                      <li>Total (Currency)</li>
                      <li>Items (Long text - JSON or linked records)</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-bold">Statistics Table</h4>
                    <p className="text-xs text-muted-foreground">Recommended fields:</p>
                    <ul className="list-disc list-inside text-xs ml-2 space-y-1">
                      <li>Date (Date)</li>
                      <li>Sales (Currency)</li>
                      <li>Orders (Number)</li>
                      <li>New Customers (Number)</li>
                      <li>Conversion Rate (Percent)</li>
                      <li>Average Order Value (Currency)</li>
                    </ul>
                  </div>
                  
                  <div className="mt-2 p-2 bg-muted/50 rounded text-xs">
                    <p className="font-medium">Tip:</p>
                    <p>You can customize these table structures to match your specific business needs. Just make sure to update the field mappings in the synchronization code if you make significant changes.</p>
                  </div>
                </div>
              )}
            </div>
            
            <div className="text-center mt-4">
              <Button asChild variant="outline">
                <a href="/settings" className="inline-flex items-center">
                  <FileText className="mr-2 h-4 w-4" /> 
                  Go to Settings to Configure Airtable
                </a>
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="usage" className="space-y-4">
            <div>
              <div 
                className="flex items-center justify-between cursor-pointer px-4 py-2 bg-muted rounded-md hover:bg-muted/80 transition-colors"
                onClick={() => toggleSection("syncData")}
              >
                <div className="flex items-center gap-2">
                  <Database size={16} />
                  <h3 className="font-medium">Syncing Data with Airtable</h3>
                </div>
                {expandedSection === "syncData" ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
              </div>
              
              {expandedSection === "syncData" && (
                <div className="mt-2 ml-6 p-4 border rounded-md space-y-2">
                  <p className="text-sm">Once you've configured your Airtable connection in Settings, you can sync data in two ways:</p>
                  
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">1. From the Dashboard</h4>
                    <p className="text-xs">Use the Airtable Sync component on your dashboard:</p>
                    <ul className="list-disc list-inside text-xs ml-2">
                      <li><strong>Sync All Data</strong>: Push all data types to Airtable at once</li>
                      <li><strong>Sync Leads</strong>: Only push leads data</li>
                      <li><strong>Sync Products</strong>: Only push product catalog data</li>
                      <li><strong>Sync Orders</strong>: Only push order data</li>
                    </ul>
                    <p className="text-xs mt-2">The sync process creates new records or updates existing ones in Airtable.</p>
                  </div>
                  
                  <div className="space-y-2 mt-4">
                    <h4 className="text-sm font-medium">2. Automated Syncing</h4>
                    <p className="text-xs">Schedule regular syncs to keep your Airtable data current:</p>
                    <ul className="list-disc list-inside text-xs ml-2">
                      <li>Set up a recurring task to sync data at specific intervals</li>
                      <li>Use webhooks to trigger syncs when data changes</li>
                      <li>Configure sync preferences in the Settings page</li>
                    </ul>
                  </div>
                  
                  <div className="mt-4 p-2 bg-muted/50 rounded text-xs">
                    <p className="font-medium">Best Practices:</p>
                    <ul className="list-disc list-inside text-xs ml-2">
                      <li>Sync during off-peak hours to minimize performance impact</li>
                      <li>Verify sync results by checking Airtable directly</li>
                      <li>Set up field mappings carefully to ensure data integrity</li>
                    </ul>
                  </div>
                </div>
              )}
            </div>
            
            <div className="text-center mt-4">
              <Button asChild variant="outline" className="mr-2">
                <a href="/" className="inline-flex items-center">
                  <Database className="mr-2 h-4 w-4" /> 
                  Go to Dashboard
                </a>
              </Button>
              <Button asChild variant="outline">
                <a href="/settings" className="inline-flex items-center">
                  <FileText className="mr-2 h-4 w-4" /> 
                  Go to Settings
                </a>
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="troubleshooting" className="space-y-4">
            <div className="space-y-4">
              <div className="p-4 border rounded-md">
                <h3 className="font-medium mb-2">Common Issues</h3>
                <div className="space-y-3">
                  <div>
                    <h4 className="text-sm font-medium">Authentication Errors</h4>
                    <p className="text-xs">If you see "Failed to connect to Airtable" messages:</p>
                    <ul className="list-disc list-inside text-xs ml-2">
                      <li>Verify your Personal Access Token is correct</li>
                      <li>Check that the token hasn't expired</li>
                      <li>Ensure the token has the right permission scopes</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium">Sync Failures</h4>
                    <p className="text-xs">If data isn't syncing properly:</p>
                    <ul className="list-disc list-inside text-xs ml-2">
                      <li>Confirm your Base ID is correct</li>
                      <li>Verify table names match exactly what's in Airtable</li>
                      <li>Check that your Airtable tables have the correct fields</li>
                      <li>Look for any API rate limiting messages</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium">Data Mapping Issues</h4>
                    <p className="text-xs">If data appears incorrectly in Airtable:</p>
                    <ul className="list-disc list-inside text-xs ml-2">
                      <li>Review field names and types in your Airtable base</li>
                      <li>Check for any data format mismatches</li>
                      <li>Verify that required fields aren't missing</li>
                    </ul>
                  </div>
                </div>
              </div>
              
              <div className="p-4 border rounded-md">
                <h3 className="font-medium mb-2">Getting Help</h3>
                <p className="text-sm">If you continue to experience issues:</p>
                <ul className="list-disc list-inside text-sm ml-2">
                  <li>Check the <a href="https://airtable.com/developers/web/api" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline inline-flex items-center">Airtable API documentation <ExternalLink size={12} className="ml-1" /></a></li>
                  <li>Visit our support portal for additional guidance</li>
                  <li>Contact the admin team for assistance</li>
                </ul>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default AirtableTutorial;
