import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DashboardStats } from "@/lib/api";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { DollarSign, ShoppingBag, FileText, UsersRound, TrendingUp } from "lucide-react";

interface DashboardMetricsProps {
  stats: DashboardStats | null;
  isLoading: boolean;
}

const DashboardMetrics = ({ stats, isLoading }: DashboardMetricsProps) => {
  const [chartData, setChartData] = useState<{name: string; value: number}[]>([]);
  const [orderStatusData, setOrderStatusData] = useState<{name: string; value: number}[]>([]);
  const [kpiData, setKpiData] = useState<any>({
    totalRevenue: 0,
    averageOrderValue: 0,
    conversionRate: 0,
    repeatCustomers: 0
  });

  useEffect(() => {
    if (stats) {
      // Format sales performance chart data
      const data = stats.salesPerformance.labels.map((month, index) => ({
        name: month,
        value: stats.salesPerformance.data[index]
      }));
      setChartData(data);
      
      // Convert to number to ensure we're working with numerical values
      const openOrdersCount = typeof stats.openOrders === 'number' 
        ? stats.openOrders 
        : (Array.isArray(stats.openOrders) ? stats.openOrders.length : 0);
      
      const pendingDesignsCount = typeof stats.pendingDesigns === 'number'
        ? stats.pendingDesigns
        : 0;
        
      // Generate mock data for order status
      setOrderStatusData([
        { name: 'Draft', value: Math.floor(openOrdersCount * 0.2) },
        { name: 'Submitted', value: Math.floor(openOrdersCount * 0.3) },
        { name: 'Design', value: pendingDesignsCount },
        { name: 'Manufacturing', value: Math.floor(openOrdersCount * 0.25) },
        { name: 'Completed', value: Math.floor(openOrdersCount * 0.15) }
      ]);
      
      // Calculate KPIs
      const totalSales = typeof stats.totalSales === 'number' ? stats.totalSales : 0;
      
      setKpiData({
        totalRevenue: totalSales,
        averageOrderValue: openOrdersCount > 0 ? Math.round(totalSales / (openOrdersCount + 20)) : 0,
        conversionRate: 24, // Mock conversion rate
        repeatCustomers: 32 // Mock repeat customers
      });
    }
  }, [stats]);

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardHeader className="pb-2">
              <Skeleton className="h-4 w-24" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-16" />
            </CardContent>
          </Card>
        ))}
        <Card className="col-span-1 md:col-span-2 lg:col-span-4">
          <CardHeader>
            <Skeleton className="h-5 w-32" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-[200px] w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!stats) {
    return null;
  }

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Revenue
            </CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${kpiData.totalRevenue.toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground mt-1 flex items-center">
              <TrendingUp className="h-3 w-3 mr-1 text-green-500" />
              12% increase from last month
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Open Orders
            </CardTitle>
            <ShoppingBag className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {typeof stats.openOrders === 'number' 
                ? stats.openOrders 
                : Array.isArray(stats.openOrders) ? stats.openOrders.length : 0}
            </div>
            <div className="flex gap-1 mt-1">
              <Badge variant="outline" className="bg-blue-50 text-blue-700 text-xs">
                {orderStatusData[1]?.value} Submitted
              </Badge>
              <Badge variant="outline" className="bg-purple-50 text-purple-700 text-xs">
                {orderStatusData[2]?.value} Design
              </Badge>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Conversion Rate
            </CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{kpiData.conversionRate}%</div>
            <p className="text-xs text-muted-foreground mt-1">
              Of leads converted to orders
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              New Leads
            </CardTitle>
            <UsersRound className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stats.newLeads 
                ? (typeof stats.newLeads === 'number' ? stats.newLeads : stats.newLeads.length) 
                : 0}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {stats.newLeads 
                ? Math.floor((typeof stats.newLeads === 'number' ? stats.newLeads : stats.newLeads.length) * 0.25) 
                : 0} need attention
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-4">
        <Card className="col-span-1 xl:col-span-3">
          <CardHeader>
            <CardTitle>Monthly Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={chartData}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value) => [`$${value}`, 'Revenue']}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="value" 
                    stroke="#3B82F6" 
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top Products</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stats.topProducts.map((product, index) => (
                <div key={index} className="flex justify-between items-center">
                  <div className="flex-1">
                    <div className="text-sm font-medium truncate">{product.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {Math.floor(product.sales / kpiData.averageOrderValue)} units
                    </div>
                  </div>
                  <span className="text-sm font-medium">
                    ${product.sales.toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
};

export default DashboardMetrics;
