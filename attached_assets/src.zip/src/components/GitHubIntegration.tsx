
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { toast } from 'sonner';
import { Github, RefreshCw, Check, X, Database, ArrowUpDown } from 'lucide-react';
import { githubService, GitHubConnection, GitHubRepository } from '@/services/githubService';
import { Skeleton } from '@/components/ui/skeleton';

const GitHubIntegration = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [connection, setConnection] = useState<GitHubConnection | null>(null);
  const [repositories, setRepositories] = useState<GitHubRepository[]>([]);
  const [selectedRepo, setSelectedRepo] = useState<string>('');
  const [lastSynced, setLastSynced] = useState<string | null>(null);

  // Load GitHub connection on component mount
  useEffect(() => {
    const loadConnection = async () => {
      setIsLoading(true);
      try {
        const conn = await githubService.getConnection();
        setConnection(conn);
        
        if (conn?.repositories && conn.repositories.length > 0) {
          setRepositories(conn.repositories);
          setSelectedRepo(conn.selected_repository || conn.repositories[0].full_name);
        } else if (conn) {
          await fetchRepositories();
        }
        
        setLastSynced(conn?.last_synced_at || null);
      } catch (error) {
        console.error("Error loading GitHub connection:", error);
        toast.error("Failed to load GitHub connection");
      } finally {
        setIsLoading(false);
      }
    };
    
    loadConnection();
  }, []);

  const fetchRepositories = async () => {
    try {
      const repos = await githubService.fetchRepositories();
      setRepositories(repos);
      
      if (repos.length > 0 && !selectedRepo) {
        setSelectedRepo(repos[0].full_name);
      }
      
      return repos;
    } catch (error) {
      console.error("Error fetching repositories:", error);
      toast.error("Failed to fetch GitHub repositories");
      return [];
    }
  };

  const handleSync = async () => {
    if (!selectedRepo) {
      toast.error("Please select a repository first");
      return;
    }
    
    setIsSyncing(true);
    try {
      const success = await githubService.syncAllDataToGitHub(selectedRepo.split('/')[1]);
      
      if (success) {
        setLastSynced(new Date().toISOString());
        toast.success("Data successfully synced to GitHub");
      } else {
        toast.error("Failed to sync some data to GitHub");
      }
    } catch (error) {
      console.error("Error syncing data to GitHub:", error);
      toast.error("Failed to sync data to GitHub");
    } finally {
      setIsSyncing(false);
    }
  };

  const handleDisconnect = async () => {
    try {
      const success = await githubService.disconnect();
      if (success) {
        setConnection(null);
        setRepositories([]);
        setSelectedRepo('');
        toast.success("Disconnected from GitHub");
      }
    } catch (error) {
      console.error("Error disconnecting from GitHub:", error);
      toast.error("Failed to disconnect from GitHub");
    }
  };

  const handleRepositoryChange = (value: string) => {
    setSelectedRepo(value);
  };

  // Show loading skeleton
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-8 w-3/4" />
          <Skeleton className="h-4 w-1/2" />
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-24 w-full" />
        </CardContent>
        <CardFooter>
          <Skeleton className="h-10 w-1/3" />
        </CardFooter>
      </Card>
    );
  }

  // Not connected state
  if (!connection) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Github className="mr-2 h-5 w-5" />
            GitHub Integration
          </CardTitle>
          <CardDescription>
            Connect to GitHub to sync and backup your data
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Alert className="mb-4">
            <AlertTitle>Not Connected</AlertTitle>
            <AlertDescription>
              You need to connect to GitHub to use this feature. This allows you to backup and sync your data to a GitHub repository.
            </AlertDescription>
          </Alert>
          <p className="text-sm text-muted-foreground mb-4">
            After connecting, you'll be able to select a repository to sync your data with.
          </p>
          <p className="text-sm font-medium">Authorization completed!</p>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" disabled>Already Authorized</Button>
          <Button onClick={() => toast.info("GitHub integration ready to use")}>
            Continue
          </Button>
        </CardFooter>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Github className="mr-2 h-5 w-5" />
          GitHub Integration
        </CardTitle>
        <CardDescription>
          Connected as {connection.github_username}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium">Connection Status</p>
            <div className="flex items-center mt-1">
              {connection.sync_status === 'active' ? (
                <>
                  <Check className="h-4 w-4 text-green-500 mr-1" />
                  <span className="text-sm text-green-500">Connected</span>
                </>
              ) : (
                <>
                  <X className="h-4 w-4 text-red-500 mr-1" />
                  <span className="text-sm text-red-500">
                    {connection.sync_status === 'error' ? 'Error' : 'Paused'}
                  </span>
                </>
              )}
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={handleDisconnect}>
            Disconnect
          </Button>
        </div>

        <div>
          <p className="text-sm font-medium mb-2">Select Repository</p>
          <Select value={selectedRepo} onValueChange={handleRepositoryChange}>
            <SelectTrigger>
              <SelectValue placeholder="Select a repository" />
            </SelectTrigger>
            <SelectContent>
              {repositories.map((repo) => (
                <SelectItem key={repo.id} value={repo.full_name}>
                  {repo.full_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <p className="text-sm font-medium">Data Sync Information</p>
          <div className="text-sm text-muted-foreground mt-1">
            {lastSynced ? (
              <p>Last synced: {new Date(lastSynced).toLocaleString()}</p>
            ) : (
              <p>Not yet synced</p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          <Button 
            variant="outline" 
            onClick={fetchRepositories}
            disabled={isSyncing}
            className="flex items-center"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh Repos
          </Button>
          
          <Button 
            onClick={handleSync} 
            disabled={isSyncing || !selectedRepo}
            className="flex items-center"
          >
            <Database className="h-4 w-4 mr-2" />
            {isSyncing ? 'Syncing...' : 'Sync Data'}
          </Button>
        </div>
      </CardContent>
      <CardFooter>
        <p className="text-xs text-muted-foreground">
          This will create or update JSON files in your repository with the latest data from your application.
        </p>
      </CardFooter>
    </Card>
  );
};

export default GitHubIntegration;
