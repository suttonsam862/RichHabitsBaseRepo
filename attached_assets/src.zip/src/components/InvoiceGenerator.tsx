
import { useState } from "react";
import { Order } from "@/lib/api";
import { generateInvoicePDF } from "@/utils/pdfUtils";
import { quickbooksService } from "@/services/quickbooksService";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";

interface InvoiceGeneratorProps {
  order: Order;
  isOpen: boolean;
  onClose: () => void;
}

const InvoiceGenerator = ({ order, isOpen, onClose }: InvoiceGeneratorProps) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [invoiceNumber, setInvoiceNumber] = useState(`INV-${order.id.replace(/\D/g, '')}`);
  const [syncToQuickBooks, setSyncToQuickBooks] = useState(false);
  const [quickBooksConnected, setQuickBooksConnected] = useState(false);
  
  // In a real app, you'd check if QuickBooks is already connected
  const handleConnectQuickBooks = () => {
    // This would typically open OAuth flow for QuickBooks
    toast.success("Successfully connected to QuickBooks.");
    setQuickBooksConnected(true);
  };
  
  const handleGenerateInvoice = async () => {
    setIsGenerating(true);
    
    try {
      // Generate PDF
      const doc = generateInvoicePDF(order, invoiceNumber);
      
      // If sync to QuickBooks is enabled
      if (syncToQuickBooks && quickBooksConnected) {
        try {
          // In a real application, you would have configured QuickBooks earlier
          // Here we're simulating the configuration
          const config = {
            consumerKey: "your-consumer-key",
            consumerSecret: "your-consumer-secret",
            realmId: "your-realm-id",
            oauthToken: "your-oauth-token",
            oauthTokenSecret: "your-oauth-token-secret",
            useSandbox: true
          };
          
          quickbooksService.initialize(config);
          if (quickbooksService.instance) {
            await quickbooksService.instance.createInvoice(order, invoiceNumber);
          }
          
          toast.success("Invoice synced to QuickBooks successfully.");
        } catch (error) {
          console.error("Failed to sync to QuickBooks:", error);
          toast.error("Failed to sync invoice to QuickBooks. Please try again.");
        }
      }
      
      // Save PDF
      doc.save(`Invoice_${invoiceNumber}.pdf`);
      
      toast.success("Invoice generated successfully.");
      
      // Close dialog
      onClose();
    } catch (error) {
      console.error("Error generating invoice:", error);
      toast.error("Failed to generate invoice. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Generate Invoice</DialogTitle>
          <DialogDescription>
            Create a new invoice for order {order.id}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="invoiceNumber" className="text-right">
              Invoice #
            </Label>
            <Input
              id="invoiceNumber"
              value={invoiceNumber}
              onChange={(e) => setInvoiceNumber(e.target.value)}
              className="col-span-3"
            />
          </div>
          
          <div className="grid grid-cols-4 items-center gap-4">
            <Label className="text-right">Customer</Label>
            <div className="col-span-3">
              <p className="text-sm">{order.customerName}</p>
            </div>
          </div>
          
          <div className="grid grid-cols-4 items-center gap-4">
            <Label className="text-right">Amount</Label>
            <div className="col-span-3">
              <p className="text-sm">${order.total.toFixed(2)}</p>
            </div>
          </div>
          
          <div className="grid grid-cols-4 items-center gap-4">
            <Label className="text-right">Date</Label>
            <div className="col-span-3">
              <p className="text-sm">{new Date().toLocaleDateString()}</p>
            </div>
          </div>
          
          <div className="border-t pt-4">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="syncQuickBooks"
                checked={syncToQuickBooks}
                onCheckedChange={(checked) => setSyncToQuickBooks(checked as boolean)}
              />
              <Label htmlFor="syncQuickBooks">Sync to QuickBooks</Label>
            </div>
            
            {syncToQuickBooks && !quickBooksConnected && (
              <Button
                variant="outline"
                onClick={handleConnectQuickBooks}
                className="mt-2"
                size="sm"
              >
                Connect to QuickBooks
              </Button>
            )}
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleGenerateInvoice} 
            disabled={isGenerating || (syncToQuickBooks && !quickBooksConnected)}
          >
            {isGenerating ? "Generating..." : "Generate Invoice"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default InvoiceGenerator;
