
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Organization, LeadStatus } from "@/services/baseService";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/custom/badge";
import { 
  ChevronRight, 
  Building2, 
  User, 
  Phone, 
  Mail, 
  Calendar,
  Clock,
  AlertTriangle
} from "lucide-react";

interface LeadCardProps {
  lead: {
    id: string;
    name: string;
    organization: string;
    email: string | null;
    phone: string | null;
    status: LeadStatus;
    notes: string | null;
    created_at?: string;
    dateCreated?: string;
  };
  organization?: Organization | null;
  onClick?: (id: string) => void;
  onConvertToOrder?: (id: string, organization: Organization | null) => void;
  isConverting?: boolean;
  conversionError?: boolean;
}

const LeadCard = ({
  lead,
  organization,
  onClick,
  onConvertToOrder,
  isConverting = false,
  conversionError = false
}: LeadCardProps) => {
  const [isHovered, setIsHovered] = useState(false);
  
  // Format the date - handle both date formats (Supabase and API)
  const createdDate = lead.created_at || lead.dateCreated || new Date().toISOString();
  const formattedDate = new Date(createdDate).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
  
  // Format the time
  const formattedTime = new Date(createdDate).toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit'
  });
  
  // Determine badge variant based on status
  const getBadgeVariant = (status: LeadStatus): "default" | "secondary" | "destructive" | "outline" | "success" => {
    switch (status) {
      case "prospect":
        return "default";
      case "discovery":
        return "secondary";
      case "qualified":
        return "success";
      case "negotiation":
        return "outline";
      case "closed-won":
        return "success";
      case "closed-lost":
        return "destructive";
      default:
        return "outline";
    }
  };

  return (
    <Card 
      className={`mb-4 transition-all duration-200 ${isHovered ? 'shadow-lg' : 'shadow'}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <CardTitle className="text-xl font-bold">{lead.name}</CardTitle>
          <Badge variant={getBadgeVariant(lead.status)}>
            {lead.status.charAt(0).toUpperCase() + lead.status.slice(1)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="flex items-center text-sm">
              <Building2 className="h-4 w-4 mr-2 text-muted-foreground" />
              <span className="font-medium">{lead.organization}</span>
            </div>
            
            {lead.email && (
              <div className="flex items-center text-sm">
                <Mail className="h-4 w-4 mr-2 text-muted-foreground" />
                <a href={`mailto:${lead.email}`} className="text-blue-600 hover:underline">
                  {lead.email}
                </a>
              </div>
            )}
            
            {lead.phone && (
              <div className="flex items-center text-sm">
                <Phone className="h-4 w-4 mr-2 text-muted-foreground" />
                <a href={`tel:${lead.phone}`} className="text-blue-600 hover:underline">
                  {lead.phone}
                </a>
              </div>
            )}
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center text-sm">
              <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
              <span>{formattedDate}</span>
            </div>
            
            <div className="flex items-center text-sm">
              <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
              <span>{formattedTime}</span>
            </div>
            
            {lead.notes && (
              <div className="text-sm mt-2">
                <p className="text-muted-foreground line-clamp-2">{lead.notes}</p>
              </div>
            )}
          </div>
        </div>
        
        <div className="flex justify-between items-center mt-4 pt-4 border-t">
          <div>
            {conversionError && (
              <div className="flex items-center text-red-500 text-sm">
                <AlertTriangle className="h-4 w-4 mr-1" />
                <span>Error converting lead</span>
              </div>
            )}
          </div>
          
          <div className="flex space-x-2">
            {onConvertToOrder && lead.status !== "closed-won" && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => onConvertToOrder(lead.id, organization || null)}
                disabled={isConverting}
              >
                {isConverting ? (
                  <>
                    <span className="mr-2">Converting...</span>
                  </>
                ) : (
                  'Convert to Order'
                )}
              </Button>
            )}
            
            {onClick && (
              <Button 
                variant="default" 
                size="sm"
                onClick={() => onClick(lead.id)}
              >
                View Details
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default LeadCard;
