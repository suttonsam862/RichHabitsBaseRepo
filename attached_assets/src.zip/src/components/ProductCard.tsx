
import { useState } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Product } from "@/lib/api";
import { ShoppingBag } from "lucide-react";

interface ProductCardProps {
  product: Product;
  onAddToOrder?: (product: Product) => void;
}

const ProductCard = ({ product, onAddToOrder }: ProductCardProps) => {
  const [isHovered, setIsHovered] = useState(false);

  const handleAddToOrder = () => {
    if (onAddToOrder) {
      onAddToOrder(product);
    }
  };

  return (
    <Card 
      className="overflow-hidden transition-all duration-200 h-full flex flex-col"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative aspect-video w-full overflow-hidden bg-gray-100">
        <img 
          src={product.imageUrl} 
          alt={product.name} 
          className={`w-full h-full object-cover transition-transform duration-300 ${isHovered ? 'scale-110' : 'scale-100'}`}
        />
        <div className="absolute top-2 right-2">
          <Badge variant="secondary" className="bg-white text-primary">
            ${product.price.toFixed(2)}
          </Badge>
        </div>
      </div>
      <CardHeader className="p-4 pb-0">
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg">{product.name}</CardTitle>
        </div>
        <div className="flex gap-2 mt-2">
          <Badge variant="outline" className="text-xs">
            {product.sport}
          </Badge>
          <Badge variant="outline" className="text-xs">
            {product.category}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="p-4 pt-2 text-sm text-muted-foreground flex-grow">
        <p className="line-clamp-2">{product.description}</p>
        <div className="mt-2 flex flex-wrap gap-1">
          {product.sizes.map((size) => (
            <span key={size} className="text-xs px-2 py-1 bg-gray-100 rounded-md">
              {size}
            </span>
          ))}
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        {onAddToOrder && (
          <Button 
            onClick={handleAddToOrder}
            className="w-full"
            variant="outline"
          >
            <ShoppingBag className="h-4 w-4 mr-2" />
            Add to Order
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default ProductCard;
