
import { useEffect } from "react";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export function RequireAuth({ children }: { children: JSX.Element }) {
  const { user, isLoading, isAuthenticated } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    // Navigate to the homepage after authentication is successful
    if (isAuthenticated && location.pathname === "/login") {
      console.log("RequireAuth: Authenticated user detected on login page");
      console.log("RequireAuth: Redirecting to homepage");
      
      // Use a slight timeout to ensure state is fully updated before navigation
      setTimeout(() => {
        navigate("/", { replace: true });
      }, 100);
    }
  }, [isAuthenticated, location.pathname, navigate]);

  console.log("RequireAuth: Current auth state:", { 
    isAuthenticated, 
    isLoading, 
    currentPath: location.pathname,
    user: user?.email 
  });

  // Handle loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="flex flex-col items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  // Redirect to login if not authenticated
  if (!isAuthenticated && location.pathname !== "/login") {
    console.log("RequireAuth: Unauthenticated user attempting to access:", location.pathname);
    console.log("RequireAuth: Redirecting to login page");
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
}
