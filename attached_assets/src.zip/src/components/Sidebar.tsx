
import { useAuth } from "@/context/AuthContext";
import MainNavigation from "./sidebar/MainNavigation";
import AdminNavigation from "./sidebar/AdminNavigation";
import UserNavigation from "./sidebar/UserNavigation";
import logo from '../assets/logo.png';

const Sidebar = () => {
  const { isAdmin, userRole } = useAuth();

  return (
    <div className="fixed left-0 top-0 w-64 h-full bg-gray-900 text-white flex flex-col">
      <div className="p-4 border-b border-gray-800">
        <div className="flex items-center">
          <img src={logo} alt="Rich Habits Logo" className="h-10 w-auto mr-2" />
          <span className="text-xl font-bold">Rich Habits</span>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto py-4">
        <nav className="px-2 space-y-1">
          <MainNavigation userRole={userRole} />
          
          {isAdmin && <AdminNavigation />}
        </nav>
      </div>

      <UserNavigation userRole={userRole} />
    </div>
  );
};

export default Sidebar;
