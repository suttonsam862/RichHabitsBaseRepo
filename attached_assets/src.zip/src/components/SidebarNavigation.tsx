
import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { 
  LayoutDashboard, 
  Users, 
  PackageOpen, 
  ClipboardList, 
  UserSquare, 
  LineChart, 
  BarChart, 
  Settings, 
  Palette, 
  Factory, 
  DollarSign
} from 'lucide-react';

export interface SidebarNavProps extends React.HTMLAttributes<HTMLElement> {
  className?: string;
}

const SidebarNavigation = ({ className, ...props }: SidebarNavProps) => {
  const location = useLocation();
  const pathname = location.pathname;

  const navItems = [
    {
      title: "Dashboard",
      icon: <LayoutDashboard className="mr-2 h-4 w-4" />,
      href: "/",
      active: pathname === "/"
    },
    {
      title: "Clients",
      icon: <Users className="mr-2 h-4 w-4" />,
      href: "/clients",
      active: pathname === "/clients"
    },
    {
      title: "Leads",
      icon: <UserSquare className="mr-2 h-4 w-4" />,
      href: "/leads", 
      active: pathname === "/leads"
    },
    {
      title: "Orders",
      icon: <ClipboardList className="mr-2 h-4 w-4" />,
      href: "/orders",
      active: pathname === "/orders" || pathname.startsWith("/orders/")
    },
    {
      title: "Catalog",
      icon: <PackageOpen className="mr-2 h-4 w-4" />,
      href: "/catalog",
      active: pathname === "/catalog"
    },
    {
      title: "Design",
      icon: <Palette className="mr-2 h-4 w-4" />,
      href: "/design",
      active: pathname === "/design"
    },
    {
      title: "Manufacturing",
      icon: <Factory className="mr-2 h-4 w-4" />,
      href: "/manufacturing",
      active: pathname === "/manufacturing"
    },
    {
      title: "Wholesale",
      icon: <DollarSign className="mr-2 h-4 w-4" />,
      href: "/wholesale",
      active: pathname === "/wholesale" || pathname.startsWith("/wholesale/")
    },
    {
      title: "Reports",
      icon: <BarChart className="mr-2 h-4 w-4" />,
      href: "/reports",
      active: pathname === "/reports"
    },
    {
      title: "Settings",
      icon: <Settings className="mr-2 h-4 w-4" />,
      href: "/settings",
      active: pathname === "/settings"
    }
  ];

  return (
    <nav className={cn("flex flex-col space-y-1", className)} {...props}>
      {navItems.map((item) => (
        <Link
          key={item.href}
          to={item.href}
          className={cn(
            "flex items-center px-3 py-2 text-sm font-medium rounded-md hover:bg-gray-800 hover:text-white transition-colors",
            item.active ? "bg-gray-800 text-white" : "text-gray-300"
          )}
        >
          {item.icon}
          {item.title}
        </Link>
      ))}
    </nav>
  );
};

export default SidebarNavigation;
