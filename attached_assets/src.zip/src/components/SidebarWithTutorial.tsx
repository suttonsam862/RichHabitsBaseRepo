
import React from "react";
import Sidebar from "./Sidebar";
import { TutorialButton } from "./tutorial/TutorialButton";
import { PageTutorial } from "./tutorial/PageTutorial";

const SidebarWithTutorial: React.FC<{ children?: React.ReactNode }> = ({ children }) => {
  return (
    <>
      <Sidebar />
      <div className="fixed top-4 right-4 z-40">
        <TutorialButton className="tutorial-button" />
      </div>
      {children}
      <PageTutorial />
    </>
  );
};

export default SidebarWithTutorial;
