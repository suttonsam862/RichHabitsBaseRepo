
import { useState, useEffect } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { CheckCircle2, AlertTriangle, Database, Server, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';

const SupabaseStatus = () => {
  const [status, setStatus] = useState<{
    connected: boolean;
    message: string;
  }>({
    connected: false,
    message: 'Checking connection...'
  });

  // Check if Supabase is configured
  const supabaseConfigured = isSupabaseConfigured();

  const checkConnection = async () => {
    if (!supabaseConfigured) {
      setStatus({
        connected: false,
        message: 'Supabase is not properly configured. Please check your environment variables.'
      });
      return;
    }

    try {
      // Simple connection test - note we're using a more generic approach to avoid type errors
      const { error } = await supabase
        .from('dummy_check')
        .select('*')
        .limit(1)
        .maybeSingle();
      
      if (error && error.code !== 'PGRST116') { // PGRST116 means table doesn't exist, which is fine
        setStatus({
          connected: false,
          message: `Connection failed: ${error.message}`
        });
        return;
      }
      
      setStatus({
        connected: true,
        message: 'Successfully connected to Supabase database.'
      });
    } catch (error) {
      console.error('Error checking Supabase connection:', error);
      setStatus({
        connected: false,
        message: error instanceof Error ? error.message : 'An unknown error occurred'
      });
    }
  };

  useEffect(() => {
    checkConnection();
  }, [supabaseConfigured]);

  if (!supabaseConfigured) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" /> 
            Supabase Database Status
          </CardTitle>
          <CardDescription>
            Configuration issue detected
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Configuration Missing</AlertTitle>
            <AlertDescription>
              <p className="mb-2">Supabase environment variables are not properly configured.</p>
              <p className="text-sm">Please make sure you've connected your project to Supabase and that the environment variables are correctly set.</p>
            </AlertDescription>
          </Alert>
          <Button
            variant="outline"
            size="sm"
            className="mt-2"
            onClick={() => window.open('https://docs.lovable.dev/integrations/supabase/', '_blank')}
          >
            <ExternalLink className="h-4 w-4 mr-2" />
            Supabase Integration Docs
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" /> 
          Supabase Database Status
        </CardTitle>
        <CardDescription>
          Information about your Supabase database connection
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert variant={status.connected ? "default" : "destructive"}>
          {status.connected ? (
            <CheckCircle2 className="h-4 w-4" />
          ) : (
            <AlertTriangle className="h-4 w-4" />
          )}
          <AlertTitle>
            {status.connected ? "Connected" : "Connection Issues"}
          </AlertTitle>
          <AlertDescription>
            {status.message}
          </AlertDescription>
        </Alert>
        
        <Button
          variant="outline"
          size="sm"
          onClick={checkConnection}
          className="mt-2"
        >
          <Server className="h-4 w-4 mr-2" />
          Refresh Connection Status
        </Button>
      </CardContent>
    </Card>
  );
};

export default SupabaseStatus;
