
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { AlertCircle, RefreshCw } from 'lucide-react';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

const SupabaseSync = () => {
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState('');

  const handleSync = async () => {
    setIsSyncing(true);
    setSyncMessage('Syncing with Supabase...');

    try {
      // For now, we'll simulate sync by testing the connection
      const { data, error } = await supabase
        .from('dummy_check')
        .select('count')
        .limit(1);

      if (error) {
        throw new Error(`Sync failed: ${error.message}`);
      }

      // Simulated delay to show sync process
      await new Promise(resolve => setTimeout(resolve, 1000));

      setSyncMessage('Sync completed successfully.');
      toast.success('Synchronized with Supabase');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      setSyncMessage(`Error: ${errorMessage}`);
      toast.error(`Sync failed: ${errorMessage}`);
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Supabase Synchronization</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {syncMessage && (
          <Alert variant={syncMessage.includes('Error') ? 'destructive' : 'default'}>
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Sync Status</AlertTitle>
            <AlertDescription>{syncMessage}</AlertDescription>
          </Alert>
        )}

        <Button 
          onClick={handleSync} 
          disabled={isSyncing}
          className="w-full"
        >
          {isSyncing ? (
            <>
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              Syncing...
            </>
          ) : (
            'Sync with Supabase'
          )}
        </Button>
      </CardContent>
    </Card>
  );
};

export default SupabaseSync;
