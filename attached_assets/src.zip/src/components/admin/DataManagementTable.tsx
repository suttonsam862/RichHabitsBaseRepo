
import { Search, Download, Upload, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { TableEntity } from "@/types/admin";

interface DataManagementTableProps {
  entities: TableEntity[];
  isLoading: boolean;
  searchTerm: string;
  onSearchChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onExportData: (tableName: string) => void;
  onImportData: (tableName: string) => void;
  onRefreshData: (tableName: string) => void;
}

const DataManagementTable = ({
  entities,
  isLoading,
  searchTerm,
  onSearchChange,
  onExportData,
  onImportData,
  onRefreshData
}: DataManagementTableProps) => {
  return (
    <>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
        <div className="mt-3 md:mt-0 relative w-full md:w-auto max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search entities..."
            className="pl-8 w-full md:w-64"
            value={searchTerm}
            onChange={onSearchChange}
          />
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-10">
          <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary"></div>
        </div>
      ) : entities.length === 0 ? (
        <div className="text-center py-10">
          <p className="text-muted-foreground">No entities found matching your search</p>
        </div>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Entity</TableHead>
              <TableHead>Record Count</TableHead>
              <TableHead>Last Updated</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {entities.map((entity) => (
              <TableRow key={entity.name}>
                <TableCell className="font-medium">{entity.displayName}</TableCell>
                <TableCell>
                  {entity.error ? (
                    <Badge variant="destructive">Error</Badge>
                  ) : (
                    <Badge variant="outline">{entity.count}</Badge>
                  )}
                </TableCell>
                <TableCell>
                  {new Date().toLocaleDateString()}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" size="icon" onClick={() => onExportData(entity.name)}>
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="icon" onClick={() => onImportData(entity.name)}>
                      <Upload className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="icon" onClick={() => onRefreshData(entity.name)}>
                      <RefreshCw className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </>
  );
};

export default DataManagementTable;
