
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface PlaceholderCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
}

const PlaceholderCard = ({ title, description, icon: Icon }: PlaceholderCardProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex justify-center items-center flex-col py-10">
          <Icon className="h-12 w-12 text-gray-300 mb-4" />
          <p className="text-muted-foreground">{title} coming soon</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default PlaceholderCard;
