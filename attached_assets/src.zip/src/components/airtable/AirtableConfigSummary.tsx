
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";

interface AirtableConfigSummaryProps {
  tableMapping: Record<string, string>;
  focusedTable?: string | null;
}

const AirtableConfigSummary: React.FC<AirtableConfigSummaryProps> = ({ 
  tableMapping,
  focusedTable 
}) => {
  // If we have a focused table, only show information for that table
  if (focusedTable) {
    const tableName = tableMapping[focusedTable];
    if (!tableName) {
      return null;
    }

    return (
      <Card className="bg-muted/50">
        <CardContent className="pt-6 pb-4">
          <h3 className="text-sm font-medium mb-2">Table Configuration</h3>
          <div className="text-sm">
            <div className="mb-1">
              <span className="font-medium">{focusedTable.charAt(0).toUpperCase() + focusedTable.slice(1)} Table:</span> {tableName}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Default case: show all table mappings
  return (
    <Card className="bg-muted/50">
      <CardContent className="pt-6 pb-4">
        <h3 className="text-sm font-medium mb-2">Table Configuration</h3>
        <div className="text-sm">
          {Object.entries(tableMapping).map(([key, value]) => (
            <div key={key} className="mb-1">
              <span className="font-medium">{key.charAt(0).toUpperCase() + key.slice(1)} Table:</span> {value}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default AirtableConfigSummary;
