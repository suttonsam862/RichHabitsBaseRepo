
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { HelpCircle, ExternalLink, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const AirtableCredentialsHelp = () => {
  return (
    <div className="mt-6 mb-4">
      <Alert className="bg-blue-50 border-blue-200">
        <HelpCircle className="h-4 w-4 text-blue-500" />
        <AlertTitle>Airtable Credentials Help</AlertTitle>
        <AlertDescription>
          <p className="mb-2">If you're having trouble connecting to Airtable, verify your credentials:</p>
          
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="personal-access-token">
              <AccordionTrigger className="text-sm font-medium text-blue-700">
                Personal Access Token
              </AccordionTrigger>
              <AccordionContent className="text-sm space-y-2">
                <ol className="list-decimal pl-5 space-y-1">
                  <li>Go to your <a href="https://airtable.com/create/tokens" target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">Airtable Personal Access Tokens page</a></li>
                  <li>Create a new token with the following scopes:
                    <ul className="list-disc pl-5 mt-1 text-xs">
                      <li>data.records:read</li>
                      <li>data.records:write</li>
                      <li>schema.bases:read</li>
                    </ul>
                  </li>
                  <li>Make sure to select the base you want to connect to</li>
                  <li>Copy the token right after creation (it won't be shown again)</li>
                </ol>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="base-id">
              <AccordionTrigger className="text-sm font-medium text-blue-700">
                Base ID
              </AccordionTrigger>
              <AccordionContent className="text-sm space-y-2">
                <ol className="list-decimal pl-5 space-y-1">
                  <li>Go to the <a href="https://airtable.com/api" target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">Airtable API documentation</a></li>
                  <li>Select your base from the list</li>
                  <li>Look for the text "The ID of this base is" followed by the base ID</li>
                  <li>Base IDs start with "app" followed by letters and numbers</li>
                  <li>Copy the entire ID including "app"</li>
                </ol>
                <div className="mt-2 p-2 bg-blue-100 rounded">
                  <p className="text-xs font-semibold">Example Base ID:</p>
                  <p className="font-mono text-xs">applW0923S1f7ugBY</p>
                </div>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="common-errors">
              <AccordionTrigger className="text-sm font-medium text-blue-700">
                Common Connection Errors
              </AccordionTrigger>
              <AccordionContent className="text-sm space-y-2">
                <div className="bg-yellow-50 p-2 rounded border border-yellow-200 mb-2">
                  <div className="flex gap-2">
                    <AlertTriangle className="h-4 w-4 text-yellow-500 mt-0.5" />
                    <p className="text-xs">
                      If you see <span className="font-mono font-semibold">this.base.tables is not a function</span> error, 
                      make sure your Personal Access Token has all required scopes.
                    </p>
                  </div>
                </div>
                <ul className="list-disc pl-5 space-y-1">
                  <li><span className="font-medium">Authentication failure:</span> Your token may be invalid or expired</li>
                  <li><span className="font-medium">Base not found:</span> The Base ID is incorrect or the token doesn't have access to this base</li>
                  <li><span className="font-medium">Table not found:</span> Check that the table names exactly match what's in your Airtable base (case-sensitive)</li>
                  <li><span className="font-medium">Permission denied:</span> Your token doesn't have the required scopes or access to this base</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="required-tables">
              <AccordionTrigger className="text-sm font-medium text-blue-700">
                Required Tables
              </AccordionTrigger>
              <AccordionContent className="text-sm space-y-2">
                <p>Make sure your Airtable base has these tables with exact names (case-sensitive):</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li><span className="font-medium font-mono">Leads</span></li>
                  <li><span className="font-medium font-mono">Products</span></li>
                  <li><span className="font-medium font-mono">Orders</span></li>
                  <li><span className="font-medium font-mono">OrderLineItems</span></li>
                  <li><span className="font-medium font-mono">Organizations</span></li>
                  <li><span className="font-medium font-mono">Statistics</span></li>
                </ul>
                <p className="text-xs mt-2">
                  Create these tables in your Airtable base before connecting. The app will automatically
                  detect and use the appropriate fields.
                </p>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
          
          <div className="mt-4">
            <Button variant="outline" size="sm" asChild>
              <a 
                href="https://airtable.com/developers/web/api/introduction" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="flex items-center"
              >
                Airtable API Documentation
                <ExternalLink className="ml-1 h-3 w-3" />
              </a>
            </Button>
          </div>
        </AlertDescription>
      </Alert>
    </div>
  );
};

export default AirtableCredentialsHelp;
