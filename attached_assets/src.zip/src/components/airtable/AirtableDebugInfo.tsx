
import { Button } from "@/components/ui/button";
import { Clipboard } from "lucide-react";
import { toast } from "sonner";
import { getDebugInfo } from "@/services/airtableUtils";

interface AirtableDebugInfoProps {
  showDebugInfo: boolean;
}

const AirtableDebugInfo = ({ showDebugInfo }: AirtableDebugInfoProps) => {
  if (!showDebugInfo) {
    return null;
  }

  const copyDebugInfo = () => {
    const info = JSON.stringify(getDebugInfo(), null, 2);
    navigator.clipboard.writeText(info);
    toast.success("Debug info copied to clipboard");
  };

  return (
    <div className="mb-4 p-3 bg-gray-100 rounded-md text-xs">
      <div className="flex justify-between">
        <p className="font-bold mb-1">Airtable Debug Info:</p>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={copyDebugInfo}
          className="h-5 w-5"
        >
          <Clipboard className="h-3 w-3" />
        </Button>
      </div>
      <pre>{JSON.stringify(getDebugInfo(), null, 2)}</pre>
    </div>
  );
};

export default AirtableDebugInfo;
