
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertTriangle, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import AirtableDebugInfo from "./AirtableDebugInfo";
import { getDebugInfo } from "@/services/airtableUtils";
import { toast } from "sonner";
import { Link } from "react-router-dom";

interface AirtableNotConfiguredProps {
  showDebugInfo: boolean;
  toggleDebugInfo: () => void;
}

const AirtableNotConfigured = ({ showDebugInfo, toggleDebugInfo }: AirtableNotConfiguredProps) => {
  const copyDebugInfo = () => {
    const info = JSON.stringify(getDebugInfo(), null, 2);
    navigator.clipboard.writeText(info);
    toast.success("Debug info copied to clipboard");
  };

  return (
    <>
      <Alert className="mb-4">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Not Configured</AlertTitle>
        <AlertDescription>
          Airtable integration is not configured. Please go to Settings to set up your Airtable connection.
        </AlertDescription>
      </Alert>
      
      <AirtableDebugInfo showDebugInfo={showDebugInfo} />
      
      <div className="flex space-x-2">
        <Button asChild>
          <Link to="/settings?tab=integrations">Configure Airtable</Link>
        </Button>
        <Button 
          variant="outline" 
          size="icon"
          onClick={toggleDebugInfo}
          title="Toggle Debug Info"
        >
          <Info className="h-4 w-4" />
        </Button>
      </div>
    </>
  );
};

export default AirtableNotConfigured;
