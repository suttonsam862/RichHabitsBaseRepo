
import React from 'react';
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";

interface AirtableSyncButtonsProps {
  tableMapping: Record<string, string>;
  isSyncingLeads: boolean;
  isSyncingProducts: boolean;
  isSyncingOrders: boolean;
  syncErrors: Record<string, string>;
  connectionSuccess: boolean;
  handleSyncLeads: () => Promise<void>;
  handleSyncProducts: () => Promise<void>;
  handleSyncOrders: () => Promise<void>;
  focusedTable?: string | null;
}

const AirtableSyncButtons: React.FC<AirtableSyncButtonsProps> = ({
  tableMapping,
  isSyncingLeads,
  isSyncingProducts,
  isSyncingOrders,
  syncErrors,
  connectionSuccess,
  handleSyncLeads,
  handleSyncProducts,
  handleSyncOrders,
  focusedTable
}) => {
  // If we're focused on a specific table, only show that button
  if (focusedTable === 'leads') {
    return (
      <div className="flex justify-center">
        <Button
          variant="outline"
          onClick={handleSyncLeads}
          disabled={!connectionSuccess || isSyncingLeads || !tableMapping.leads}
          className="w-full"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${isSyncingLeads ? 'animate-spin' : ''}`} />
          {isSyncingLeads ? "Syncing Leads..." : "Sync Leads to Airtable"}
        </Button>
      </div>
    );
  }

  if (focusedTable === 'orders') {
    return (
      <div className="flex justify-center">
        <Button
          variant="outline"
          onClick={handleSyncOrders}
          disabled={!connectionSuccess || isSyncingOrders || !tableMapping.orders}
          className="w-full"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${isSyncingOrders ? 'animate-spin' : ''}`} />
          {isSyncingOrders ? "Syncing Orders..." : "Sync Orders to Airtable"}
        </Button>
      </div>
    );
  }

  if (focusedTable === 'products') {
    return (
      <div className="flex justify-center">
        <Button
          variant="outline"
          onClick={handleSyncProducts}
          disabled={!connectionSuccess || isSyncingProducts || !tableMapping.products}
          className="w-full"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${isSyncingProducts ? 'animate-spin' : ''}`} />
          {isSyncingProducts ? "Syncing Products..." : "Sync Products to Airtable"}
        </Button>
      </div>
    );
  }

  if (focusedTable === 'organizations') {
    return (
      <div className="flex justify-center">
        <p className="text-muted-foreground text-sm">
          Organization sync is currently view-only.
        </p>
      </div>
    );
  }

  // If no focused table, display all buttons
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
      <Button
        variant="outline"
        onClick={handleSyncLeads}
        disabled={!connectionSuccess || isSyncingLeads || !tableMapping.leads}
      >
        <RefreshCw className={`h-4 w-4 mr-2 ${isSyncingLeads ? 'animate-spin' : ''}`} />
        {isSyncingLeads ? "Syncing..." : "Sync Leads"}
      </Button>
      
      <Button
        variant="outline"
        onClick={handleSyncProducts}
        disabled={!connectionSuccess || isSyncingProducts || !tableMapping.products}
      >
        <RefreshCw className={`h-4 w-4 mr-2 ${isSyncingProducts ? 'animate-spin' : ''}`} />
        {isSyncingProducts ? "Syncing..." : "Sync Products"}
      </Button>
      
      <Button
        variant="outline"
        onClick={handleSyncOrders}
        disabled={!connectionSuccess || isSyncingOrders || !tableMapping.orders}
      >
        <RefreshCw className={`h-4 w-4 mr-2 ${isSyncingOrders ? 'animate-spin' : ''}`} />
        {isSyncingOrders ? "Syncing..." : "Sync Orders"}
      </Button>
    </div>
  );
};

export default AirtableSyncButtons;
