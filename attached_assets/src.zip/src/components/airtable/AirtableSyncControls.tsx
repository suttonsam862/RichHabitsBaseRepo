
import { Button } from "@/components/ui/button";
import { Upload, ArrowUpDown, Info, Clock } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useState, useEffect } from "react";
import { toast } from "sonner";

interface AirtableSyncControlsProps {
  handleSyncAll: () => Promise<void>;
  connectionSuccess: boolean;
  toggleLogs: () => void;
  toggleDebugInfo: () => void;
}

const AirtableSyncControls = ({ 
  handleSyncAll, 
  connectionSuccess,
  toggleLogs,
  toggleDebugInfo
}: AirtableSyncControlsProps) => {
  const [autoSync, setAutoSync] = useState(false);
  const [syncInterval, setSyncInterval] = useState<number | null>(null);
  const AUTO_SYNC_INTERVAL = 300000; // 5 minutes in milliseconds

  // Initialize auto-sync from localStorage if available
  useEffect(() => {
    const savedAutoSync = localStorage.getItem('airtableAutoSync');
    if (savedAutoSync === 'true') {
      setAutoSync(true);
    }
  }, []);

  // Setup or clear the sync interval based on autoSync state
  useEffect(() => {
    if (autoSync && connectionSuccess) {
      // Set up the interval for auto-sync
      const intervalId = window.setInterval(() => {
        console.log("Auto-sync triggered");
        handleSyncAll().catch(error => {
          console.error("Auto-sync failed:", error);
          toast.error("Automatic sync failed. See logs for details.");
        });
      }, AUTO_SYNC_INTERVAL);

      // Store the interval ID
      setSyncInterval(intervalId);
      localStorage.setItem('airtableAutoSync', 'true');
      
      // Initial sync when auto-sync is turned on
      handleSyncAll().catch(error => {
        console.error("Initial auto-sync failed:", error);
      });

      // Cleanup on unmount or when autoSync is toggled off
      return () => {
        if (intervalId) {
          window.clearInterval(intervalId);
        }
      };
    } else {
      // Clear the interval when autoSync is turned off
      if (syncInterval) {
        window.clearInterval(syncInterval);
        setSyncInterval(null);
      }
      localStorage.setItem('airtableAutoSync', 'false');
    }
  }, [autoSync, connectionSuccess, handleSyncAll]);

  // Handle toggle change
  const handleAutoSyncToggle = (checked: boolean) => {
    setAutoSync(checked);
    if (checked) {
      toast.success("Auto-sync enabled. Data will sync every 5 minutes.");
    } else {
      toast.info("Auto-sync disabled.");
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between bg-muted/50 p-3 rounded-lg">
        <div className="flex items-center space-x-2">
          <Clock className="h-4 w-4 text-muted-foreground" />
          <div>
            <Label htmlFor="auto-sync" className="font-medium">Auto-Sync</Label>
            <p className="text-xs text-muted-foreground">Automatically sync data every 5 minutes</p>
          </div>
        </div>
        <Switch 
          id="auto-sync" 
          checked={autoSync} 
          onCheckedChange={handleAutoSyncToggle}
          disabled={!connectionSuccess}
        />
      </div>

      <div className="flex justify-between">
        <Button 
          className="w-full mr-2" 
          onClick={handleSyncAll}
          disabled={!connectionSuccess}
        >
          <Upload className="h-4 w-4 mr-2" />
          Sync All Data
        </Button>
        
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="icon"
            onClick={toggleLogs}
            title="Toggle Logs"
          >
            <ArrowUpDown className="h-4 w-4" />
          </Button>
          
          <Button 
            variant="outline" 
            size="icon"
            onClick={toggleDebugInfo}
            title="Toggle Debug Info"
          >
            <Info className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AirtableSyncControls;
