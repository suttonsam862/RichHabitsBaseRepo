
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertTriangle, Info, Eye, ExternalLink } from "lucide-react";
import { airtableService } from "@/services/airtableService";
import { Badge } from "@/components/ui/badge";

interface AirtableSyncDetailsProps {
  tableName: string;
  recordCount: number;
  lastSyncTime?: Date;
  onManualSync: () => Promise<void>;
  isLoading: boolean;
}

const AirtableSyncDetails = ({
  tableName,
  recordCount,
  lastSyncTime,
  onManualSync,
  isLoading
}: AirtableSyncDetailsProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [showDebugInfo, setShowDebugInfo] = useState(false);
  const tableConfig = airtableService.getTableMapping();
  const mappedTableName = tableConfig[tableName as keyof typeof tableConfig];
  
  // Determine if we've had a previous sync attempt
  const hasSyncedBefore = lastSyncTime !== undefined;
  
  // Get any sync errors specific to this table type
  const syncError = airtableService.getLastSyncError(tableName);
  const hasError = syncError !== undefined && syncError !== null;
  
  return (
    <Card className="mb-4">
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex justify-between items-center">
          <div className="flex items-center gap-2">
            <span>
              {tableName.charAt(0).toUpperCase() + tableName.slice(1)} Sync Details
              {mappedTableName && (
                <span className="text-sm text-muted-foreground ml-2">
                  → {mappedTableName}
                  {!hasSyncedBefore && (
                    <Badge variant="outline" className="ml-2 text-xs">
                      Not synced yet
                    </Badge>
                  )}
                </span>
              )}
            </span>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={onManualSync}
            disabled={isLoading}
          >
            {isLoading ? "Syncing..." : "Sync Now"}
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-sm">
              {recordCount} {tableName} ready to sync
              {lastSyncTime && (
                <span className="text-muted-foreground ml-2">
                  Last synced: {lastSyncTime.toLocaleString()}
                </span>
              )}
            </p>
            {hasError && (
              <Badge variant="destructive" className="text-xs">
                Last sync failed
              </Badge>
            )}
          </div>
          
          {hasError && (
            <Alert variant="destructive" className="mt-2">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Sync Error</AlertTitle>
              <AlertDescription className="text-xs">
                {typeof syncError === 'string' ? syncError : 'Unknown error occurred during sync'}
              </AlertDescription>
            </Alert>
          )}
          
          <Collapsible open={isOpen} onOpenChange={setIsOpen}>
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" className="p-0 h-auto">
                <Eye className="h-3 w-3 mr-1" />
                <span className="text-xs">{isOpen ? "Hide Sync Details" : "View Sync Details"}</span>
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="mt-2">
              <Alert variant="default" className="bg-slate-50">
                <Info className="h-4 w-4" />
                <AlertTitle>Sync Details</AlertTitle>
                <AlertDescription className="text-xs space-y-2">
                  <div>
                    <p className="font-medium">Table Configuration:</p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Airtable table name: <span className="font-mono">{mappedTableName || 'Not configured'}</span></li>
                      <li>Data type: <span className="font-mono">{tableName}</span></li>
                      <li>Records to sync: {recordCount}</li>
                      {lastSyncTime && <li>Last sync attempt: {lastSyncTime.toLocaleString()}</li>}
                    </ul>
                  </div>
                  
                  <div>
                    <p className="font-medium mt-2">Sync Tips:</p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Ensure your Airtable column names match the expected field names</li>
                      <li>Check that required columns exist in your Airtable</li>
                      <li>Image columns should be set as "Single line text" types in Airtable</li>
                      <li>Verify you have proper permissions on the Airtable base</li>
                      <li>Field names are case-sensitive</li>
                    </ul>
                  </div>
                  
                  <div className="pt-1">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="text-xs h-7"
                      onClick={() => setShowDebugInfo(!showDebugInfo)}
                    >
                      {showDebugInfo ? "Hide Debug Info" : "Show Debug Info"}
                    </Button>
                  </div>
                  
                  {showDebugInfo && (
                    <div className="bg-slate-100 p-2 rounded mt-2 font-mono text-xs">
                      <p>Integration Status: {airtableService.isInitialized() ? 'Initialized' : 'Not Initialized'}</p>
                      <p>Token Set: {localStorage.getItem('airtablePersonalAccessToken') ? 'Yes' : 'No'}</p>
                      <p>Base ID: {localStorage.getItem('airtableBaseId') || 'Not Set'}</p>
                      <p>Expected Table: {mappedTableName}</p>
                      
                      <p className="mt-1">
                        <a 
                          href="https://airtable.com/developers/web/api/introduction" 
                          target="_blank" 
                          rel="noreferrer" 
                          className="text-blue-600 inline-flex items-center"
                        >
                          Airtable API Docs
                          <ExternalLink className="h-3 w-3 ml-1" />
                        </a>
                      </p>
                    </div>
                  )}
                </AlertDescription>
              </Alert>
            </CollapsibleContent>
          </Collapsible>
        </div>
      </CardContent>
    </Card>
  );
};

export default AirtableSyncDetails;
