
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertTriangle, Info, ExternalLink, Settings, Database } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { airtableService } from "@/services/airtableService";

interface AirtableSyncErrorsProps {
  syncErrors: { [key: string]: string };
}

const AirtableSyncErrors = ({ syncErrors }: AirtableSyncErrorsProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [fieldMappingOpen, setFieldMappingOpen] = useState(false);
  const [allComputedFields, setAllComputedFields] = useState<Record<string, string[]>>({});

  useEffect(() => {
    // Get any computed fields that have been detected
    const detectedFields = airtableService.getDetectedComputedFields();
    
    // Make sure we're getting the expected type
    if (detectedFields && typeof detectedFields === 'object' && !Array.isArray(detectedFields)) {
      setAllComputedFields(detectedFields as Record<string, string[]>);
    }
    
    // If there's a computed field error, try to extract the field name
    Object.values(syncErrors).forEach(error => {
      const fieldMatch = error.match(/Field ["']([^"']+)["'] cannot accept a value because the field is computed/);
      if (fieldMatch) {
        const field = fieldMatch[1];
        const table = Object.keys(syncErrors).find(key => syncErrors[key] === error) || 'unknown';
        const tableMapping = airtableService.getTableMapping();
        const airtableTable = tableMapping[table as keyof typeof tableMapping] || table;
        
        // Add to detected computed fields
        if (airtableTable) {
          let existingFields = airtableService.getDetectedComputedFields(airtableTable);
          if (!Array.isArray(existingFields)) {
            existingFields = [];
          }
          if (!existingFields.includes(field)) {
            airtableService.setDetectedComputedFields(airtableTable, [...existingFields, field]);
          }
        }
      }
    });
  }, [syncErrors]);

  // Always add "Lead ID" to the computed fields if we have lead errors
  useEffect(() => {
    if (syncErrors.leads && syncErrors.leads.includes("Lead ID")) {
      const tableMapping = airtableService.getTableMapping();
      const leadsTable = tableMapping.leads || "Leads";
      
      let existingFields = airtableService.getDetectedComputedFields(leadsTable);
      if (!Array.isArray(existingFields)) {
        existingFields = [];
      }
      
      if (!existingFields.includes("Lead ID")) {
        airtableService.setDetectedComputedFields(leadsTable, [...existingFields, "Lead ID"]);
        
        // Update our local state too
        setAllComputedFields(prev => ({
          ...prev,
          [leadsTable]: [...(prev[leadsTable] || []), "Lead ID"]
        }));
      }
    }
  }, [syncErrors]);

  if (Object.keys(syncErrors).length === 0 && Object.keys(allComputedFields).length === 0) {
    return null;
  }

  // Check if one of the errors is about computed fields
  const hasComputedFieldError = Object.values(syncErrors).some(error => 
    error.includes("computed") || error.includes("INVALID_VALUE_FOR_COLUMN")
  );
  
  // Check if there's a connection issue with Airtable
  const hasConnectionIssue = syncErrors.connection || 
    Object.values(syncErrors).some(error => 
      error.includes("authentication") || 
      error.includes("permission") || 
      error.includes("connect")
    );
    
  // Check if there's a field mapping issue
  const hasFieldMappingIssue = Object.values(syncErrors).some(error => 
    error.includes("Unknown field") || error.includes("UNKNOWN_FIELD_NAME") || 
    error.includes("Invalid attachment") || error.includes("INVALID_ATTACHMENT_OBJECT")
  );

  // Count total computed fields across all tables
  const totalComputedFields = Object.values(allComputedFields).reduce(
    (total, fields) => total + fields.length, 0
  );

  return (
    <Alert 
      variant={Object.keys(syncErrors).length > 0 ? "warning" : "info"} 
      className="mb-6 border-white/20 shadow-[0_8px_32px_rgba(0,0,0,0.15)]"
    >
      <AlertTriangle className="h-5 w-5" />
      <AlertTitle className="text-lg font-medium mb-2">Sync Information</AlertTitle>
      <AlertDescription className="space-y-4">
        {syncErrors.connection && (
          <div className="font-medium text-red-500">{syncErrors.connection}</div>
        )}
        
        {hasFieldMappingIssue && (
          <Collapsible open={fieldMappingOpen} onOpenChange={setFieldMappingOpen} className="p-4 bg-white/5 backdrop-blur-sm rounded-lg border border-white/10 text-sm mt-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Database className="h-4 w-4 text-amber-500" />
                <span className="font-medium">Field Mapping Issues Detected</span>
              </div>
              <CollapsibleTrigger asChild>
                <Button variant="ghost" size="sm" className="p-1 h-auto hover:bg-white/10">
                  {fieldMappingOpen ? "Hide Details" : "Show Details"}
                </Button>
              </CollapsibleTrigger>
            </div>
            
            <CollapsibleContent className="mt-3">
              <p>There are mismatches between the app's field names and your Airtable columns:</p>
              
              <ul className="mt-3 list-disc pl-5 text-sm space-y-1">
                {Object.values(syncErrors).map((error, index) => {
                  if (error.includes("Unknown field") || error.includes("UNKNOWN_FIELD_NAME") || 
                      error.includes("Invalid attachment") || error.includes("INVALID_ATTACHMENT_OBJECT")) {
                    return <li key={index}>{error}</li>;
                  }
                  return null;
                }).filter(Boolean)}
              </ul>
              
              <div className="bg-amber-500/10 p-3 rounded-lg mt-3">
                <p className="font-medium">Field Mapping Solution:</p>
                <ol className="list-decimal ml-5 mt-2 text-xs">
                  <li>Go to Settings → Airtable Integration</li>
                  <li>Check that your Airtable columns exactly match the expected field names</li>
                  <li>For image fields, ensure they are set as "Attachment" type in Airtable</li>
                  <li>You can either rename columns in Airtable, or customize field mappings in Settings</li>
                </ol>
              </div>
              
              <div className="mt-3">
                <Button 
                  variant="secondary" 
                  size="sm" 
                  onClick={() => window.location.href = '/settings?tab=airtable'}
                  className="text-xs w-full bg-white/10 hover:bg-white/20"
                >
                  <Settings className="h-3 w-3 mr-1" />
                  Go to Airtable Settings
                </Button>
              </div>
            </CollapsibleContent>
          </Collapsible>
        )}
        
        {(hasComputedFieldError || totalComputedFields > 0) && (
          <Collapsible open={isOpen} onOpenChange={setIsOpen} className="p-4 backdrop-blur-sm bg-blue-500/5 rounded-lg border border-blue-500/10 text-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Info className="h-4 w-4 text-blue-400" />
                <span className="font-medium">
                  {totalComputedFields > 0 
                    ? `${totalComputedFields} Computed Fields Detected` 
                    : "Computed Fields Detected"}
                </span>
              </div>
              <CollapsibleTrigger asChild>
                <Button variant="ghost" size="sm" className="p-1 h-auto hover:bg-white/10">
                  {isOpen ? "Hide Details" : "Show Details"}
                </Button>
              </CollapsibleTrigger>
            </div>
            
            <CollapsibleContent className="mt-3">
              <p>Your Airtable has fields that are computed or have formulas:</p>
              
              {Object.keys(allComputedFields).length > 0 ? (
                <div className="mt-3 space-y-3">
                  {Object.entries(allComputedFields).map(([table, fields]) => (
                    <div key={table} className="bg-white/5 p-3 rounded-lg">
                      <p className="font-medium text-xs">{table}:</p>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {fields.map(field => (
                          <Badge key={field} variant="outline" className="bg-blue-500/10 border-blue-400/20 text-xs">
                            {field}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="italic text-sm mt-2">
                  No specific computed fields identified yet. Run a sync test to detect them.
                </p>
              )}
              
              <div className="mt-3 bg-blue-500/5 p-3 rounded-lg">
                <p className="font-medium">Information:</p>
                <ol className="list-decimal ml-5 mt-2">
                  <li>Computed fields are being handled automatically</li>
                  <li>The app will read values from computed fields properly</li>
                  <li>During write operations, computed fields will be skipped</li>
                  <li>
                    If you see "computed field" errors, they've been detected and the 
                    app will adapt future syncs automatically
                  </li>
                </ol>
              </div>
              
              {hasComputedFieldError && (
                <div className="bg-blue-500/10 p-3 rounded-lg mt-3">
                  <p className="font-medium">Computed Fields Solution:</p>
                  <p className="text-xs mt-2">
                    The app has now detected your computed fields and will skip writing to them.
                    Try running the sync again - it should work now!
                  </p>
                </div>
              )}
            </CollapsibleContent>
          </Collapsible>
        )}
        
        {hasConnectionIssue && (
          <div className="backdrop-blur-sm bg-red-500/5 p-4 rounded-lg border border-red-500/20 text-sm mt-3">
            <p className="font-medium">Connection Issue Detected</p>
            <ul className="list-disc pl-5 mt-2 text-xs space-y-1">
              <li>Double-check that your Personal Access Token is correct and not expired</li>
              <li>Verify that the API key has proper permissions to the base</li>
              <li>Confirm that your Base ID is correct (should start with "app")</li>
              <li>Make sure network connectivity to Airtable is working</li>
            </ul>
          </div>
        )}
        
        {Object.keys(syncErrors).filter(k => k !== 'connection').length > 0 && (
          <ul className="mt-3 list-disc pl-5 text-sm bg-white/5 p-3 rounded-lg">
            {Object.entries(syncErrors)
              .filter(([key]) => key !== 'connection')
              .map(([key, error]) => (
                <li key={key} className="mb-1"><span className="font-medium">{key}:</span> {error}</li>
              ))}
          </ul>
        )}
        
        <div className="mt-4">
          <Button 
            variant="secondary" 
            size="sm" 
            onClick={() => window.location.href = '/settings?tab=sync-test'}
            className="text-xs backdrop-blur-lg bg-white/10 hover:bg-white/20 border border-white/10 shadow-[0_4px_12px_rgba(0,0,0,0.1)]"
          >
            Go to Sync Test Tools
            <ExternalLink className="ml-1 h-3 w-3" />
          </Button>
        </div>
      </AlertDescription>
    </Alert>
  );
};

export default AirtableSyncErrors;
