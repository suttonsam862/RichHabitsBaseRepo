
import React from 'react';
import { Badge } from "@/components/custom/badge";
import { Clock, CheckCircle2, AlertTriangle, Database } from "lucide-react";

interface ConnectionStatus {
  checked: boolean;
  success: boolean;
  message: string;
  details?: any;
}

interface AirtableSyncHeaderProps {
  connectionStatus: ConnectionStatus;
  tableType?: string | null;
}

const AirtableSyncHeader: React.FC<AirtableSyncHeaderProps> = ({ 
  connectionStatus, 
  tableType 
}) => {
  return (
    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2">
      <div>
        <h3 className="text-lg font-medium flex items-center">
          <Database className="h-5 w-5 mr-2" />
          {tableType ? `Airtable ${tableType} Sync` : "Airtable Sync"}
        </h3>
        <p className="text-sm text-muted-foreground">
          Synchronize your data with Airtable
          {tableType && <span className="font-medium"> - {tableType}</span>}
        </p>
      </div>
      
      <div className="flex items-center gap-2">
        {!connectionStatus.checked ? (
          <Badge variant="outline" className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            <span>Not Checked</span>
          </Badge>
        ) : connectionStatus.success ? (
          <Badge variant="success" className="flex items-center gap-1">
            <CheckCircle2 className="h-3 w-3" />
            <span>Connected</span>
          </Badge>
        ) : (
          <Badge variant="destructive" className="flex items-center gap-1">
            <AlertTriangle className="h-3 w-3" />
            <span>Connection Issue</span>
          </Badge>
        )}
      </div>
    </div>
  );
};

export default AirtableSyncHeader;
