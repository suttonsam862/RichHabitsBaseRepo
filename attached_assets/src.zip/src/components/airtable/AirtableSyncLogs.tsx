
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

interface AirtableSyncLogsProps {
  showDetailedLogs: boolean;
  syncLogs: string[];
}

const AirtableSyncLogs = ({ showDetailedLogs, syncLogs }: AirtableSyncLogsProps) => {
  if (!showDetailedLogs) {
    return null;
  }

  return (
    <Accordion type="single" collapsible className="mt-4">
      <AccordionItem value="logs">
        <AccordionTrigger className="text-sm font-medium">
          Sync Logs
        </AccordionTrigger>
        <AccordionContent>
          <div className="bg-black text-green-400 p-2 rounded text-xs font-mono h-48 overflow-y-auto">
            {syncLogs.length > 0 ? (
              syncLogs.map((log, i) => (
                <div key={i} className="py-0.5">{log}</div>
              ))
            ) : (
              <div className="opacity-50">No logs yet. Run a sync to see detailed logs.</div>
            )}
          </div>
        </AccordionContent>
      </AccordionItem>
    </Accordion>
  );
};

export default AirtableSyncLogs;
