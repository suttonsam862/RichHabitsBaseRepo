
import { AlertTriangle, HelpCircle, BookOpen } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { knownComputedFields } from "@/services/airtableConfig";

interface AirtableTroubleshootingProps {
  showTroubleshooting: boolean;
}

const AirtableTroubleshooting = ({ showTroubleshooting }: AirtableTroubleshootingProps) => {
  if (!showTroubleshooting) {
    return null;
  }

  const flattenedComputedFields = Object.values(knownComputedFields).flat();

  return (
    <div className="mt-4 p-3 bg-gray-50 rounded-lg border border-gray-200">
      <h3 className="text-sm font-semibold mb-2 flex items-center">
        <HelpCircle className="h-4 w-4 mr-1 text-blue-500" />
        Airtable Sync Troubleshooting Guide
      </h3>
      
      <Accordion type="single" collapsible className="w-full">
        <AccordionItem value="item-1">
          <AccordionTrigger className="text-xs font-medium">
            Configuration Issues
          </AccordionTrigger>
          <AccordionContent className="text-xs space-y-2 text-muted-foreground">
            <ul className="list-disc pl-5 space-y-1">
              <li>Table names must match exactly (Airtable is case-sensitive)</li>
              <li>Base ID should start with "app..." and come from Airtable API docs</li>
              <li>The Personal Access Token may be expired or invalid</li>
              <li>
                <strong>Solution:</strong> Go to Settings → Integrations and verify all configuration
                values match exactly what's in your Airtable account
              </li>
            </ul>
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="item-2">
          <AccordionTrigger className="text-xs font-medium">
            Permission & Access Issues
          </AccordionTrigger>
          <AccordionContent className="text-xs space-y-2 text-muted-foreground">
            <ul className="list-disc pl-5 space-y-1">
              <li>Your API token may not have permission to access the base</li>
              <li>The base might be in a workspace you don't have full access to</li>
              <li>Table permissions might be restricted to read-only</li>
              <li>
                <strong>Solution:</strong> In Airtable, check that you have Editor/Creator
                permissions for the base and create a new Personal Access Token with
                full data access permissions
              </li>
            </ul>
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="item-3" className="bg-amber-50 border border-amber-100 rounded mt-2">
          <AccordionTrigger className="text-xs font-medium text-amber-800">
            Computed Field Issues (Common Problem)
          </AccordionTrigger>
          <AccordionContent className="text-xs space-y-2 text-amber-800">
            <p className="font-medium">The app has detected computed fields in your Airtable:</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Formula fields (e.g., "{flattenedComputedFields[0] || 'Lead ID'}", "{flattenedComputedFields[1] || 'Order ID'}")</li>
              <li>Auto-number fields</li>
              <li>Lookup fields from other tables</li>
              <li>Rollup fields (sums, counts, etc.)</li>
            </ul>
            <p className="font-medium mt-2">Solution:</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>The app now automatically detects and skips computed fields during sync</li>
              <li>For ID fields, the app will use its internal IDs rather than trying to write to computed fields</li>
              <li>If you continue seeing errors, go to Settings → Sync Test to identify additional computed fields</li>
              <li>You can also change these fields to regular fields in Airtable if you need to write to them</li>
            </ul>
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="item-4">
          <AccordionTrigger className="text-xs font-medium">
            Field Type Mismatch Issues
          </AccordionTrigger>
          <AccordionContent className="text-xs space-y-2 text-muted-foreground">
            <ul className="list-disc pl-5 space-y-1">
              <li>Sending a text value to a number field</li>
              <li>Sending a string to a date field with incorrect format</li>
              <li>Arrays being sent to single-select fields</li>
              <li>
                <strong>Solution:</strong> In Airtable, ensure your field types match what the
                app is sending. For example, price fields should be Currency or Number type
              </li>
            </ul>
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="item-5">
          <AccordionTrigger className="text-xs font-medium">
            Network & Rate Limit Issues
          </AccordionTrigger>
          <AccordionContent className="text-xs space-y-2 text-muted-foreground">
            <ul className="list-disc pl-5 space-y-1">
              <li>Airtable API has rate limits (5 requests per second)</li>
              <li>Network connection issues</li>
              <li>Firewalls or proxies blocking Airtable API access</li>
              <li>
                <strong>Solution:</strong> This app handles rate limiting by batching requests. 
                For network issues, try using a different network connection
              </li>
            </ul>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
      
      <div className="bg-amber-50 border border-amber-200 rounded p-2 mt-4">
        <p className="flex items-center text-xs font-medium text-amber-800 mb-1">
          <BookOpen className="h-3 w-3 mr-1" />
          Quick Solution Steps:
        </p>
        <ol className="list-decimal ml-5 text-xs text-amber-700">
          <li>Run the Test Connection in Settings to verify your credentials</li>
          <li>Use the individual table test buttons to identify specific table issues</li>
          <li>If you see computed field errors, they're now automatically detected and skipped</li>
          <li>Verify your Airtable field names match the field mapping</li>
          <li>Try clearing Airtable settings and reconfiguring from scratch</li>
        </ol>
      </div>
    </div>
  );
};

export default AirtableTroubleshooting;
