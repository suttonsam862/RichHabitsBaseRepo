
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Trash2, Building, Users, DollarSign, Calendar } from "lucide-react";
import { toast } from "sonner";

export interface Accommodation {
  id: string;
  name: string;
  location: string;
  capacity: number;
  costPerNight: number;
  totalNights: number;
  notes: string;
  addedToBudget: boolean;
}

interface AccommodationItemProps {
  accommodation: Accommodation;
  onUpdate: (accommodation: Accommodation) => void;
  onDelete: (id: string) => void;
  onAddToBudget: (accommodation: Accommodation) => void;
}

const AccommodationItem: React.FC<AccommodationItemProps> = ({
  accommodation,
  onUpdate,
  onDelete,
  onAddToBudget,
}) => {
  const totalCost = accommodation.costPerNight * accommodation.totalNights;

  const handleAddToBudget = () => {
    if (!accommodation.name) {
      toast.error("Please enter a name for this accommodation");
      return;
    }
    if (accommodation.costPerNight <= 0) {
      toast.error("Please enter a valid cost per night");
      return;
    }
    if (accommodation.totalNights <= 0) {
      toast.error("Please enter the number of nights");
      return;
    }
    
    onAddToBudget(accommodation);
  };

  return (
    <Card className="mb-4">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-medium flex justify-between items-center">
          <div className="flex items-center">
            <Building className="h-5 w-5 mr-2 text-gray-500" />
            <span>{accommodation.name || "New Accommodation"}</span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onDelete(accommodation.id)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <Label htmlFor={`name-${accommodation.id}`}>Name</Label>
            <Input
              id={`name-${accommodation.id}`}
              value={accommodation.name}
              onChange={(e) =>
                onUpdate({ ...accommodation, name: e.target.value })
              }
              placeholder="Hotel or venue name"
            />
          </div>
          <div>
            <Label htmlFor={`location-${accommodation.id}`}>Location</Label>
            <Input
              id={`location-${accommodation.id}`}
              value={accommodation.location}
              onChange={(e) =>
                onUpdate({ ...accommodation, location: e.target.value })
              }
              placeholder="Address or location"
            />
          </div>
          <div>
            <Label htmlFor={`capacity-${accommodation.id}`} className="flex items-center gap-1">
              <Users className="h-4 w-4" /> Capacity
            </Label>
            <Input
              id={`capacity-${accommodation.id}`}
              type="number"
              value={accommodation.capacity === 0 ? "" : accommodation.capacity}
              onChange={(e) =>
                onUpdate({
                  ...accommodation,
                  capacity: parseInt(e.target.value) || 0,
                })
              }
              placeholder="Number of people"
            />
          </div>
          <div>
            <Label htmlFor={`cost-${accommodation.id}`} className="flex items-center gap-1">
              <DollarSign className="h-4 w-4" /> Cost per night
            </Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2">
                $
              </span>
              <Input
                id={`cost-${accommodation.id}`}
                type="number"
                className="pl-6"
                value={accommodation.costPerNight === 0 ? "" : accommodation.costPerNight}
                onChange={(e) =>
                  onUpdate({
                    ...accommodation,
                    costPerNight: parseFloat(e.target.value) || 0,
                  })
                }
                placeholder="0.00"
              />
            </div>
          </div>
          <div>
            <Label htmlFor={`nights-${accommodation.id}`} className="flex items-center gap-1">
              <Calendar className="h-4 w-4" /> Total nights
            </Label>
            <Input
              id={`nights-${accommodation.id}`}
              type="number"
              value={accommodation.totalNights === 0 ? "" : accommodation.totalNights}
              onChange={(e) =>
                onUpdate({
                  ...accommodation,
                  totalNights: parseInt(e.target.value) || 0,
                })
              }
              placeholder="Number of nights"
            />
          </div>
          <div className="md:col-span-2">
            <Label htmlFor={`notes-${accommodation.id}`}>Notes</Label>
            <Input
              id={`notes-${accommodation.id}`}
              value={accommodation.notes}
              onChange={(e) =>
                onUpdate({ ...accommodation, notes: e.target.value })
              }
              placeholder="Additional information"
            />
          </div>
        </div>

        <div className="flex justify-between items-center mt-4 pt-3 border-t border-gray-100">
          <div className="text-sm">
            <span className="font-medium">Total cost: </span>
            <span className="font-semibold">${totalCost.toFixed(2)}</span>
            <span className="text-gray-500 ml-1">
              (${accommodation.costPerNight} × {accommodation.totalNights} nights)
            </span>
          </div>
          <Button
            variant={accommodation.addedToBudget ? "secondary" : "default"}
            size="sm"
            onClick={handleAddToBudget}
            disabled={accommodation.addedToBudget}
          >
            {accommodation.addedToBudget ? "Added to Budget" : "Add to Budget"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default AccommodationItem;
