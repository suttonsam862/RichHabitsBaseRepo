
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2 } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export interface CostItem {
  id: string;
  description: string;
  amount: number;
}

interface CampCostCategoryProps {
  title: string;
  items: CostItem[];
  onAddItem: (categoryTitle: string) => void;
  onUpdateItem: (categoryTitle: string, item: CostItem) => void;
  onRemoveItem: (categoryTitle: string, itemId: string) => void;
  className?: string;
}

const CampCostCategory: React.FC<CampCostCategoryProps> = ({
  title,
  items,
  onAddItem,
  onUpdateItem,
  onRemoveItem,
  className,
}) => {
  const totalAmount = items && Array.isArray(items) 
    ? items.reduce((sum, item) => sum + item.amount, 0) 
    : 0;

  return (
    <Card className={className}>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold flex justify-between items-center">
          <span>{title}</span>
          <span className="text-sm font-normal text-gray-500">
            Total: ${totalAmount.toFixed(2)}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!items || items.length === 0 ? (
          <Alert variant="default" className="bg-gray-50 mb-3">
            <AlertDescription>
              No items added to this category yet.
            </AlertDescription>
          </Alert>
        ) : (
          <div className="space-y-2 mb-3">
            {items.map((item) => (
              <div key={item.id} className="flex items-center gap-2">
                <Input
                  className="flex-1"
                  value={item.description}
                  onChange={(e) =>
                    onUpdateItem(title, {
                      ...item,
                      description: e.target.value,
                    })
                  }
                  placeholder="Description"
                />
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2">
                    $
                  </span>
                  <Input
                    type="number"
                    className="w-32 pl-6"
                    value={item.amount === 0 ? "" : item.amount}
                    onChange={(e) =>
                      onUpdateItem(title, {
                        ...item,
                        amount: parseFloat(e.target.value) || 0,
                      })
                    }
                    placeholder="0.00"
                  />
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onRemoveItem(title, item.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        )}
        <Button
          variant="outline"
          className="w-full"
          onClick={() => onAddItem(title)}
        >
          <Plus className="mr-2 h-4 w-4" /> Add Item
        </Button>
      </CardContent>
    </Card>
  );
};

export default CampCostCategory;
