
import React from "react";
import { Button } from "@/components/ui/button";
import { Link2, ExternalLink } from "lucide-react";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

interface IntegrationButtonProps {
  title: string;
  description: string;
  icon?: React.ReactNode;
  variant?: "default" | "outline" | "secondary";
}

const IntegrationButton: React.FC<IntegrationButtonProps> = ({
  title,
  description,
  icon = <Link2 className="mr-2 h-4 w-4" />,
  variant = "outline"
}) => {
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [integrationUrl, setIntegrationUrl] = React.useState("");
  const [apiKey, setApiKey] = React.useState("");

  const handleConnect = () => {
    // Here we would typically handle the actual integration
    console.log(`Connecting to external service: ${integrationUrl}`);
    console.log(`Using API key: ${apiKey ? "********" : "Not provided"}`);
    
    toast.success(`Connection to ${title} initiated. Authorization pending.`);
    setIsDialogOpen(false);
    
    // Reset the form
    setTimeout(() => {
      setIntegrationUrl("");
      setApiKey("");
    }, 500);
  };

  return (
    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
      <DialogTrigger asChild>
        <Button variant={variant} className="w-full justify-start">
          {icon}
          {title}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            {description}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="integration-url">Integration URL</Label>
            <div className="flex items-center gap-2">
              <Input
                id="integration-url"
                value={integrationUrl}
                onChange={(e) => setIntegrationUrl(e.target.value)}
                placeholder="https://yourexternalsite.com/api/connect"
              />
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => window.open("https://example.com/help", "_blank")}
              >
                <ExternalLink className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="api-key">API Key (Optional)</Label>
            <Input 
              id="api-key" 
              type="password" 
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="Your API key for this service"
            />
          </div>
        </div>
        <DialogFooter className="sm:justify-between">
          <Button 
            variant="secondary" 
            onClick={() => setIsDialogOpen(false)}
          >
            Cancel
          </Button>
          <Button 
            type="button" 
            onClick={handleConnect}
            disabled={!integrationUrl}
          >
            Connect Service
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default IntegrationButton;
