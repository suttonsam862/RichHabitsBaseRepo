
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { NewClientData } from "@/hooks/useClientData";

interface AddClientDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit?: (clientData: NewClientData) => Promise<void>;
}

const AddClientDialog = ({ open, onOpenChange, onSubmit }: AddClientDialogProps) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [contactFirstName, setContactFirstName] = useState("");
  const [contactLastName, setContactLastName] = useState("");
  const [notes, setNotes] = useState("");
  
  const [billingAddress, setBillingAddress] = useState("");
  const [billingAddressLine2, setBillingAddressLine2] = useState("");
  const [billingCity, setBillingCity] = useState("");
  const [billingState, setBillingState] = useState("");
  const [billingZip, setBillingZip] = useState("");
  
  const [sameAsShipping, setSameAsShipping] = useState(true);
  const [shippingAddress, setShippingAddress] = useState("");
  const [shippingAddressLine2, setShippingAddressLine2] = useState("");
  const [shippingCity, setShippingCity] = useState("");
  const [shippingState, setShippingState] = useState("");
  const [shippingZip, setShippingZip] = useState("");
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState("basic");

  const resetForm = () => {
    setName("");
    setEmail("");
    setPhone("");
    setContactFirstName("");
    setContactLastName("");
    setNotes("");
    
    setBillingAddress("");
    setBillingAddressLine2("");
    setBillingCity("");
    setBillingState("");
    setBillingZip("");
    
    setSameAsShipping(true);
    setShippingAddress("");
    setShippingAddressLine2("");
    setShippingAddressLine2("");
    setShippingCity("");
    setShippingState("");
    setShippingZip("");
    
    setActiveTab("basic");
  };

  const handleAddClient = async () => {
    if (!name) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const clientData: NewClientData = {
        name,
        email,
        phone,
        contact_first_name: contactFirstName,
        contact_last_name: contactLastName,
        billing_address: billingAddress,
        billing_address_line2: billingAddressLine2,
        billing_city: billingCity,
        billing_state: billingState,
        billing_zip: billingZip,
        shipping_address: sameAsShipping ? billingAddress : shippingAddress,
        shipping_address_line2: sameAsShipping ? billingAddressLine2 : shippingAddressLine2,
        shipping_city: sameAsShipping ? billingCity : shippingCity,
        shipping_state: sameAsShipping ? billingState : shippingState,
        shipping_zip: sameAsShipping ? billingZip : shippingZip,
        notes,
      };
      
      if (onSubmit) {
        await onSubmit(clientData);
      }
      
      resetForm();
      onOpenChange(false);
    } catch (error) {
      console.error("Error adding client:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog 
      open={open} 
      onOpenChange={(newOpen) => {
        if (!newOpen) {
          resetForm();
        }
        onOpenChange(newOpen);
      }}
    >
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add New Client</DialogTitle>
          <DialogDescription>
            Add a new client to your database.
          </DialogDescription>
        </DialogHeader>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="basic">Basic Info</TabsTrigger>
            <TabsTrigger value="billing">Billing Address</TabsTrigger>
            <TabsTrigger value="shipping">Shipping Address</TabsTrigger>
          </TabsList>
          
          <TabsContent value="basic" className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <div>
                <Label htmlFor="name" className="mb-2 block">
                  Organization Name <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter organization name"
                  required
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="email" className="mb-2 block">
                  Email Address
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter email address"
                />
              </div>
              
              <div>
                <Label htmlFor="phone" className="mb-2 block">
                  Phone Number
                </Label>
                <Input
                  id="phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="Enter phone number"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="contactFirstName" className="mb-2 block">
                  Contact First Name
                </Label>
                <Input
                  id="contactFirstName"
                  value={contactFirstName}
                  onChange={(e) => setContactFirstName(e.target.value)}
                  placeholder="Enter first name"
                />
              </div>
              
              <div>
                <Label htmlFor="contactLastName" className="mb-2 block">
                  Contact Last Name
                </Label>
                <Input
                  id="contactLastName"
                  value={contactLastName}
                  onChange={(e) => setContactLastName(e.target.value)}
                  placeholder="Enter last name"
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="notes" className="mb-2 block">
                Notes
              </Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Enter any additional notes"
                className="resize-none"
                rows={3}
              />
            </div>
          </TabsContent>
          
          <TabsContent value="billing" className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <div>
                <Label htmlFor="billingAddress" className="mb-2 block">
                  Street Address
                </Label>
                <Input
                  id="billingAddress"
                  value={billingAddress}
                  onChange={(e) => setBillingAddress(e.target.value)}
                  placeholder="Enter street address"
                />
              </div>
              
              <div>
                <Label htmlFor="billingAddressLine2" className="mb-2 block">
                  Address Line 2
                </Label>
                <Input
                  id="billingAddressLine2"
                  value={billingAddressLine2}
                  onChange={(e) => setBillingAddressLine2(e.target.value)}
                  placeholder="Apartment, suite, etc."
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <div className="col-span-2 sm:col-span-1">
                <Label htmlFor="billingCity" className="mb-2 block">
                  City
                </Label>
                <Input
                  id="billingCity"
                  value={billingCity}
                  onChange={(e) => setBillingCity(e.target.value)}
                  placeholder="Enter city"
                />
              </div>
              
              <div>
                <Label htmlFor="billingState" className="mb-2 block">
                  State
                </Label>
                <Input
                  id="billingState"
                  value={billingState}
                  onChange={(e) => setBillingState(e.target.value)}
                  placeholder="Enter state"
                />
              </div>
              
              <div>
                <Label htmlFor="billingZip" className="mb-2 block">
                  ZIP Code
                </Label>
                <Input
                  id="billingZip"
                  value={billingZip}
                  onChange={(e) => setBillingZip(e.target.value)}
                  placeholder="Enter ZIP code"
                />
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="shipping" className="space-y-4">
            <div className="mb-4">
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="sameAsShipping"
                  checked={sameAsShipping}
                  onChange={(e) => setSameAsShipping(e.target.checked)}
                  className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                />
                <Label htmlFor="sameAsShipping">
                  Same as billing address
                </Label>
              </div>
            </div>
            
            {!sameAsShipping && (
              <>
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <Label htmlFor="shippingAddress" className="mb-2 block">
                      Street Address
                    </Label>
                    <Input
                      id="shippingAddress"
                      value={shippingAddress}
                      onChange={(e) => setShippingAddress(e.target.value)}
                      placeholder="Enter street address"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="shippingAddressLine2" className="mb-2 block">
                      Address Line 2
                    </Label>
                    <Input
                      id="shippingAddressLine2"
                      value={shippingAddressLine2}
                      onChange={(e) => setShippingAddressLine2(e.target.value)}
                      placeholder="Apartment, suite, etc."
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  <div className="col-span-2 sm:col-span-1">
                    <Label htmlFor="shippingCity" className="mb-2 block">
                      City
                    </Label>
                    <Input
                      id="shippingCity"
                      value={shippingCity}
                      onChange={(e) => setShippingCity(e.target.value)}
                      placeholder="Enter city"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="shippingState" className="mb-2 block">
                      State
                    </Label>
                    <Input
                      id="shippingState"
                      value={shippingState}
                      onChange={(e) => setShippingState(e.target.value)}
                      placeholder="Enter state"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="shippingZip" className="mb-2 block">
                      ZIP Code
                    </Label>
                    <Input
                      id="shippingZip"
                      value={shippingZip}
                      onChange={(e) => setShippingZip(e.target.value)}
                      placeholder="Enter ZIP code"
                    />
                  </div>
                </div>
              </>
            )}
          </TabsContent>
        </Tabs>
        
        <DialogFooter className="flex flex-col sm:flex-row gap-2 sm:gap-0">
          <div className="flex gap-2 justify-end sm:justify-between w-full">
            <div className="flex gap-2">
              {activeTab === "basic" ? (
                <Button variant="outline" onClick={() => onOpenChange(false)}>
                  Cancel
                </Button>
              ) : (
                <Button variant="outline" onClick={() => setActiveTab(activeTab === "shipping" ? "billing" : "basic")}>
                  Back
                </Button>
              )}
            </div>
            
            <div className="flex gap-2">
              {activeTab !== "shipping" ? (
                <Button 
                  type="button" 
                  onClick={() => setActiveTab(activeTab === "basic" ? "billing" : "shipping")}
                  disabled={activeTab === "basic" && !name}
                >
                  Next
                </Button>
              ) : (
                <Button 
                  type="button" 
                  onClick={handleAddClient}
                  disabled={!name || isSubmitting}
                >
                  {isSubmitting ? "Adding..." : "Add Client"}
                </Button>
              )}
            </div>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AddClientDialog;
