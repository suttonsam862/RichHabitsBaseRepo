
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Organization } from "@/services/baseService";
import { toast } from "sonner";
import { Mail } from "lucide-react";

interface ClientContactDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  client: Organization | null;
}

const ClientContactDialog = ({ open, onOpenChange, client }: ClientContactDialogProps) => {
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");

  const handleOpenOutlook = () => {
    if (!client?.email) {
      toast.error("Client email address is missing");
      return;
    }

    // Encode the subject and body for the mailto URL
    const encodedSubject = encodeURIComponent(subject);
    const encodedBody = encodeURIComponent(message);
    
    // Create the mailto URL
    const mailtoUrl = `mailto:${client.email}?subject=${encodedSubject}&body=${encodedBody}`;
    
    // Open the user's default email client
    window.open(mailtoUrl, "_blank");
    
    toast.success("Opening email client");
    onOpenChange(false);
  };

  const resetForm = () => {
    setSubject("");
    setMessage("");
  };

  // Reset the form when the dialog opens with a different client
  if (open && client) {
    // Pre-populate the message with client details
    if (!message) {
      setMessage(`Dear ${client.contact_first_name || ""},\n\n\n\nBest regards,\nTeamWear Pro`);
    }
  }

  return (
    <Dialog 
      open={open} 
      onOpenChange={(newOpen) => {
        if (!newOpen) {
          resetForm();
        }
        onOpenChange(newOpen);
      }}
    >
      <DialogContent className="sm:max-w-[525px]">
        <DialogHeader>
          <DialogTitle>Contact Client</DialogTitle>
          <DialogDescription>
            {client ? `Send an email to ${client.name}` : "Contact client via email"}
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-1 gap-4">
            <div>
              <Label htmlFor="recipient" className="mb-2 block">
                Recipient
              </Label>
              <Input
                id="recipient"
                value={client?.email || ""}
                readOnly
                className="bg-gray-50"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 gap-4">
            <div>
              <Label htmlFor="subject" className="mb-2 block">
                Subject
              </Label>
              <Input
                id="subject"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Enter email subject"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 gap-4">
            <div>
              <Label htmlFor="message" className="mb-2 block">
                Message
              </Label>
              <Textarea
                id="message"
                rows={8}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Enter your message"
                className="resize-none"
              />
            </div>
          </div>
        </div>
        
        <DialogFooter className="flex-col sm:flex-row gap-2">
          <div className="text-xs text-muted-foreground">
            This will open your default email client.
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button onClick={handleOpenOutlook}>
              <Mail className="h-4 w-4 mr-2" /> Open in Email Client
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ClientContactDialog;
