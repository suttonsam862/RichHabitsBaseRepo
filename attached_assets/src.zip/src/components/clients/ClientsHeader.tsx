
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

interface ClientsHeaderProps {
  onAddClient: () => void;
}

const ClientsHeader = ({ onAddClient }: ClientsHeaderProps) => {
  return (
    <div className="flex justify-between items-center mb-6">
      <h1 className="text-2xl font-bold">Client Management</h1>
      <Button onClick={onAddClient}>
        <Plus className="h-4 w-4 mr-2" /> Add Client
      </Button>
    </div>
  );
};

export default ClientsHeader;
