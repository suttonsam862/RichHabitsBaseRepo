
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Building, MapPin, Phone, Mail, Edit, Trash2 } from "lucide-react";
import ClientContactDialog from "./ClientContactDialog";

interface Client {
  id: string;
  name: string;
  phone: string;
  email: string;
  billing_address: string;
  billing_address_line2: string;
  billing_city: string;
  billing_state: string;
  billing_zip: string;
  shipping_address: string;
  shipping_address_line2: string;
  shipping_city: string;
  shipping_state: string;
  shipping_zip: string;
  contact_first_name: string;
  contact_last_name: string;
  notes: string;
  created_at: string;
  updated_at: string;
}

interface ClientsListProps {
  clients: Client[];
  isLoading: boolean;
  searchQuery?: string;
  onViewClient?: (client: Client) => void;
  onEdit?: (client: Client) => void;
  onDelete?: (id: string) => void;
  onContactClient?: (client: Client) => void;
  onAddClient?: () => void;
}

const ClientsList = ({ 
  clients, 
  isLoading, 
  searchQuery,
  onViewClient, 
  onEdit, 
  onDelete,
  onContactClient,
  onAddClient
}: ClientsListProps) => {
  const [contactDialogOpen, setContactDialogOpen] = useState(false);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  
  const handleContactClick = (client: Client) => {
    setSelectedClient(client);
    if (onContactClient) {
      onContactClient(client);
    }
    setContactDialogOpen(true);
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <p className="text-muted-foreground">Loading clients...</p>
      </div>
    );
  }

  if (clients.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <Building className="w-12 h-12 text-gray-400 mb-4" />
        <p className="text-xl font-semibold mb-2">No clients found</p>
        <p className="text-muted-foreground mb-4">
          Get started by adding your first client
        </p>
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Clients</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Contact</TableHead>
              <TableHead>Address</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {clients.map((client) => (
              <TableRow key={client.id}>
                <TableCell className="font-medium">
                  <div className="flex items-center space-x-2">
                    <Building className="h-4 w-4 text-gray-500" />
                    <span>{client.name}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="space-y-1">
                    <div className="flex items-center text-sm">
                      <Phone className="h-4 w-4 text-gray-500 mr-2" />
                      {client.phone || "N/A"}
                    </div>
                    <div className="flex items-center text-sm">
                      <Mail className="h-4 w-4 text-gray-500 mr-2" />
                      {client.email || "N/A"}
                    </div>
                    <Button
                      variant="link"
                      size="sm"
                      className="px-0 text-sm font-normal h-6"
                      onClick={() => handleContactClick(client)}
                    >
                      View contact details
                    </Button>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="space-y-1">
                    <div className="flex items-start text-sm">
                      <MapPin className="h-4 w-4 text-gray-500 mr-2 mt-0.5" />
                      <div>
                        <p>{client.billing_address || "N/A"}</p>
                        {client.billing_address_line2 && (
                          <p>{client.billing_address_line2}</p>
                        )}
                        {client.billing_city && client.billing_state && (
                          <p>
                            {client.billing_city}, {client.billing_state}{" "}
                            {client.billing_zip}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex space-x-2">
                    {onEdit && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onEdit(client)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                    )}
                    {onDelete && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onDelete(client.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};

export default ClientsList;
