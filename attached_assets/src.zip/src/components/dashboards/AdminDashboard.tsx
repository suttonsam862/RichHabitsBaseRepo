
import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Sidebar from "@/components/Sidebar";
import { api } from "@/lib/api";
import { toast } from "sonner";

// Import the new component files
import DashboardHeader from "@/components/dashboards/admin/DashboardHeader";
import AttentionRequiredCard from "@/components/dashboards/admin/AttentionRequiredCard";
import TeamsGrid from "@/components/dashboards/admin/TeamsGrid";
import OrdersCard from "@/components/dashboards/admin/OrdersCard";
import DashboardMetrics from "@/components/DashboardMetrics";

const AdminDashboard = () => {
  const [stats, setStats] = useState(null);
  const [recentOrders, setRecentOrders] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");
  const [searchQuery, setSearchQuery] = useState("");

  const fetchDashboardData = async () => {
    setIsLoading(true);
    try {
      // Fetch dashboard stats
      const dashboardStats = await api.getDashboardStats();
      setStats(dashboardStats);

      // Fetch recent orders
      const orders = await api.getOrders();
      setRecentOrders(orders.slice(0, 5));
      
      toast.success("Dashboard data refreshed");
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
      toast.error("Failed to load dashboard data");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  return (
    <div className="flex min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 text-white">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <DashboardHeader 
          searchQuery={searchQuery} 
          setSearchQuery={setSearchQuery} 
          fetchDashboardData={fetchDashboardData} 
        />

        <Tabs 
          defaultValue="overview" 
          value={activeTab} 
          onValueChange={setActiveTab}
          className="w-full mb-6"
        >
          <TabsList className="grid w-full md:w-auto grid-cols-2 md:grid-cols-3 h-auto">
            <TabsTrigger value="overview" className="py-2">Overview</TabsTrigger>
            <TabsTrigger value="teams" className="py-2">Teams</TabsTrigger>
            <TabsTrigger value="orders" className="py-2">Recent Orders</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="pt-4">
            <DashboardMetrics stats={stats} isLoading={isLoading} />
            
            <div className="mt-8">
              <AttentionRequiredCard isLoading={isLoading} />
            </div>
          </TabsContent>
          
          <TabsContent value="teams" className="pt-4">
            <TeamsGrid />
          </TabsContent>
          
          <TabsContent value="orders" className="pt-4">
            <OrdersCard orders={recentOrders} isLoading={isLoading} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;
