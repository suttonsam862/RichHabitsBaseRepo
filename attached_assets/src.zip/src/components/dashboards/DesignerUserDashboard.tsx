
import { useState, useEffect } from "react";
import Sidebar from "@/components/Sidebar";
import { api } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { DesignSubmission, designService } from "@/services/designService";
import DashboardSummaryCards from "./designer/DashboardSummaryCards";
import AssignmentsTable from "./designer/AssignmentsTable";
import QuickActionsCard from "./designer/QuickActionsCard";

const DesignerUserDashboard = () => {
  const { user } = useAuth();
  const [assignments, setAssignments] = useState([]);
  const [submissions, setSubmissions] = useState<DesignSubmission[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      setIsLoading(true);
      try {
        // In a real application, you would fetch assignments and submissions
        // specific to the logged-in designer
        const allSubmissions = await designService.getDesignSubmissions();
        setSubmissions(allSubmissions.slice(0, 5));
        
        // Mock assignments data
        setAssignments([
          {
            id: '1',
            order_id: '12345',
            design_type: 'Jersey Design',
            due_date: '2023-06-15',
            status: 'in-progress',
            client_name: 'Springfield High School'
          },
          {
            id: '2',
            order_id: '12346',
            design_type: 'Logo Design',
            due_date: '2023-06-20',
            status: 'not-started',
            client_name: 'Shelbyville Youth Soccer'
          },
          {
            id: '3',
            order_id: '12347',
            design_type: 'Uniform Design',
            due_date: '2023-06-25',
            status: 'in-progress',
            client_name: 'Capital City Baseball'
          }
        ]);
      } catch (error) {
        console.error("Error fetching designer dashboard data:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchDashboardData();
  }, [user]);

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold">
            Rich Habits Dashboard (Designer)
          </h1>
          <p className="text-muted-foreground">
            View your design assignments and manage submissions
          </p>
        </div>

        <DashboardSummaryCards 
          isLoading={isLoading}
          assignments={assignments}
          submissions={submissions}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="col-span-2">
            <AssignmentsTable 
              assignments={assignments}
              isLoading={isLoading}
            />
          </div>

          <QuickActionsCard />
        </div>
      </div>
    </div>
  );
};

export default DesignerUserDashboard;
