
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import Sidebar from "@/components/Sidebar";
import { api } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { ArrowRight, Clock, ClipboardList, Factory, FileCheck2, Truck } from "lucide-react";
import { ProductionOrder, manufacturingService } from "@/services/manufacturingService";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const ManufacturingUserDashboard = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [productionOrders, setProductionOrders] = useState<ProductionOrder[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      setIsLoading(true);
      try {
        // In a real app, you would fetch orders assigned to this manufacturing staff member
        const orders = await manufacturingService.getProductionOrders();
        setProductionOrders(orders);
      } catch (error) {
        console.error("Error fetching manufacturing dashboard data:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchDashboardData();
  }, [user]);

  const getPriorityBadge = (priority: string) => {
    const priorityMap: {[key: string]: {color: string, label: string}} = {
      'high': { color: 'bg-red-200 text-red-800', label: 'High Priority' },
      'normal': { color: 'bg-blue-200 text-blue-800', label: 'Normal' },
      'low': { color: 'bg-gray-200 text-gray-800', label: 'Low Priority' }
    };
    
    const style = priorityMap[priority] || { color: 'bg-gray-200 text-gray-800', label: priority };
    
    return (
      <Badge className={`${style.color} font-medium`}>
        {style.label}
      </Badge>
    );
  };

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold">
            Rich Habits Dashboard (Manufacturing)
          </h1>
          <p className="text-muted-foreground">
            Track production and manage manufacturing workflow
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Production Queue</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? "Loading..." : productionOrders.length}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Orders in production
              </p>
              <div className="flex items-center mt-4">
                <Clock className="h-4 w-4 text-orange-500 mr-1" />
                <span className="text-xs text-orange-500 font-medium">
                  {productionOrders.filter(o => o.priority === 'high').length} high priority
                </span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">In Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? "Loading..." : productionOrders.filter(o => o.status === 'in-progress').length}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Orders being processed
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Ready for Shipping</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? "Loading..." : productionOrders.filter(o => o.status === 'completed').length}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Orders ready for delivery
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Weekly Production</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? "Loading..." : "24"}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Orders completed this week
              </p>
              <div className="flex items-center mt-4">
                <FileCheck2 className="h-4 w-4 text-green-500 mr-1" />
                <span className="text-xs text-green-500 font-medium">
                  On target for weekly goal
                </span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Production Orders</CardTitle>
                <CardDescription>
                  Current orders in the manufacturing pipeline
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex justify-center items-center h-48">
                    <p className="text-muted-foreground">Loading production orders...</p>
                  </div>
                ) : productionOrders.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-48">
                    <Factory className="h-12 w-12 text-gray-400 mb-4" />
                    <p className="text-xl font-semibold mb-2">No production orders</p>
                    <p className="text-muted-foreground">
                      There are no orders in the production queue
                    </p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Order ID</TableHead>
                        <TableHead>Priority</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Assigned To</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {productionOrders.map((order) => (
                        <TableRow key={order.id}>
                          <TableCell className="font-medium">
                            {order.order_id.substring(0, 8)}...
                          </TableCell>
                          <TableCell>
                            {getPriorityBadge(order.priority)}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              {order.status === 'pending' ? 'Not Started' : order.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {order.assigned_to || 'Unassigned'}
                          </TableCell>
                          <TableCell>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => navigate(`/manufacturing?order=${order.order_id}`)}
                            >
                              View Details
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
                <div className="mt-4 flex justify-end">
                  <Button variant="outline" onClick={() => navigate("/manufacturing")}>
                    View All Orders <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>
                Common manufacturing tasks
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" className="w-full justify-start" onClick={() => navigate("/manufacturing")}>
                <Factory className="mr-2 h-4 w-4" />
                Production Control
              </Button>
              <Button variant="outline" className="w-full justify-start" onClick={() => navigate("/orders")}>
                <ClipboardList className="mr-2 h-4 w-4" />
                View All Orders
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Truck className="mr-2 h-4 w-4" />
                Shipping Dashboard
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ManufacturingUserDashboard;
