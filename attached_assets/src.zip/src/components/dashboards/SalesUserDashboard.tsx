
import { useState, useEffect } from "react";
import Sidebar from "@/components/Sidebar";
import { api, Lead } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import DashboardHeader from "./sales/DashboardHeader";
import SalesMetricsCards from "./sales/SalesMetricsCards";
import ActiveLeadsCard from "./sales/ActiveLeadsCard";
import RecentOrdersCard from "./sales/RecentOrdersCard";
import SalesQuickActions from "./sales/SalesQuickActions";
import UpcomingTasksCard from "./sales/UpcomingTasksCard";

const SalesUserDashboard = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState<any>(null);
  const [recentOrders, setRecentOrders] = useState([]);
  const [activeLeads, setActiveLeads] = useState<Lead[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Calculate today's date and current month/quarter
  const today = new Date();
  const currentMonth = today.toLocaleString('default', { month: 'long' });
  const currentQuarter = Math.floor(today.getMonth() / 3) + 1;
  const previousMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1).toLocaleString('default', { month: 'long' });

  const fetchDashboardData = async () => {
    setIsLoading(true);
    try {
      // Fetch dashboard stats
      const dashboardStats = await api.getDashboardStats();
      setStats(dashboardStats);

      // Fetch recent orders
      const orders = await api.getOrders();
      setRecentOrders(orders.slice(0, 5));

      // Fetch active leads
      const leads = await api.getLeads();
      const userLeads = leads.filter(lead => 
        (lead.owner === user?.email || !lead.owner) && 
        lead.status !== "closed-won" && 
        lead.status !== "closed-lost"
      );
      setActiveLeads(userLeads);
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
      toast.error("Failed to load dashboard data");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [user]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchDashboardData();
    setRefreshing(false);
    toast.success("Dashboard refreshed");
  };

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <DashboardHeader 
          refreshing={refreshing} 
          handleRefresh={handleRefresh} 
        />

        <SalesMetricsCards 
          isLoading={isLoading}
          activeLeads={activeLeads}
          currentMonth={currentMonth}
          previousMonth={previousMonth}
        />

        <div className="grid grid-cols-1 gap-6 mb-8">
          <ActiveLeadsCard 
            isLoading={isLoading}
            activeLeads={activeLeads}
          />
        </div>

        <div className="grid grid-cols-1 gap-6">
          <RecentOrdersCard
            isLoading={isLoading}
            recentOrders={recentOrders}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-8">
          <SalesQuickActions />
          <UpcomingTasksCard />
        </div>
      </div>
    </div>
  );
};

export default SalesUserDashboard;
