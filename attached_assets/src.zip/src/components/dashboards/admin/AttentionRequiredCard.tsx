
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { AlertTriangle, Activity, Loader2, ArrowRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface AttentionRequiredCardProps {
  isLoading: boolean;
}

const AttentionRequiredCard = ({ isLoading }: AttentionRequiredCardProps) => {
  const navigate = useNavigate();
  const [leads, setLeads] = useState<any[]>([]);
  const [ordersNeedingAttention, setOrdersNeedingAttention] = useState<any[]>([]);
  const [fetchingLeads, setFetchingLeads] = useState(false);

  useEffect(() => {
    if (!isLoading) {
      fetchLeadsAndAttentionItems();
    }
  }, [isLoading]);

  const fetchLeadsAndAttentionItems = async () => {
    setFetchingLeads(true);
    try {
      // Fetch unassigned leads
      const { data: leadsData, error: leadsError } = await supabase
        .from('leads')
        .select('*')
        .is('owner', null)
        .not('status', 'eq', 'closed-won')
        .not('status', 'eq', 'closed-lost')
        .order('created_at', { ascending: false })
        .limit(3);
        
      if (leadsError) throw leadsError;
      
      // Fetch orders needing attention
      const { data: ordersData, error: ordersError } = await supabase
        .from('orders')
        .select('*')
        .in('status', ['draft', 'submitted'])
        .is('assigned_to', null)
        .order('created_at', { ascending: false })
        .limit(3);
        
      if (ordersError) throw ordersError;
      
      setLeads(leadsData || []);
      setOrdersNeedingAttention(ordersData || []);
    } catch (error) {
      console.error("Error fetching attention items:", error);
      toast.error("Failed to load attention items");
    } finally {
      setFetchingLeads(false);
    }
  };

  return (
    <Card className="bg-gray-800 border-gray-700 shadow-xl">
      <CardHeader>
        <CardTitle className="text-xl text-white flex items-center">
          <AlertTriangle className="mr-2 h-5 w-5 text-yellow-400" />
          Needs Attention
        </CardTitle>
        <CardDescription className="text-gray-400">
          Items that require your immediate attention
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading || fetchingLeads ? (
          <div className="space-y-3">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="border border-gray-700 rounded-lg p-4 animate-pulse">
                <div className="h-4 bg-gray-700 rounded w-1/4 mb-3"></div>
                <div className="h-3 bg-gray-700 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-700 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        ) : leads.length === 0 && ordersNeedingAttention.length === 0 ? (
          <div className="text-center py-8 border border-gray-700 rounded-lg">
            <Activity className="h-12 w-12 text-gray-500 mx-auto mb-3" />
            <h3 className="text-lg font-medium text-white mb-1">All caught up!</h3>
            <p className="text-gray-400 mb-4">
              There are no items that need your attention right now.
            </p>
            <Button 
              variant="outline" 
              onClick={fetchLeadsAndAttentionItems}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              <Loader2 className="mr-2 h-4 w-4" />
              Refresh
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {leads.map(lead => (
              <div 
                key={lead.id} 
                className="border border-gray-700 rounded-lg p-4 hover:border-blue-500 transition-colors cursor-pointer"
                onClick={() => navigate(`/leads/${lead.id}`)}
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-2">
                  <div>
                    <h3 className="font-medium text-white">{lead.name}</h3>
                    <p className="text-sm text-gray-400">{lead.organization || "No Organization"}</p>
                  </div>
                  <Badge className="mt-2 md:mt-0 bg-yellow-800 text-yellow-200">
                    Unassigned Lead
                  </Badge>
                </div>
                <div className="flex justify-between items-center mt-2 pt-2 border-t border-gray-700">
                  <div className="text-sm text-gray-400">
                    Created: {new Date(lead.created_at).toLocaleDateString()}
                  </div>
                  <Button variant="ghost" size="sm" className="text-blue-400 hover:text-blue-300 p-0">
                    View Details <ArrowRight className="ml-1 h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
            
            {ordersNeedingAttention.map(order => (
              <div 
                key={order.id} 
                className="border border-gray-700 rounded-lg p-4 hover:border-blue-500 transition-colors cursor-pointer"
                onClick={() => navigate(`/orders/${order.id}`)}
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-2">
                  <div>
                    <h3 className="font-medium text-white">{order.customer_name || "Customer #" + order.customer_id?.substring(0, 8)}</h3>
                    <p className="text-sm text-gray-400">Order #{order.id.substring(0, 8)}</p>
                  </div>
                  <Badge className="mt-2 md:mt-0 bg-blue-800 text-blue-200">
                    {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                  </Badge>
                </div>
                <div className="flex justify-between items-center mt-2 pt-2 border-t border-gray-700">
                  <div className="text-sm text-gray-400">
                    Created: {new Date(order.created_at).toLocaleDateString()}
                  </div>
                  <Button variant="ghost" size="sm" className="text-blue-400 hover:text-blue-300 p-0">
                    View Details <ArrowRight className="ml-1 h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
        
        <div className="mt-4 flex justify-end">
          <Button 
            variant="outline" 
            onClick={() => navigate("/leads")}
            className="border-gray-600 text-gray-200 hover:bg-gray-700"
          >
            View All Leads <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default AttentionRequiredCard;
