
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";
import OrderTable from "@/components/OrderTable";

interface OrdersCardProps {
  orders: any[];
  isLoading: boolean;
}

const OrdersCard = ({ orders, isLoading }: OrdersCardProps) => {
  const navigate = useNavigate();

  return (
    <Card className="bg-gray-800 border-gray-700 shadow-xl">
      <CardHeader>
        <CardTitle className="text-xl text-white">Recent Orders</CardTitle>
        <CardDescription className="text-gray-400">
          Your most recent orders and their status
        </CardDescription>
      </CardHeader>
      <CardContent>
        <OrderTable orders={orders} isLoading={isLoading} />
        <div className="mt-4 flex justify-end">
          <Button 
            variant="outline" 
            onClick={() => navigate("/orders")}
            className="border-gray-600 text-gray-200 hover:bg-gray-700"
          >
            View All Orders <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default OrdersCard;
