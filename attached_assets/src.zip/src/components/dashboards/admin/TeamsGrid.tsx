
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, Calendar } from "lucide-react";
import { useNavigate } from "react-router-dom";

const TeamsGrid = () => {
  const navigate = useNavigate();

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card className="bg-gray-800 border-gray-700 shadow-xl hover:shadow-2xl transition-shadow duration-300 hover:border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-xl text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-600">Design Team</CardTitle>
          <CardDescription className="text-gray-400">
            Manage designers and their assignments
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4 text-gray-300">
            Oversee design team personnel, view submissions, and track design completion.
          </p>
          <Button onClick={() => navigate("/design")} className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
            Access Design Hub <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700 shadow-xl hover:shadow-2xl transition-shadow duration-300 hover:border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-xl text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-600">Manufacturing Team</CardTitle>
          <CardDescription className="text-gray-400">
            Manage production staff and workflows
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4 text-gray-300">
            Monitor production staff, track manufacturing progress, and manage resource allocation.
          </p>
          <Button onClick={() => navigate("/manufacturing")} className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
            Access Production Control <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700 shadow-xl hover:shadow-2xl transition-shadow duration-300 hover:border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-xl text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-600">Sales Team</CardTitle>
          <CardDescription className="text-gray-400">
            Manage sales personnel and track performance
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4 text-gray-300">
            Monitor sales performance, manage team members, and track commission payouts.
          </p>
          <Button onClick={() => navigate("/sales-people")} className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
            Manage Sales Team <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700 shadow-xl hover:shadow-2xl transition-shadow duration-300 hover:border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-xl text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-600">Client Communications</CardTitle>
          <CardDescription className="text-gray-400">
            Manage client emails and communications
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4 text-gray-300">
            Connect with Outlook to view and manage all client communications in one place.
          </p>
          <Button onClick={() => navigate("/client-emails")} className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
            Access Client Emails <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700 shadow-xl hover:shadow-2xl transition-shadow duration-300 hover:border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-xl text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-600">Camp Management</CardTitle>
          <CardDescription className="text-gray-400">
            Organize sports camps and events
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4 text-gray-300">
            Plan and manage sports camps, track registrations, budget, and logistics.
          </p>
          <Button onClick={() => navigate("/camp-management")} className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
            Access Camp Management <ArrowRight className="ml-2 h-4 w-4" />
            <Calendar className="ml-2 h-4 w-4" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default TeamsGrid;
