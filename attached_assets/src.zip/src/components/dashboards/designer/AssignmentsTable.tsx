
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Palette } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface Assignment {
  id: string;
  order_id: string;
  design_type: string;
  due_date: string;
  status: string;
  client_name: string;
}

interface AssignmentsTableProps {
  assignments: Assignment[];
  isLoading: boolean;
}

const AssignmentsTable = ({ assignments, isLoading }: AssignmentsTableProps) => {
  const navigate = useNavigate();

  const getStatusBadge = (status: string) => {
    const statusMap: {[key: string]: {color: string, label: string}} = {
      'not-started': { color: 'bg-gray-200 text-gray-800', label: 'Not Started' },
      'in-progress': { color: 'bg-blue-200 text-blue-800', label: 'In Progress' },
      'completed': { color: 'bg-green-200 text-green-800', label: 'Completed' },
      'pending': { color: 'bg-yellow-200 text-yellow-800', label: 'Pending Review' },
      'approved': { color: 'bg-green-200 text-green-800', label: 'Approved' },
      'rejected': { color: 'bg-red-200 text-red-800', label: 'Needs Revision' }
    };
    
    const style = statusMap[status] || { color: 'bg-gray-200 text-gray-800', label: status };
    
    return (
      <Badge className={`${style.color} font-medium`}>
        {style.label}
      </Badge>
    );
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Current Assignments</CardTitle>
        <CardDescription>
          Designs you need to work on
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center items-center h-48">
            <p className="text-muted-foreground">Loading assignments...</p>
          </div>
        ) : assignments.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48">
            <Palette className="h-12 w-12 text-gray-400 mb-4" />
            <p className="text-xl font-semibold mb-2">No active assignments</p>
            <p className="text-muted-foreground">
              You don't have any designs assigned to you yet
            </p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Client</TableHead>
                <TableHead>Design Type</TableHead>
                <TableHead>Due Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {assignments.map((assignment) => (
                <TableRow key={assignment.id}>
                  <TableCell className="font-medium">
                    {assignment.client_name}
                  </TableCell>
                  <TableCell>{assignment.design_type}</TableCell>
                  <TableCell>
                    {new Date(assignment.due_date).toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    {getStatusBadge(assignment.status)}
                  </TableCell>
                  <TableCell>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => navigate(`/design?order=${assignment.order_id}`)}
                    >
                      View Details
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
};

export default AssignmentsTable;
