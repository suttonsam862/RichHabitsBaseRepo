
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle2, Clock } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { DesignSubmission } from "@/services/designService";

interface DashboardSummaryCardsProps {
  isLoading: boolean;
  assignments: any[];
  submissions: DesignSubmission[];
}

const DashboardSummaryCards = ({ isLoading, assignments, submissions }: DashboardSummaryCardsProps) => {
  const navigate = useNavigate();

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Active Assignments</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            {isLoading ? "Loading..." : assignments.filter(a => a.status !== 'completed').length}
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Designs requiring your attention
          </p>
          <div className="flex items-center mt-4">
            <Clock className="h-4 w-4 text-orange-500 mr-1" />
            <span className="text-xs text-orange-500 font-medium">
              {assignments.filter(a => new Date(a.due_date) < new Date(Date.now() + 86400000 * 3)).length} due soon
            </span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Completed Designs</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            {isLoading ? "Loading..." : submissions.filter(s => s.status === 'approved').length}
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Designs approved this month
          </p>
          <div className="flex items-center mt-4">
            <CheckCircle2 className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-xs text-green-500 font-medium">
              Good completion rate
            </span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Pending Review</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            {isLoading ? "Loading..." : submissions.filter(s => s.status === 'pending').length}
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Designs awaiting feedback
          </p>
          <Button 
            variant="link" 
            className="px-0 mt-4" 
            onClick={() => navigate("/design")}
          >
            View all submissions <ArrowRight className="h-4 w-4 ml-1" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default DashboardSummaryCards;
