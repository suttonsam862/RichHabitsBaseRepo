
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FileImage, Palette, PanelRight } from "lucide-react";
import { useNavigate } from "react-router-dom";

const QuickActionsCard = () => {
  const navigate = useNavigate();
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
        <CardDescription>
          Common design tasks
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-2">
        <Button variant="outline" className="w-full justify-start" onClick={() => navigate("/design")}>
          <Palette className="mr-2 h-4 w-4" />
          Design Hub
        </Button>
        <Button variant="outline" className="w-full justify-start">
          <FileImage className="mr-2 h-4 w-4" />
          Upload Design
        </Button>
        <Button variant="outline" className="w-full justify-start">
          <PanelRight className="mr-2 h-4 w-4" />
          View Design Library
        </Button>
      </CardContent>
    </Card>
  );
};

export default QuickActionsCard;
