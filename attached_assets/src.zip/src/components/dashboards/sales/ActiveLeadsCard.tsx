
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";
import LeadCard from "@/components/LeadCard";
import CreateLeadButton from "@/components/leads/CreateLeadButton";
import { Lead } from "@/lib/api";

interface ActiveLeadsCardProps {
  isLoading: boolean;
  activeLeads: Lead[];
}

const ActiveLeadsCard = ({ isLoading, activeLeads }: ActiveLeadsCardProps) => {
  const navigate = useNavigate();

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Active Leads</CardTitle>
          <CardDescription>
            Your leads that need attention
          </CardDescription>
        </div>
        <CreateLeadButton variant="outline" size="sm" />
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {isLoading ? (
            Array(3).fill(0).map((_, i) => (
              <Card key={i} className="h-[320px] opacity-50"></Card>
            ))
          ) : activeLeads.length === 0 ? (
            <div className="text-center col-span-3 py-8 text-muted-foreground">
              <Users className="mx-auto h-12 w-12 text-gray-300 mb-2" />
              <p className="mb-2">No active leads found</p>
              <CreateLeadButton variant="outline" size="sm" />
            </div>
          ) : (
            activeLeads.slice(0, 3).map((lead) => (
              <LeadCard
                key={lead.id}
                lead={{
                  id: lead.id,
                  name: lead.name,
                  organization: lead.organization,
                  email: lead.email,
                  phone: lead.phone,
                  status: lead.status,
                  notes: lead.notes || null,
                  dateCreated: lead.dateCreated
                }}
                onClick={() => navigate(`/leads/${lead.id}`)}
              />
            ))
          )}
        </div>
        {activeLeads.length > 0 && (
          <div className="mt-4 flex justify-end">
            <Button variant="outline" onClick={() => navigate("/leads")}>
              View All Leads <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ActiveLeadsCard;
