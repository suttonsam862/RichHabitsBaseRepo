
import { Button } from "@/components/ui/button";
import { RefreshCw, Plus } from "lucide-react";
import CreateLeadButton from "@/components/leads/CreateLeadButton";

interface DashboardHeaderProps {
  refreshing: boolean;
  handleRefresh: () => void;
}

const DashboardHeader = ({ refreshing, handleRefresh }: DashboardHeaderProps) => {
  return (
    <div className="flex justify-between items-center mb-6">
      <div>
        <h1 className="text-2xl font-bold">
          Rich Habits Dashboard (Sales)
        </h1>
        <p className="text-muted-foreground">
          Manage your sales activities and track performance
        </p>
      </div>
      
      <div className="flex gap-2">
        <Button 
          variant="outline" 
          size="icon"
          onClick={handleRefresh}
          disabled={refreshing}
        >
          <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
        </Button>
        <CreateLeadButton variant="default" />
      </div>
    </div>
  );
};

export default DashboardHeader;
