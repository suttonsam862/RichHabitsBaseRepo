
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, Plus } from "lucide-react";
import { useNavigate } from "react-router-dom";
import OrderTable from "@/components/OrderTable";

interface RecentOrdersCardProps {
  isLoading: boolean;
  recentOrders: any[];
}

const RecentOrdersCard = ({ isLoading, recentOrders }: RecentOrdersCardProps) => {
  const navigate = useNavigate();

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Recent Orders</CardTitle>
          <CardDescription>
            Your most recent orders and their status
          </CardDescription>
        </div>
        <Button variant="outline" size="sm" onClick={() => navigate("/orders/new")}>
          <Plus className="mr-2 h-4 w-4" />
          New Order
        </Button>
      </CardHeader>
      <CardContent>
        <OrderTable 
          orders={recentOrders} 
          isLoading={isLoading} 
        />
        <div className="mt-4 flex justify-end">
          <Button variant="outline" onClick={() => navigate("/orders")}>
            View All Orders <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default RecentOrdersCard;
