
import { formatCurrency } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Lead } from "@/lib/api";

interface MetricsCardProps {
  isLoading: boolean;
  activeLeads: Lead[];
  currentMonth: string;
  previousMonth: string;
}

const SalesMetricsCards = ({ isLoading, activeLeads, currentMonth, previousMonth }: MetricsCardProps) => {
  const navigate = useNavigate();

  // Calculate time-based KPIs
  const getTimeBasedMetric = (value: number, targetValue: number, label: string) => {
    const percentOfTarget = Math.min(100, Math.round((value / targetValue) * 100));
    
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">{label}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            {isLoading ? "Loading..." : formatCurrency(value)}
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            {label === "This Month's Sales" ? `+${Math.round(Math.random() * 20)}% from ${previousMonth}` : 
             `${percentOfTarget}% of ${label.toLowerCase()} goal`}
          </p>
          <div className="mt-4 h-1 w-full bg-gray-200 rounded">
            <div 
              className={`h-1 rounded ${percentOfTarget > 75 ? 'bg-green-500' : percentOfTarget > 40 ? 'bg-yellow-500' : 'bg-red-500'}`} 
              style={{ width: `${percentOfTarget}%` }}
            ></div>
          </div>
          <div className="mt-1 text-xs text-muted-foreground">
            Target: {formatCurrency(targetValue)}
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      {getTimeBasedMetric(45231.89, 60000, "This Month's Sales")}
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Open Leads</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            {isLoading ? "Loading..." : activeLeads.length}
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            {activeLeads.length} leads requiring attention
          </p>
          <div className="flex justify-between mt-4">
            <div className="flex items-center gap-1 text-xs">
              <div className="h-2 w-2 rounded-full bg-blue-500"></div>
              <span>New: {activeLeads.filter(l => l.status === 'prospect').length}</span>
            </div>
            <div className="flex items-center gap-1 text-xs">
              <div className="h-2 w-2 rounded-full bg-yellow-500"></div>
              <span>In progress: {activeLeads.filter(l => ['discovery', 'qualified', 'negotiation'].includes(l.status)).length}</span>
            </div>
          </div>
          <Button 
            variant="link" 
            className="px-0 mt-2" 
            onClick={() => navigate("/leads")}
          >
            View all leads <ArrowRight className="h-4 w-4 ml-1" />
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Orders This Month</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            {isLoading ? "Loading..." : "12"}
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            +2 from last week
          </p>
          <div className="flex justify-between mt-4">
            <div className="flex items-center gap-1 text-xs">
              <div className="h-2 w-2 rounded-full bg-green-500"></div>
              <span>Completed: 5</span>
            </div>
            <div className="flex items-center gap-1 text-xs">
              <div className="h-2 w-2 rounded-full bg-blue-500"></div>
              <span>In progress: 7</span>
            </div>
          </div>
          <Button 
            variant="link" 
            className="px-0 mt-2" 
            onClick={() => navigate("/orders")}
          >
            View all orders <ArrowRight className="h-4 w-4 ml-1" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default SalesMetricsCards;
