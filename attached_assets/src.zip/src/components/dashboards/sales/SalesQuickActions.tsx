
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Clipboard, BarChart2 } from "lucide-react";
import { useNavigate } from "react-router-dom";

const SalesQuickActions = () => {
  const navigate = useNavigate();

  return (
    <Card className="col-span-1">
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
        <CardDescription>
          Common tasks to get things done
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-2">
        <Button variant="outline" className="w-full justify-start" onClick={() => navigate("/leads")}>
          <Users className="mr-2 h-4 w-4" />
          Manage Leads
        </Button>
        <Button variant="outline" className="w-full justify-start" onClick={() => navigate("/orders/new")}>
          <Clipboard className="mr-2 h-4 w-4" />
          Create New Order
        </Button>
        <Button variant="outline" className="w-full justify-start" onClick={() => navigate("/clients")}>
          <Users className="mr-2 h-4 w-4" />
          View Clients
        </Button>
        <Button variant="outline" className="w-full justify-start" onClick={() => navigate("/reports")}>
          <BarChart2 className="mr-2 h-4 w-4" />
          Sales Reports
        </Button>
      </CardContent>
    </Card>
  );
};

export default SalesQuickActions;
