
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Pencil, Calendar, ArchiveX, Clock } from "lucide-react";

const UpcomingTasksCard = () => {
  return (
    <Card className="col-span-3">
      <CardHeader>
        <CardTitle>Upcoming Tasks</CardTitle>
        <CardDescription>Your scheduled tasks for the week</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="p-3 border rounded-md flex justify-between items-center">
            <div className="flex items-center">
              <Pencil className="h-4 w-4 mr-2 text-blue-500" />
              <span>Follow up with East High School</span>
            </div>
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-1 text-yellow-500" />
              <span className="text-sm">Today</span>
            </div>
          </div>
          <div className="p-3 border rounded-md flex justify-between items-center">
            <div className="flex items-center">
              <Calendar className="h-4 w-4 mr-2 text-purple-500" />
              <span>Send design mockups to Westview College</span>
            </div>
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-1 text-yellow-500" />
              <span className="text-sm">Tomorrow</span>
            </div>
          </div>
          <div className="p-3 border rounded-md flex justify-between items-center">
            <div className="flex items-center">
              <ArchiveX className="h-4 w-4 mr-2 text-green-500" />
              <span>Prepare quarterly client renewal report</span>
            </div>
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-1" />
              <span className="text-sm">In 3 days</span>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-end">
        <Button variant="outline" size="sm">View All Tasks</Button>
      </CardFooter>
    </Card>
  );
};

export default UpcomingTasksCard;
