
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { toast } from "sonner";
import { Pencil, Plus, Send } from "lucide-react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { quickbooksService } from "@/services/quickbooksService";

const invoiceSchema = z.object({
  customer: z.string().min(1, "Customer is required"),
  amount: z.string().min(1, "Amount is required"),
  dueDate: z.string().min(1, "Due date is required"),
  description: z.string().optional(),
});

interface InvoiceData {
  id: string;
  customer: string;
  amount: number;
  date: string;
  dueDate: string;
  status: "draft" | "sent" | "paid" | "overdue";
  description?: string;
}

const sampleInvoices: InvoiceData[] = [
  {
    id: "INV-001",
    customer: "ABC School District",
    amount: 4500.00,
    date: "2023-09-15",
    dueDate: "2023-10-15",
    status: "paid",
    description: "Team uniforms and equipment"
  },
  {
    id: "INV-002",
    customer: "XYZ Sports Academy",
    amount: 2750.00,
    date: "2023-10-01",
    dueDate: "2023-10-31",
    status: "sent",
    description: "Custom jerseys for basketball team"
  },
  {
    id: "INV-003",
    customer: "Regional Athletics Association",
    amount: 6200.00,
    date: "2023-10-10",
    dueDate: "2023-11-10",
    status: "draft",
    description: "Equipment for winter sports season"
  },
  {
    id: "INV-004",
    customer: "City Recreation Department",
    amount: 3800.00,
    date: "2023-09-25",
    dueDate: "2023-10-25",
    status: "overdue",
    description: "Summer camp uniforms and gear"
  },
];

const InvoicesList = () => {
  const [invoices, setInvoices] = useState<InvoiceData[]>(sampleInvoices);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isSendDialogOpen, setIsSendDialogOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<InvoiceData | null>(null);
  const [isQuickBooksConnected, setIsQuickBooksConnected] = useState(false);
  const [isSending, setIsSending] = useState(false);

  const form = useForm<z.infer<typeof invoiceSchema>>({
    resolver: zodResolver(invoiceSchema),
    defaultValues: {
      customer: "",
      amount: "",
      dueDate: new Date().toISOString().split('T')[0],
      description: "",
    },
  });

  const handleCreateInvoice = (values: z.infer<typeof invoiceSchema>) => {
    const newInvoice: InvoiceData = {
      id: `INV-00${invoices.length + 1}`,
      customer: values.customer,
      amount: parseFloat(values.amount),
      date: new Date().toISOString().split('T')[0],
      dueDate: values.dueDate,
      status: "draft",
      description: values.description,
    };
    
    setInvoices([...invoices, newInvoice]);
    setIsCreateDialogOpen(false);
    form.reset();
    
    toast.success("Invoice created successfully");
  };

  const handleSendToQuickBooks = async () => {
    if (!selectedInvoice) return;
    
    setIsSending(true);
    
    try {
      // Check if QuickBooks service is configured
      if (!quickbooksService.instance) {
        // In a real app, this would be handled better
        const dummyConfig = {
          oauthToken: "dummy-token",
          oauthTokenSecret: "dummy-secret",
          consumerKey: "dummy-key",
          consumerSecret: "dummy-secret",
          realmId: "dummy-realm",
          useSandbox: true
        };
        quickbooksService.initialize(dummyConfig);
      }
      
      if (quickbooksService.instance) {
        await quickbooksService.instance.createInvoice(
          {
            customer: selectedInvoice.customer,
            amount: selectedInvoice.amount,
            description: selectedInvoice.description || "",
            dueDate: selectedInvoice.dueDate
          },
          selectedInvoice.id
        );
        
        // Update invoice status
        setInvoices(invoices.map(inv => 
          inv.id === selectedInvoice.id ? {...inv, status: "sent"} : inv
        ));
        
        toast.success(`Invoice ${selectedInvoice.id} sent to QuickBooks`);
      } else {
        throw new Error("QuickBooks service not initialized");
      }
    } catch (error) {
      console.error("Error sending to QuickBooks:", error);
      toast.error("Failed to send invoice to QuickBooks. Please check your connection.");
    } finally {
      setIsSending(false);
      setIsSendDialogOpen(false);
    }
  };

  const handleConnectQuickBooks = () => {
    // This would typically open OAuth flow for QuickBooks
    toast.success("QuickBooks connected successfully.");
    setIsQuickBooksConnected(true);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return <Badge className="bg-green-500">Paid</Badge>;
      case "sent":
        return <Badge className="bg-blue-500">Sent</Badge>;
      case "draft":
        return <Badge variant="outline">Draft</Badge>;
      case "overdue":
        return <Badge className="bg-red-500">Overdue</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Invoices</h2>
        <Button onClick={() => setIsCreateDialogOpen(true)}>
          <Plus className="h-4 w-4 mr-2" /> Create Invoice
        </Button>
      </div>
      
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Invoice #</TableHead>
            <TableHead>Customer</TableHead>
            <TableHead>Amount</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Due Date</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {invoices.map((invoice) => (
            <TableRow key={invoice.id}>
              <TableCell>{invoice.id}</TableCell>
              <TableCell>{invoice.customer}</TableCell>
              <TableCell>${invoice.amount.toFixed(2)}</TableCell>
              <TableCell>{new Date(invoice.date).toLocaleDateString()}</TableCell>
              <TableCell>{new Date(invoice.dueDate).toLocaleDateString()}</TableCell>
              <TableCell>{getStatusBadge(invoice.status)}</TableCell>
              <TableCell>
                <div className="flex space-x-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      // Edit functionality would go here
                      toast.info("Edit functionality coming soon");
                    }}
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => {
                      setSelectedInvoice(invoice);
                      setIsSendDialogOpen(true);
                    }}
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      
      {/* Create Invoice Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Create New Invoice</DialogTitle>
            <DialogDescription>
              Fill in the details to create a new invoice
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleCreateInvoice)} className="space-y-4">
              <FormField
                control={form.control}
                name="customer"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Customer</FormLabel>
                    <FormControl>
                      <Input placeholder="Customer name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Amount</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" placeholder="0.00" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="dueDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Due Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Input placeholder="Invoice description" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button variant="outline" type="button" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Create Invoice</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Send to QuickBooks Dialog */}
      <Dialog open={isSendDialogOpen} onOpenChange={setIsSendDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Send to QuickBooks</DialogTitle>
            <DialogDescription>
              Send invoice {selectedInvoice?.id} to QuickBooks
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {selectedInvoice && (
              <div className="space-y-2">
                <div className="grid grid-cols-4 gap-2">
                  <div className="text-sm font-medium">Customer:</div>
                  <div className="col-span-3">{selectedInvoice.customer}</div>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  <div className="text-sm font-medium">Amount:</div>
                  <div className="col-span-3">${selectedInvoice.amount.toFixed(2)}</div>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  <div className="text-sm font-medium">Due Date:</div>
                  <div className="col-span-3">{new Date(selectedInvoice.dueDate).toLocaleDateString()}</div>
                </div>
                {selectedInvoice.description && (
                  <div className="grid grid-cols-4 gap-2">
                    <div className="text-sm font-medium">Description:</div>
                    <div className="col-span-3">{selectedInvoice.description}</div>
                  </div>
                )}
              </div>
            )}
            
            {!isQuickBooksConnected && (
              <div className="bg-yellow-50 p-4 rounded-md border border-yellow-200">
                <h4 className="text-yellow-800 font-medium">QuickBooks Not Connected</h4>
                <p className="text-yellow-700 text-sm mt-1">Connect to QuickBooks to send invoices.</p>
                <Button 
                  variant="outline" 
                  className="mt-2"
                  onClick={handleConnectQuickBooks}
                >
                  Connect to QuickBooks
                </Button>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsSendDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleSendToQuickBooks} 
              disabled={!isQuickBooksConnected || isSending}
            >
              {isSending ? "Sending..." : "Send to QuickBooks"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default InvoicesList;
