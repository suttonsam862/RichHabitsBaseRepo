
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Payment {
  id: string;
  customer: string;
  amount: number;
  date: string;
  method: string;
  status: string;
  invoiceId: string;
}

const payments: Payment[] = [
  {
    id: "PMT-001",
    customer: "ABC School District",
    amount: 4500.00,
    date: "2023-09-20",
    method: "Credit Card",
    status: "completed",
    invoiceId: "INV-001"
  },
  {
    id: "PMT-002",
    customer: "City Recreation Department",
    amount: 1200.00,
    date: "2023-10-05",
    method: "Bank Transfer",
    status: "processing",
    invoiceId: "INV-004"
  },
  {
    id: "PMT-003",
    customer: "XYZ Sports Academy",
    amount: 750.00,
    date: "2023-10-12",
    method: "Check",
    status: "completed",
    invoiceId: "INV-002"
  }
];

const PaymentProcessing = () => {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-500">Completed</Badge>;
      case "processing":
        return <Badge className="bg-blue-500">Processing</Badge>;
      case "failed":
        return <Badge className="bg-red-500">Failed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Payment ID</TableHead>
            <TableHead>Customer</TableHead>
            <TableHead>Amount</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Method</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Invoice</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {payments.map((payment) => (
            <TableRow key={payment.id}>
              <TableCell>{payment.id}</TableCell>
              <TableCell>{payment.customer}</TableCell>
              <TableCell>${payment.amount.toFixed(2)}</TableCell>
              <TableCell>{new Date(payment.date).toLocaleDateString()}</TableCell>
              <TableCell>{payment.method}</TableCell>
              <TableCell>{getStatusBadge(payment.status)}</TableCell>
              <TableCell>{payment.invoiceId}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Payment Methods</CardTitle>
            <CardDescription>Distribution of payment methods</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Credit Card</span>
                <span>45%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '45%' }}></div>
              </div>
              
              <div className="flex justify-between">
                <span>Bank Transfer</span>
                <span>30%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div className="bg-green-600 h-2.5 rounded-full" style={{ width: '30%' }}></div>
              </div>
              
              <div className="flex justify-between">
                <span>Check</span>
                <span>20%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div className="bg-purple-600 h-2.5 rounded-full" style={{ width: '20%' }}></div>
              </div>
              
              <div className="flex justify-between">
                <span>Other</span>
                <span>5%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div className="bg-yellow-600 h-2.5 rounded-full" style={{ width: '5%' }}></div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Payment Status</CardTitle>
            <CardDescription>Overview of payment statuses</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Completed</span>
                <span>82%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div className="bg-green-600 h-2.5 rounded-full" style={{ width: '82%' }}></div>
              </div>
              
              <div className="flex justify-between">
                <span>Processing</span>
                <span>15%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '15%' }}></div>
              </div>
              
              <div className="flex justify-between">
                <span>Failed</span>
                <span>3%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div className="bg-red-600 h-2.5 rounded-full" style={{ width: '3%' }}></div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PaymentProcessing;
