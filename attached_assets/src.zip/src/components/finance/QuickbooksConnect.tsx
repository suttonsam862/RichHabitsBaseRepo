
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Switch } from "@/components/ui/switch";
import { QuickBooks } from "@/services/quickbooksService";
import { CreditCard, Receipt, ArrowUpDown } from "lucide-react";

const QuickbooksConnect = () => {
  const [isConnecting, setIsConnecting] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [consumerKey, setConsumerKey] = useState("");
  const [consumerSecret, setConsumerSecret] = useState("");
  const [realmId, setRealmId] = useState("");
  const [oauthToken, setOauthToken] = useState("");
  const [oauthTokenSecret, setOauthTokenSecret] = useState("");
  const [autoSync, setAutoSync] = useState(false);
  const [syncInvoices, setSyncInvoices] = useState(true);
  const [syncPayments, setSyncPayments] = useState(true);
  const [syncExpenses, setSyncExpenses] = useState(true);
  
  const handleConnect = async () => {
    if (!consumerKey || !consumerSecret || !realmId || !oauthToken || !oauthTokenSecret) {
      toast.error("Please fill in all required fields");
      return;
    }

    setIsConnecting(true);
    try {
      const qb = new QuickBooks({
        consumerKey,
        consumerSecret,
        realmId,
        oauthToken,
        oauthTokenSecret,
        useSandbox: true
      });

      const success = await qb.testConnection();
      
      if (success) {
        setIsConnected(true);
        toast.success("Successfully connected to QuickBooks");
      } else {
        toast.error("Failed to connect to QuickBooks");
      }
    } catch (error) {
      console.error("Error connecting to QuickBooks:", error);
      toast.error("Error connecting to QuickBooks. Please check your credentials.");
    } finally {
      setIsConnecting(false);
    }
  };
  
  const handleSyncNow = () => {
    toast.success("Sync initiated with QuickBooks");
    
    // In a real app, this would trigger actual sync processes
    setTimeout(() => {
      toast.success("QuickBooks sync completed successfully");
    }, 2000);
  };

  return (
    <div className="space-y-6">
      {isConnected ? (
        <div className="space-y-6">
          <div className="bg-green-50 border border-green-200 rounded-md p-4">
            <h3 className="text-green-800 font-medium">Connected to QuickBooks</h3>
            <p className="text-green-600 text-sm mt-1">Your account is successfully connected to QuickBooks</p>
            <div className="flex space-x-2 mt-2">
              <Button 
                variant="outline" 
                className="text-green-700 border-green-300 hover:bg-green-100"
                onClick={handleSyncNow}
              >
                <ArrowUpDown className="h-4 w-4 mr-2" />
                Sync Now
              </Button>
              <Button 
                variant="outline" 
                className="text-red-700 border-red-300 hover:bg-red-100"
                onClick={() => setIsConnected(false)}
              >
                Disconnect
              </Button>
            </div>
          </div>
          
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-lg font-medium mb-4">Sync Settings</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="auto-sync" className="font-medium">Auto Sync</Label>
                      <p className="text-sm text-muted-foreground">Automatically sync data with QuickBooks</p>
                    </div>
                    <Switch 
                      id="auto-sync" 
                      checked={autoSync} 
                      onCheckedChange={setAutoSync} 
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="sync-invoices" className="font-medium">
                        <Receipt className="h-4 w-4 inline mr-1" /> Invoices
                      </Label>
                      <p className="text-sm text-muted-foreground">Sync invoices with QuickBooks</p>
                    </div>
                    <Switch 
                      id="sync-invoices" 
                      checked={syncInvoices} 
                      onCheckedChange={setSyncInvoices} 
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="sync-payments" className="font-medium">
                        <CreditCard className="h-4 w-4 inline mr-1" /> Payments
                      </Label>
                      <p className="text-sm text-muted-foreground">Sync payments with QuickBooks</p>
                    </div>
                    <Switch 
                      id="sync-payments" 
                      checked={syncPayments} 
                      onCheckedChange={setSyncPayments} 
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="sync-expenses" className="font-medium">Expenses</Label>
                      <p className="text-sm text-muted-foreground">Sync expenses with QuickBooks</p>
                    </div>
                    <Switch 
                      id="sync-expenses" 
                      checked={syncExpenses} 
                      onCheckedChange={setSyncExpenses} 
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-lg font-medium mb-4">Sync History</h3>
                <div className="space-y-3">
                  <div className="bg-gray-50 p-3 rounded-md border">
                    <div className="flex justify-between">
                      <span className="font-medium">Full Sync</span>
                      <span className="text-sm text-muted-foreground">2023-10-15 09:30 AM</span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">Synchronized 24 invoices, 18 payments, 12 expenses</p>
                  </div>
                  
                  <div className="bg-gray-50 p-3 rounded-md border">
                    <div className="flex justify-between">
                      <span className="font-medium">Invoices Sync</span>
                      <span className="text-sm text-muted-foreground">2023-10-14 02:15 PM</span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">Synchronized 8 new invoices</p>
                  </div>
                  
                  <div className="bg-gray-50 p-3 rounded-md border">
                    <div className="flex justify-between">
                      <span className="font-medium">Payments Sync</span>
                      <span className="text-sm text-muted-foreground">2023-10-13 11:45 AM</span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">Synchronized 5 new payments</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      ) : (
        <Card>
          <CardContent className="pt-6">
            <h3 className="text-lg font-medium mb-4">Connect to QuickBooks</h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="consumerKey">Consumer Key</Label>
                <Input 
                  id="consumerKey" 
                  value={consumerKey} 
                  onChange={(e) => setConsumerKey(e.target.value)} 
                  placeholder="Enter QuickBooks Consumer Key"
                />
              </div>
              
              <div>
                <Label htmlFor="consumerSecret">Consumer Secret</Label>
                <Input 
                  id="consumerSecret" 
                  value={consumerSecret} 
                  onChange={(e) => setConsumerSecret(e.target.value)}
                  type="password"
                  placeholder="Enter QuickBooks Consumer Secret"
                />
              </div>
              
              <div>
                <Label htmlFor="realmId">Realm ID</Label>
                <Input 
                  id="realmId" 
                  value={realmId} 
                  onChange={(e) => setRealmId(e.target.value)} 
                  placeholder="Enter QuickBooks Realm ID"
                />
              </div>
              
              <div>
                <Label htmlFor="oauthToken">OAuth Token</Label>
                <Input 
                  id="oauthToken" 
                  value={oauthToken} 
                  onChange={(e) => setOauthToken(e.target.value)} 
                  placeholder="Enter OAuth Token"
                />
              </div>
              
              <div>
                <Label htmlFor="oauthTokenSecret">OAuth Token Secret</Label>
                <Input 
                  id="oauthTokenSecret" 
                  value={oauthTokenSecret} 
                  onChange={(e) => setOauthTokenSecret(e.target.value)}
                  type="password"
                  placeholder="Enter OAuth Token Secret"
                />
              </div>
              
              <Button 
                onClick={handleConnect} 
                disabled={isConnecting}
                className="w-full"
              >
                {isConnecting ? "Connecting..." : "Connect to QuickBooks"}
              </Button>
              
              <div className="text-center mt-2">
                <a 
                  href="https://developer.intuit.com/app/developer/qbo/docs/get-started"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-blue-600 hover:underline"
                >
                  How to get QuickBooks API credentials?
                </a>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default QuickbooksConnect;
