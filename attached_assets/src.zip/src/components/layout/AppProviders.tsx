
import { ReactNode } from "react";
import { BrowserRouter as Router } from "react-router-dom";
import { AuthProvider } from "@/context/AuthContext";
import { TutorialProvider } from "@/components/tutorial/TutorialContext";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "sonner";

interface AppProvidersProps {
  children: ReactNode;
}

export function AppProviders({ children }: AppProvidersProps) {
  return (
    <Router>
      <AuthProvider>
        <TutorialProvider>
          {children}
          <Toaster />
          <SonnerToaster position="top-right" />
        </TutorialProvider>
      </AuthProvider>
    </Router>
  );
}
