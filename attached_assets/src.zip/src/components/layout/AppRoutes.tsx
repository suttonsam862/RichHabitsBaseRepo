
import { Routes, Route, useRoutes } from "react-router-dom";
import { routes } from "@/App.routes";

export function AppRoutes() {
  // Using useRoutes hook for cleaner route definitions
  const routeElements = useRoutes(routes);
  
  return routeElements;
}
