
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import CreateLeadDialog from "./CreateLeadDialog";
import { useState } from "react";

interface CreateLeadButtonProps {
  onLeadCreated?: () => void;
  variant?: "default" | "outline" | "ghost" | "link" | "destructive" | "secondary";
  size?: "default" | "sm" | "lg" | "icon";
  className?: string;
}

const CreateLeadButton = ({ 
  onLeadCreated, 
  variant = "default", 
  size = "default",
  className
}: CreateLeadButtonProps) => {
  const [dialogOpen, setDialogOpen] = useState(false);

  const handleClick = () => {
    setDialogOpen(true);
  };

  const handleLeadCreated = () => {
    if (onLeadCreated) {
      onLeadCreated();
    }
    setDialogOpen(false);
  };

  const handleDialogClose = () => {
    setDialogOpen(false);
  };

  return (
    <>
      <Button 
        variant={variant} 
        size={size} 
        onClick={handleClick} 
        id="create-lead-trigger"
        className={className}
      >
        <Plus className="h-4 w-4 mr-2" />
        Create Lead
      </Button>
      
      {dialogOpen && (
        <CreateLeadDialog 
          onLeadCreated={handleLeadCreated} 
          onClose={handleDialogClose}
          trigger={<span style={{ display: 'none' }}></span>}
        />
      )}
    </>
  );
};

export default CreateLeadButton;
