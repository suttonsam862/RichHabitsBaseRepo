
import React from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Phone, Mail, Building, Calendar, User, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { Lead } from "@/services/baseService";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

interface LeadDetailProps {
  lead: Lead | null;
  isOpen: boolean;
  onClose: () => void;
  onDelete: (id: string) => void;
}

const LeadDetail = ({ lead, isOpen, onClose, onDelete }: LeadDetailProps) => {
  if (!lead) return null;

  const getStatusColor = (status: string) => {
    switch (status) {
      case "prospect":
        return "bg-blue-100 text-blue-800";
      case "discovery":
        return "bg-purple-100 text-purple-800";
      case "qualified":
        return "bg-green-100 text-green-800";
      case "negotiation":
        return "bg-orange-100 text-orange-800";
      case "closed-won":
        return "bg-green-500 text-white";
      case "closed-lost":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "PPP");
    } catch (error) {
      return "Invalid date";
    }
  };

  const handleDelete = () => {
    onDelete(lead.id);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>{lead.name}</span>
            <Badge className={getStatusColor(lead.status)}>
              {lead.status.replace("-", " ")}
            </Badge>
          </DialogTitle>
          <DialogDescription>
            Lead details and contact information
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="flex items-start space-x-2">
            <Building className="h-4 w-4 text-gray-500 mt-0.5" />
            <div>
              <p className="font-medium">{lead.organization}</p>
              {lead.estimated_value && (
                <p className="text-sm text-gray-500">
                  Est. Value: ${lead.estimated_value.toLocaleString()}
                </p>
              )}
            </div>
          </div>

          {lead.email && (
            <div className="flex items-center space-x-2">
              <Mail className="h-4 w-4 text-gray-500" />
              <a
                href={`mailto:${lead.email}`}
                className="text-blue-600 hover:underline"
              >
                {lead.email}
              </a>
            </div>
          )}

          {lead.phone && (
            <div className="flex items-center space-x-2">
              <Phone className="h-4 w-4 text-gray-500" />
              <a
                href={`tel:${lead.phone}`}
                className="text-blue-600 hover:underline"
              >
                {lead.phone}
              </a>
            </div>
          )}

          {lead.owner && (
            <div className="flex items-center space-x-2">
              <User className="h-4 w-4 text-gray-500" />
              <span>Owner: {lead.owner}</span>
            </div>
          )}

          <div className="flex items-center space-x-2">
            <Calendar className="h-4 w-4 text-gray-500" />
            <span>Created: {formatDate(lead.created_at)}</span>
          </div>

          {lead.notes && (
            <div className="pt-2">
              <p className="text-sm font-medium mb-1">Notes:</p>
              <p className="text-sm text-gray-700 whitespace-pre-wrap bg-gray-50 p-3 rounded-md">
                {lead.notes}
              </p>
            </div>
          )}
        </div>

        <DialogFooter className="flex justify-between sm:justify-between">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="sm">
                <Trash2 className="h-4 w-4 mr-2" />
                Delete Lead
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete the lead "{lead.name}" from {lead.organization}. 
                  This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default LeadDetail;
