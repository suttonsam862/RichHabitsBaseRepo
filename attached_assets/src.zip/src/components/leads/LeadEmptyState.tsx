
import { Button } from "@/components/ui/button";
import { SearchX, RefreshCw } from "lucide-react";

interface LeadEmptyStateProps {
  searchQuery?: string;
  onClearSearch?: () => void;
}

const LeadEmptyState = ({ 
  searchQuery = "", 
  onClearSearch = () => {} 
}: LeadEmptyStateProps) => {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      {searchQuery ? (
        <>
          <SearchX className="h-16 w-16 text-muted-foreground mb-4" />
          <h3 className="text-xl font-semibold mb-2">No matching leads found</h3>
          <p className="text-muted-foreground mb-6 max-w-md">
            We couldn't find any leads matching your search query "{searchQuery}".
          </p>
          <Button onClick={onClearSearch} variant="outline">
            <RefreshCw className="mr-2 h-4 w-4" />
            Clear Search
          </Button>
        </>
      ) : (
        <>
          <SearchX className="h-16 w-16 text-muted-foreground mb-4" />
          <h3 className="text-xl font-semibold mb-2">No leads available</h3>
          <p className="text-muted-foreground mb-6 max-w-md">
            There are no leads available at the moment. Create a new lead or try again later.
          </p>
        </>
      )}
    </div>
  );
};

export default LeadEmptyState;
