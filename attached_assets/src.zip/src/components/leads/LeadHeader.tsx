
import { Button } from "@/components/ui/button";
import { Plus, RefreshCw, Upload } from "lucide-react";
import { airtableService } from "@/services/airtableService";

interface LeadHeaderProps {
  isAdmin: boolean;
  isSyncing: boolean;
  handleSyncLeads: () => Promise<void>;
  handleCreateLead: () => void;
}

const LeadHeader = ({ isAdmin, isSyncing, handleSyncLeads, handleCreateLead }: LeadHeaderProps) => {
  return (
    <div className="flex justify-between items-center mb-6">
      <div>
        <h1 className="text-2xl font-bold">Lead Management</h1>
        <p className="text-muted-foreground">
          Track and manage potential customers
        </p>
      </div>
      <div className="flex space-x-2">
        {isAdmin && (
          <Button 
            variant="outline" 
            onClick={handleSyncLeads}
            disabled={isSyncing || !airtableService.isInitialized()}
          >
            {isSyncing ? (
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Upload className="h-4 w-4 mr-2" />
            )}
            Sync with Airtable
          </Button>
        )}
        <Button onClick={handleCreateLead}>
          <Plus className="h-4 w-4 mr-2" />
          Create Lead
        </Button>
      </div>
    </div>
  );
};

export default LeadHeader;
