
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import LeadCard from "@/components/LeadCard";
import LeadEmptyState from "@/components/leads/LeadEmptyState";
import { Organization, Lead } from "@/services/baseService";
import LeadSyncError from "@/components/leads/LeadSyncError";
import { Loader2, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";

interface LeadListProps {
  leads: Lead[] | any[]; // Accept both Supabase Leads and API Leads
  isLoading: boolean;
  error: string | null;
  refetch?: () => void;
  organizations?: Organization[];
  searchQuery?: string;
  onClearSearch?: () => void;
  onViewLead?: (leadId: string) => void;
}

const LeadList = ({ 
  leads, 
  isLoading, 
  error, 
  refetch = () => {}, 
  organizations = [],
  searchQuery = "",
  onClearSearch = () => {},
  onViewLead
}: LeadListProps) => {
  const navigate = useNavigate();
  const [showSyncError, setShowSyncError] = useState(false);

  const handleLeadClick = (leadId: string) => {
    if (onViewLead) {
      onViewLead(leadId);
    } else {
      navigate(`/leads/${leadId}`);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-48">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-4">
        <p className="text-red-500">Error: {error}</p>
        <button onClick={refetch} className="text-blue-500 hover:underline">
          Retry
        </button>
      </div>
    );
  }

  if (!leads || leads.length === 0) {
    return <LeadEmptyState searchQuery={searchQuery} onClearSearch={onClearSearch} />;
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {leads.map((lead) => {
        // Find the organization if it exists
        let organization = null;
        if (organizations && organizations.length > 0) {
          organization = organizations.find((org) => org.name === lead.organization);
        }
        
        return (
          <div key={lead.id} className="relative">
            <LeadCard
              lead={lead}
              organization={organization}
              onClick={() => handleLeadClick(lead.id)}
            />
            {onViewLead && (
              <Button 
                size="sm" 
                variant="ghost" 
                className="absolute top-2 right-2"
                onClick={(e) => {
                  e.stopPropagation();
                  onViewLead(lead.id);
                }}
              >
                <Eye className="h-4 w-4" />
              </Button>
            )}
          </div>
        );
      })}
      {showSyncError && <LeadSyncError onClose={() => setShowSyncError(false)} />}
    </div>
  );
};

export default LeadList;
