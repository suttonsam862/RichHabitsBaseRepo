
import { Button } from "@/components/ui/button";
import { AlertCircle, X } from "lucide-react";

interface LeadSyncErrorProps {
  onClose?: () => void;
  message?: string;
}

const LeadSyncError = ({ onClose = () => {}, message = "There was an error synchronizing your data with the database." }: LeadSyncErrorProps) => {
  return (
    <div className="fixed bottom-4 right-4 bg-red-50 border border-red-200 rounded-lg p-4 shadow-lg max-w-md">
      <div className="flex items-start">
        <div className="flex-shrink-0">
          <AlertCircle className="h-5 w-5 text-red-500" />
        </div>
        <div className="ml-3">
          <h3 className="text-sm font-medium text-red-800">
            Database Sync Error
          </h3>
          <div className="mt-2 text-sm text-red-700">
            <p>{message}</p>
          </div>
          <div className="mt-4">
            <Button
              size="sm"
              variant="outline"
              className="text-red-700 bg-red-50 hover:bg-red-100"
            >
              Try Again
            </Button>
          </div>
        </div>
        <div className="ml-auto pl-3">
          <Button
            size="sm"
            variant="ghost"
            className="inline-flex rounded-md text-red-500 hover:text-red-700 focus:outline-none"
            onClick={onClose}
          >
            <span className="sr-only">Dismiss</span>
            <X className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default LeadSyncError;
