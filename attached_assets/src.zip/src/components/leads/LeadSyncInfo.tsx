
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { 
  AlertTriangle, 
  ExternalLink, 
  Settings, 
  CheckCircle2, 
  Info, 
  RefreshCw,
  Database,
  Shield,
} from "lucide-react";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";

interface LeadSyncInfoProps {
  lastSyncTime: Date | null;
  isSuccess: boolean;
  errorMessage?: string | null;
  navigateToSettings: () => void;
}

const LeadSyncInfo = ({ 
  lastSyncTime, 
  isSuccess, 
  errorMessage, 
  navigateToSettings 
}: LeadSyncInfoProps) => {
  const [isOpen, setIsOpen] = useState(false);

  if (!lastSyncTime) return null;

  if (isSuccess && !errorMessage) {
    return (
      <Alert className="mb-6 backdrop-blur-xl bg-green-500/5 border border-green-500/20 shadow-[0_8px_16px_rgba(0,0,0,0.15)]">
        <CheckCircle2 className="h-5 w-5 text-green-500" />
        <AlertTitle className="text-lg font-medium mb-2">Sync Successful</AlertTitle>
        <AlertDescription className="space-y-3">
          <p className="text-slate-900 dark:text-white">
            Data synchronized at {lastSyncTime.toLocaleString()}.
            <Badge variant="outline" className="ml-2 text-xs font-normal bg-green-500/10 border-green-500/20">
              Supabase
            </Badge>
          </p>

          <Collapsible open={isOpen} onOpenChange={setIsOpen} className="backdrop-blur-sm bg-green-500/5 p-4 rounded-lg border border-green-500/20 mt-3">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium flex items-center">
                <Info className="h-4 w-4 mr-1 text-green-500" />
                Database Information
              </p>
              <CollapsibleTrigger asChild>
                <Button variant="ghost" size="sm" className="p-1 h-auto hover:bg-white/10">
                  {isOpen ? "Hide" : "Show"}
                </Button>
              </CollapsibleTrigger>
            </div>
            
            <CollapsibleContent className="mt-2">
              <div className="space-y-3">
                <div>
                  <p className="text-sm font-medium">Troubleshooting Tips</p>
                  <ul className="list-disc pl-5 text-sm mt-1">
                    <li className="mb-1">
                      <strong>Data not showing up?</strong> Make sure you've refreshed the page.
                    </li>
                    <li className="mb-1">
                      <strong>Changes not saving?</strong> Check your network connection and try again.
                    </li>
                  </ul>
                </div>
                
                <div className="bg-green-200/80 p-2 rounded flex items-start gap-2">
                  <Database className="h-4 w-4 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Supabase Database</p>
                    <p className="text-xs">Your data is now being stored in Supabase, a modern database service built on PostgreSQL.</p>
                  </div>
                </div>
              </div>
            </CollapsibleContent>
          </Collapsible>
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Alert 
      variant="destructive" 
      className="mb-6 backdrop-blur-xl bg-white/10 border border-white/20 shadow-[0_8px_32px_rgba(0,0,0,0.15)] text-slate-900 dark:text-white"
    >
      <AlertTriangle className="h-5 w-5 text-red-500" />
      <AlertTitle className="text-lg font-medium mb-2">Sync Error</AlertTitle>
      <AlertDescription className="space-y-3">
        <p>
          {errorMessage 
            ? `Failed to sync data at ${lastSyncTime.toLocaleString()}`
            : `Sync operation completed at ${lastSyncTime.toLocaleString()} but no data changes were detected`
          }
        </p>
        
        {errorMessage && (
          <div className="bg-amber-100 p-2 rounded mt-1">
            <p className="text-sm font-medium flex items-center">
              <AlertTriangle className="h-4 w-4 mr-1" />
              Error Details:
            </p>
            <p className="text-xs mt-1">{errorMessage}</p>
          </div>
        )}
        
        <Collapsible open={isOpen} onOpenChange={setIsOpen} className="bg-red-50 p-2 rounded">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Troubleshooting</span>
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" className="p-1 h-auto">
                {isOpen ? "Hide" : "Show"}
              </Button>
            </CollapsibleTrigger>
          </div>
          
          <CollapsibleContent className="mt-2">
            <div className="bg-red-100 p-2 rounded mt-2">
              <p className="font-medium text-sm">Possible Solutions:</p>
              <ul className="list-disc pl-5 mt-1 text-sm">
                <li className="mb-1">
                  <strong>Database Connection:</strong> Check if your database connection is configured correctly
                </li>
                <li className="mb-1">
                  <strong>Network Issues:</strong> Ensure you have a stable internet connection
                </li>
                <li className="mb-1">
                  <strong>Database Permissions:</strong> Verify that you have the correct permissions to access the database
                </li>
              </ul>
            </div>
          </CollapsibleContent>
        </Collapsible>
        
        <div className="flex gap-2">
          <Button 
            variant="secondary" 
            size="sm" 
            onClick={navigateToSettings}
            className="flex-1 backdrop-blur-lg bg-white/10 hover:bg-white/20 border border-white/10 shadow-[0_4px_12px_rgba(0,0,0,0.1)]"
          >
            <Settings className="h-4 w-4 mr-2" />
            Database Settings
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => window.location.reload()}
            className="flex-1 backdrop-blur-lg bg-white/10 hover:bg-white/20 border border-white/10 shadow-[0_4px_12px_rgba(0,0,0,0.1)]"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh Data
          </Button>
        </div>
      </AlertDescription>
    </Alert>
  );
};

export default LeadSyncInfo;
