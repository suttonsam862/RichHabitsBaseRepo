
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, Truck } from "lucide-react";
import { ManufacturingFormData } from "@/types/manufacturing";

interface ManufacturingFormProps {
  formData: ManufacturingFormData;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  onSubmit: (e: React.FormEvent) => void;
}

const ManufacturingForm = ({ formData, onChange, onSubmit }: ManufacturingFormProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Truck className="mr-2 h-5 w-5" />
          Manufacturing Submission Form
        </CardTitle>
        <CardDescription>
          Provide details for the manufacturing team
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={onSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">
              Tracking Number (Optional)
            </label>
            <Input
              name="trackingNumber"
              value={formData.trackingNumber}
              onChange={onChange}
              placeholder="Enter tracking number if available"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">
              Manufacturing Notes
            </label>
            <Textarea
              name="notes"
              value={formData.notes}
              onChange={onChange}
              placeholder="Add any special instructions or notes for the manufacturing team"
              rows={5}
            />
          </div>

          <div className="pt-4">
            <Button type="submit" className="w-full">
              <CheckCircle className="mr-2 h-4 w-4" />
              Submit to Manufacturing
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default ManufacturingForm;
