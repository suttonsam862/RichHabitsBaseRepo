
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Info } from "lucide-react";
import { Order } from "@/types/manufacturing";

interface OrderSummaryCardProps {
  order: Order;
}

const OrderSummaryCard = ({ order }: OrderSummaryCardProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Order Summary</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-medium text-muted-foreground">Customer</h3>
            <p className="font-medium">{order.organizations?.name || "Unknown"}</p>
          </div>
          
          <div>
            <h3 className="text-sm font-medium text-muted-foreground">Order Status</h3>
            <div className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold bg-amber-100 text-amber-800 mt-0.5">
              {order.status}
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-medium text-muted-foreground">Order Total</h3>
            <p className="font-medium">${order.total?.toFixed(2) || "0.00"}</p>
          </div>
          
          <div>
            <h3 className="text-sm font-medium text-muted-foreground">Items</h3>
            <ul className="mt-1 space-y-1">
              {order.line_items?.map((item) => (
                <li key={item.id} className="text-sm">
                  {item.quantity}x {item.product_name || "Product"} 
                  {item.size && <span> - Size: {item.size}</span>}
                  {item.color && <span> - Color: {item.color}</span>}
                </li>
              ))}
            </ul>
          </div>
          
          <div className="border-t pt-4 mt-4">
            <div className="flex items-start">
              <Info className="h-5 w-5 text-blue-500 mr-2 mt-0.5" />
              <p className="text-sm text-muted-foreground">
                Once submitted, the manufacturing team will be notified and the order status will be updated.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default OrderSummaryCard;
