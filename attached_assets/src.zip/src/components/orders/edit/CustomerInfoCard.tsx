
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Organization } from "@/lib/api";
import { OrderFormData } from "./types";

interface CustomerInfoCardProps {
  selectedOrganization: string;
  setSelectedOrganization: (value: string) => void;
  orderDetails: OrderFormData;
  setOrderDetails: (value: OrderFormData) => void;
  organizations: Organization[];
}

const CustomerInfoCard = ({
  selectedOrganization,
  setSelectedOrganization,
  orderDetails,
  setOrderDetails,
  organizations
}: CustomerInfoCardProps) => {
  return (
    <Card className="lg:col-span-1">
      <CardHeader>
        <CardTitle>Customer Information</CardTitle>
        <CardDescription>
          Select the customer for this order
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="organization">Customer</Label>
          <Select 
            value={selectedOrganization} 
            onValueChange={setSelectedOrganization}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select customer" />
            </SelectTrigger>
            <SelectContent>
              {organizations.map(org => (
                <SelectItem key={org.id} value={org.id}>
                  {org.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="mt-4 pt-4 border-t space-y-2">
          <Label>Order Details</Label>
          
          <div className="space-y-2">
            <Label htmlFor="status">Status</Label>
            <Select 
              value={orderDetails.status} 
              onValueChange={(value: any) => setOrderDetails({...orderDetails, status: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="submitted">Submitted</SelectItem>
                <SelectItem value="design">Design</SelectItem>
                <SelectItem value="manufacturing">Manufacturing</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="assignedTo">Assigned To</Label>
            <Input 
              id="assignedTo" 
              value={orderDetails.assignedTo}
              onChange={(e) => setOrderDetails({...orderDetails, assignedTo: e.target.value})}
              placeholder="Sales rep name"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="notes">Order Notes</Label>
            <Textarea 
              id="notes" 
              value={orderDetails.notes}
              onChange={(e) => setOrderDetails({...orderDetails, notes: e.target.value})}
              placeholder="Add any notes about this order"
              rows={3}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default CustomerInfoCard;
