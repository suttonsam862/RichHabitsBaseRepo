
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Save, ArrowLeft } from "lucide-react";
import CustomerInfoCard from "./CustomerInfoCard";
import OrderItemsCard from "./OrderItemsCard";
import { OrderFormData, OrderItemData } from "./types";

interface OrderEditFormProps {
  id: string;
  order: any;
  products: any[];
  organizations: any[];
  isLoading: boolean;
}

const OrderEditForm = ({ id, order, products, organizations, isLoading }: OrderEditFormProps) => {
  const navigate = useNavigate();
  const [isSaving, setIsSaving] = useState(false);
  const [selectedOrganization, setSelectedOrganization] = useState<string>("");
  const [orderItems, setOrderItems] = useState<OrderItemData[]>([]);
  const [orderDetails, setOrderDetails] = useState<OrderFormData>({
    status: "draft",
    notes: "",
    assignedTo: "",
  });

  useEffect(() => {
    if (order) {
      setOrderDetails({
        status: order.status || "draft",
        notes: order.notes || "",
        assignedTo: order.assigned_to || "",
      });
      
      setSelectedOrganization(order.customer_id || "");
      
      if (order.lineItems && order.lineItems.length > 0) {
        setOrderItems(order.lineItems.map((item: any) => ({
          id: item.id,
          productId: item.productId,
          productName: item.productName || "Unknown Product",
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          size: item.size || "",
          color: item.color || "",
          notes: item.notes || "",
          orderId: order.id
        })));
      }
    }
  }, [order]);

  const calculateTotal = () => {
    return orderItems.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!order || !selectedOrganization) {
      toast.error("Order data not fully loaded");
      return;
    }

    if (orderItems.length === 0) {
      toast.error("Please add at least one product to the order");
      return;
    }

    setIsSaving(true);
    
    try {
      const selectedOrg = organizations.find(org => org.id === selectedOrganization);
      
      // Update the order
      const { data: updatedOrder, error: orderError } = await supabase
        .from('orders')
        .update({
          customer_id: selectedOrganization,
          customer_name: selectedOrg?.name || "",
          updated_at: new Date().toISOString(),
          status: orderDetails.status,
          total: calculateTotal(),
          assigned_to: orderDetails.assignedTo,
          notes: orderDetails.notes,
        })
        .eq('id', id)
        .select()
        .single();
        
      if (orderError) throw orderError;
      
      // Handle line items - first delete existing ones
      const { error: deleteError } = await supabase
        .from('line_items')
        .delete()
        .eq('order_id', id);
        
      if (deleteError) throw deleteError;
      
      // Then insert new ones
      const lineItemsToInsert = orderItems.map(item => ({
        order_id: id,
        product_id: item.productId,
        quantity: item.quantity,
        unit_price: item.unitPrice,
        size: item.size,
        color: item.color,
        notes: item.notes
      }));
      
      const { error: insertError } = await supabase
        .from('line_items')
        .insert(lineItemsToInsert);
        
      if (insertError) throw insertError;

      toast.success("Order updated successfully");
      navigate(`/orders/${id}`);
    } catch (error) {
      console.error("Error updating order:", error);
      toast.error("Failed to update order");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <CustomerInfoCard 
          selectedOrganization={selectedOrganization}
          setSelectedOrganization={setSelectedOrganization}
          orderDetails={orderDetails}
          setOrderDetails={setOrderDetails}
          organizations={organizations}
        />
        <OrderItemsCard 
          orderItems={orderItems}
          setOrderItems={setOrderItems}
          products={products}
          calculateTotal={calculateTotal}
          id={id}
          isSaving={isSaving}
          navigate={navigate}
        />
      </div>
    </form>
  );
};

export default OrderEditForm;
