
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Plus, Trash, Save } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { OrderItemData } from "./types";
import { Product } from "@/lib/api";
import { NavigateFunction } from "react-router-dom";

interface OrderItemsCardProps {
  orderItems: OrderItemData[];
  setOrderItems: (items: OrderItemData[]) => void;
  products: Product[];
  calculateTotal: () => number;
  id: string;
  isSaving: boolean;
  navigate: NavigateFunction;
}

const OrderItemsCard = ({
  orderItems,
  setOrderItems,
  products,
  calculateTotal,
  id,
  isSaving,
  navigate
}: OrderItemsCardProps) => {
  const handleAddOrderItem = () => {
    if (products.length === 0) {
      return;
    }

    const defaultProduct = products[0];
    setOrderItems([
      ...orderItems,
      {
        productId: defaultProduct.id,
        productName: defaultProduct.name,
        quantity: 1,
        unitPrice: defaultProduct.price,
        size: defaultProduct.sizes?.[0] || "",
        color: defaultProduct.colors?.[0] || "",
        notes: ""
      }
    ]);
  };

  const handleRemoveOrderItem = (index: number) => {
    setOrderItems(orderItems.filter((_, i) => i !== index));
  };

  const handleOrderItemChange = (index: number, field: string, value: any) => {
    const newOrderItems = [...orderItems];
    newOrderItems[index] = { ...newOrderItems[index], [field]: value };

    // If product changes, update related fields
    if (field === "productId") {
      const selectedProduct = products.find(p => p.id === value);
      if (selectedProduct) {
        newOrderItems[index].productName = selectedProduct.name;
        newOrderItems[index].unitPrice = selectedProduct.price;
        newOrderItems[index].size = selectedProduct.sizes?.[0] || "";
        newOrderItems[index].color = selectedProduct.colors?.[0] || "";
      }
    }

    setOrderItems(newOrderItems);
  };

  return (
    <Card className="lg:col-span-2">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Order Items</CardTitle>
          <CardDescription>
            Add or modify products in this order
          </CardDescription>
        </div>
        <Button type="button" onClick={handleAddOrderItem}>
          <Plus className="h-4 w-4 mr-2" /> Add Item
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        {orderItems.length === 0 ? (
          <div className="flex justify-center items-center p-8 border border-dashed rounded-lg">
            <p className="text-muted-foreground">
              No items added. Click "Add Item" to start building your order.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {orderItems.map((item, index) => (
              <div key={index} className="p-4 border rounded-lg relative">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2"
                  onClick={() => handleRemoveOrderItem(index)}
                >
                  <Trash className="h-4 w-4 text-red-500" />
                </Button>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Product</Label>
                    <Select 
                      value={item.productId} 
                      onValueChange={(value) => handleOrderItemChange(index, 'productId', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select product" />
                      </SelectTrigger>
                      <SelectContent>
                        {products.map(product => (
                          <SelectItem key={product.id} value={product.id}>
                            {product.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Quantity</Label>
                    <Input 
                      type="number" 
                      min="1" 
                      value={item.quantity}
                      onChange={(e) => handleOrderItemChange(index, 'quantity', parseInt(e.target.value) || 1)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Size</Label>
                    <Select 
                      value={item.size} 
                      onValueChange={(value) => handleOrderItemChange(index, 'size', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select size" />
                      </SelectTrigger>
                      <SelectContent>
                        {products.find(p => p.id === item.productId)?.sizes?.map(size => (
                          <SelectItem key={size} value={size}>
                            {size}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Color</Label>
                    <Select 
                      value={item.color} 
                      onValueChange={(value) => handleOrderItemChange(index, 'color', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select color" />
                      </SelectTrigger>
                      <SelectContent>
                        {products.find(p => p.id === item.productId)?.colors?.map(color => (
                          <SelectItem key={color} value={color}>
                            {color}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Unit Price</Label>
                    <Input 
                      type="number" 
                      min="0" 
                      step="0.01" 
                      value={item.unitPrice}
                      onChange={(e) => handleOrderItemChange(index, 'unitPrice', parseFloat(e.target.value) || 0)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Item Total</Label>
                    <Input 
                      value={`$${(item.quantity * item.unitPrice).toFixed(2)}`}
                      readOnly
                      className="bg-gray-50"
                    />
                  </div>
                  
                  <div className="md:col-span-2 space-y-2">
                    <Label>Item Notes</Label>
                    <Textarea 
                      rows={2} 
                      value={item.notes}
                      onChange={(e) => handleOrderItemChange(index, 'notes', e.target.value)}
                      placeholder="Add any notes about this item"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {orderItems.length > 0 && (
          <div className="mt-6 pt-4 border-t">
            <div className="flex justify-between text-xl font-bold">
              <span>Total:</span>
              <span>${calculateTotal().toFixed(2)}</span>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button 
          type="button"
          variant="outline"
          onClick={() => navigate(`/orders/${id}`)}
        >
          Cancel
        </Button>
        <Button 
          type="submit"
          disabled={isSaving || orderItems.length === 0}
        >
          <Save className="h-4 w-4 mr-2" />
          {isSaving ? "Saving..." : "Save Changes"}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default OrderItemsCard;
