
import { OrderStatus } from "@/services/baseService";

export interface OrderFormData {
  status: OrderStatus;
  notes: string;
  assignedTo: string;
}

export interface OrderItemData {
  id?: string;
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  size: string;
  color: string;
  notes: string;
  orderId?: string;
}
