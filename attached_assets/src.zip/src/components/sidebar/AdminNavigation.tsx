
import NavLink from "./NavLink";
import {
  Palette,
  Factory,
  Database,
  Send,
  UserCircle,
  Calendar,
  ChevronRight
} from "lucide-react";
import { useLocation } from "react-router-dom";

interface NavLinkProps {
  to: string;
  icon: React.ComponentType<any>;
  isActive: boolean;
  children: React.ReactNode;
  className?: string;
}

const AdminNavigation = () => {
  const location = useLocation();
  
  return (
    <>
      <div className="pt-4 pb-2">
        <div className="px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">
          Admin
        </div>
      </div>

      <NavLink 
        to="/admin/design-team" 
        icon={Palette} 
        isActive={location.pathname === "/admin/design-team"}
      >
        Design Team
      </NavLink>

      <NavLink 
        to="/admin/manufacturing-team" 
        icon={Factory} 
        isActive={location.pathname === "/admin/manufacturing-team"}
      >
        Manufacturing Team
      </NavLink>

      <NavLink 
        to="/admin/data" 
        icon={Database} 
        isActive={location.pathname === "/admin/data"}
      >
        Data Management
      </NavLink>

      <NavLink 
        to="/admin/client-emails" 
        icon={Send} 
        isActive={location.pathname === "/admin/client-emails"}
      >
        Client Emails
      </NavLink>

      <NavLink 
        to="/admin/sales-team" 
        icon={UserCircle} 
        isActive={location.pathname === "/admin/sales-team"}
      >
        Sales Team
      </NavLink>

      <NavLink 
        to="/admin/camp-management" 
        icon={Calendar} 
        isActive={location.pathname === "/admin/camp-management"}
      >
        Camp Management
      </NavLink>
    </>
  );
};

export default AdminNavigation;
