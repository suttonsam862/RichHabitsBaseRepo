
import { useNavigate, useLocation } from "react-router-dom";
import { HomeIcon, Package, Users, ShoppingCart, Settings, BarChart, Palette, Factory, CreditCard, Truck } from "lucide-react";
import NavLink from "./NavLink";

interface MainNavigationProps {
  userRole: string;
}

const MainNavigation = ({ userRole }: MainNavigationProps) => {
  const navigate = useNavigate();
  const location = useLocation();
  
  return (
    <div className="space-y-1">
      <h2 className="px-2 text-xs font-semibold text-gray-400 uppercase tracking-wider">
        Main
      </h2>
      
      {/* Dynamic menu based on user role */}
      {userRole === "admin" && (
        <NavLink to="/" icon={HomeIcon} isActive={location.pathname === "/"}>
          Dashboard
        </NavLink>
      )}
      
      {userRole === "sales" && (
        <NavLink to="/sales-account" icon={HomeIcon} isActive={location.pathname === "/sales-account"}>
          Dashboard
        </NavLink>
      )}
      
      {/* Show leads for both admin and sales roles */}
      {(userRole === "admin" || userRole === "sales") && (
        <NavLink to="/leads" icon={Users} isActive={location.pathname === "/leads"}>
          Leads
        </NavLink>
      )}
      
      {/* Show orders for all roles */}
      {userRole === "admin" && (
        <NavLink to="/orders" icon={Package} isActive={location.pathname === "/orders"}>
          Orders
        </NavLink>
      )}
      
      {userRole === "sales" && (
        <NavLink to="/sales-orders" icon={Package} isActive={location.pathname === "/sales-orders"}>
          Orders
        </NavLink>
      )}
      
      {/* Sales-specific design management */}
      {userRole === "sales" && (
        <NavLink to="/sales-design-management" icon={Palette} isActive={location.pathname === "/sales-design-management"}>
          Design Management
        </NavLink>
      )}
      
      {/* Sales-specific manufacturing management */}
      {userRole === "sales" && (
        <NavLink to="/sales-manufacturing-management" icon={Factory} isActive={location.pathname === "/sales-manufacturing-management"}>
          Manufacturing
        </NavLink>
      )}

      {/* Sales-specific manufacturing submission quick link */}
      {userRole === "sales" && (
        <NavLink 
          to={location.pathname.includes('/manufacturing-submission/') 
              ? location.pathname 
              : "/sales-manufacturing-management"}
          icon={Truck} 
          isActive={location.pathname.includes('/manufacturing-submission/')}
          className="pl-8 text-sm"
        >
          Submit to Manufacturing
        </NavLink>
      )}
      
      {/* Sales-specific finance */}
      {userRole === "sales" && (
        <NavLink to="/sales-finance" icon={CreditCard} isActive={location.pathname === "/sales-finance"}>
          Finance & Payouts
        </NavLink>
      )}
      
      {/* Catalog is visible to all roles */}
      <NavLink to="/catalog" icon={ShoppingCart} isActive={location.pathname === "/catalog"}>
        Catalog
      </NavLink>
      
      {/* Show design pages only for designers and admin - but admin accesses the admin version */}
      {userRole === "designer" && (
        <NavLink to="/design" icon={Palette} isActive={location.pathname === "/design"}>
          Design
        </NavLink>
      )}
      
      {/* Show manufacturing only for manufacturing staff and admin - but admin accesses the admin version */}
      {userRole === "manufacturing" && (
        <NavLink to="/manufacturing" icon={Factory} isActive={location.pathname === "/manufacturing"}>
          Manufacturing
        </NavLink>
      )}
      
      {/* Reports is visible to admin and sales */}
      {(userRole === "admin" || userRole === "sales") && (
        <NavLink to="/reports" icon={BarChart} isActive={location.pathname === "/reports"}>
          Reports
        </NavLink>
      )}
      
      {/* Settings is visible to all roles */}
      <NavLink to="/settings" icon={Settings} isActive={location.pathname === "/settings"}>
        Settings
      </NavLink>
    </div>
  );
};

export default MainNavigation;
