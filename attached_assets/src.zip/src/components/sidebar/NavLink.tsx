
import React from "react";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";

interface NavLinkProps {
  to: string;
  icon: React.ComponentType<any>;
  isActive: boolean;
  children: React.ReactNode;
  className?: string;
}

const NavLink = ({ to, icon: Icon, isActive, children, className }: NavLinkProps) => {
  return (
    <Link
      to={to}
      className={cn(
        "flex items-center px-4 py-2 text-sm font-medium rounded-md transition-colors",
        isActive
          ? "bg-gray-800 text-white"
          : "text-gray-300 hover:bg-gray-700 hover:text-white",
        className
      )}
    >
      <Icon className="mr-3 h-5 w-5" />
      {children}
    </Link>
  );
};

export default NavLink;
