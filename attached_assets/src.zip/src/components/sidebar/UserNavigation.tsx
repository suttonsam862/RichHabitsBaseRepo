
import { useAuth } from "@/context/AuthContext";
import { useNavigate } from "react-router-dom";
import { LogOut, User } from "lucide-react";

interface UserNavigationProps {
  userRole: string;
}

const UserNavigation = ({ userRole }: UserNavigationProps) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const userProfilePath = userRole === "sales" ? "/sales-account" : "/account";

  return (
    <div className="mt-auto p-4 border-t border-gray-800">
      <div className="flex flex-col space-y-2">
        <button
          onClick={() => navigate(userProfilePath)}
          className="flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-300 hover:bg-gray-700 hover:text-white transition-colors"
        >
          <User className="mr-3 h-4 w-4" />
          <span>{user?.email || "Account"}</span>
        </button>

        <button
          onClick={handleLogout}
          className="flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-300 hover:bg-gray-700 hover:text-white transition-colors"
        >
          <LogOut className="mr-3 h-4 w-4" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
};

export default UserNavigation;
