
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Mail, Edit, Trash2 } from "lucide-react";
import { UserProfile } from "@/hooks/useUserProfiles";
import { useAuth } from "@/context/AuthContext";

interface TeamGridProps {
  team: UserProfile[];
  loading?: boolean;
  onEdit?: (user: UserProfile) => void;
  onRemove?: (user: UserProfile) => void;
  onContact?: (user: UserProfile) => void;
}

const TeamGrid = ({ team, loading = false, onEdit, onRemove, onContact }: TeamGridProps) => {
  const { isAdmin } = useAuth();

  // Function to get initials from name
  const getInitials = (name: string | null) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="opacity-50 animate-pulse">
            <CardContent className="p-0">
              <div className="bg-primary h-16"></div>
              <div className="px-4 pb-4 pt-2 h-40"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (team.length === 0) {
    return (
      <div className="text-center py-10">
        <p className="text-muted-foreground">No team members found</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {team.map((person) => (
        <Card key={person.id} className="overflow-hidden">
          <CardContent className="p-0">
            <div className="bg-primary h-16"></div>
            <div className="px-4 pb-4 -mt-10">
              <Avatar className="h-20 w-20 border-4 border-background">
                <AvatarImage src={person.profile_image_url || undefined} alt={person.name || "Team Member"} />
                <AvatarFallback className="text-lg">{getInitials(person.name)}</AvatarFallback>
              </Avatar>
              <h3 className="text-lg font-semibold mt-2">{person.name || "Unnamed Member"}</h3>
              <div className="flex items-center text-sm text-muted-foreground mt-1">
                <Mail className="h-4 w-4 mr-1" />
                <span className="truncate">{person.email}</span>
              </div>
              <div className="mt-4 flex space-x-2">
                {isAdmin && onEdit && (
                  <Button variant="outline" size="sm" className="flex-1" onClick={() => onEdit(person)}>
                    <Edit className="h-4 w-4 mr-1" />
                    Edit
                  </Button>
                )}
                {isAdmin && onRemove && (
                  <Button variant="outline" size="sm" className="flex-1" onClick={() => onRemove(person)}>
                    <Trash2 className="h-4 w-4 mr-1" />
                    Remove
                  </Button>
                )}
                {onContact && (
                  <Button variant="default" size="sm" className="flex-1" onClick={() => onContact(person)}>
                    <Mail className="h-4 w-4 mr-1" />
                    Contact
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default TeamGrid;
