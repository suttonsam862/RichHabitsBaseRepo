
import React from "react";
import { useLocation } from "react-router-dom";
import { TutorialPopup } from "./TutorialPopup";
import { getTutorialForPath } from "./pageTutorials";

export const PageTutorial: React.FC = () => {
  const location = useLocation();
  const tutorialData = getTutorialForPath(location.pathname);

  return <TutorialPopup {...tutorialData} />;
};
