
import React from "react";
import { Button } from "@/components/ui/button";
import { HelpCircle } from "lucide-react";
import { useTutorial } from "./TutorialContext";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface TutorialButtonProps {
  className?: string;
}

export const TutorialButton: React.FC<TutorialButtonProps> = ({ className }) => {
  const { isTutorialActive, setIsTutorialActive, resetTutorial } = useTutorial();

  const handleToggleTutorial = () => {
    if (!isTutorialActive) {
      resetTutorial();
    }
    setIsTutorialActive(!isTutorialActive);
  };

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant={isTutorialActive ? "default" : "outline"}
            size="icon"
            onClick={handleToggleTutorial}
            className={className}
            aria-label="Toggle tutorial"
          >
            <HelpCircle className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom">
          <p>{isTutorialActive ? "Disable Tutorial" : "Enable Tutorial"}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};
