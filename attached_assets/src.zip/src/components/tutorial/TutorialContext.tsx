
import React, { createContext, useContext, useState, useEffect } from "react";
import { useLocation } from "react-router-dom";

interface TutorialContextType {
  isTutorialActive: boolean;
  setIsTutorialActive: (active: boolean) => void;
  currentStep: number;
  setCurrentStep: (step: number) => void;
  nextStep: () => void;
  previousStep: () => void;
  skipTutorial: () => void;
  resetTutorial: () => void;
}

const defaultContext: TutorialContextType = {
  isTutorialActive: false,
  setIsTutorialActive: () => {},
  currentStep: 0,
  setCurrentStep: () => {},
  nextStep: () => {},
  previousStep: () => {},
  skipTutorial: () => {},
  resetTutorial: () => {},
};

const TutorialContext = createContext<TutorialContextType>(defaultContext);

export const useTutorial = () => useContext(TutorialContext);

export const TutorialProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isTutorialActive, setIsTutorialActive] = useState(() => {
    // Check local storage for tutorial preference
    const savedPreference = localStorage.getItem("tutorial-active");
    return savedPreference === "true";
  });
  const [currentStep, setCurrentStep] = useState(0);
  const location = useLocation();

  // Reset the step counter when the route changes
  useEffect(() => {
    setCurrentStep(0);
  }, [location.pathname]);

  // Save tutorial preference to local storage
  useEffect(() => {
    localStorage.setItem("tutorial-active", isTutorialActive.toString());
  }, [isTutorialActive]);

  const nextStep = () => {
    setCurrentStep((prev) => prev + 1);
  };

  const previousStep = () => {
    setCurrentStep((prev) => Math.max(0, prev - 1));
  };

  const skipTutorial = () => {
    setCurrentStep(0);
    setIsTutorialActive(false);
  };

  const resetTutorial = () => {
    setCurrentStep(0);
  };

  return (
    <TutorialContext.Provider
      value={{
        isTutorialActive,
        setIsTutorialActive,
        currentStep,
        setCurrentStep,
        nextStep,
        previousStep,
        skipTutorial,
        resetTutorial,
      }}
    >
      {children}
    </TutorialContext.Provider>
  );
};
