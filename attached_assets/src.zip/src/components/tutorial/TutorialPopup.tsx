
import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, ArrowRight, X, HelpCircle } from "lucide-react";
import { useTutorial } from "./TutorialContext";
import { motion, AnimatePresence } from "framer-motion";

interface TutorialPopupProps {
  title: string;
  description: string;
  steps: {
    title: string;
    content: React.ReactNode;
    highlightSelector?: string;
  }[];
  position?: "top" | "right" | "bottom" | "left" | "center";
}

export const TutorialPopup: React.FC<TutorialPopupProps> = ({
  title,
  description,
  steps,
  position = "center",
}) => {
  const { isTutorialActive, currentStep, nextStep, previousStep, skipTutorial } = useTutorial();

  if (!isTutorialActive || steps.length === 0) {
    return null;
  }

  const currentTutorialStep = steps[currentStep] || steps[0];
  const isLastStep = currentStep === steps.length - 1;
  const isFirstStep = currentStep === 0;

  // Position the popup based on props
  const getPositionClasses = () => {
    switch (position) {
      case "top":
        return "top-4 left-1/2 transform -translate-x-1/2";
      case "right":
        return "top-1/2 right-4 transform -translate-y-1/2";
      case "bottom":
        return "bottom-4 left-1/2 transform -translate-x-1/2";
      case "left":
        return "top-1/2 left-4 transform -translate-y-1/2";
      case "center":
      default:
        return "top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2";
    }
  };

  // Highlight the element if a selector is provided
  React.useEffect(() => {
    const highlightElement = () => {
      // Remove previous highlights
      document.querySelectorAll(".tutorial-highlight").forEach((el) => {
        el.classList.remove("tutorial-highlight");
      });

      if (currentTutorialStep.highlightSelector) {
        const element = document.querySelector(currentTutorialStep.highlightSelector);
        if (element) {
          element.classList.add("tutorial-highlight");
          
          // Scroll to the element if it's not in view
          element.scrollIntoView({
            behavior: "smooth",
            block: "center",
          });
        }
      }
    };

    highlightElement();

    return () => {
      // Clean up highlights when component unmounts
      document.querySelectorAll(".tutorial-highlight").forEach((el) => {
        el.classList.remove("tutorial-highlight");
      });
    };
  }, [currentStep, currentTutorialStep.highlightSelector]);

  return (
    <AnimatePresence>
      <motion.div
        className={`fixed z-50 ${getPositionClasses()} shadow-2xl`}
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        transition={{ duration: 0.2 }}
      >
        <Card className="w-96 bg-white border border-gray-200">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <HelpCircle className="h-5 w-5 mr-2 text-blue-500" />
                <CardTitle className="text-lg">{currentTutorialStep.title || title}</CardTitle>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={skipTutorial}
                aria-label="Close tutorial"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            <CardDescription>{description}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="prose prose-sm max-w-none text-gray-600">
              {currentTutorialStep.content}
            </div>
          </CardContent>
          <CardFooter className="flex justify-between border-t pt-4 bg-gray-50">
            <div>
              <Button
                variant="outline"
                size="sm"
                onClick={previousStep}
                disabled={isFirstStep}
                className="mr-2"
              >
                <ArrowLeft className="h-4 w-4 mr-1" />
                Previous
              </Button>
              <Button
                variant={isLastStep ? "default" : "outline"}
                size="sm"
                onClick={nextStep}
              >
                {isLastStep ? "Finish" : "Next"}
                {!isLastStep && <ArrowRight className="h-4 w-4 ml-1" />}
              </Button>
            </div>
            <div className="text-sm text-gray-500">
              {currentStep + 1} / {steps.length}
            </div>
          </CardFooter>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
};
