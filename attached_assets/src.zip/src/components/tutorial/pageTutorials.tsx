
import React from 'react';

// Define the TutorialStep type based on what we're using
type TutorialStep = {
  title: string;
  content: React.ReactNode;
  highlightSelector?: string;
};

// Define the structure that matches what TutorialPopup expects
type PageTutorial = {
  title: string;
  description: string;
  steps: TutorialStep[];
  position?: "top" | "right" | "bottom" | "left" | "center";
};

const tutorials: Record<string, PageTutorial> = {
  "/": {
    title: "Dashboard Tutorial",
    description: "Get familiar with the main dashboard",
    steps: [
      {
        title: "Welcome to the Dashboard",
        content: "This is your main dashboard where you can find an overview of all your activities.",
        highlightSelector: ".dashboard-container",
      },
      {
        title: "Navigation Sidebar",
        content: "Use the sidebar to navigate to different parts of the application.",
        highlightSelector: ".sidebar",
      },
      {
        title: "Quick Actions",
        content: "Perform common actions quickly using these buttons.",
        highlightSelector: ".quick-actions",
      },
    ],
  },
  "/leads": {
    title: "Leads Management Tutorial",
    description: "Learn how to manage your sales leads",
    steps: [
      {
        title: "Welcome to Leads Management",
        content: "This is where you can track and manage all your sales leads.",
        highlightSelector: ".leads-container",
      },
      {
        title: "Create New Leads",
        content: "Click here to add a new lead to your pipeline.",
        highlightSelector: ".create-lead-button",
      },
      {
        title: "Lead Status",
        content: "See the status of each lead in your pipeline.",
        highlightSelector: ".lead-status",
      },
    ],
  },
  "/orders": {
    title: "Orders Management Tutorial",
    description: "Learn how to manage your orders",
    steps: [
      {
        title: "Welcome to Orders Management",
        content: "This is where you can track and manage all your customer orders.",
        highlightSelector: ".orders-container",
      },
      {
        title: "Create New Order",
        content: "Click here to create a new order.",
        highlightSelector: ".create-order-button",
      },
      {
        title: "Order Status",
        content: "See the status of each order in your pipeline.",
        highlightSelector: ".order-status",
      },
    ],
  },
  "/finance": {
    title: "Finance & QuickBooks Tutorial",
    description: "Learn how to manage finances and integrate with QuickBooks",
    steps: [
      {
        title: "Welcome to Finance Dashboard",
        content: "This is your finance hub where you can manage invoices, payments, expenses, and QuickBooks integration.",
      },
      {
        title: "Financial Overview",
        content: "Get a quick snapshot of your financial metrics including revenue, pending invoices, and expenses.",
        highlightSelector: "h1.text-2xl",
      },
      {
        title: "Navigation Tabs",
        content: "Use these tabs to navigate between different financial management features.",
        highlightSelector: ".tab-list",
      },
      {
        title: "Invoice Management",
        content: "Create and manage customer invoices, and send them directly to QuickBooks.",
        highlightSelector: "[data-value='invoices']",
      },
      {
        title: "QuickBooks Integration",
        content: "Connect your account to QuickBooks to sync invoices, payments, and expenses automatically.",
        highlightSelector: "[data-value='quickbooks']",
      },
      {
        title: "Create Invoices",
        content: "Click here to create new invoices that can be synced with QuickBooks.",
        highlightSelector: "button:has(.plus)",
      },
    ],
  },
  "/wholesale": {
    title: "Wholesale Finance Tutorial",
    description: "Learn how to manage wholesale finances",
    steps: [
      {
        title: "Welcome to Wholesale Finance",
        content: "This is where you can manage wholesale orders, designer payouts, and sales commissions.",
        highlightSelector: "h1.text-2xl",
      },
      {
        title: "Navigation Tabs",
        content: "Use these tabs to navigate between different wholesale finance features.",
        highlightSelector: ".tabs-list",
      },
      {
        title: "QuickBooks Sync",
        content: "Sync your wholesale data with QuickBooks for streamlined accounting.",
        highlightSelector: "[data-value='quickbooks']",
      },
    ],
  },
};

// Update the return type to match what TutorialPopup expects
export function getTutorialForPath(path: string): {
  title: string;
  description: string;
  steps: TutorialStep[];
  position?: "top" | "right" | "bottom" | "left" | "center";
} {
  // Extract the base path (remove query parameters and trailing slashes)
  const basePath = path.split('?')[0].replace(/\/+$/, '');
  
  // Try to find a direct match
  if (tutorials[basePath]) {
    return {
      ...tutorials[basePath]
    };
  }
  
  // If no direct match, try to find a match for the parent path
  const parentPath = basePath.split('/').slice(0, -1).join('/');
  if (tutorials[parentPath]) {
    return {
      ...tutorials[parentPath]
    };
  }
  
  // Default to the home tutorial if no match is found
  return {
    ...tutorials["/"]
  };
}
