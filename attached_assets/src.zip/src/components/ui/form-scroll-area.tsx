
import { ScrollArea } from "./scroll-area";
import { cn } from "@/lib/utils";

interface FormScrollAreaProps {
  children: React.ReactNode;
  className?: string;
  maxHeight?: string;
}

/**
 * A scrollable container specifically designed for forms,
 * ensuring buttons at the bottom remain accessible
 */
export function FormScrollArea({ 
  children, 
  className, 
  maxHeight = "65vh" 
}: FormScrollAreaProps) {
  return (
    <ScrollArea 
      className={cn("pr-4", className)} 
      style={{ maxHeight }}
    >
      <div className="pb-4">
        {children}
      </div>
    </ScrollArea>
  );
}
