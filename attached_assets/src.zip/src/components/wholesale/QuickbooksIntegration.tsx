import { useState } from "react";
import { Button } from "@/components/ui/button";
import { QuickBooks } from "@/services/quickbooksService";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const QuickbooksIntegration = () => {
  const [isConnecting, setIsConnecting] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [consumerKey, setConsumerKey] = useState("");
  const [consumerSecret, setConsumerSecret] = useState("");
  const [realmId, setRealmId] = useState("");
  const [oauthToken, setOauthToken] = useState("");
  const [oauthTokenSecret, setOauthTokenSecret] = useState("");
  const [activeTab, setActiveTab] = useState("connection");

  const handleConnect = async () => {
    if (!consumerKey || !consumerSecret || !realmId || !oauthToken || !oauthTokenSecret) {
      toast.error("Please fill in all required fields");
      return;
    }

    setIsConnecting(true);
    try {
      const qb = new QuickBooks({
        consumerKey,
        consumerSecret,
        realmId,
        oauthToken,
        oauthTokenSecret,
        useSandbox: true
      });

      const success = await qb.testConnection();
      
      if (success) {
        setIsConnected(true);
        toast.success("Successfully connected to QuickBooks");
      } else {
        toast.error("Failed to connect to QuickBooks");
      }
    } catch (error) {
      console.error("Error connecting to QuickBooks:", error);
      toast.error("Error connecting to QuickBooks. Please check your credentials.");
    } finally {
      setIsConnecting(false);
    }
  };

  return (
    <div className="space-y-4">
      <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="connection">Connection</TabsTrigger>
          <TabsTrigger value="invoices" disabled={!isConnected}>Invoices</TabsTrigger>
          <TabsTrigger value="customers" disabled={!isConnected}>Customers</TabsTrigger>
          <TabsTrigger value="products" disabled={!isConnected}>Products</TabsTrigger>
        </TabsList>
        
        <TabsContent value="connection" className="space-y-4 pt-4">
          <Card>
            <CardContent className="pt-6">
              <div className="grid gap-4">
                {isConnected ? (
                  <div className="bg-green-50 border border-green-200 rounded-md p-4">
                    <h3 className="text-green-800 font-medium">Connected to QuickBooks</h3>
                    <p className="text-green-600 text-sm mt-1">You are successfully connected to QuickBooks</p>
                    <Button 
                      variant="outline" 
                      className="mt-2"
                      onClick={() => setIsConnected(false)}
                    >
                      Disconnect
                    </Button>
                  </div>
                ) : (
                  <>
                    <div>
                      <Label htmlFor="consumerKey">Consumer Key</Label>
                      <Input 
                        id="consumerKey" 
                        value={consumerKey} 
                        onChange={(e) => setConsumerKey(e.target.value)} 
                        placeholder="Enter QuickBooks Consumer Key"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="consumerSecret">Consumer Secret</Label>
                      <Input 
                        id="consumerSecret" 
                        value={consumerSecret} 
                        onChange={(e) => setConsumerSecret(e.target.value)}
                        type="password"
                        placeholder="Enter QuickBooks Consumer Secret"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="realmId">Realm ID</Label>
                      <Input 
                        id="realmId" 
                        value={realmId} 
                        onChange={(e) => setRealmId(e.target.value)} 
                        placeholder="Enter QuickBooks Realm ID"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="oauthToken">OAuth Token</Label>
                      <Input 
                        id="oauthToken" 
                        value={oauthToken} 
                        onChange={(e) => setOauthToken(e.target.value)} 
                        placeholder="Enter OAuth Token"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="oauthTokenSecret">OAuth Token Secret</Label>
                      <Input 
                        id="oauthTokenSecret" 
                        value={oauthTokenSecret} 
                        onChange={(e) => setOauthTokenSecret(e.target.value)}
                        type="password"
                        placeholder="Enter OAuth Token Secret"
                      />
                    </div>
                    
                    <Button 
                      onClick={handleConnect} 
                      disabled={isConnecting}
                      className="mt-2"
                    >
                      {isConnecting ? "Connecting..." : "Connect to QuickBooks"}
                    </Button>
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="invoices" className="space-y-4 pt-4">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-medium mb-4">QuickBooks Invoices</h3>
              <p className="text-muted-foreground">
                Manage invoices synced with QuickBooks.
              </p>
              {/* Invoice management will be implemented here */}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="customers" className="space-y-4 pt-4">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-medium mb-4">QuickBooks Customers</h3>
              <p className="text-muted-foreground">
                Manage customers synced with QuickBooks.
              </p>
              {/* Customer management will be implemented here */}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="products" className="space-y-4 pt-4">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-medium mb-4">QuickBooks Products</h3>
              <p className="text-muted-foreground">
                Manage products synced with QuickBooks.
              </p>
              {/* Product management will be implemented here */}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default QuickbooksIntegration;
