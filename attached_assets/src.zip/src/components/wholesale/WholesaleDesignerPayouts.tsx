
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Search,
  Download,
  Filter,
  ArrowDown,
  ArrowUp,
  FileText,
  CircleDollarSign
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";

type DesignerPayout = {
  id: string;
  designerId: string;
  designerName: string;
  orderId: string;
  orderCustomer: string;
  amount: number;
  status: string;
  designDate: string;
  paymentDate: string | null;
};

const WholesaleDesignerPayouts = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [sortField, setSortField] = useState<keyof DesignerPayout>("designDate");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [showFilters, setShowFilters] = useState(false);

  const { data: payouts = [], isLoading } = useQuery({
    queryKey: ['designerPayouts'],
    queryFn: async (): Promise<DesignerPayout[]> => {
      // In a real implementation, fetch from Supabase
      // For now, we'll use mock data
      return [
        {
          id: "DP-2023-001",
          designerId: "D001",
          designerName: "Alex Johnson",
          orderId: "WO-2023-001",
          orderCustomer: "Metro High School",
          amount: 1250,
          status: "paid",
          designDate: "2023-05-10",
          paymentDate: "2023-06-01"
        },
        {
          id: "DP-2023-002",
          designerId: "D002",
          designerName: "Sarah Williams",
          orderId: "WO-2023-002",
          orderCustomer: "Riverside Athletics",
          amount: 1875,
          status: "pending",
          designDate: "2023-05-25",
          paymentDate: null
        },
        {
          id: "DP-2023-003",
          designerId: "D001",
          designerName: "Alex Johnson",
          orderId: "WO-2023-003",
          orderCustomer: "East Valley College",
          amount: 980,
          status: "in-progress",
          designDate: "2023-06-05",
          paymentDate: null
        },
        {
          id: "DP-2023-004",
          designerId: "D003",
          designerName: "Michael Chen",
          orderId: "WO-2023-004",
          orderCustomer: "Westlake Sports Club",
          amount: 1520,
          status: "not-started",
          designDate: "2023-06-15",
          paymentDate: null
        }
      ];
    }
  });

  const designerTotals = payouts.reduce((acc, payout) => {
    if (!acc[payout.designerId]) {
      acc[payout.designerId] = {
        name: payout.designerName,
        total: 0,
        paid: 0,
        pending: 0
      };
    }
    
    acc[payout.designerId].total += payout.amount;
    if (payout.status === "paid") {
      acc[payout.designerId].paid += payout.amount;
    } else {
      acc[payout.designerId].pending += payout.amount;
    }
    
    return acc;
  }, {} as Record<string, { name: string; total: number; paid: number; pending: number }>);

  const handleSort = (field: keyof DesignerPayout) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const filteredPayouts = [...(payouts || [])].filter(payout => {
    // Apply status filter
    if (statusFilter !== "all" && payout.status !== statusFilter) {
      return false;
    }
    
    // Apply search filter
    return (
      payout.designerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payout.orderCustomer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payout.orderId.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const sortedPayouts = filteredPayouts.sort((a, b) => {
    if (sortField === "amount") {
      return sortDirection === "asc" 
        ? a[sortField] - b[sortField]
        : b[sortField] - a[sortField];
    }
    
    const aValue = a[sortField] || "";
    const bValue = b[sortField] || "";
    
    return sortDirection === "asc"
      ? String(aValue).localeCompare(String(bValue))
      : String(bValue).localeCompare(String(aValue));
  });

  const SortIcon = ({ field }: { field: keyof DesignerPayout }) => {
    if (sortField !== field) return null;
    return sortDirection === "asc" ? <ArrowUp className="h-4 w-4 ml-1" /> : <ArrowDown className="h-4 w-4 ml-1" />;
  };

  const renderSortableHeader = (label: string, field: keyof DesignerPayout) => (
    <div 
      className="flex items-center cursor-pointer hover:text-primary"
      onClick={() => handleSort(field)}
    >
      {label}
      <SortIcon field={field} />
    </div>
  );

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return <Badge className="bg-green-100 text-green-800">Paid</Badge>;
      case "pending":
        return <Badge className="bg-amber-100 text-amber-800">Pending</Badge>;
      case "in-progress":
        return <Badge className="bg-blue-100 text-blue-800">In Progress</Badge>;
      case "not-started":
        return <Badge className="bg-gray-100 text-gray-800">Not Started</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div>
        <div className="flex items-center justify-between mb-6">
          <Skeleton className="h-10 w-64" />
          <Skeleton className="h-10 w-28" />
        </div>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead><Skeleton className="h-4 w-28" /></TableHead>
                <TableHead><Skeleton className="h-4 w-32" /></TableHead>
                <TableHead><Skeleton className="h-4 w-28" /></TableHead>
                <TableHead><Skeleton className="h-4 w-32" /></TableHead>
                <TableHead><Skeleton className="h-4 w-24" /></TableHead>
                <TableHead><Skeleton className="h-4 w-24" /></TableHead>
                <TableHead><Skeleton className="h-4 w-24" /></TableHead>
                <TableHead><Skeleton className="h-4 w-24" /></TableHead>
                <TableHead><Skeleton className="h-4 w-24" /></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...Array(4)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-8 w-28" /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex flex-col md:flex-row items-start md:items-center md:justify-between gap-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search designer or order..."
              className="pl-8 w-64"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <Button
            variant="outline"
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-2"
          >
            <Filter className="h-4 w-4" />
            Filters {showFilters ? '↑' : '↓'}
          </Button>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
        </div>
      </div>
      
      {showFilters && (
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-wrap gap-6">
              <div className="flex flex-col gap-2">
                <Label htmlFor="statusFilter">Payment Status</Label>
                <Select
                  value={statusFilter}
                  onValueChange={setStatusFilter}
                >
                  <SelectTrigger id="statusFilter" className="w-36">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="paid">Paid</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="not-started">Not Started</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {Object.entries(designerTotals).map(([id, data]) => (
          <Card key={id} className="p-4 shadow-sm">
            <div className="flex flex-col">
              <span className="text-sm text-muted-foreground">Designer</span>
              <span className="text-lg font-semibold">{data.name}</span>
              <div className="grid grid-cols-2 gap-4 mt-2">
                <div>
                  <span className="text-sm text-muted-foreground">Total</span>
                  <p className="font-medium">${data.total.toLocaleString()}</p>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">Pending</span>
                  <p className="font-medium">${data.pending.toLocaleString()}</p>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>{renderSortableHeader("ID", "id")}</TableHead>
              <TableHead>{renderSortableHeader("Designer", "designerName")}</TableHead>
              <TableHead>{renderSortableHeader("Order", "orderId")}</TableHead>
              <TableHead>{renderSortableHeader("Customer", "orderCustomer")}</TableHead>
              <TableHead>{renderSortableHeader("Amount", "amount")}</TableHead>
              <TableHead>{renderSortableHeader("Status", "status")}</TableHead>
              <TableHead>{renderSortableHeader("Design Date", "designDate")}</TableHead>
              <TableHead>{renderSortableHeader("Payment Date", "paymentDate")}</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedPayouts.length === 0 ? (
              <TableRow>
                <TableCell colSpan={9} className="text-center py-6 text-muted-foreground">
                  No designer payouts matching your search
                </TableCell>
              </TableRow>
            ) : (
              sortedPayouts.map((payout) => (
                <TableRow key={payout.id}>
                  <TableCell className="font-medium">{payout.id}</TableCell>
                  <TableCell>{payout.designerName}</TableCell>
                  <TableCell>{payout.orderId}</TableCell>
                  <TableCell>{payout.orderCustomer}</TableCell>
                  <TableCell>${payout.amount.toLocaleString()}</TableCell>
                  <TableCell>{getStatusBadge(payout.status)}</TableCell>
                  <TableCell>{payout.designDate}</TableCell>
                  <TableCell>{payout.paymentDate || "—"}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="outline" size="icon">
                              <FileText className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>View Design Details</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="outline" size="icon">
                              <CircleDollarSign className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Process Payment</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default WholesaleDesignerPayouts;
