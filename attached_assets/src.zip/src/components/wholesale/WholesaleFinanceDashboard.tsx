
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import WholesaleSummary from "./WholesaleSummary";
import WholesaleOrdersTable from "./WholesaleOrdersTable";
import WholesaleDesignerPayouts from "./WholesaleDesignerPayouts";
import WholesaleSalesCommissions from "./WholesaleSalesCommissions";
import QuickbooksIntegration from "./QuickbooksIntegration";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

const WholesaleFinanceDashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("overview");

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <Button 
            variant="ghost" 
            onClick={() => navigate("/")}
            className="mb-2"
          >
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
          </Button>
          <h1 className="text-2xl font-bold">Wholesale Finance Tracker</h1>
          <p className="text-muted-foreground">
            Manage wholesale orders, design costs, and sales commissions
          </p>
        </div>
      </div>

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-5 w-full max-w-4xl">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="designers">Designer Payouts</TabsTrigger>
          <TabsTrigger value="commissions">Sales Commissions</TabsTrigger>
          <TabsTrigger value="quickbooks">QuickBooks Sync</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-6 mt-6">
          <WholesaleSummary />
        </TabsContent>
        
        <TabsContent value="orders" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Wholesale Orders</CardTitle>
              <CardDescription>
                Track and manage all wholesale bulk orders
              </CardDescription>
            </CardHeader>
            <CardContent>
              <WholesaleOrdersTable />
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="designers" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Designer Payouts</CardTitle>
              <CardDescription>
                Track payments to designers for custom gear designs
              </CardDescription>
            </CardHeader>
            <CardContent>
              <WholesaleDesignerPayouts />
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="commissions" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Sales Commissions</CardTitle>
              <CardDescription>
                Manage commissions for salespeople on wholesale transactions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <WholesaleSalesCommissions />
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="quickbooks" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>QuickBooks Integration</CardTitle>
              <CardDescription>
                Sync orders, customers, and invoices with QuickBooks
              </CardDescription>
            </CardHeader>
            <CardContent>
              <QuickbooksIntegration />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default WholesaleFinanceDashboard;
