
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Eye,
  FileText,
  Pencil,
  Search,
  FileCheck,
  ArrowDown,
  ArrowUp
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

type WholesaleOrder = {
  id: string;
  customerName: string;
  dateCreated: string;
  total: number;
  status: string;
  designStatus: string;
  invoiceStatus: string;
  designerPayout: number;
  salesCommission: number;
};

const WholesaleOrdersTable = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [sortField, setSortField] = useState<keyof WholesaleOrder>("dateCreated");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");

  const { data: orders = [], isLoading } = useQuery({
    queryKey: ['wholesaleOrders'],
    queryFn: async (): Promise<WholesaleOrder[]> => {
      // In a real implementation, fetch from Supabase
      // For now, we'll use mock data
      return [
        {
          id: "WO-2023-001",
          customerName: "Metro High School",
          dateCreated: "2023-05-15",
          total: 12500,
          status: "completed",
          designStatus: "approved",
          invoiceStatus: "paid",
          designerPayout: 1250,
          salesCommission: 625
        },
        {
          id: "WO-2023-002",
          customerName: "Riverside Athletics",
          dateCreated: "2023-06-02",
          total: 18750,
          status: "manufacturing",
          designStatus: "approved",
          invoiceStatus: "sent",
          designerPayout: 1875,
          salesCommission: 938
        },
        {
          id: "WO-2023-003",
          customerName: "East Valley College",
          dateCreated: "2023-06-10",
          total: 9800,
          status: "design",
          designStatus: "in-progress",
          invoiceStatus: "draft",
          designerPayout: 980,
          salesCommission: 490
        },
        {
          id: "WO-2023-004",
          customerName: "Westlake Sports Club",
          dateCreated: "2023-06-18",
          total: 15200,
          status: "submitted",
          designStatus: "pending",
          invoiceStatus: "not-created",
          designerPayout: 1520,
          salesCommission: 760
        }
      ];
    }
  });

  const handleSort = (field: keyof WholesaleOrder) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const sortedOrders = [...(orders || [])].sort((a, b) => {
    if (sortField === "total" || sortField === "designerPayout" || sortField === "salesCommission") {
      return sortDirection === "asc" 
        ? a[sortField] - b[sortField]
        : b[sortField] - a[sortField];
    }
    
    return sortDirection === "asc"
      ? String(a[sortField]).localeCompare(String(b[sortField]))
      : String(b[sortField]).localeCompare(String(a[sortField]));
  });

  const filteredOrders = sortedOrders.filter(order => 
    order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    order.status.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const SortIcon = ({ field }: { field: keyof WholesaleOrder }) => {
    if (sortField !== field) return null;
    return sortDirection === "asc" ? <ArrowUp className="h-4 w-4 ml-1" /> : <ArrowDown className="h-4 w-4 ml-1" />;
  };

  const renderSortableHeader = (label: string, field: keyof WholesaleOrder) => (
    <div 
      className="flex items-center cursor-pointer hover:text-primary"
      onClick={() => handleSort(field)}
    >
      {label}
      <SortIcon field={field} />
    </div>
  );

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-100 text-green-800">Completed</Badge>;
      case "manufacturing":
        return <Badge className="bg-amber-100 text-amber-800">Manufacturing</Badge>;
      case "design":
        return <Badge className="bg-purple-100 text-purple-800">Design</Badge>;
      case "submitted":
        return <Badge className="bg-blue-100 text-blue-800">Submitted</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };

  const getInvoiceStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return <Badge className="bg-green-100 text-green-800">Paid</Badge>;
      case "sent":
        return <Badge className="bg-blue-100 text-blue-800">Sent</Badge>;
      case "draft":
        return <Badge className="bg-gray-100 text-gray-800">Draft</Badge>;
      case "not-created":
        return <Badge variant="outline">Not Created</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };

  const getDesignStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return <Badge className="bg-green-100 text-green-800">Approved</Badge>;
      case "in-progress":
        return <Badge className="bg-amber-100 text-amber-800">In Progress</Badge>;
      case "pending":
        return <Badge className="bg-blue-100 text-blue-800">Pending</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div>
        <div className="flex items-center mb-6">
          <Skeleton className="h-10 w-64" />
        </div>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead><Skeleton className="h-4 w-28" /></TableHead>
                <TableHead><Skeleton className="h-4 w-32" /></TableHead>
                <TableHead><Skeleton className="h-4 w-24" /></TableHead>
                <TableHead><Skeleton className="h-4 w-24" /></TableHead>
                <TableHead><Skeleton className="h-4 w-24" /></TableHead>
                <TableHead><Skeleton className="h-4 w-24" /></TableHead>
                <TableHead><Skeleton className="h-4 w-24" /></TableHead>
                <TableHead><Skeleton className="h-4 w-24" /></TableHead>
                <TableHead><Skeleton className="h-4 w-24" /></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...Array(4)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-8 w-28" /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center mb-6">
        <div className="relative max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search orders..."
            className="pl-8 w-64"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>{renderSortableHeader("Order ID", "id")}</TableHead>
              <TableHead>{renderSortableHeader("Customer", "customerName")}</TableHead>
              <TableHead>{renderSortableHeader("Date", "dateCreated")}</TableHead>
              <TableHead>{renderSortableHeader("Status", "status")}</TableHead>
              <TableHead>{renderSortableHeader("Design", "designStatus")}</TableHead>
              <TableHead>{renderSortableHeader("Invoice", "invoiceStatus")}</TableHead>
              <TableHead>{renderSortableHeader("Total", "total")}</TableHead>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <TableHead>{renderSortableHeader("Designer $", "designerPayout")}</TableHead>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Amount paid to designers for custom work</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <TableHead>{renderSortableHeader("Commission", "salesCommission")}</TableHead>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Sales commission for this order</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredOrders.length === 0 ? (
              <TableRow>
                <TableCell colSpan={10} className="text-center py-6 text-muted-foreground">
                  No orders matching your search
                </TableCell>
              </TableRow>
            ) : (
              filteredOrders.map((order) => (
                <TableRow key={order.id}>
                  <TableCell className="font-medium">{order.id}</TableCell>
                  <TableCell>{order.customerName}</TableCell>
                  <TableCell>{order.dateCreated}</TableCell>
                  <TableCell>{getStatusBadge(order.status)}</TableCell>
                  <TableCell>{getDesignStatusBadge(order.designStatus)}</TableCell>
                  <TableCell>{getInvoiceStatusBadge(order.invoiceStatus)}</TableCell>
                  <TableCell>${order.total.toLocaleString()}</TableCell>
                  <TableCell>${order.designerPayout.toLocaleString()}</TableCell>
                  <TableCell>${order.salesCommission.toLocaleString()}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="outline" size="icon">
                              <Eye className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>View Order Details</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="outline" size="icon">
                              <Pencil className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Edit Order</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="outline" size="icon">
                              <FileText className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Generate/View Invoice</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="outline" size="icon">
                              <FileCheck className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Reconcile Financials</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default WholesaleOrdersTable;
