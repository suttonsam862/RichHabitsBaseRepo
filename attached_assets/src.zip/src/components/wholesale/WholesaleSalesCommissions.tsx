
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Search,
  Download,
  Filter,
  ArrowDown,
  ArrowUp,
  FileText,
  CircleDollarSign,
  PieChart
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";

type SalesCommission = {
  id: string;
  salespersonId: string;
  salespersonName: string;
  orderId: string;
  orderCustomer: string;
  orderAmount: number;
  commissionAmount: number;
  status: string;
  saleDate: string;
  paymentDate: string | null;
};

const WholesaleSalesCommissions = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [sortField, setSortField] = useState<keyof SalesCommission>("saleDate");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [showFilters, setShowFilters] = useState(false);

  const { data: commissions = [], isLoading } = useQuery({
    queryKey: ['salesCommissions'],
    queryFn: async (): Promise<SalesCommission[]> => {
      // In a real implementation, fetch from Supabase
      // For now, we'll use mock data
      return [
        {
          id: "SC-2023-001",
          salespersonId: "S001",
          salespersonName: "Jennifer Miller",
          orderId: "WO-2023-001",
          orderCustomer: "Metro High School",
          orderAmount: 12500,
          commissionAmount: 625,
          status: "paid",
          saleDate: "2023-05-15",
          paymentDate: "2023-06-15"
        },
        {
          id: "SC-2023-002",
          salespersonId: "S002",
          salespersonName: "Robert Taylor",
          orderId: "WO-2023-002",
          orderCustomer: "Riverside Athletics",
          orderAmount: 18750,
          commissionAmount: 938,
          status: "pending",
          saleDate: "2023-06-02",
          paymentDate: null
        },
        {
          id: "SC-2023-003",
          salespersonId: "S003",
          salespersonName: "Emily Davis",
          orderId: "WO-2023-003",
          orderCustomer: "East Valley College",
          orderAmount: 9800,
          commissionAmount: 490,
          status: "pending",
          saleDate: "2023-06-10",
          paymentDate: null
        },
        {
          id: "SC-2023-004",
          salespersonId: "S001",
          salespersonName: "Jennifer Miller",
          orderId: "WO-2023-004",
          orderCustomer: "Westlake Sports Club",
          orderAmount: 15200,
          commissionAmount: 760,
          status: "pending",
          saleDate: "2023-06-18",
          paymentDate: null
        }
      ];
    }
  });

  const salespersonTotals = commissions.reduce((acc, commission) => {
    if (!acc[commission.salespersonId]) {
      acc[commission.salespersonId] = {
        name: commission.salespersonName,
        total: 0,
        paid: 0,
        pending: 0,
        orderCount: 0
      };
    }
    
    acc[commission.salespersonId].total += commission.commissionAmount;
    acc[commission.salespersonId].orderCount += 1;
    
    if (commission.status === "paid") {
      acc[commission.salespersonId].paid += commission.commissionAmount;
    } else {
      acc[commission.salespersonId].pending += commission.commissionAmount;
    }
    
    return acc;
  }, {} as Record<string, { name: string; total: number; paid: number; pending: number; orderCount: number }>);

  const handleSort = (field: keyof SalesCommission) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const filteredCommissions = [...(commissions || [])].filter(commission => {
    // Apply status filter
    if (statusFilter !== "all" && commission.status !== statusFilter) {
      return false;
    }
    
    // Apply search filter
    return (
      commission.salespersonName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      commission.orderCustomer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      commission.orderId.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const sortedCommissions = filteredCommissions.sort((a, b) => {
    if (sortField === "commissionAmount" || sortField === "orderAmount") {
      return sortDirection === "asc" 
        ? a[sortField] - b[sortField]
        : b[sortField] - a[sortField];
    }
    
    const aValue = a[sortField] || "";
    const bValue = b[sortField] || "";
    
    return sortDirection === "asc"
      ? String(aValue).localeCompare(String(bValue))
      : String(bValue).localeCompare(String(aValue));
  });

  const SortIcon = ({ field }: { field: keyof SalesCommission }) => {
    if (sortField !== field) return null;
    return sortDirection === "asc" ? <ArrowUp className="h-4 w-4 ml-1" /> : <ArrowDown className="h-4 w-4 ml-1" />;
  };

  const renderSortableHeader = (label: string, field: keyof SalesCommission) => (
    <div 
      className="flex items-center cursor-pointer hover:text-primary"
      onClick={() => handleSort(field)}
    >
      {label}
      <SortIcon field={field} />
    </div>
  );

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return <Badge className="bg-green-100 text-green-800">Paid</Badge>;
      case "pending":
        return <Badge className="bg-amber-100 text-amber-800">Pending</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div>
        <div className="flex items-center justify-between mb-6">
          <Skeleton className="h-10 w-64" />
          <Skeleton className="h-10 w-28" />
        </div>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead><Skeleton className="h-4 w-28" /></TableHead>
                <TableHead><Skeleton className="h-4 w-32" /></TableHead>
                <TableHead><Skeleton className="h-4 w-28" /></TableHead>
                <TableHead><Skeleton className="h-4 w-32" /></TableHead>
                <TableHead><Skeleton className="h-4 w-24" /></TableHead>
                <TableHead><Skeleton className="h-4 w-24" /></TableHead>
                <TableHead><Skeleton className="h-4 w-24" /></TableHead>
                <TableHead><Skeleton className="h-4 w-24" /></TableHead>
                <TableHead><Skeleton className="h-4 w-24" /></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...Array(4)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-8 w-28" /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex flex-col md:flex-row items-start md:items-center md:justify-between gap-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search salesperson or order..."
              className="pl-8 w-64"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <Button
            variant="outline"
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-2"
          >
            <Filter className="h-4 w-4" />
            Filters {showFilters ? '↑' : '↓'}
          </Button>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
        </div>
      </div>
      
      {showFilters && (
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-wrap gap-6">
              <div className="flex flex-col gap-2">
                <Label htmlFor="statusFilter">Payment Status</Label>
                <Select
                  value={statusFilter}
                  onValueChange={setStatusFilter}
                >
                  <SelectTrigger id="statusFilter" className="w-36">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="paid">Paid</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {Object.entries(salespersonTotals).map(([id, data]) => (
          <Card key={id} className="p-4 shadow-sm">
            <div className="flex flex-col">
              <span className="text-sm text-muted-foreground">Salesperson</span>
              <span className="text-lg font-semibold">{data.name}</span>
              <div className="grid grid-cols-3 gap-4 mt-2">
                <div>
                  <span className="text-sm text-muted-foreground">Total</span>
                  <p className="font-medium">${data.total.toLocaleString()}</p>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">Pending</span>
                  <p className="font-medium">${data.pending.toLocaleString()}</p>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">Orders</span>
                  <p className="font-medium">{data.orderCount}</p>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>{renderSortableHeader("ID", "id")}</TableHead>
              <TableHead>{renderSortableHeader("Salesperson", "salespersonName")}</TableHead>
              <TableHead>{renderSortableHeader("Order", "orderId")}</TableHead>
              <TableHead>{renderSortableHeader("Customer", "orderCustomer")}</TableHead>
              <TableHead>{renderSortableHeader("Order Amount", "orderAmount")}</TableHead>
              <TableHead>{renderSortableHeader("Commission", "commissionAmount")}</TableHead>
              <TableHead>{renderSortableHeader("Status", "status")}</TableHead>
              <TableHead>{renderSortableHeader("Sale Date", "saleDate")}</TableHead>
              <TableHead>{renderSortableHeader("Payment Date", "paymentDate")}</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedCommissions.length === 0 ? (
              <TableRow>
                <TableCell colSpan={10} className="text-center py-6 text-muted-foreground">
                  No sales commissions matching your search
                </TableCell>
              </TableRow>
            ) : (
              sortedCommissions.map((commission) => (
                <TableRow key={commission.id}>
                  <TableCell className="font-medium">{commission.id}</TableCell>
                  <TableCell>{commission.salespersonName}</TableCell>
                  <TableCell>{commission.orderId}</TableCell>
                  <TableCell>{commission.orderCustomer}</TableCell>
                  <TableCell>${commission.orderAmount.toLocaleString()}</TableCell>
                  <TableCell>${commission.commissionAmount.toLocaleString()}</TableCell>
                  <TableCell>{getStatusBadge(commission.status)}</TableCell>
                  <TableCell>{commission.saleDate}</TableCell>
                  <TableCell>{commission.paymentDate || "—"}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="outline" size="icon">
                              <FileText className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>View Order Details</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="outline" size="icon">
                              <CircleDollarSign className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Process Commission Payment</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="outline" size="icon">
                              <PieChart className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>View Commission Structure</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default WholesaleSalesCommissions;
