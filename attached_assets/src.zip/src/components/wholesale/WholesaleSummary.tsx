
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, ShoppingBag, Users, Palette, Percent } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { api } from "@/lib/api";

const WholesaleSummary = () => {
  const navigate = useNavigate();

  const { data: summaryData, isLoading } = useQuery({
    queryKey: ['wholesaleSummary'],
    queryFn: async () => {
      // In a real implementation, this would fetch from Supabase
      // For now, we'll use mock data
      return {
        totalRevenue: 125000,
        pendingRevenue: 35000,
        totalOrders: 24,
        pendingOrders: 7,
        activeDesigners: 8,
        designCosts: 12500,
        salespeopleCount: 5,
        totalCommissions: 6250,
      };
    }
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardHeader className="pb-2">
              <Skeleton className="h-4 w-24" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-32" />
              <Skeleton className="h-4 w-40 mt-2" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              <DollarSign className="h-5 w-5 text-muted-foreground" />
              <span className="text-2xl font-bold">${summaryData?.totalRevenue.toLocaleString()}</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              ${summaryData?.pendingRevenue.toLocaleString()} pending
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              <ShoppingBag className="h-5 w-5 text-muted-foreground" />
              <span className="text-2xl font-bold">{summaryData?.totalOrders}</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {summaryData?.pendingOrders} pending fulfillment
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Designer Costs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              <Palette className="h-5 w-5 text-muted-foreground" />
              <span className="text-2xl font-bold">${summaryData?.designCosts.toLocaleString()}</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {summaryData?.activeDesigners} active designers
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Sales Commissions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              <Percent className="h-5 w-5 text-muted-foreground" />
              <span className="text-2xl font-bold">${summaryData?.totalCommissions.toLocaleString()}</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {summaryData?.salespeopleCount} salespeople
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
        <Card>
          <CardHeader>
            <CardTitle>Revenue Breakdown</CardTitle>
            <CardDescription>Wholesale revenue by month</CardDescription>
          </CardHeader>
          <CardContent className="h-80">
            <div className="flex h-full items-center justify-center">
              <p className="text-muted-foreground">Revenue chart will be displayed here</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top Products</CardTitle>
            <CardDescription>Best-selling wholesale items</CardDescription>
          </CardHeader>
          <CardContent className="h-80">
            <div className="flex h-full items-center justify-center">
              <p className="text-muted-foreground">Product breakdown will be displayed here</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end mt-6">
        <Button variant="outline" onClick={() => navigate("/wholesale/reports")}>
          View Detailed Reports
        </Button>
      </div>
    </>
  );
};

export default WholesaleSummary;
