
import { createContext, useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';

interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'sales' | 'designer' | 'manufacturing';
  profileId?: string;
}

export interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  isAdmin: boolean;
  userRole: string;
  isLoading: boolean;
  isAuthenticated: boolean;
  refreshUserProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  login: async () => {},
  logout: () => {},
  isAdmin: false,
  userRole: 'guest',
  isLoading: false,
  isAuthenticated: false,
  refreshUserProfile: async () => {},
});

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [userRole, setUserRole] = useState('guest');
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const navigate = useNavigate();

  const fetchUserProfile = async (userId: string) => {
    try {
      const { data: profile, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) {
        console.error('Error fetching user profile:', error);
        return null;
      }

      return profile;
    } catch (error) {
      console.error('Failed to fetch user profile:', error);
      return null;
    }
  };

  const ensureUserProfile = async (userId: string, email: string) => {
    try {
      // Check if profile exists
      let profile = await fetchUserProfile(userId);
      
      // If profile doesn't exist, create one
      if (!profile) {
        let role = 'sales'; // Default role
        
        // Determine role based on email
        if (email.includes('rich-habits.com')) {
          role = 'admin';
        } else if (email === 'designer@example.com') {
          role = 'designer';
        } else if (email === 'manufacturing@example.com') {
          role = 'manufacturing';
        }
        
        const name = email.split('@')[0] || 'User';
        
        const { data, error } = await supabase
          .from('user_profiles')
          .insert([
            { id: userId, email, name, role }
          ])
          .select()
          .single();
          
        if (error) {
          console.error('Error creating user profile:', error);
          return null;
        }
        
        profile = data;
      }
      
      return profile;
    } catch (error) {
      console.error('Error ensuring user profile:', error);
      return null;
    }
  };

  const refreshUserProfile = async () => {
    if (!user?.id) return;
    
    const profile = await fetchUserProfile(user.id);
    if (profile) {
      const updatedUser = {
        ...user,
        name: profile.name || user.name,
        role: profile.role || user.role
      };
      
      setUser(updatedUser);
      setIsAdmin(updatedUser.role === 'admin');
      setUserRole(updatedUser.role);
      console.log('User profile refreshed:', updatedUser);
    }
  };

  useEffect(() => {
    const loadUser = async () => {
      setIsLoading(true);
      
      try {
        // First, get the current session
        const { data: { session } } = await supabase.auth.getSession();
        
        if (session && session.user) {
          // Ensure user profile exists (creates one if it doesn't)
          const profile = await ensureUserProfile(session.user.id, session.user.email || '');
          let userRole = 'guest';
          let isAdmin = false;
          
          if (profile) {
            // Use role from profile
            userRole = profile.role;
            isAdmin = profile.role === 'admin';
          } else {
            // Fallback to email domain logic if profile creation failed
            const emailDomain = session.user.email?.split('@')[1];
            
            if (emailDomain === 'rich-habits.com') {
              isAdmin = true;
              userRole = 'admin';
            } else if (emailDomain === 'sales.rich-habits.com' || 
                      session.user.email === 'sales@example.com' ||
                      session.user.email === 'laird@rich-habits.com' ||
                      session.user.email === 'colinvasquez@rich-habits.com') {
              userRole = 'sales';
            } else if (emailDomain === 'design.rich-habits.com' || session.user.email === 'designer@example.com') {
              userRole = 'designer';
            } else if (emailDomain === 'manufacturing.rich-habits.com' || session.user.email === 'manufacturing@example.com') {
              userRole = 'manufacturing';
            }
          }
          
          const userDetails: User = {
            id: session.user.id,
            email: session.user.email || '',
            name: profile?.name || session.user.email?.split('@')[0] || 'User',
            role: userRole as 'admin' | 'sales' | 'designer' | 'manufacturing',
            profileId: profile?.id
          };
          
          setUser(userDetails);
          setIsAdmin(isAdmin);
          setUserRole(userRole);
          setIsAuthenticated(true);
          console.log('User authenticated:', userDetails);
        } else {
          // Check for demo user in localStorage
          const tokenData = localStorage.getItem('supabase.auth.token');
          if (tokenData) {
            try {
              const parsedData = JSON.parse(tokenData);
              if (parsedData.currentSession && parsedData.currentSession.user) {
                const demoUser = parsedData.currentSession.user;
                
                // Ensure demo user has a profile
                const profile = await ensureUserProfile(demoUser.id, demoUser.email || '');
                let userRole = profile?.role || demoUser.user_metadata?.role || 'guest';
                let isAdmin = userRole === 'admin';
                
                const userDetails: User = {
                  id: demoUser.id,
                  email: demoUser.email || '',
                  name: profile?.name || demoUser.email?.split('@')[0] || 'User',
                  role: userRole as 'admin' | 'sales' | 'designer' | 'manufacturing',
                  profileId: profile?.id
                };
                
                setUser(userDetails);
                setIsAdmin(isAdmin);
                setUserRole(userRole);
                setIsAuthenticated(true);
                console.log('Demo user authenticated:', userDetails);
                setIsLoading(false);
                return;
              }
            } catch (e) {
              console.error('Error parsing demo user data:', e);
            }
          }
          
          // No valid session found
          setUser(null);
          setIsAdmin(false);
          setUserRole('guest');
          setIsAuthenticated(false);
        }
      } catch (error) {
        console.error('Authentication loading error:', error);
        setUser(null);
        setIsAdmin(false);
        setUserRole('guest');
        setIsAuthenticated(false);
      } finally {
        setIsLoading(false);
      }
    };

    loadUser();

    // Set up auth state change listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_IN' && session) {
        // Don't reload user here to avoid infinite loops
        // Just set loading so UI can show something
        setIsLoading(true);
        
        // Use setTimeout to defer the user loading logic to next tick
        setTimeout(() => {
          loadUser();
        }, 0);
      } else if (event === 'SIGNED_OUT') {
        setUser(null);
        setIsAdmin(false);
        setUserRole('guest');
        setIsAuthenticated(false);
        setIsLoading(false);
      }
    });

    // Also listen for custom demo auth events
    const handleTokenChange = () => {
      loadUser();
    };
    
    window.addEventListener('supabase.auth.token-changed', handleTokenChange);

    return () => {
      subscription.unsubscribe();
      window.removeEventListener('supabase.auth.token-changed', handleTokenChange);
    };
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    
    try {
      // Use regular login function
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        // If regular login fails, check if it's a demo user
        if (
          (email === 'sales@example.com' && password === 'password') ||
          (email === 'designer@example.com' && password === 'password') ||
          (email === 'manufacturing@example.com' && password === 'password') ||
          (email === 'samsutton@rich-habits.com' && password === 'Arlodog2013!') ||
          (email === 'colinvasquez@rich-habits.com' && password === 'bigchungus$!Afro') ||
          (email === 'laird@rich-habits.com' && password === 'tinyCOCK420##!')
        ) {
          // Mock user session for demo users
          const mockRole = email.includes('rich-habits.com') ? 'admin' : 
                          email.startsWith('sales') ? 'sales' :
                          email.startsWith('designer') ? 'designer' : 'manufacturing';
          
          const demoId = `demo-${Date.now()}`;
          const mockUser = {
            id: demoId,
            email: email,
            user_metadata: {
              name: email.split('@')[0],
              role: mockRole
            }
          };

          // Ensure this demo user has a profile in our database
          await ensureUserProfile(demoId, email);
          
          // Store mock user in localStorage to persist the session
          localStorage.setItem('supabase.auth.token', JSON.stringify({
            currentSession: {
              access_token: `demo-token-${Date.now()}`,
              refresh_token: `demo-refresh-${Date.now()}`,
              user: mockUser,
              expires_at: Date.now() + 86400000 // 24 hours
            }
          }));
          
          // Trigger auth state change to update the UI
          const event = new CustomEvent('supabase.auth.token-changed');
          window.dispatchEvent(event);
          
          // Force a small delay to ensure state updates before navigation
          await new Promise(resolve => setTimeout(resolve, 300));
          
          // Explicitly set the authenticated state before navigation
          setUser({
            id: mockUser.id,
            email: mockUser.email,
            name: mockUser.email.split('@')[0],
            role: mockRole as 'admin' | 'sales' | 'designer' | 'manufacturing'
          });
          setIsAuthenticated(true);
          
          console.log('Demo login successful, redirecting to home page');
          navigate('/', { replace: true });
          toast.success('Login successful');
          return;
        } else {
          throw error;
        }
      }

      if (data?.user) {
        console.log('Login successful, user data:', data.user);
        
        // Ensure user has a profile
        await ensureUserProfile(data.user.id, data.user.email || '');
        
        // Fetch profile data
        const profile = await fetchUserProfile(data.user.id);
        
        // Force a small delay to ensure state updates before navigation
        await new Promise(resolve => setTimeout(resolve, 300));
        
        // Explicitly set the authenticated state before navigation
        const userRole = profile?.role || 'guest';
        setUser({
          id: data.user.id,
          email: data.user.email || '',
          name: profile?.name || data.user.email?.split('@')[0] || 'User',
          role: userRole as 'admin' | 'sales' | 'designer' | 'manufacturing',
          profileId: profile?.id
        });
        setIsAdmin(userRole === 'admin');
        setUserRole(userRole);
        setIsAuthenticated(true);
        
        console.log('Authentication state updated, redirecting to home page');
        navigate('/', { replace: true });
        toast.success('Login successful');
        return;
      }
    } catch (error: any) {
      console.error('Login failed:', error.message);
      toast.error(`Login failed: ${error.message}`);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    setIsLoading(true);
    try {
      // Clear demo user data if it exists
      localStorage.removeItem('supabase.auth.token');
      
      await supabase.auth.signOut();
      setUser(null);
      setIsAdmin(false);
      setUserRole('guest');
      setIsAuthenticated(false);
      navigate('/login');
      toast.success('Logged out successfully');
    } catch (error) {
      console.error('Logout failed:', error);
      toast.error('Logout failed');
    } finally {
      setIsLoading(false);
    }
  };

  const value: AuthContextType = {
    user,
    login,
    logout,
    isAdmin,
    userRole,
    isLoading,
    isAuthenticated,
    refreshUserProfile,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
