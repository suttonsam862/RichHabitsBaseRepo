
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase, isSupabaseConfigured } from "@/lib/supabase";
import type { Organization } from "@/services/baseService";

export type NewClientData = {
  name: string;
  email?: string;
  phone?: string;
  contact_first_name?: string;
  contact_last_name?: string;
  billing_address?: string;
  billing_address_line2?: string;
  billing_city?: string;
  billing_state?: string;
  billing_zip?: string;
  shipping_address?: string;
  shipping_address_line2?: string;
  shipping_city?: string;
  shipping_state?: string;
  shipping_zip?: string;
  notes?: string;
};

export const useClientData = () => {
  const queryClient = useQueryClient();
  const [isSupabaseConnected] = useState(isSupabaseConfigured());

  // Fetch organizations from Supabase
  const { data: clients = [], isLoading } = useQuery({
    queryKey: ['organizations'],
    queryFn: async (): Promise<Organization[]> => {
      if (!isSupabaseConnected) {
        return []; // Return empty array instead of mock data
      }

      try {
        const { data, error } = await supabase
          .from('organizations')
          .select('*')
          .order('name');
        
        if (error) {
          throw new Error(`Error fetching organizations: ${error.message}`);
        }
        
        return data || [];
      } catch (error) {
        console.error('Error fetching clients:', error);
        toast.error('Failed to load clients');
        return [];
      }
    },
    meta: {
      onSettled: (data, error) => {
        if (error) {
          console.error('Error fetching clients:', error);
        }
      }
    }
  });

  // Add a new client
  const addClientMutation = useMutation({
    mutationFn: async (clientData: NewClientData): Promise<Organization> => {
      if (!isSupabaseConnected) {
        // Mock client creation for when Supabase is not connected - using correct field names
        return {
          id: `mock-${Date.now()}`,
          name: clientData.name,
          phone: clientData.phone || '',
          email: clientData.email || '',
          billing_address: clientData.billing_address || '',
          billing_address_line2: clientData.billing_address_line2 || '',
          billing_city: clientData.billing_city || '',
          billing_state: clientData.billing_state || '',
          billing_zip: clientData.billing_zip || '',
          shipping_address: clientData.shipping_address || '',
          shipping_address_line2: clientData.shipping_address_line2 || '',
          shipping_city: clientData.shipping_city || '',
          shipping_state: clientData.shipping_state || '',
          shipping_zip: clientData.shipping_zip || '',
          contact_first_name: clientData.contact_first_name || '',
          contact_last_name: clientData.contact_last_name || '',
          notes: clientData.notes || '',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        };
      }

      const { data, error } = await supabase
        .from('organizations')
        .insert([clientData])
        .select()
        .single();
      
      if (error) {
        throw new Error(`Error creating client: ${error.message}`);
      }
      
      return data;
    },
    onSuccess: () => {
      toast.success("Client added successfully");
      queryClient.invalidateQueries({ queryKey: ['organizations'] });
    },
    onError: (error) => {
      toast.error(`Failed to add client: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  });

  const addClient = async (clientData: NewClientData) => {
    await addClientMutation.mutateAsync(clientData);
  };

  return {
    clients,
    isLoading,
    addClient,
    isSupabaseConnected
  };
};
