
import { useLocation } from "react-router-dom";
import { useTutorial } from "@/components/tutorial/TutorialContext";
import { getTutorialForPath } from "@/components/tutorial/pageTutorials";

export const usePageTutorial = () => {
  const location = useLocation();
  const tutorialContext = useTutorial();
  const tutorialData = getTutorialForPath(location.pathname);

  return {
    ...tutorialContext,
    tutorial: tutorialData,
  };
};
