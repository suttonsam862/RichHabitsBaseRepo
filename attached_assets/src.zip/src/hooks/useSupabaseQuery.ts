
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";

interface UseSupabaseQueryOptions<T> {
  key: string[];
  table: string;
  select?: string;
  filter?: {
    column: string;
    value: any;
    operator?: string;
  }[];
  order?: {
    column: string;
    ascending?: boolean;
  };
  single?: boolean;
  enabled?: boolean;
  onSuccess?: (data: T) => void;
  onError?: (error: Error) => void;
}

export function useSupabaseQuery<T>({
  key,
  table,
  select = "*",
  filter,
  order,
  single = false,
  enabled = true,
  onSuccess,
  onError,
}: UseSupabaseQueryOptions<T>) {
  return useQuery({
    queryKey: key,
    queryFn: async (): Promise<T> => {
      try {
        let query = supabase.from(table).select(select);

        // Apply filters if provided
        if (filter && filter.length > 0) {
          filter.forEach((f) => {
            const operator = f.operator || "eq";
            if (operator === "eq") {
              query = query.eq(f.column, f.value);
            } else if (operator === "gt") {
              query = query.gt(f.column, f.value);
            } else if (operator === "lt") {
              query = query.lt(f.column, f.value);
            } else if (operator === "gte") {
              query = query.gte(f.column, f.value);
            } else if (operator === "lte") {
              query = query.lte(f.column, f.value);
            } else if (operator === "like") {
              query = query.like(f.column, f.value);
            } else if (operator === "ilike") {
              query = query.ilike(f.column, f.value);
            }
          });
        }

        // Apply ordering if provided
        if (order) {
          query = query.order(order.column, {
            ascending: order.ascending ?? true,
          });
        }

        // Get single record or multiple
        const { data, error } = single
          ? await query.single()
          : await query;

        if (error) {
          throw new Error(`Error fetching data: ${error.message}`);
        }

        if (onSuccess) {
          onSuccess(data as T);
        }

        return data as T;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        toast.error(`Query error: ${errorMessage}`);
        if (onError) {
          onError(error instanceof Error ? error : new Error(String(error)));
        }
        throw error;
      }
    },
    enabled,
  });
}
