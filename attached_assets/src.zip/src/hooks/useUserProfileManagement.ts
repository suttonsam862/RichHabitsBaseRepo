
import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { useAuth } from '@/context/AuthContext';

export interface UserProfileUpdateData {
  name?: string;
  role?: 'admin' | 'sales' | 'designer' | 'manufacturing';
  profile_image_url?: string | null;
}

export interface UserProfile {
  id: string;
  email: string;
  name: string | null;
  role: 'admin' | 'sales' | 'designer' | 'manufacturing';
  profile_image_url?: string | null;
  created_at?: string;
  updated_at?: string;
}

export function useUserProfileManagement() {
  const [isLoading, setIsLoading] = useState(false);
  const { refreshUserProfile } = useAuth();

  // Ensure user profile exists in user_profiles table
  const ensureUserProfile = async (
    userId: string, 
    email: string, 
    defaultRole: 'admin' | 'sales' | 'designer' | 'manufacturing' = 'sales'
  ): Promise<UserProfile | null> => {
    setIsLoading(true);
    try {
      console.log(`Ensuring user profile for ${email} with ID ${userId} and role ${defaultRole}`);
      
      // For demo accounts with non-UUID IDs, generate a valid UUID
      const isDemo = userId.startsWith('demo-') || !userId.includes('-');
      const validUserId = isDemo 
        ? `00000000-0000-0000-0000-${Date.now().toString().slice(-12)}`
        : userId;
        
      // Check if profile already exists
      const { data: existingProfile, error: checkError } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('email', email)
        .maybeSingle();

      if (checkError) {
        console.error('Error checking user profile:', checkError);
        return null;
      }

      // If profile exists, return it
      if (existingProfile) {
        console.log('User profile already exists:', existingProfile);
        return existingProfile as UserProfile;
      }

      // Extract name from email
      const name = email.split('@')[0] || email;

      // Determine role based on email
      let role = defaultRole;
      
      // Check for admin accounts based on email domain or specific addresses
      if (email.includes('rich-habits.com')) {
        // Admin emails include specific sales accounts and general admins
        if (email === 'laird@rich-habits.com' || 
            email === 'colinvasquez@rich-habits.com') {
          role = 'sales';
        } else {
          // Default to admin for all other rich-habits.com emails
          role = 'admin';
        }
      } else if (email === 'sales@example.com') {
        role = 'sales';
      } else if (email === 'designer@example.com') {
        role = 'designer';
      } else if (email === 'manufacturing@example.com') {
        role = 'manufacturing';
      }

      console.log(`Creating new profile for ${email} with role ${role}`);

      // Create new profile
      const { data: newProfile, error: insertError } = await supabase
        .from('user_profiles')
        .insert([
          { id: validUserId, email, name, role }
        ])
        .select()
        .single();

      if (insertError) {
        console.error('Error creating user profile:', insertError);
        toast.error('Failed to create user profile');
        return null;
      }

      console.log('User profile created successfully:', newProfile);
      toast.success('User profile created successfully');
      return newProfile as UserProfile;
    } catch (error) {
      console.error('Error in ensureUserProfile:', error);
      toast.error('An unexpected error occurred');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  // Update user profile
  const updateUserProfile = async (
    userIdOrEmail: string, 
    updates: UserProfileUpdateData
  ): Promise<UserProfile | null> => {
    setIsLoading(true);
    try {
      const isEmail = userIdOrEmail.includes('@');
      
      let query = supabase
        .from('user_profiles')
        .update(updates);
        
      if (isEmail) {
        query = query.eq('email', userIdOrEmail);
      } else {
        query = query.eq('id', userIdOrEmail);
      }
      
      const { data, error } = await query.select().single();
      
      if (error) {
        console.error('Error updating user profile:', error);
        toast.error('Failed to update user profile');
        return null;
      }
      
      refreshUserProfile();
      toast.success('Profile updated successfully');
      return data as UserProfile;
    } catch (error) {
      console.error('Error updating user profile:', error);
      toast.error('An unexpected error occurred');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  // Get user profile by email or ID
  const getUserProfile = async (
    userIdOrEmail: string
  ): Promise<UserProfile | null> => {
    setIsLoading(true);
    try {
      const isEmail = userIdOrEmail.includes('@');
      
      let query = supabase
        .from('user_profiles')
        .select('*');
        
      if (isEmail) {
        query = query.eq('email', userIdOrEmail);
      } else {
        query = query.eq('id', userIdOrEmail);
      }
      
      const { data, error } = await query.maybeSingle();
      
      if (error) {
        console.error('Error fetching user profile:', error);
        return null;
      }
      
      return data as UserProfile;
    } catch (error) {
      console.error('Error fetching user profile:', error);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    isLoading,
    ensureUserProfile,
    updateUserProfile,
    getUserProfile
  };
}
