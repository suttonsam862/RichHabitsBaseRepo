
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';

export interface UserProfile {
  id: string;
  email: string;
  name: string | null;
  role: 'admin' | 'sales' | 'designer' | 'manufacturing';
  profile_image_url: string | null;
  created_at: string;
  updated_at: string;
}

export const useUserProfiles = () => {
  const [isLoading, setIsLoading] = useState(false);

  // Fetch all user profiles
  const { data: userProfiles = [], refetch } = useQuery({
    queryKey: ['userProfiles'],
    queryFn: async (): Promise<UserProfile[]> => {
      try {
        const { data, error } = await supabase
          .from('user_profiles')
          .select('*')
          .order('name');
        
        if (error) {
          throw new Error(`Error fetching user profiles: ${error.message}`);
        }
        
        return data || [];
      } catch (error) {
        console.error('Error fetching user profiles:', error);
        toast.error('Failed to load user profiles');
        return [];
      }
    }
  });

  // Get profiles by role
  const getSalesTeam = () => {
    return userProfiles.filter(profile => profile.role === 'sales');
  };

  const getDesignTeam = () => {
    return userProfiles.filter(profile => profile.role === 'designer');
  };

  const getManufacturingTeam = () => {
    return userProfiles.filter(profile => profile.role === 'manufacturing');
  };

  const getAdmins = () => {
    return userProfiles.filter(profile => profile.role === 'admin');
  };

  // Get a single user profile by id
  const getUserById = (id: string) => {
    return userProfiles.find(profile => profile.id === id);
  };

  // Get a single user profile by email
  const getUserByEmail = (email: string) => {
    return userProfiles.find(profile => profile.email === email);
  };

  // Update a user profile
  const updateUserProfile = async (id: string, updates: Partial<UserProfile>) => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      
      if (error) {
        throw error;
      }
      
      await refetch();
      toast.success('Profile updated successfully');
      return data;
    } catch (error) {
      console.error('Error updating user profile:', error);
      toast.error('Failed to update profile');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    userProfiles,
    isLoading,
    refetch,
    getSalesTeam,
    getDesignTeam,
    getManufacturingTeam,
    getAdmins,
    getUserById,
    getUserByEmail,
    updateUserProfile
  };
};
