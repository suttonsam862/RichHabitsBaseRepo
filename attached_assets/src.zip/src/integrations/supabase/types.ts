export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      camp_attendees: {
        Row: {
          age: number | null
          allergies: string | null
          camp_id: string | null
          created_at: string | null
          emergency_contact: string | null
          emergency_phone: string | null
          first_name: string
          grade: string | null
          guardian_email: string | null
          guardian_name: string | null
          guardian_phone: string | null
          id: string
          last_name: string
          notes: string | null
          registration_date: string | null
          shirt_size: string | null
          updated_at: string | null
        }
        Insert: {
          age?: number | null
          allergies?: string | null
          camp_id?: string | null
          created_at?: string | null
          emergency_contact?: string | null
          emergency_phone?: string | null
          first_name: string
          grade?: string | null
          guardian_email?: string | null
          guardian_name?: string | null
          guardian_phone?: string | null
          id?: string
          last_name: string
          notes?: string | null
          registration_date?: string | null
          shirt_size?: string | null
          updated_at?: string | null
        }
        Update: {
          age?: number | null
          allergies?: string | null
          camp_id?: string | null
          created_at?: string | null
          emergency_contact?: string | null
          emergency_phone?: string | null
          first_name?: string
          grade?: string | null
          guardian_email?: string | null
          guardian_name?: string | null
          guardian_phone?: string | null
          id?: string
          last_name?: string
          notes?: string | null
          registration_date?: string | null
          shirt_size?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "camp_attendees_camp_id_fkey"
            columns: ["camp_id"]
            isOneToOne: false
            referencedRelation: "camps"
            referencedColumns: ["id"]
          },
        ]
      }
      camps: {
        Row: {
          age_group: string
          capacity: number
          coach: string | null
          created_at: string | null
          description: string | null
          end_date: string
          enrollment_count: number | null
          id: string
          includes_uniform: boolean | null
          location: string
          name: string
          price: number
          sport_type: string
          start_date: string
          status: string | null
          updated_at: string | null
        }
        Insert: {
          age_group: string
          capacity: number
          coach?: string | null
          created_at?: string | null
          description?: string | null
          end_date: string
          enrollment_count?: number | null
          id?: string
          includes_uniform?: boolean | null
          location: string
          name: string
          price: number
          sport_type: string
          start_date: string
          status?: string | null
          updated_at?: string | null
        }
        Update: {
          age_group?: string
          capacity?: number
          coach?: string | null
          created_at?: string | null
          description?: string | null
          end_date?: string
          enrollment_count?: number | null
          id?: string
          includes_uniform?: boolean | null
          location?: string
          name?: string
          price?: number
          sport_type?: string
          start_date?: string
          status?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      design_assignments: {
        Row: {
          assigned_at: string | null
          created_at: string | null
          design_type: string
          designer_id: string | null
          due_date: string | null
          id: string
          notes: string | null
          order_id: string | null
          status: string
          updated_at: string | null
        }
        Insert: {
          assigned_at?: string | null
          created_at?: string | null
          design_type: string
          designer_id?: string | null
          due_date?: string | null
          id?: string
          notes?: string | null
          order_id?: string | null
          status?: string
          updated_at?: string | null
        }
        Update: {
          assigned_at?: string | null
          created_at?: string | null
          design_type?: string
          designer_id?: string | null
          due_date?: string | null
          id?: string
          notes?: string | null
          order_id?: string | null
          status?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "design_assignments_designer_id_fkey"
            columns: ["designer_id"]
            isOneToOne: false
            referencedRelation: "designers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "design_assignments_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      design_submissions: {
        Row: {
          created_at: string | null
          design_type: string
          designer_id: string | null
          feedback: string | null
          id: string
          image_url: string | null
          notes: string | null
          order_id: string | null
          payment_amount: number | null
          payment_date: string | null
          payment_status: string | null
          status: string
          submission_date: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          design_type: string
          designer_id?: string | null
          feedback?: string | null
          id?: string
          image_url?: string | null
          notes?: string | null
          order_id?: string | null
          payment_amount?: number | null
          payment_date?: string | null
          payment_status?: string | null
          status?: string
          submission_date?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          design_type?: string
          designer_id?: string | null
          feedback?: string | null
          id?: string
          image_url?: string | null
          notes?: string | null
          order_id?: string | null
          payment_amount?: number | null
          payment_date?: string | null
          payment_status?: string | null
          status?: string
          submission_date?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "design_submissions_designer_id_fkey"
            columns: ["designer_id"]
            isOneToOne: false
            referencedRelation: "designers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "design_submissions_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      designers: {
        Row: {
          address: string | null
          bank_account: string | null
          city: string | null
          created_at: string | null
          email: string
          id: string
          name: string
          notes: string | null
          phone: string | null
          profile_image_url: string | null
          rate_per_design: number
          state: string | null
          tax_id: string | null
          updated_at: string | null
          zip: string | null
        }
        Insert: {
          address?: string | null
          bank_account?: string | null
          city?: string | null
          created_at?: string | null
          email: string
          id?: string
          name: string
          notes?: string | null
          phone?: string | null
          profile_image_url?: string | null
          rate_per_design?: number
          state?: string | null
          tax_id?: string | null
          updated_at?: string | null
          zip?: string | null
        }
        Update: {
          address?: string | null
          bank_account?: string | null
          city?: string | null
          created_at?: string | null
          email?: string
          id?: string
          name?: string
          notes?: string | null
          phone?: string | null
          profile_image_url?: string | null
          rate_per_design?: number
          state?: string | null
          tax_id?: string | null
          updated_at?: string | null
          zip?: string | null
        }
        Relationships: []
      }
      dummy_check: {
        Row: {
          created_at: string
          id: number
        }
        Insert: {
          created_at?: string
          id?: number
        }
        Update: {
          created_at?: string
          id?: number
        }
        Relationships: []
      }
      leads: {
        Row: {
          assigned_to: string | null
          assigned_user_id: string | null
          claimed_at: string | null
          created_at: string
          email: string | null
          estimated_value: number | null
          id: string
          name: string
          notes: string | null
          organization: string
          organization_id: string | null
          owner: string | null
          owner_id: string | null
          phone: string | null
          status: Database["public"]["Enums"]["lead_status"]
          updated_at: string
        }
        Insert: {
          assigned_to?: string | null
          assigned_user_id?: string | null
          claimed_at?: string | null
          created_at?: string
          email?: string | null
          estimated_value?: number | null
          id?: string
          name: string
          notes?: string | null
          organization: string
          organization_id?: string | null
          owner?: string | null
          owner_id?: string | null
          phone?: string | null
          status?: Database["public"]["Enums"]["lead_status"]
          updated_at?: string
        }
        Update: {
          assigned_to?: string | null
          assigned_user_id?: string | null
          claimed_at?: string | null
          created_at?: string
          email?: string | null
          estimated_value?: number | null
          id?: string
          name?: string
          notes?: string | null
          organization?: string
          organization_id?: string | null
          owner?: string | null
          owner_id?: string | null
          phone?: string | null
          status?: Database["public"]["Enums"]["lead_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "leads_assigned_user_id_fkey"
            columns: ["assigned_user_id"]
            isOneToOne: false
            referencedRelation: "user_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leads_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leads_owner_id_fkey"
            columns: ["owner_id"]
            isOneToOne: false
            referencedRelation: "user_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      line_items: {
        Row: {
          color: string | null
          created_at: string
          customization: string | null
          id: string
          notes: string | null
          order_id: string
          product_id: string
          quantity: number
          size: string | null
          unit_price: number
          updated_at: string
        }
        Insert: {
          color?: string | null
          created_at?: string
          customization?: string | null
          id?: string
          notes?: string | null
          order_id: string
          product_id: string
          quantity: number
          size?: string | null
          unit_price: number
          updated_at?: string
        }
        Update: {
          color?: string | null
          created_at?: string
          customization?: string | null
          id?: string
          notes?: string | null
          order_id?: string
          product_id?: string
          quantity?: number
          size?: string | null
          unit_price?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "line_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "line_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      manufacturing_staff: {
        Row: {
          address: string | null
          bank_account: string | null
          certifications: string[] | null
          city: string | null
          created_at: string | null
          department: string | null
          email: string
          hire_date: string | null
          hourly_rate: number | null
          id: string
          name: string
          notes: string | null
          phone: string | null
          profile_image_url: string | null
          role: string
          skills: string[] | null
          state: string | null
          tax_id: string | null
          updated_at: string | null
          zip: string | null
        }
        Insert: {
          address?: string | null
          bank_account?: string | null
          certifications?: string[] | null
          city?: string | null
          created_at?: string | null
          department?: string | null
          email: string
          hire_date?: string | null
          hourly_rate?: number | null
          id?: string
          name: string
          notes?: string | null
          phone?: string | null
          profile_image_url?: string | null
          role: string
          skills?: string[] | null
          state?: string | null
          tax_id?: string | null
          updated_at?: string | null
          zip?: string | null
        }
        Update: {
          address?: string | null
          bank_account?: string | null
          certifications?: string[] | null
          city?: string | null
          created_at?: string | null
          department?: string | null
          email?: string
          hire_date?: string | null
          hourly_rate?: number | null
          id?: string
          name?: string
          notes?: string | null
          phone?: string | null
          profile_image_url?: string | null
          role?: string
          skills?: string[] | null
          state?: string | null
          tax_id?: string | null
          updated_at?: string | null
          zip?: string | null
        }
        Relationships: []
      }
      manufacturing_vendors: {
        Row: {
          active: boolean | null
          address: string | null
          average_turnaround_time: number | null
          city: string | null
          company_size: number | null
          contact_person: string | null
          cost_per_unit: number | null
          country: string | null
          created_at: string | null
          email: string | null
          id: string
          lead_time: number | null
          minimum_order: number | null
          name: string
          notes: string | null
          phone: string | null
          region: string | null
          specialties: string[] | null
          state: string | null
          updated_at: string | null
          zip: string | null
        }
        Insert: {
          active?: boolean | null
          address?: string | null
          average_turnaround_time?: number | null
          city?: string | null
          company_size?: number | null
          contact_person?: string | null
          cost_per_unit?: number | null
          country?: string | null
          created_at?: string | null
          email?: string | null
          id?: string
          lead_time?: number | null
          minimum_order?: number | null
          name: string
          notes?: string | null
          phone?: string | null
          region?: string | null
          specialties?: string[] | null
          state?: string | null
          updated_at?: string | null
          zip?: string | null
        }
        Update: {
          active?: boolean | null
          address?: string | null
          average_turnaround_time?: number | null
          city?: string | null
          company_size?: number | null
          contact_person?: string | null
          cost_per_unit?: number | null
          country?: string | null
          created_at?: string | null
          email?: string | null
          id?: string
          lead_time?: number | null
          minimum_order?: number | null
          name?: string
          notes?: string | null
          phone?: string | null
          region?: string | null
          specialties?: string[] | null
          state?: string | null
          updated_at?: string | null
          zip?: string | null
        }
        Relationships: []
      }
      orders: {
        Row: {
          assigned_to: string | null
          assigned_user_id: string | null
          created_at: string
          customer_id: string
          design_files: string | null
          design_status: string | null
          id: string
          invoice_id: string | null
          invoice_status: string | null
          lead_id: string | null
          notes: string | null
          status: Database["public"]["Enums"]["order_status"]
          total: number | null
          tracking_number: string | null
          updated_at: string
        }
        Insert: {
          assigned_to?: string | null
          assigned_user_id?: string | null
          created_at?: string
          customer_id: string
          design_files?: string | null
          design_status?: string | null
          id?: string
          invoice_id?: string | null
          invoice_status?: string | null
          lead_id?: string | null
          notes?: string | null
          status?: Database["public"]["Enums"]["order_status"]
          total?: number | null
          tracking_number?: string | null
          updated_at?: string
        }
        Update: {
          assigned_to?: string | null
          assigned_user_id?: string | null
          created_at?: string
          customer_id?: string
          design_files?: string | null
          design_status?: string | null
          id?: string
          invoice_id?: string | null
          invoice_status?: string | null
          lead_id?: string | null
          notes?: string | null
          status?: Database["public"]["Enums"]["order_status"]
          total?: number | null
          tracking_number?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "orders_assigned_user_id_fkey"
            columns: ["assigned_user_id"]
            isOneToOne: false
            referencedRelation: "user_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "orders_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "orders_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      organizations: {
        Row: {
          billing_address: string | null
          billing_address_line2: string | null
          billing_city: string | null
          billing_state: string | null
          billing_zip: string | null
          contact_first_name: string | null
          contact_last_name: string | null
          created_at: string
          email: string | null
          id: string
          name: string
          notes: string | null
          phone: string | null
          shipping_address: string | null
          shipping_address_line2: string | null
          shipping_city: string | null
          shipping_state: string | null
          shipping_zip: string | null
          updated_at: string
        }
        Insert: {
          billing_address?: string | null
          billing_address_line2?: string | null
          billing_city?: string | null
          billing_state?: string | null
          billing_zip?: string | null
          contact_first_name?: string | null
          contact_last_name?: string | null
          created_at?: string
          email?: string | null
          id?: string
          name: string
          notes?: string | null
          phone?: string | null
          shipping_address?: string | null
          shipping_address_line2?: string | null
          shipping_city?: string | null
          shipping_state?: string | null
          shipping_zip?: string | null
          updated_at?: string
        }
        Update: {
          billing_address?: string | null
          billing_address_line2?: string | null
          billing_city?: string | null
          billing_state?: string | null
          billing_zip?: string | null
          contact_first_name?: string | null
          contact_last_name?: string | null
          created_at?: string
          email?: string | null
          id?: string
          name?: string
          notes?: string | null
          phone?: string | null
          shipping_address?: string | null
          shipping_address_line2?: string | null
          shipping_city?: string | null
          shipping_state?: string | null
          shipping_zip?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      products: {
        Row: {
          category: string | null
          colors: string[] | null
          created_at: string
          description: string | null
          id: string
          image_url: string | null
          inventory: number | null
          name: string
          price: number
          sizes: string[] | null
          sport: string | null
          updated_at: string
        }
        Insert: {
          category?: string | null
          colors?: string[] | null
          created_at?: string
          description?: string | null
          id?: string
          image_url?: string | null
          inventory?: number | null
          name: string
          price: number
          sizes?: string[] | null
          sport?: string | null
          updated_at?: string
        }
        Update: {
          category?: string | null
          colors?: string[] | null
          created_at?: string
          description?: string | null
          id?: string
          image_url?: string | null
          inventory?: number | null
          name?: string
          price?: number
          sizes?: string[] | null
          sport?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      sales_people: {
        Row: {
          address: string | null
          annual_target: number | null
          bank_account: string | null
          city: string | null
          commission_rate: number
          created_at: string | null
          email: string
          hire_date: string | null
          id: string
          monthly_target: number | null
          name: string
          notes: string | null
          phone: string | null
          profile_image_url: string | null
          quarterly_target: number | null
          state: string | null
          tax_id: string | null
          updated_at: string | null
          zip: string | null
        }
        Insert: {
          address?: string | null
          annual_target?: number | null
          bank_account?: string | null
          city?: string | null
          commission_rate?: number
          created_at?: string | null
          email: string
          hire_date?: string | null
          id?: string
          monthly_target?: number | null
          name: string
          notes?: string | null
          phone?: string | null
          profile_image_url?: string | null
          quarterly_target?: number | null
          state?: string | null
          tax_id?: string | null
          updated_at?: string | null
          zip?: string | null
        }
        Update: {
          address?: string | null
          annual_target?: number | null
          bank_account?: string | null
          city?: string | null
          commission_rate?: number
          created_at?: string | null
          email?: string
          hire_date?: string | null
          id?: string
          monthly_target?: number | null
          name?: string
          notes?: string | null
          phone?: string | null
          profile_image_url?: string | null
          quarterly_target?: number | null
          state?: string | null
          tax_id?: string | null
          updated_at?: string | null
          zip?: string | null
        }
        Relationships: []
      }
      user_profiles: {
        Row: {
          created_at: string | null
          email: string
          id: string
          name: string | null
          profile_image_url: string | null
          role: Database["public"]["Enums"]["user_role"]
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          email: string
          id: string
          name?: string | null
          profile_image_url?: string | null
          role?: Database["public"]["Enums"]["user_role"]
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          email?: string
          id?: string
          name?: string | null
          profile_image_url?: string | null
          role?: Database["public"]["Enums"]["user_role"]
          updated_at?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      user_has_role: {
        Args: {
          required_role: Database["public"]["Enums"]["user_role"]
        }
        Returns: boolean
      }
    }
    Enums: {
      lead_status:
        | "prospect"
        | "discovery"
        | "qualified"
        | "negotiation"
        | "closed-won"
        | "closed-lost"
      order_status:
        | "draft"
        | "submitted"
        | "design"
        | "manufacturing"
        | "completed"
        | "cancelled"
      user_role: "admin" | "sales" | "designer" | "manufacturing"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type PublicSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  PublicTableNameOrOptions extends
    | keyof (PublicSchema["Tables"] & PublicSchema["Views"])
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
        Database[PublicTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
      Database[PublicTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : PublicTableNameOrOptions extends keyof (PublicSchema["Tables"] &
        PublicSchema["Views"])
    ? (PublicSchema["Tables"] &
        PublicSchema["Views"])[PublicTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  PublicTableNameOrOptions extends
    | keyof PublicSchema["Tables"]
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : PublicTableNameOrOptions extends keyof PublicSchema["Tables"]
    ? PublicSchema["Tables"][PublicTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  PublicTableNameOrOptions extends
    | keyof PublicSchema["Tables"]
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : PublicTableNameOrOptions extends keyof PublicSchema["Tables"]
    ? PublicSchema["Tables"][PublicTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  PublicEnumNameOrOptions extends
    | keyof PublicSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends PublicEnumNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = PublicEnumNameOrOptions extends { schema: keyof Database }
  ? Database[PublicEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : PublicEnumNameOrOptions extends keyof PublicSchema["Enums"]
    ? PublicSchema["Enums"][PublicEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof PublicSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof PublicSchema["CompositeTypes"]
    ? PublicSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never
