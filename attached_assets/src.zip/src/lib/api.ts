import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';

// Define all required types
export interface Lead {
  id: string;
  name: string;
  organization: string;
  email: string | null;
  phone: string | null;
  status: LeadStatus;
  notes: string | null;
  owner: string | null;
  owner_id: string | null;
  assigned_to: string | null;
  assigned_user_id: string | null;
  estimated_value: number | null;
  created_at?: string;
  updated_at?: string;
  // Client-side aliases for database fields (for backward compatibility)
  dateCreated?: string;
  dateUpdated?: string;
  estimatedValue?: number;
  assignedTo?: string;
}

export type LeadStatus = 'prospect' | 'discovery' | 'qualified' | 'negotiation' | 'closed-won' | 'closed-lost';

export interface LineItem {
  id: string;
  product_id: string;
  order_id: string;
  quantity: number;
  unit_price: number;
  color?: string;
  size?: string;
  notes?: string;
  customization?: string;
  // Client aliases
  product?: string;
  price?: number;
  productName?: string;
  description?: string;
}

export type OrderStatus = 'draft' | 'submitted' | 'design' | 'manufacturing' | 'completed' | 'cancelled';

export interface Order {
  id: string;
  customer_id?: string;
  customerId?: string;
  customerName: string;
  customerEmail?: string;
  customerPhone?: string;
  date?: string;
  created_at: string;
  updated_at: string;
  dateCreated?: string;
  dateUpdated?: string;
  total: number;
  status: OrderStatus;
  items?: LineItem[];
  lineItems?: LineItem[];
  notes?: string;
  assigned_to?: string | null;
  assignedTo?: string | null;
  assigned_user_id?: string | null;
  design_status?: string | null;
  design_files?: string | null;
  tracking_number?: string | null;
  invoice_id?: string | null;
  invoice_status?: string | null;
}

export interface Organization {
  id: string;
  name: string;
  email?: string | null;
  phone?: string | null;
  notes?: string | null;
  // Address fields
  billing_address?: string | null;
  billing_address_line2?: string | null;
  billing_city?: string | null;
  billing_state?: string | null;
  billing_zip?: string | null;
  shipping_address?: string | null; 
  shipping_address_line2?: string | null;
  shipping_city?: string | null;
  shipping_state?: string | null;
  shipping_zip?: string | null;
  // Contact info
  contact_first_name?: string | null;
  contact_last_name?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface Product {
  id: string;
  name: string;
  description?: string | null;
  price: number;
  category?: string | null;
  sport?: string | null;
  imageUrl?: string | null;
  image_url?: string | null;
  inventory?: number | null;
  sizes?: string[] | null;
  colors?: string[] | null;
  created_at?: string;
  updated_at?: string;
}

export interface DashboardStats {
  leadsCount: number;
  ordersCount: number;
  totalRevenue: number;
  avgOrderValue: number;
  recentLeads: Lead[];
  recentOrders: Order[];
  designInProgress: number;
  manufacturingInProgress: number;
  // Adding previously missing properties
  salesPerformance: {
    labels: string[];
    data: number[];
  };
  topProducts: {
    name: string;
    sales: number;
  }[];
  totalSales?: number;
  openOrders?: Order[];
  pendingDesigns?: number;
  newLeads?: Lead[];
}

export interface UserProfile {
  id: string;
  email: string;
  name: string | null;
  role: 'admin' | 'sales' | 'designer' | 'manufacturing';
  profile_image_url?: string | null;
}

export interface OrderLineItem {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  price: number;
  size?: string;
  color?: string;
  notes?: string;
  customization?: string;
}

const mockLeads: Lead[] = [
  {
    id: '1',
    name: 'John Smith',
    organization: 'Westview High School',
    email: 'jsmith@westview.edu',
    phone: '555-123-4567',
    status: 'prospect',
    notes: 'Interested in football uniforms for upcoming season',
    owner: 'laird@rich-habits.com',
    owner_id: null,
    assigned_to: null,
    assigned_user_id: null,
    estimated_value: 5000,
    created_at: '2023-04-15T10:30:00Z',
    dateCreated: '2023-04-15T10:30:00Z'
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    organization: 'Eastside Basketball Club',
    email: 'sjohnson@eastside.org',
    phone: '555-234-5678',
    status: 'discovery',
    notes: 'Looking for custom basketball jerseys for 3 teams',
    owner: 'colinvasquez@rich-habits.com',
    owner_id: null,
    assigned_to: null,
    assigned_user_id: null,
    estimated_value: 3500,
    created_at: '2023-04-10T14:20:00Z',
    dateCreated: '2023-04-10T14:20:00Z'
  },
  {
    id: '3',
    name: 'Eric Mountain',
    organization: 'Cane Nation Wrestling Club',
    email: 'coach.eric@cane-nation.org',
    phone: '555-123-4567',
    status: 'qualified',
    notes: 'Needs custom singlets and warmups for wrestling team',
    owner: null,
    owner_id: null,
    assigned_to: null,
    assigned_user_id: null,
    estimated_value: 7500,
    created_at: '2023-04-18T09:15:00Z',
    dateCreated: '2023-04-18T09:15:00Z'
  }
];

const mockOrders: Order[] = [
  {
    id: '1',
    customerName: 'Westside Elementary',
    customerEmail: 'athletics@westside.edu',
    customerPhone: '555-987-6543',
    created_at: '2023-03-15T08:00:00Z',
    updated_at: '2023-03-15T08:00:00Z',
    total: 4250.75,
    status: 'completed',
    assigned_to: 'colinvasquez@rich-habits.com'
  },
  {
    id: '2',
    customerName: 'Lincoln High School',
    customerEmail: 'sports@lincoln.edu',
    customerPhone: '555-876-5432',
    created_at: '2023-04-02T10:30:00Z',
    updated_at: '2023-04-02T10:30:00Z',
    total: 6750.50,
    status: 'manufacturing',
    assigned_to: 'laird@rich-habits.com'
  },
  {
    id: '3',
    customerName: 'Metro Youth Soccer League',
    customerEmail: 'director@metrosoccer.org',
    customerPhone: '555-765-4321',
    created_at: '2023-04-10T14:20:00Z',
    updated_at: '2023-04-10T14:20:00Z',
    total: 8975.25,
    status: 'design',
    assigned_to: 'colinvasquez@rich-habits.com'
  }
];

export const api = {
  async getLeads(): Promise<Lead[]> {
    try {
      const { data, error } = await supabase
        .from('leads')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        throw error;
      }

      if (!data || data.length === 0) {
        return mockLeads;
      }

      return data.map(lead => ({
        id: lead.id,
        name: lead.name,
        organization: lead.organization,
        email: lead.email,
        phone: lead.phone,
        status: lead.status,
        notes: lead.notes,
        owner: lead.owner,
        owner_id: lead.owner_id,
        assigned_to: lead.assigned_to,
        assigned_user_id: lead.assigned_user_id,
        estimated_value: lead.estimated_value,
        created_at: lead.created_at,
        dateCreated: lead.created_at
      }));
    } catch (error) {
      console.error('Error fetching leads:', error);
      return mockLeads;
    }
  },

  async getLead(id: string): Promise<Lead | null> {
    try {
      const { data, error } = await supabase
        .from('leads')
        .select('*')
        .eq('id', id)
        .single();

      if (error) {
        throw error;
      }

      if (!data) {
        return mockLeads.find(lead => lead.id === id) || null;
      }

      return {
        id: data.id,
        name: data.name,
        organization: data.organization,
        email: data.email,
        phone: data.phone,
        status: data.status,
        notes: data.notes,
        owner: data.owner,
        owner_id: data.owner_id,
        assigned_to: data.assigned_to,
        assigned_user_id: data.assigned_user_id,
        estimated_value: data.estimated_value,
        created_at: data.created_at,
        dateCreated: data.created_at
      };
    } catch (error) {
      console.error(`Error fetching lead ${id}:`, error);
      return mockLeads.find(lead => lead.id === id) || null;
    }
  },

  async createLead(leadData: Omit<Lead, 'id'>): Promise<Lead | null> {
    try {
      const { data, error } = await supabase
        .from('leads')
        .insert([leadData])
        .select()
        .single();

      if (error) {
        throw error;
      }

      return data ? {
        id: data.id,
        name: data.name,
        organization: data.organization,
        email: data.email,
        phone: data.phone,
        status: data.status,
        notes: data.notes,
        owner: data.owner,
        owner_id: data.owner_id,
        assigned_to: data.assigned_to,
        assigned_user_id: data.assigned_user_id,
        estimated_value: data.estimated_value,
        created_at: data.created_at,
        dateCreated: data.created_at
      } : null;
    } catch (error) {
      console.error('Error creating lead:', error);
      toast.error('Failed to create lead');
      return null;
    }
  },

  async updateLead(id: string, updates: Partial<Lead>): Promise<Lead | null> {
    try {
      const { data, error } = await supabase
        .from('leads')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        throw error;
      }

      return data ? {
        id: data.id,
        name: data.name,
        organization: data.organization,
        email: data.email,
        phone: data.phone,
        status: data.status,
        notes: data.notes,
        owner: data.owner,
        owner_id: data.owner_id,
        assigned_to: data.assigned_to,
        assigned_user_id: data.assigned_user_id,
        estimated_value: data.estimated_value,
        created_at: data.created_at,
        dateCreated: data.created_at
      } : null;
    } catch (error) {
      console.error(`Error updating lead ${id}:`, error);
      return null;
    }
  },

  async getOrders(): Promise<Order[]> {
    try {
      const { data, error } = await supabase
        .from('orders')
        .select(`
          *,
          organizations:customer_id (name, email, phone)
        `)
        .order('created_at', { ascending: false });

      if (error) {
        throw error;
      }

      if (!data || data.length === 0) {
        return mockOrders;
      }

      return data.map(order => ({
        id: order.id,
        customerName: order.organizations?.name || 'Unknown Customer',
        customerEmail: order.organizations?.email || undefined,
        customerPhone: order.organizations?.phone || undefined,
        created_at: order.created_at,
        updated_at: order.updated_at,
        total: order.total || 0,
        status: order.status,
        notes: order.notes,
        assigned_to: order.assigned_to,
        assigned_user_id: order.assigned_user_id,
        design_status: order.design_status,
        design_files: order.design_files,
        tracking_number: order.tracking_number
      }));
    } catch (error) {
      console.error('Error fetching orders:', error);
      return mockOrders;
    }
  },

  async getOrder(id: string): Promise<Order | null> {
    try {
      const { data, error } = await supabase
        .from('orders')
        .select(`
          *,
          organizations:customer_id (name, email, phone),
          line_items:line_items (id, product_id, quantity, unit_price, color, size, notes, customization)
        `)
        .eq('id', id)
        .single();

      if (error) {
        throw error;
      }

      if (!data) {
        return mockOrders.find(order => order.id === id) || null;
      }

      return {
        id: data.id,
        customerName: data.organizations?.name || 'Unknown Customer',
        customerEmail: data.organizations?.email || undefined,
        customerPhone: data.organizations?.phone || undefined,
        created_at: data.created_at,
        updated_at: data.updated_at,
        total: data.total || 0,
        status: data.status,
        notes: data.notes,
        assigned_to: data.assigned_to,
        assigned_user_id: data.assigned_user_id,
        design_status: data.design_status,
        design_files: data.design_files,
        tracking_number: data.tracking_number,
        items: data.line_items
      };
    } catch (error) {
      console.error(`Error fetching order ${id}:`, error);
      return mockOrders.find(order => order.id === id) || null;
    }
  },

  async getDashboardStats(): Promise<DashboardStats> {
    try {
      const leads = await this.getLeads();
      const orders = await this.getOrders();
      
      const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);
      const avgOrderValue = orders.length > 0 ? totalRevenue / orders.length : 0;
      
      const currentYear = new Date().getFullYear();
      const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      const currentMonth = new Date().getMonth();
      
      const salesData = months.map((_, index) => {
        if (index <= currentMonth) {
          return 10000 + Math.floor(Math.random() * 20000);
        }
        return 0;
      });
      
      const topProductsData = [
        { name: "Custom Soccer Jersey", sales: 12500 },
        { name: "Basketball Uniform Set", sales: 9800 },
        { name: "Track Team Jacket", sales: 7600 },
        { name: "Football Practice Jersey", sales: 6900 },
        { name: "Custom Team Socks", sales: 5200 }
      ];
      
      return {
        leadsCount: leads.length,
        ordersCount: orders.length,
        totalRevenue,
        avgOrderValue,
        recentLeads: leads.slice(0, 5),
        recentOrders: orders.slice(0, 5),
        designInProgress: orders.filter(o => o.status === 'design').length,
        manufacturingInProgress: orders.filter(o => o.status === 'manufacturing').length,
        salesPerformance: {
          labels: months.slice(0, currentMonth + 1),
          data: salesData.slice(0, currentMonth + 1)
        },
        topProducts: topProductsData,
        totalSales: totalRevenue,
        openOrders: orders.filter(o => o.status !== 'completed' && o.status !== 'cancelled'),
        pendingDesigns: orders.filter(o => o.status === 'design').length,
        newLeads: leads.slice(0, 3)
      };
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"];
      return {
        leadsCount: mockLeads.length,
        ordersCount: mockOrders.length,
        totalRevenue: mockOrders.reduce((sum, order) => sum + order.total, 0),
        avgOrderValue: mockOrders.reduce((sum, order) => sum + order.total, 0) / mockOrders.length,
        recentLeads: mockLeads.slice(0, 5),
        recentOrders: mockOrders.slice(0, 5),
        designInProgress: mockOrders.filter(o => o.status === 'design').length,
        manufacturingInProgress: mockOrders.filter(o => o.status === 'manufacturing').length,
        salesPerformance: {
          labels: months,
          data: [12000, 19000, 15000, 17500, 21000, 22000]
        },
        topProducts: [
          { name: "Custom Soccer Jersey", sales: 12500 },
          { name: "Basketball Uniform Set", sales: 9800 },
          { name: "Track Team Jacket", sales: 7600 },
          { name: "Football Practice Jersey", sales: 6900 },
          { name: "Custom Team Socks", sales: 5200 }
        ],
        totalSales: 80000,
        openOrders: mockOrders.filter(o => o.status !== 'completed' && o.status !== 'cancelled'),
        pendingDesigns: mockOrders.filter(o => o.status === 'design').length,
        newLeads: mockLeads.slice(0, 3)
      };
    }
  },

  async getUserProfiles(): Promise<UserProfile[]> {
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .order('name');

      if (error) {
        throw error;
      }

      return data || [];
    } catch (error) {
      console.error('Error fetching user profiles:', error);
      return [];
    }
  },

  async getSalesTeam(): Promise<UserProfile[]> {
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('role', 'sales')
        .order('name');

      if (error) {
        throw error;
      }

      return data || [];
    } catch (error) {
      console.error('Error fetching sales team:', error);
      return [];
    }
  },

  async getDesignTeam(): Promise<UserProfile[]> {
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('role', 'designer')
        .order('name');

      if (error) {
        throw error;
      }

      return data || [];
    } catch (error) {
      console.error('Error fetching design team:', error);
      return [];
    }
  },

  async getManufacturingTeam(): Promise<UserProfile[]> {
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('role', 'manufacturing')
        .order('name');

      if (error) {
        throw error;
      }

      return data || [];
    } catch (error) {
      console.error('Error fetching manufacturing team:', error);
      return [];
    }
  },

  async getProducts(): Promise<Product[]> {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('name');

      if (error) {
        throw error;
      }

      return data || [];
    } catch (error) {
      console.error('Error fetching products:', error);
      return [];
    }
  },

  async getOrganizations(): Promise<Organization[]> {
    try {
      const { data, error } = await supabase
        .from('organizations')
        .select('*')
        .order('name');

      if (error) {
        throw error;
      }

      return data || [];
    } catch (error) {
      console.error('Error fetching organizations:', error);
      return [];
    }
  },

  async createOrder(orderData: Partial<Order>): Promise<Order | null> {
    try {
      const { data, error } = await supabase
        .from('orders')
        .insert([orderData])
        .select()
        .single();

      if (error) {
        throw error;
      }

      return data;
    } catch (error) {
      console.error('Error creating order:', error);
      toast.error('Failed to create order');
      return null;
    }
  },

  async updateOrder(id: string, updates: Partial<Order>): Promise<Order | null> {
    try {
      const { data, error } = await supabase
        .from('orders')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        throw error;
      }

      return data;
    } catch (error) {
      console.error(`Error updating order ${id}:`, error);
      toast.error('Failed to update order');
      return null;
    }
  },

  async deleteOrder(id: string): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('orders')
        .delete()
        .eq('id', id);

      if (error) {
        throw error;
      }

      return true;
    } catch (error) {
      console.error(`Error deleting order ${id}:`, error);
      toast.error('Failed to delete order');
      return false;
    }
  }
};
