
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      organizations: {
        Row: {
          id: string
          name: string
          phone: string | null
          email: string | null
          billing_address: string | null
          billing_address_line2: string | null
          billing_city: string | null
          billing_state: string | null
          billing_zip: string | null
          shipping_address: string | null
          shipping_address_line2: string | null
          shipping_city: string | null
          shipping_state: string | null
          shipping_zip: string | null
          contact_first_name: string | null
          contact_last_name: string | null
          notes: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          phone?: string | null
          email?: string | null
          billing_address?: string | null
          billing_address_line2?: string | null
          billing_city?: string | null
          billing_state?: string | null
          billing_zip?: string | null
          shipping_address?: string | null
          shipping_address_line2?: string | null
          shipping_city?: string | null
          shipping_state?: string | null
          shipping_zip?: string | null
          contact_first_name?: string | null
          contact_last_name?: string | null
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          phone?: string | null
          email?: string | null
          billing_address?: string | null
          billing_address_line2?: string | null
          billing_city?: string | null
          billing_state?: string | null
          billing_zip?: string | null
          shipping_address?: string | null
          shipping_address_line2?: string | null
          shipping_city?: string | null
          shipping_state?: string | null
          shipping_zip?: string | null
          contact_first_name?: string | null
          contact_last_name?: string | null
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      products: {
        Row: {
          id: string
          name: string
          category: string | null
          sport: string | null
          price: number
          description: string | null
          image_url: string | null
          inventory: number | null
          sizes: string[] | null
          colors: string[] | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          category?: string | null
          sport?: string | null
          price: number
          description?: string | null
          image_url?: string | null
          inventory?: number | null
          sizes?: string[] | null
          colors?: string[] | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          category?: string | null
          sport?: string | null
          price?: number
          description?: string | null
          image_url?: string | null
          inventory?: number | null
          sizes?: string[] | null
          colors?: string[] | null
          created_at?: string
          updated_at?: string
        }
      }
      leads: {
        Row: {
          id: string
          name: string
          organization: string
          email: string | null
          phone: string | null
          status: Database['public']['Enums']['lead_status']
          assigned_to: string | null
          notes: string | null
          estimated_value: number | null
          owner: string | null
          created_at: string
          updated_at: string
          claimed_at: string | null
          organization_id: string | null
        }
        Insert: {
          id?: string
          name: string
          organization: string
          email?: string | null
          phone?: string | null
          status?: Database['public']['Enums']['lead_status']
          assigned_to?: string | null
          notes?: string | null
          estimated_value?: number | null
          owner?: string | null
          created_at?: string
          updated_at?: string
          claimed_at?: string | null
          organization_id?: string | null
        }
        Update: {
          id?: string
          name?: string
          organization?: string
          email?: string | null
          phone?: string | null
          status?: Database['public']['Enums']['lead_status']
          assigned_to?: string | null
          notes?: string | null
          estimated_value?: number | null
          owner?: string | null
          created_at?: string
          updated_at?: string
          claimed_at?: string | null
          organization_id?: string | null
        }
      }
      orders: {
        Row: {
          id: string
          customer_id: string
          status: Database['public']['Enums']['order_status']
          total: number | null
          assigned_to: string | null
          notes: string | null
          tracking_number: string | null
          design_status: string | null
          design_files: string | null
          invoice_status: string | null
          invoice_id: string | null
          lead_id: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          customer_id: string
          status?: Database['public']['Enums']['order_status']
          total?: number | null
          assigned_to?: string | null
          notes?: string | null
          tracking_number?: string | null
          design_status?: string | null
          design_files?: string | null
          invoice_status?: string | null
          invoice_id?: string | null
          lead_id?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          customer_id?: string
          status?: Database['public']['Enums']['order_status']
          total?: number | null
          assigned_to?: string | null
          notes?: string | null
          tracking_number?: string | null
          design_status?: string | null
          design_files?: string | null
          invoice_status?: string | null
          invoice_id?: string | null
          lead_id?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      line_items: {
        Row: {
          id: string
          order_id: string
          product_id: string
          quantity: number
          unit_price: number
          size: string | null
          color: string | null
          notes: string | null
          customization: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          order_id: string
          product_id: string
          quantity: number
          unit_price: number
          size?: string | null
          color?: string | null
          notes?: string | null
          customization?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          order_id?: string
          product_id?: string
          quantity?: number
          unit_price?: number
          size?: string | null
          color?: string | null
          notes?: string | null
          customization?: string | null
          created_at?: string
          updated_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      lead_status: "prospect" | "discovery" | "qualified" | "negotiation" | "closed-won" | "closed-lost"
      order_status: "draft" | "submitted" | "design" | "manufacturing" | "completed" | "cancelled"
    }
  }
}
