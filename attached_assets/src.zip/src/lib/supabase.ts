
import { createClient } from '@supabase/supabase-js';

// Use environment variables or constants
const SUPABASE_URL = "https://qzllffhidxeskqlugpwc.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InF6bGxmZmhpZHhlc2txbHVncHdjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDM0MzEzMzcsImV4cCI6MjA1OTAwNzMzN30.ajaBSD8qsmICCbExznMvuan-96MAJA_nYCqcRRx4ndQ";

// Function to check if Supabase is configured
export const isSupabaseConfigured = () => {
  return SUPABASE_URL && SUPABASE_PUBLISHABLE_KEY;
};

// Function to handle Supabase errors
export const handleSupabaseError = (error: any): string => {
  if (error?.message) {
    return error.message;
  }
  
  if (error?.error_description) {
    return error.error_description;
  }
  
  return 'An unknown error occurred';
};

// Initialize the Supabase client with proper storage configuration
export const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    storage: localStorage,
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false,
  }
});

// Map of demo accounts to real database UUIDs
const DEMO_USER_IDS: Record<string, string> = {
  'sales@example.com': '00000000-0000-0000-0000-000000000001',
  'designer@example.com': '00000000-0000-0000-0000-000000000002',
  'manufacturing@example.com': '00000000-0000-0000-0000-000000000003',
  'samsutton@rich-habits.com': '00000000-0000-0000-0000-000000000004',
  'colinvasquez@rich-habits.com': '00000000-0000-0000-0000-000000000005',
  'laird@rich-habits.com': '00000000-0000-0000-0000-000000000006',
  'admin@rich-habits.com': '00000000-0000-0000-0000-000000000007',
  'cartervail@rich-habits.com': '00000000-0000-0000-0000-000000000008'
};

// Helper function to handle demo login
export const handleDemoLogin = async (email: string, password: string) => {
  // Mock successful login for demo accounts
  const isDemoAccount = 
    (email === 'sales@example.com' && password === 'password') ||
    (email === 'designer@example.com' && password === 'password') ||
    (email === 'manufacturing@example.com' && password === 'password') ||
    (email === 'samsutton@rich-habits.com' && password === 'Arlodog2013!') ||
    (email === 'colinvasquez@rich-habits.com' && password === 'bigchungus$!Afro') ||
    (email === 'laird@rich-habits.com' && password === 'tinyCOCK420##!') ||
    (email === 'admin@rich-habits.com' && password === 'FridayHarbor123!') ||
    (email === 'cartervail@rich-habits.com' && password === 'Wildcat1234!');
    
  if (isDemoAccount) {
    // For demo accounts, simulate a login with a custom session
    const userRole = email.includes('rich-habits.com') ? 'admin' : 
                     email.startsWith('sales') ? 'sales' :
                     email.startsWith('designer') ? 'designer' : 'manufacturing';
                     
    // Use a proper UUID for demo users instead of timestamp-based ID
    const demoUserId = DEMO_USER_IDS[email] || `00000000-0000-0000-0000-${Date.now().toString().slice(-12)}`;
    
    const mockUser = {
      id: demoUserId,
      email: email,
      user_metadata: {
        name: email.split('@')[0],
        role: userRole
      }
    };
    
    // Store mock user in localStorage to persist the session
    localStorage.setItem('supabase.auth.token', JSON.stringify({
      currentSession: {
        access_token: `demo-token-${Date.now()}`,
        refresh_token: `demo-refresh-${Date.now()}`,
        user: mockUser,
        expires_at: Date.now() + 86400000 // 24 hours
      }
    }));
    
    // Trigger auth state change to update the UI
    const event = new CustomEvent('supabase.auth.token-changed');
    window.dispatchEvent(event);
    
    return { data: { user: mockUser, session: { user: mockUser } }, error: null };
  }
  
  // For non-demo accounts, use the regular login
  return await supabase.auth.signInWithPassword({
    email,
    password
  });
};
