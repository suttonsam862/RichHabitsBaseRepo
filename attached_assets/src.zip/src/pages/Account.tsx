
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import SidebarWithTutorial from '@/components/SidebarWithTutorial';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { User, PenLine, Camera } from 'lucide-react';

const Account = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  
  useEffect(() => {
    if (user) {
      setName(user.name || '');
      setEmail(user.email || '');
      // In a real app, you'd fetch the user's avatar URL from your backend
      setAvatarUrl('');
    }
  }, [user]);
  
  const handleSaveProfile = () => {
    // In a real app, you'd update the user profile in your backend
    toast.success('Profile updated successfully!');
    setIsEditing(false);
  };
  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };
  
  const uploadAvatar = () => {
    // In a real app, you'd implement file upload functionality
    toast.info('File upload would be implemented here');
  };
  
  if (!user) {
    return null;
  }
  
  return (
    <div className="min-h-screen bg-background">
      <SidebarWithTutorial />
      
      <div className="ml-64 p-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold">My Account</h1>
          <p className="text-muted-foreground">Manage your account settings and profile information</p>
        </div>
        
        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
              <CardDescription>
                Update your account profile details and personal information
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center mb-6 space-x-6">
                <div className="relative">
                  <Avatar className="h-24 w-24">
                    {avatarUrl ? (
                      <AvatarImage src={avatarUrl} alt={name} />
                    ) : (
                      <AvatarFallback className="text-xl bg-primary text-primary-foreground">
                        {getInitials(name)}
                      </AvatarFallback>
                    )}
                  </Avatar>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="absolute bottom-0 right-0 rounded-full bg-secondary"
                    onClick={uploadAvatar}
                  >
                    <Camera className="h-4 w-4" />
                  </Button>
                </div>
                <div>
                  <h3 className="font-medium text-lg">{name}</h3>
                  <p className="text-muted-foreground text-sm">{user.role}</p>
                </div>
              </div>
              
              {isEditing ? (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name</Label>
                    <Input 
                      id="name" 
                      value={name} 
                      onChange={(e) => setName(e.target.value)} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                      id="email" 
                      type="email" 
                      value={email} 
                      onChange={(e) => setEmail(e.target.value)} 
                      disabled
                    />
                    <p className="text-sm text-muted-foreground">Email cannot be changed</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="space-y-1">
                    <p className="text-sm font-medium">Name</p>
                    <p>{name}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-medium">Email</p>
                    <p>{email}</p>
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between">
              {isEditing ? (
                <>
                  <Button variant="outline" onClick={() => setIsEditing(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleSaveProfile}>
                    Save changes
                  </Button>
                </>
              ) : (
                <Button 
                  variant="outline" 
                  className="flex items-center" 
                  onClick={() => setIsEditing(true)}
                >
                  <PenLine className="mr-2 h-4 w-4" />
                  Edit profile
                </Button>
              )}
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Account Settings</CardTitle>
              <CardDescription>
                Manage your account settings and preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-1">
                <p className="text-sm font-medium">Role</p>
                <p className="capitalize">{user.role}</p>
              </div>
              
              <div className="space-y-1">
                <p className="text-sm font-medium">Account ID</p>
                <p className="text-sm text-muted-foreground">{user.id}</p>
              </div>
            </CardContent>
            <CardFooter>
              <Button 
                variant="destructive" 
                className="w-full"
                onClick={handleLogout}
              >
                Log out
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Account;
