
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Calendar, CalendarIcon, ChevronRight, Edit, Plus, Trash } from "lucide-react";
import Sidebar from "@/components/Sidebar";
import { FormScrollArea } from "@/components/ui/form-scroll-area";
import { supabase } from "@/lib/supabase";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { format, parseISO } from "date-fns";
import CampCostCategory from "@/components/camp/CampCostCategory";
import { cn } from "@/lib/utils";

// Camp Types
interface Camp {
  id: string;
  name: string;
  sport_type: string;
  start_date: string;
  end_date: string;
  location: string;
  capacity: number;
  price: number;
  age_group: string;
  status?: string;
  description?: string;
  coach?: string;
  includes_uniform?: boolean;
  enrollment_count?: number;
}

interface CampAttendee {
  id: string;
  first_name: string;
  last_name: string;
  camp_id?: string;
  guardian_name?: string;
  guardian_email?: string;
  guardian_phone?: string;
  emergency_contact?: string;
  emergency_phone?: string;
  age?: number;
  grade?: string;
  shirt_size?: string;
  allergies?: string;
  notes?: string;
}

// Form Data Types
interface CampFormData {
  name: string;
  sport_type: string;
  start_date: Date | null;
  end_date: Date | null;
  location: string;
  capacity: number;
  price: number;
  age_group: string;
  description: string;
  coach: string;
  includes_uniform: boolean;
}

interface AttendeeFormData {
  first_name: string;
  last_name: string;
  guardian_name: string;
  guardian_email: string;
  guardian_phone: string;
  emergency_contact: string;
  emergency_phone: string;
  age: number;
  grade: string;
  shirt_size: string;
  allergies: string;
  notes: string;
  camp_id: string;
}

const AdminCampManagement = () => {
  const [camps, setCamps] = useState<Camp[]>([]);
  const [attendees, setAttendees] = useState<CampAttendee[]>([]);
  const [selectedCampId, setSelectedCampId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showAddCampDialog, setShowAddCampDialog] = useState(false);
  const [showAddAttendeeDialog, setShowAddAttendeeDialog] = useState(false);
  const [activeTab, setActiveTab] = useState("upcoming");
  const [formData, setFormData] = useState<CampFormData>({
    name: "",
    sport_type: "",
    start_date: null,
    end_date: null,
    location: "",
    capacity: 20,
    price: 0,
    age_group: "",
    description: "",
    coach: "",
    includes_uniform: false,
  });
  const [attendeeFormData, setAttendeeFormData] = useState<AttendeeFormData>({
    first_name: "",
    last_name: "",
    guardian_name: "",
    guardian_email: "",
    guardian_phone: "",
    emergency_contact: "",
    emergency_phone: "",
    age: 10,
    grade: "",
    shirt_size: "",
    allergies: "",
    notes: "",
    camp_id: "",
  });
  const [searchTerm, setSearchTerm] = useState("");

  // Fetch camps from database
  useEffect(() => {
    const fetchCamps = async () => {
      setIsLoading(true);
      try {
        const { data, error } = await supabase
          .from("camps")
          .select("*")
          .order("start_date", { ascending: true });

        if (error) {
          throw error;
        }

        setCamps(data || []);
      } catch (error) {
        console.error("Error fetching camps:", error);
        toast.error("Failed to load camps");
      } finally {
        setIsLoading(false);
      }
    };

    fetchCamps();
  }, []);

  useEffect(() => {
    if (selectedCampId) {
      fetchAttendees(selectedCampId);
    } else {
      setAttendees([]);
    }
  }, [selectedCampId]);

  const fetchAttendees = async (campId: string) => {
    try {
      const { data, error } = await supabase
        .from("camp_attendees")
        .select("*")
        .eq("camp_id", campId)
        .order("last_name", { ascending: true });

      if (error) {
        throw error;
      }

      setAttendees(data || []);
    } catch (error) {
      console.error("Error fetching attendees:", error);
      toast.error("Failed to load camp attendees");
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    
    if (type === 'checkbox') {
      const { checked } = e.target as HTMLInputElement;
      setFormData((prev) => ({ ...prev, [name]: checked }));
    } else if (type === 'number') {
      setFormData((prev) => ({ ...prev, [name]: parseFloat(value) || 0 }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleAttendeeInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    
    if (type === 'number') {
      setAttendeeFormData((prev) => ({ ...prev, [name]: parseInt(value) || 0 }));
    } else {
      setAttendeeFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleCreateCamp = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.start_date || !formData.end_date) {
      toast.error("Please select start and end dates");
      return;
    }
    
    if (!formData.name || !formData.sport_type || !formData.location || !formData.age_group) {
      toast.error("Please fill in all required fields");
      return;
    }
    
    try {
      const { data, error } = await supabase
        .from("camps")
        .insert([
          {
            name: formData.name,
            sport_type: formData.sport_type,
            start_date: formData.start_date.toISOString(),
            end_date: formData.end_date.toISOString(),
            location: formData.location,
            capacity: formData.capacity,
            price: formData.price,
            age_group: formData.age_group,
            description: formData.description,
            coach: formData.coach,
            includes_uniform: formData.includes_uniform,
            status: "upcoming",
          },
        ])
        .select();

      if (error) {
        throw error;
      }

      setCamps((prev) => [...prev, data[0]]);
      toast.success("Camp created successfully!");
      setShowAddCampDialog(false);
      
      // Reset form data
      setFormData({
        name: "",
        sport_type: "",
        start_date: null,
        end_date: null,
        location: "",
        capacity: 20,
        price: 0,
        age_group: "",
        description: "",
        coach: "",
        includes_uniform: false,
      });
    } catch (error) {
      console.error("Error creating camp:", error);
      toast.error("Failed to create camp");
    }
  };

  const handleCreateAttendee = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!attendeeFormData.first_name || !attendeeFormData.last_name) {
      toast.error("Please fill in all required fields");
      return;
    }
    
    if (!selectedCampId) {
      toast.error("No camp selected");
      return;
    }
    
    try {
      const { data, error } = await supabase
        .from("camp_attendees")
        .insert([
          {
            ...attendeeFormData,
            camp_id: selectedCampId,
          },
        ])
        .select();

      if (error) {
        throw error;
      }

      setAttendees((prev) => [...prev, data[0]]);
      toast.success("Attendee added successfully!");
      setShowAddAttendeeDialog(false);
      
      // Reset form data
      setAttendeeFormData({
        first_name: "",
        last_name: "",
        guardian_name: "",
        guardian_email: "",
        guardian_phone: "",
        emergency_contact: "",
        emergency_phone: "",
        age: 10,
        grade: "",
        shirt_size: "",
        allergies: "",
        notes: "",
        camp_id: selectedCampId,
      });
      
      // Update enrollment count in the camp
      const campToUpdate = camps.find(camp => camp.id === selectedCampId);
      if (campToUpdate) {
        const updatedEnrollmentCount = (campToUpdate.enrollment_count || 0) + 1;
        await supabase
          .from("camps")
          .update({ enrollment_count: updatedEnrollmentCount })
          .eq("id", selectedCampId);
          
        // Update local state
        setCamps(camps.map(camp => 
          camp.id === selectedCampId 
            ? { ...camp, enrollment_count: updatedEnrollmentCount } 
            : camp
        ));
      }
    } catch (error) {
      console.error("Error adding attendee:", error);
      toast.error("Failed to add attendee");
    }
  };

  const handleDeleteCamp = async (campId: string) => {
    if (!confirm("Are you sure you want to delete this camp? This action cannot be undone.")) {
      return;
    }
    
    try {
      const { error } = await supabase
        .from("camps")
        .delete()
        .eq("id", campId);

      if (error) {
        throw error;
      }

      setCamps((prev) => prev.filter((camp) => camp.id !== campId));
      if (selectedCampId === campId) {
        setSelectedCampId(null);
      }
      toast.success("Camp deleted successfully!");
    } catch (error) {
      console.error("Error deleting camp:", error);
      toast.error("Failed to delete camp");
    }
  };

  const handleDeleteAttendee = async (attendeeId: string) => {
    if (!confirm("Are you sure you want to remove this attendee? This action cannot be undone.")) {
      return;
    }
    
    try {
      const { error } = await supabase
        .from("camp_attendees")
        .delete()
        .eq("id", attendeeId);

      if (error) {
        throw error;
      }

      setAttendees((prev) => prev.filter((attendee) => attendee.id !== attendeeId));
      toast.success("Attendee removed successfully!");
      
      // Update enrollment count in the camp
      if (selectedCampId) {
        const campToUpdate = camps.find(camp => camp.id === selectedCampId);
        if (campToUpdate && campToUpdate.enrollment_count && campToUpdate.enrollment_count > 0) {
          const updatedEnrollmentCount = campToUpdate.enrollment_count - 1;
          await supabase
            .from("camps")
            .update({ enrollment_count: updatedEnrollmentCount })
            .eq("id", selectedCampId);
            
          // Update local state
          setCamps(camps.map(camp => 
            camp.id === selectedCampId 
              ? { ...camp, enrollment_count: updatedEnrollmentCount } 
              : camp
          ));
        }
      }
    } catch (error) {
      console.error("Error removing attendee:", error);
      toast.error("Failed to remove attendee");
    }
  };

  const filteredCamps = camps.filter((camp) => {
    const matchesSearch = camp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      camp.sport_type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      camp.location.toLowerCase().includes(searchTerm.toLowerCase());
      
    if (activeTab === "all") {
      return matchesSearch;
    } else if (activeTab === "upcoming") {
      return matchesSearch && (camp.status === "upcoming" || !camp.status);
    } else if (activeTab === "active") {
      return matchesSearch && camp.status === "active";
    } else if (activeTab === "completed") {
      return matchesSearch && camp.status === "completed";
    }
    
    return matchesSearch;
  });

  const renderCampsList = () => {
    if (isLoading) {
      return (
        <div className="flex justify-center items-center h-40">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
        </div>
      );
    }

    if (filteredCamps.length === 0) {
      return (
        <div className="text-center py-10">
          <Calendar className="mx-auto h-10 w-10 text-gray-400 mb-2" />
          <h3 className="text-lg font-medium text-gray-900">No camps found</h3>
          <p className="mt-1 text-sm text-gray-500">
            {searchTerm
              ? "Try adjusting your search term"
              : "Create your first camp to get started"}
          </p>
          <div className="mt-6">
            <Button onClick={() => setShowAddCampDialog(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Add Camp
            </Button>
          </div>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {filteredCamps.map((camp) => (
          <div
            key={camp.id}
            className={`p-4 border rounded-lg cursor-pointer transition-colors ${
              selectedCampId === camp.id
                ? "border-primary bg-primary/5"
                : "hover:bg-gray-50"
            }`}
            onClick={() => setSelectedCampId(camp.id)}
          >
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-medium text-gray-900">{camp.name}</h3>
                <p className="text-sm text-gray-500">{camp.sport_type}</p>
                <div className="mt-1 flex items-center text-xs text-gray-500">
                  <span>
                    {new Date(camp.start_date).toLocaleDateString()} - {new Date(camp.end_date).toLocaleDateString()}
                  </span>
                  <span className="mx-2">•</span>
                  <span>{camp.location}</span>
                </div>
                <div className="mt-2 flex items-center text-xs">
                  <span className={`px-2 py-1 rounded ${
                    camp.status === "completed" ? "bg-gray-100 text-gray-800" :
                    camp.status === "active" ? "bg-green-100 text-green-800" :
                    "bg-blue-100 text-blue-800"
                  }`}>
                    {camp.status || "Upcoming"}
                  </span>
                  <span className="ml-2 text-gray-500">
                    {camp.enrollment_count || 0}/{camp.capacity} enrolled
                  </span>
                </div>
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" onClick={(e) => {
                  e.stopPropagation();
                  // Edit functionality would go here
                  toast.info("Edit camp feature coming soon");
                }}>
                  <Edit className="h-3.5 w-3.5" />
                </Button>
                <Button variant="outline" size="sm" className="text-destructive hover:bg-destructive/10" onClick={(e) => {
                  e.stopPropagation();
                  handleDeleteCamp(camp.id);
                }}>
                  <Trash className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  const renderCampDetails = () => {
    if (!selectedCampId) {
      return (
        <div className="text-center py-10">
          <h3 className="text-lg font-medium text-gray-900">No camp selected</h3>
          <p className="mt-1 text-sm text-gray-500">Select a camp to view its details</p>
        </div>
      );
    }

    const selectedCamp = camps.find((camp) => camp.id === selectedCampId);
    
    if (!selectedCamp) {
      return (
        <div className="text-center py-10">
          <h3 className="text-lg font-medium text-gray-900">Camp not found</h3>
          <p className="mt-1 text-sm text-gray-500">The selected camp could not be found</p>
        </div>
      );
    }

    return (
      <div className="space-y-6">
        <div className="flex justify-between items-start">
          <div>
            <h2 className="text-xl font-bold text-gray-900">{selectedCamp.name}</h2>
            <p className="text-gray-500">{selectedCamp.sport_type}</p>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" onClick={() => {
              // Edit functionality would go here
              toast.info("Edit camp feature coming soon");
            }}>
              <Edit className="mr-2 h-4 w-4" />
              Edit
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-gray-500">Dates</h3>
            <p>{new Date(selectedCamp.start_date).toLocaleDateString()} - {new Date(selectedCamp.end_date).toLocaleDateString()}</p>
          </div>
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-gray-500">Location</h3>
            <p>{selectedCamp.location}</p>
          </div>
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-gray-500">Age Group</h3>
            <p>{selectedCamp.age_group}</p>
          </div>
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-gray-500">Capacity</h3>
            <p>{selectedCamp.enrollment_count || 0}/{selectedCamp.capacity} enrolled</p>
          </div>
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-gray-500">Coach</h3>
            <p>{selectedCamp.coach || "Not assigned"}</p>
          </div>
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-gray-500">Price</h3>
            <p>${selectedCamp.price.toFixed(2)}</p>
          </div>
          <div className="space-y-2 col-span-2">
            <h3 className="text-sm font-medium text-gray-500">Description</h3>
            <p className="text-sm text-gray-700">{selectedCamp.description || "No description provided."}</p>
          </div>
        </div>

        <div className="border-t pt-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium">Attendees ({attendees.length})</h3>
            <Button onClick={() => {
              setAttendeeFormData(prev => ({ ...prev, camp_id: selectedCampId }));
              setShowAddAttendeeDialog(true);
            }}>
              <Plus className="mr-2 h-4 w-4" />
              Add Attendee
            </Button>
          </div>
          
          {attendees.length === 0 ? (
            <div className="text-center py-6 bg-gray-50 rounded-lg">
              <p className="text-gray-500">No attendees yet</p>
              <Button variant="link" onClick={() => {
                setAttendeeFormData(prev => ({ ...prev, camp_id: selectedCampId }));
                setShowAddAttendeeDialog(true);
              }}>
                Add the first attendee
              </Button>
            </div>
          ) : (
            <div className="space-y-2">
              {attendees.map((attendee) => (
                <div key={attendee.id} className="p-3 border rounded-lg flex justify-between items-center">
                  <div>
                    <h4 className="font-medium">{attendee.first_name} {attendee.last_name}</h4>
                    <p className="text-sm text-gray-500">
                      {attendee.age && `Age: ${attendee.age} • `}
                      {attendee.guardian_name && `Guardian: ${attendee.guardian_name}`}
                    </p>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="ghost" size="sm" onClick={() => {
                      // View details functionality would go here
                      toast.info("View attendee details feature coming soon");
                    }}>
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm" className="text-destructive hover:bg-destructive/10" onClick={() => handleDeleteAttendee(attendee.id)}>
                      <Trash className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Camp Management</h1>
            <p className="text-muted-foreground">Create and manage camps and attendees</p>
          </div>
          <Button onClick={() => setShowAddCampDialog(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Add Camp
          </Button>
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <Card className="lg:col-span-1">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-center">
                <CardTitle>Camps</CardTitle>
                <div className="ml-auto w-[200px]">
                  <Input
                    placeholder="Search camps..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="max-w-[200px]"
                  />
                </div>
              </div>
              <Tabs
                defaultValue="upcoming"
                value={activeTab}
                onValueChange={setActiveTab}
                className="w-full mt-2"
              >
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                  <TabsTrigger value="active">Active</TabsTrigger>
                  <TabsTrigger value="completed">Completed</TabsTrigger>
                </TabsList>
              </Tabs>
            </CardHeader>
            <CardContent className="h-[calc(100vh-300px)] overflow-y-auto">
              {renderCampsList()}
            </CardContent>
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Camp Details</CardTitle>
            </CardHeader>
            <CardContent className="h-[calc(100vh-250px)] overflow-y-auto">
              {renderCampDetails()}
            </CardContent>
          </Card>
        </div>

        {/* Add Camp Dialog */}
        <Dialog open={showAddCampDialog} onOpenChange={setShowAddCampDialog}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Add New Camp</DialogTitle>
            </DialogHeader>
            
            <FormScrollArea>
              <form onSubmit={handleCreateCamp} className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <Label htmlFor="name" className="text-right">
                      Camp Name <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="sport_type" className="text-right">
                      Sport Type <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="sport_type"
                      name="sport_type"
                      value={formData.sport_type}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="age_group" className="text-right">
                      Age Group <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="age_group"
                      name="age_group"
                      value={formData.age_group}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="start_date" className="text-right">
                      Start Date <span className="text-red-500">*</span>
                    </Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !formData.start_date && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {formData.start_date ? format(formData.start_date, "PPP") : "Select date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <CalendarComponent
                          mode="single"
                          selected={formData.start_date || undefined}
                          onSelect={(date) => setFormData((prev) => ({ ...prev, start_date: date }))}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div>
                    <Label htmlFor="end_date" className="text-right">
                      End Date <span className="text-red-500">*</span>
                    </Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !formData.end_date && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {formData.end_date ? format(formData.end_date, "PPP") : "Select date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <CalendarComponent
                          mode="single"
                          selected={formData.end_date || undefined}
                          onSelect={(date) => setFormData((prev) => ({ ...prev, end_date: date }))}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div>
                    <Label htmlFor="location" className="text-right">
                      Location <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="location"
                      name="location"
                      value={formData.location}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="capacity" className="text-right">
                      Capacity <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="capacity"
                      name="capacity"
                      type="number"
                      min="1"
                      value={formData.capacity}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="price" className="text-right">
                      Price ($) <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="price"
                      name="price"
                      type="number"
                      min="0"
                      step="0.01"
                      value={formData.price}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="coach" className="text-right">
                      Coach
                    </Label>
                    <Input
                      id="coach"
                      name="coach"
                      value={formData.coach}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="description" className="text-right">
                      Description
                    </Label>
                    <Input
                      id="description"
                      name="description"
                      value={formData.description}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="col-span-2 flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="includes_uniform"
                      name="includes_uniform"
                      checked={formData.includes_uniform}
                      onChange={handleInputChange}
                      className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                    />
                    <Label htmlFor="includes_uniform" className="text-right">
                      Includes Uniform
                    </Label>
                  </div>
                </div>
                
                <div className="pt-4 space-x-2 flex justify-end">
                  <Button type="button" variant="outline" onClick={() => setShowAddCampDialog(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">Create Camp</Button>
                </div>
              </form>
            </FormScrollArea>
          </DialogContent>
        </Dialog>

        {/* Add Attendee Dialog */}
        <Dialog open={showAddAttendeeDialog} onOpenChange={setShowAddAttendeeDialog}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Add Attendee</DialogTitle>
            </DialogHeader>
            
            <FormScrollArea>
              <form onSubmit={handleCreateAttendee} className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="first_name" className="text-right">
                      First Name <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="first_name"
                      name="first_name"
                      value={attendeeFormData.first_name}
                      onChange={handleAttendeeInputChange}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="last_name" className="text-right">
                      Last Name <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="last_name"
                      name="last_name"
                      value={attendeeFormData.last_name}
                      onChange={handleAttendeeInputChange}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="age" className="text-right">
                      Age
                    </Label>
                    <Input
                      id="age"
                      name="age"
                      type="number"
                      min="1"
                      max="100"
                      value={attendeeFormData.age}
                      onChange={handleAttendeeInputChange}
                    />
                  </div>
                  <div>
                    <Label htmlFor="grade" className="text-right">
                      Grade
                    </Label>
                    <Input
                      id="grade"
                      name="grade"
                      value={attendeeFormData.grade}
                      onChange={handleAttendeeInputChange}
                    />
                  </div>
                  <div>
                    <Label htmlFor="guardian_name" className="text-right">
                      Guardian Name
                    </Label>
                    <Input
                      id="guardian_name"
                      name="guardian_name"
                      value={attendeeFormData.guardian_name}
                      onChange={handleAttendeeInputChange}
                    />
                  </div>
                  <div>
                    <Label htmlFor="guardian_email" className="text-right">
                      Guardian Email
                    </Label>
                    <Input
                      id="guardian_email"
                      name="guardian_email"
                      type="email"
                      value={attendeeFormData.guardian_email}
                      onChange={handleAttendeeInputChange}
                    />
                  </div>
                  <div>
                    <Label htmlFor="guardian_phone" className="text-right">
                      Guardian Phone
                    </Label>
                    <Input
                      id="guardian_phone"
                      name="guardian_phone"
                      value={attendeeFormData.guardian_phone}
                      onChange={handleAttendeeInputChange}
                    />
                  </div>
                  <div>
                    <Label htmlFor="shirt_size" className="text-right">
                      Shirt Size
                    </Label>
                    <Input
                      id="shirt_size"
                      name="shirt_size"
                      value={attendeeFormData.shirt_size}
                      onChange={handleAttendeeInputChange}
                    />
                  </div>
                  <div>
                    <Label htmlFor="emergency_contact" className="text-right">
                      Emergency Contact
                    </Label>
                    <Input
                      id="emergency_contact"
                      name="emergency_contact"
                      value={attendeeFormData.emergency_contact}
                      onChange={handleAttendeeInputChange}
                    />
                  </div>
                  <div>
                    <Label htmlFor="emergency_phone" className="text-right">
                      Emergency Phone
                    </Label>
                    <Input
                      id="emergency_phone"
                      name="emergency_phone"
                      value={attendeeFormData.emergency_phone}
                      onChange={handleAttendeeInputChange}
                    />
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="allergies" className="text-right">
                      Allergies
                    </Label>
                    <Input
                      id="allergies"
                      name="allergies"
                      value={attendeeFormData.allergies}
                      onChange={handleAttendeeInputChange}
                    />
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="notes" className="text-right">
                      Notes
                    </Label>
                    <Input
                      id="notes"
                      name="notes"
                      value={attendeeFormData.notes}
                      onChange={handleAttendeeInputChange}
                    />
                  </div>
                </div>
                
                <div className="pt-4 space-x-2 flex justify-end">
                  <Button type="button" variant="outline" onClick={() => setShowAddAttendeeDialog(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">Add Attendee</Button>
                </div>
              </form>
            </FormScrollArea>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default AdminCampManagement;
