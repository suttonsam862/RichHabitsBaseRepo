
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Search, Plus, Send, Filter, Mail, Clock, Archive } from "lucide-react";
import { toast } from "sonner";

const mockEmails = [
  {
    id: '1',
    subject: 'Follow-up on your recent order',
    recipient: 'john@westview.edu',
    status: 'sent',
    date: '2025-04-01T10:30:00Z',
    campaign: 'Order Follow-up'
  },
  {
    id: '2',
    subject: 'Special discount on new uniform designs',
    recipient: 'sarah@eastside.org',
    status: 'scheduled',
    date: '2025-04-05T14:00:00Z',
    campaign: 'Spring Promotion'
  },
  {
    id: '3',
    subject: 'New catalog items available now',
    recipient: 'coach.eric@cane-nation.org',
    status: 'draft',
    date: '2025-04-03T09:15:00Z',
    campaign: 'Catalog Update'
  }
];

const mockTemplates = [
  {
    id: '1',
    name: 'Order Confirmation',
    subject: 'Your order has been confirmed',
    lastModified: '2025-03-15T08:00:00Z',
    usageCount: 42
  },
  {
    id: '2',
    name: 'Welcome Email',
    subject: 'Welcome to Rich Habits!',
    lastModified: '2025-03-10T14:30:00Z',
    usageCount: 78
  },
  {
    id: '3',
    name: 'Order Shipped',
    subject: 'Your order has shipped!',
    lastModified: '2025-03-22T11:45:00Z',
    usageCount: 36
  }
];

const AdminClientEmails = () => {
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("emails");
  const [searchTerm, setSearchTerm] = useState("");

  if (!isAdmin) {
    navigate("/");
    toast.error("Admin access required");
    return null;
  }

  const filteredEmails = mockEmails.filter(email => 
    email.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
    email.recipient.toLowerCase().includes(searchTerm.toLowerCase()) ||
    email.campaign.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredTemplates = mockTemplates.filter(template => 
    template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    template.subject.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleCreateEmail = () => {
    toast.info("Create email functionality coming soon");
  };

  const handleCreateTemplate = () => {
    toast.info("Create template functionality coming soon");
  };

  const handleViewEmail = (id: string) => {
    toast.info(`View email ${id} functionality coming soon`);
  };

  const handleEditTemplate = (id: string) => {
    toast.info(`Edit template ${id} functionality coming soon`);
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Client Email Administration</h1>
            <p className="text-muted-foreground">
              Manage email campaigns, templates, and client communications
            </p>
          </div>
          {activeTab === "emails" ? (
            <Button onClick={handleCreateEmail}>
              <Plus className="mr-2 h-4 w-4" />
              Create Email
            </Button>
          ) : (
            <Button onClick={handleCreateTemplate}>
              <Plus className="mr-2 h-4 w-4" />
              Create Template
            </Button>
          )}
        </div>
        
        <Tabs value={activeTab} onValueChange={handleTabChange}>
          <TabsList className="mb-4">
            <TabsTrigger value="emails">Email Campaigns</TabsTrigger>
            <TabsTrigger value="templates">Email Templates</TabsTrigger>
            <TabsTrigger value="stats">Email Statistics</TabsTrigger>
          </TabsList>
          
          <TabsContent value="emails">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                  <CardTitle className="flex items-center">
                    <Mail className="mr-2 h-5 w-5" />
                    Email Campaigns
                  </CardTitle>
                  <div className="mt-3 md:mt-0 relative w-full md:w-auto max-w-sm">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search emails..."
                      className="pl-8 w-full md:w-64"
                      value={searchTerm}
                      onChange={handleSearch}
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Subject</TableHead>
                      <TableHead>Recipient</TableHead>
                      <TableHead>Campaign</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredEmails.map((email) => (
                      <TableRow key={email.id}>
                        <TableCell className="font-medium">{email.subject}</TableCell>
                        <TableCell>{email.recipient}</TableCell>
                        <TableCell>{email.campaign}</TableCell>
                        <TableCell>
                          <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                            ${email.status === 'sent' ? 'bg-green-100 text-green-800' : 
                              email.status === 'scheduled' ? 'bg-blue-100 text-blue-800' : 
                              'bg-gray-100 text-gray-800'}`}>
                            {email.status === 'sent' ? 'Sent' : 
                              email.status === 'scheduled' ? 'Scheduled' : 'Draft'}
                          </div>
                        </TableCell>
                        <TableCell>{new Date(email.date).toLocaleDateString()}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="outline" size="sm" onClick={() => handleViewEmail(email.id)}>
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="templates">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                  <CardTitle className="flex items-center">
                    <Mail className="mr-2 h-5 w-5" />
                    Email Templates
                  </CardTitle>
                  <div className="mt-3 md:mt-0 relative w-full md:w-auto max-w-sm">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search templates..."
                      className="pl-8 w-full md:w-64"
                      value={searchTerm}
                      onChange={handleSearch}
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Template Name</TableHead>
                      <TableHead>Subject Line</TableHead>
                      <TableHead>Last Modified</TableHead>
                      <TableHead>Usage Count</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTemplates.map((template) => (
                      <TableRow key={template.id}>
                        <TableCell className="font-medium">{template.name}</TableCell>
                        <TableCell>{template.subject}</TableCell>
                        <TableCell>{new Date(template.lastModified).toLocaleDateString()}</TableCell>
                        <TableCell>{template.usageCount}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-2">
                            <Button variant="outline" size="sm" onClick={() => handleEditTemplate(template.id)}>
                              Edit
                            </Button>
                            <Button variant="outline" size="sm">
                              Use
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="stats">
            <Card>
              <CardHeader>
                <CardTitle>Email Statistics</CardTitle>
                <CardDescription>
                  View email campaign performance metrics
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="bg-white p-4 rounded-lg border">
                    <div className="text-sm font-medium text-muted-foreground">Total Sent</div>
                    <div className="text-3xl font-bold mt-1">1,248</div>
                    <div className="text-sm text-green-500 mt-1">+12% from last month</div>
                  </div>
                  <div className="bg-white p-4 rounded-lg border">
                    <div className="text-sm font-medium text-muted-foreground">Open Rate</div>
                    <div className="text-3xl font-bold mt-1">32.5%</div>
                    <div className="text-sm text-green-500 mt-1">+2.3% from last month</div>
                  </div>
                  <div className="bg-white p-4 rounded-lg border">
                    <div className="text-sm font-medium text-muted-foreground">Click Rate</div>
                    <div className="text-3xl font-bold mt-1">8.7%</div>
                    <div className="text-sm text-red-500 mt-1">-0.5% from last month</div>
                  </div>
                </div>
                
                <div className="space-y-6">
                  <h3 className="text-lg font-medium">Top Performing Campaigns</h3>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Campaign</TableHead>
                        <TableHead>Sent</TableHead>
                        <TableHead>Open Rate</TableHead>
                        <TableHead>Click Rate</TableHead>
                        <TableHead>Conversion</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell className="font-medium">Spring Promotion</TableCell>
                        <TableCell>452</TableCell>
                        <TableCell>38.2%</TableCell>
                        <TableCell>12.4%</TableCell>
                        <TableCell>4.8%</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Catalog Update</TableCell>
                        <TableCell>328</TableCell>
                        <TableCell>36.5%</TableCell>
                        <TableCell>9.2%</TableCell>
                        <TableCell>3.5%</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Order Follow-up</TableCell>
                        <TableCell>215</TableCell>
                        <TableCell>45.1%</TableCell>
                        <TableCell>8.9%</TableCell>
                        <TableCell>5.2%</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminClientEmails;
