
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Database, FileText, Plus } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import { TableEntity } from "@/types/admin";
import DataManagementTable from "@/components/admin/DataManagementTable";
import PlaceholderCard from "@/components/admin/PlaceholderCard";

// Define allowed table names to ensure we only query valid tables
const VALID_TABLES: TableEntity[] = [
  { name: 'organizations', displayName: 'Organizations' },
  { name: 'leads', displayName: 'Leads' },
  { name: 'orders', displayName: 'Orders' },
  { name: 'products', displayName: 'Products' },
  { name: 'design_assignments', displayName: 'Design Assignments' },
  { name: 'manufacturing_staff', displayName: 'Manufacturing Staff' },
  { name: 'sales_people', displayName: 'Sales People' },
  { name: 'camps', displayName: 'Camps' },
  { name: 'camp_attendees', displayName: 'Camp Attendees' },
  { name: 'manufacturing_vendors', displayName: 'Manufacturing Vendors' },
];

const AdminData = () => {
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("data-management");
  const [searchTerm, setSearchTerm] = useState("");
  const [dataEntities, setDataEntities] = useState<TableEntity[]>([]);

  useEffect(() => {
    // Redirect if not admin
    if (!isAdmin) {
      toast.error("Admin access required");
      navigate("/");
      return;
    }

    const fetchData = async () => {
      setIsLoading(true);
      try {
        // Define tables to fetch counts for - using the valid tables list
        const tables = VALID_TABLES;
        
        // Get count of each table
        const countsPromises = tables.map(async (table) => {
          try {
            // Using type-safe approach for table names
            const { count, error } = await supabase
              .from(table.name)
              .select('*', { count: 'exact', head: true });
              
            if (error) throw error;
            return { ...table, count: count || 0 };
          } catch (error) {
            console.error(`Error fetching count for table ${table.name}:`, error);
            return { ...table, count: 0, error: true };
          }
        });
        
        const tablesWithCounts = await Promise.all(countsPromises);
        setDataEntities(tablesWithCounts);
      } catch (error) {
        console.error("Error fetching data management info:", error);
        toast.error("Failed to load data management information");
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, [isAdmin, navigate]);

  const filteredEntities = dataEntities.filter(entity => 
    entity.displayName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleExportData = (tableName: string) => {
    toast.info(`Exporting ${tableName} data...`);
    // Implement export functionality
  };

  const handleImportData = (tableName: string) => {
    toast.info(`Import ${tableName} data functionality coming soon`);
  };

  const handleRefreshData = (tableName: string) => {
    toast.info(`Refreshing ${tableName} data...`);
    // Implement data refresh functionality
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  if (!isAdmin) {
    return null; // Component will redirect in useEffect
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Data Management</h1>
            <p className="text-muted-foreground">
              Manage database entities, backups, and data operations
            </p>
          </div>
          <Button onClick={() => toast.info("Data operation functionality coming soon")}>
            <Plus className="mr-2 h-4 w-4" />
            New Data Operation
          </Button>
        </div>
        
        <Tabs value={activeTab} onValueChange={handleTabChange}>
          <TabsList className="mb-4">
            <TabsTrigger value="data-management">Data Management</TabsTrigger>
            <TabsTrigger value="backups">Backups</TabsTrigger>
            <TabsTrigger value="exports">Exports</TabsTrigger>
            <TabsTrigger value="integrations">Integrations</TabsTrigger>
          </TabsList>
          
          <TabsContent value="data-management">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Database className="mr-2 h-5 w-5" />
                  Database Entities
                </CardTitle>
              </CardHeader>
              <CardContent>
                <DataManagementTable 
                  entities={filteredEntities}
                  isLoading={isLoading}
                  searchTerm={searchTerm}
                  onSearchChange={handleSearch}
                  onExportData={handleExportData}
                  onImportData={handleImportData}
                  onRefreshData={handleRefreshData}
                />
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="backups">
            <PlaceholderCard 
              title="Database Backups"
              description="Manage and schedule database backups"
              icon={FileText}
            />
          </TabsContent>
          
          <TabsContent value="exports">
            <PlaceholderCard 
              title="Data Exports"
              description="Export data in various formats"
              icon={Database}
            />
          </TabsContent>
          
          <TabsContent value="integrations">
            <PlaceholderCard 
              title="Data Integrations"
              description="Connect to external data sources and services"
              icon={Database}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminData;
