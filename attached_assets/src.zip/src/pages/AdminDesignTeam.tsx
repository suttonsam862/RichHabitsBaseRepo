
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Plus, Edit, Trash, FileUp, Eye, Calendar, Clock, Palette, ImageIcon } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";

const AdminDesignTeam = () => {
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [designers, setDesigners] = useState<any[]>([]);
  const [designAssignments, setDesignAssignments] = useState<any[]>([]);
  const [designSubmissions, setDesignSubmissions] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("designers");
  const [selectedDesigner, setSelectedDesigner] = useState<any>(null);
  
  // Designer dialog state
  const [isAddDesignerDialogOpen, setIsAddDesignerDialogOpen] = useState(false);
  const [designerFormData, setDesignerFormData] = useState({
    name: "",
    email: "",
    phone: "",
    ratePerDesign: "",
    address: "",
    city: "",
    state: "",
    zip: "",
    bankAccount: "",
    taxId: "",
    notes: "",
    username: "",
    password: ""
  });
  
  // Design gallery state
  const [isGalleryOpen, setIsGalleryOpen] = useState(false);
  const [selectedDesignerGallery, setSelectedDesignerGallery] = useState<any>(null);

  useEffect(() => {
    // Redirect if not admin
    if (!isAdmin) {
      toast.error("Admin access required");
      navigate("/");
      return;
    }

    const fetchData = async () => {
      setIsLoading(true);
      try {
        // Fetch designers
        const { data: designersData, error: designersError } = await supabase
          .from('designers')
          .select('*');
          
        if (designersError) throw designersError;
        
        // Fetch design assignments with related order data
        const { data: assignmentsData, error: assignmentsError } = await supabase
          .from('design_assignments')
          .select('*, orders(*)');
          
        if (assignmentsError) throw assignmentsError;
        
        // Fetch design submissions
        const { data: submissionsData, error: submissionsError } = await supabase
          .from('design_submissions')
          .select('*');
          
        if (submissionsError) throw submissionsError;
        
        setDesigners(designersData || []);
        setDesignAssignments(assignmentsData || []);
        setDesignSubmissions(submissionsData || []);
      } catch (error) {
        console.error("Error fetching design team data:", error);
        toast.error("Failed to load design team data");
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, [isAdmin, navigate]);

  const filteredDesigners = designers.filter(designer => 
    designer.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    designer.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleAddDesigner = async () => {
    try {
      // 1. Create the designer record
      const { data: newDesigner, error: designerError } = await supabase
        .from('designers')
        .insert([{
          name: designerFormData.name,
          email: designerFormData.email,
          phone: designerFormData.phone,
          rate_per_design: parseFloat(designerFormData.ratePerDesign) || 0,
          address: designerFormData.address,
          city: designerFormData.city,
          state: designerFormData.state,
          zip: designerFormData.zip,
          bank_account: designerFormData.bankAccount,
          tax_id: designerFormData.taxId,
          notes: designerFormData.notes
        }])
        .select()
        .single();
        
      if (designerError) throw designerError;
      
      // 2. Here you would add code to create their user account
      // This is a placeholder since actual account creation would depend on your auth system
      console.log("Would create user account with:", designerFormData.username, designerFormData.password);
      
      toast.success("Designer added successfully");
      setDesigners(prev => [...prev, newDesigner]);
      setIsAddDesignerDialogOpen(false);
      resetDesignerForm();
    } catch (error) {
      console.error("Error adding designer:", error);
      toast.error("Failed to add designer");
    }
  };

  const handleEditDesigner = (id: string) => {
    const designer = designers.find(d => d.id === id);
    if (designer) {
      setSelectedDesigner(designer);
      setDesignerFormData({
        name: designer.name || "",
        email: designer.email || "",
        phone: designer.phone || "",
        ratePerDesign: designer.rate_per_design?.toString() || "",
        address: designer.address || "",
        city: designer.city || "",
        state: designer.state || "",
        zip: designer.zip || "",
        bankAccount: designer.bank_account || "",
        taxId: designer.tax_id || "",
        notes: designer.notes || "",
        username: "",
        password: ""
      });
      setIsAddDesignerDialogOpen(true);
    }
  };

  const handleDeleteDesigner = (id: string) => {
    toast.info(`Delete designer ${id} functionality coming soon`);
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };
  
  const handleDesignerChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setDesignerFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const resetDesignerForm = () => {
    setDesignerFormData({
      name: "",
      email: "",
      phone: "",
      ratePerDesign: "",
      address: "",
      city: "",
      state: "",
      zip: "",
      bankAccount: "",
      taxId: "",
      notes: "",
      username: "",
      password: ""
    });
    setSelectedDesigner(null);
  };
  
  const openDesignerGallery = (designerId: string) => {
    const designer = designers.find(d => d.id === designerId);
    if (designer) {
      setSelectedDesignerGallery(designer);
      // Get submissions for this designer
      const designerSubmissions = designSubmissions.filter(s => s.designer_id === designerId);
      designer.submissions = designerSubmissions;
      setIsGalleryOpen(true);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "assigned":
        return <Badge variant="outline">Assigned</Badge>;
      case "in-progress":
        return <Badge className="bg-amber-100 text-amber-800">In Progress</Badge>;
      case "completed":
        return <Badge className="bg-green-100 text-green-800">Completed</Badge>;
      case "rejected":
        return <Badge className="bg-red-100 text-red-800">Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  // Calculate designer performance metrics
  const getDesignerMetrics = (designerId: string) => {
    const designerAssignments = designAssignments.filter(a => a.designer_id === designerId);
    const designerSubmissions = designSubmissions.filter(s => s.designer_id === designerId);
    
    const totalAssignments = designerAssignments.length;
    const completedAssignments = designerAssignments.filter(a => a.status === 'completed').length;
    const completionRate = totalAssignments > 0 ? (completedAssignments / totalAssignments) * 100 : 0;
    
    // Calculate average time to complete (in days)
    let avgTimeToComplete = 0;
    const completedWithDates = designerAssignments.filter(a => 
      a.status === 'completed' && a.assigned_at && a.updated_at
    );
    
    if (completedWithDates.length > 0) {
      const totalDays = completedWithDates.reduce((sum, assignment) => {
        const assignedDate = new Date(assignment.assigned_at);
        const completedDate = new Date(assignment.updated_at);
        const days = (completedDate.getTime() - assignedDate.getTime()) / (1000 * 3600 * 24);
        return sum + days;
      }, 0);
      
      avgTimeToComplete = totalDays / completedWithDates.length;
    }
    
    return {
      totalAssignments,
      completedAssignments,
      completionRate: completionRate.toFixed(1),
      avgTimeToComplete: avgTimeToComplete.toFixed(1),
      totalSubmissions: designerSubmissions.length
    };
  };

  if (!isAdmin) {
    return null; // Component will redirect in useEffect
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Design Team Management</h1>
            <p className="text-muted-foreground">
              Manage designers and design assignments
            </p>
          </div>
          <Dialog open={isAddDesignerDialogOpen} onOpenChange={setIsAddDesignerDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Designer
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>{selectedDesigner ? 'Edit Designer' : 'Add Designer'}</DialogTitle>
                <DialogDescription>
                  {selectedDesigner 
                    ? 'Update designer information and account details.' 
                    : 'Add a new designer to the team and create their account.'}
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-3">
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      name="name"
                      value={designerFormData.name}
                      onChange={handleDesignerChange}
                      placeholder="Enter full name"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={designerFormData.email}
                      onChange={handleDesignerChange}
                      placeholder="Email address"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      name="phone"
                      value={designerFormData.phone}
                      onChange={handleDesignerChange}
                      placeholder="Phone number"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="ratePerDesign">Rate Per Design ($)</Label>
                    <Input
                      id="ratePerDesign"
                      name="ratePerDesign"
                      type="number"
                      value={designerFormData.ratePerDesign}
                      onChange={handleDesignerChange}
                      placeholder="0.00"
                    />
                  </div>
                  
                  <div className="col-span-2">
                    <Label>Address</Label>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      <Input
                        className="col-span-2"
                        name="address"
                        placeholder="Street Address"
                        value={designerFormData.address}
                        onChange={handleDesignerChange}
                      />
                      <Input
                        name="city"
                        placeholder="City"
                        value={designerFormData.city}
                        onChange={handleDesignerChange}
                      />
                      <div className="flex space-x-2">
                        <Input
                          name="state"
                          placeholder="State"
                          value={designerFormData.state}
                          onChange={handleDesignerChange}
                          className="w-1/2"
                        />
                        <Input
                          name="zip"
                          placeholder="ZIP"
                          value={designerFormData.zip}
                          onChange={handleDesignerChange}
                          className="w-1/2"
                        />
                      </div>
                    </div>
                  </div>
                  
                  {!selectedDesigner && (
                    <div className="col-span-2">
                      <Label>Account Information</Label>
                      <div className="grid grid-cols-2 gap-2 mt-2">
                        <Input
                          name="username"
                          placeholder="Username"
                          value={designerFormData.username}
                          onChange={handleDesignerChange}
                        />
                        <Input
                          name="password"
                          type="password"
                          placeholder="Password"
                          value={designerFormData.password}
                          onChange={handleDesignerChange}
                        />
                      </div>
                    </div>
                  )}
                  
                  <div>
                    <Label htmlFor="bankAccount">Bank Account</Label>
                    <Input
                      id="bankAccount"
                      name="bankAccount"
                      value={designerFormData.bankAccount}
                      onChange={handleDesignerChange}
                      placeholder="Bank account details"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="taxId">Tax ID</Label>
                    <Input
                      id="taxId"
                      name="taxId"
                      value={designerFormData.taxId}
                      onChange={handleDesignerChange}
                      placeholder="Tax ID/SSN"
                    />
                  </div>
                  
                  <div className="col-span-2">
                    <Label htmlFor="notes">Notes</Label>
                    <Textarea
                      id="notes"
                      name="notes"
                      placeholder="Additional notes about this designer"
                      value={designerFormData.notes}
                      onChange={handleDesignerChange}
                      rows={3}
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => {
                  setIsAddDesignerDialogOpen(false);
                  resetDesignerForm();
                }}>
                  Cancel
                </Button>
                <Button onClick={handleAddDesigner}>
                  {selectedDesigner ? 'Update Designer' : 'Add Designer & Create Account'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
        
        <Tabs value={activeTab} onValueChange={handleTabChange}>
          <TabsList className="mb-4">
            <TabsTrigger value="designers">Designers</TabsTrigger>
            <TabsTrigger value="assignments">Design Assignments</TabsTrigger>
            <TabsTrigger value="gallery">Design Gallery</TabsTrigger>
            <TabsTrigger value="performance">Performance Metrics</TabsTrigger>
          </TabsList>
          
          <TabsContent value="designers">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                  <CardTitle>Design Team</CardTitle>
                  <div className="mt-3 md:mt-0 relative w-full md:w-auto max-w-sm">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search designers..."
                      className="pl-8 w-full md:w-64"
                      value={searchTerm}
                      onChange={handleSearch}
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex justify-center py-10">
                    <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary"></div>
                  </div>
                ) : filteredDesigners.length === 0 ? (
                  <div className="text-center py-10">
                    <p className="text-muted-foreground">No designers found</p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Phone</TableHead>
                        <TableHead>Rate</TableHead>
                        <TableHead>Designs</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredDesigners.map((designer) => {
                        const metrics = getDesignerMetrics(designer.id);
                        
                        return (
                          <TableRow key={designer.id}>
                            <TableCell className="font-medium">{designer.name}</TableCell>
                            <TableCell>{designer.email}</TableCell>
                            <TableCell>{designer.phone || 'N/A'}</TableCell>
                            <TableCell>${designer.rate_per_design}</TableCell>
                            <TableCell>{metrics.totalSubmissions} designs</TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end space-x-2">
                                <Button 
                                  variant="outline" 
                                  size="icon" 
                                  onClick={() => openDesignerGallery(designer.id)}
                                >
                                  <ImageIcon className="h-4 w-4" />
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="icon" 
                                  onClick={() => handleEditDesigner(designer.id)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="icon" 
                                  onClick={() => handleDeleteDesigner(designer.id)}
                                >
                                  <Trash className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="assignments">
            <Card>
              <CardHeader>
                <CardTitle>Design Assignments</CardTitle>
                <CardDescription>
                  Track and manage design work assignments
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex justify-center py-10">
                    <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary"></div>
                  </div>
                ) : designAssignments.length === 0 ? (
                  <div className="text-center py-10">
                    <p className="text-muted-foreground">No design assignments found</p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Order ID</TableHead>
                        <TableHead>Designer</TableHead>
                        <TableHead>Design Type</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Due Date</TableHead>
                        <TableHead>Time Spent</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {designAssignments.map((assignment) => {
                        const designer = designers.find(d => d.id === assignment.designer_id);
                        
                        // Calculate time spent
                        let timeSpent = "N/A";
                        if (assignment.assigned_at) {
                          const startDate = new Date(assignment.assigned_at);
                          const endDate = assignment.status === 'completed' 
                            ? new Date(assignment.updated_at) 
                            : new Date();
                          
                          const days = Math.round((endDate.getTime() - startDate.getTime()) / (1000 * 3600 * 24));
                          timeSpent = days === 0 ? "Today" : `${days} days`;
                        }
                        
                        return (
                          <TableRow key={assignment.id}>
                            <TableCell className="font-medium">
                              {assignment.orders?.id?.substring(0, 8) || 'N/A'}
                            </TableCell>
                            <TableCell>{designer?.name || 'Unassigned'}</TableCell>
                            <TableCell>{assignment.design_type}</TableCell>
                            <TableCell>{getStatusBadge(assignment.status)}</TableCell>
                            <TableCell>
                              {assignment.due_date 
                                ? new Date(assignment.due_date).toLocaleDateString() 
                                : 'Not set'}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <Clock className="h-4 w-4 mr-1 text-muted-foreground" />
                                {timeSpent}
                              </div>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end space-x-2">
                                <Button variant="outline" size="icon">
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button variant="outline" size="icon">
                                  <FileUp className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="gallery">
            <Card>
              <CardHeader>
                <CardTitle>Design Gallery</CardTitle>
                <CardDescription>
                  View all design submissions by designer
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex justify-center py-10">
                    <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary"></div>
                  </div>
                ) : designSubmissions.length === 0 ? (
                  <div className="text-center py-10">
                    <p className="text-muted-foreground">No design submissions yet</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {designers.map(designer => {
                      const designerSubmissions = designSubmissions.filter(s => s.designer_id === designer.id);
                      if (designerSubmissions.length === 0) return null;
                      
                      return (
                        <Card key={designer.id} className="overflow-hidden">
                          <CardHeader className="pb-0">
                            <CardTitle className="text-lg">{designer.name}</CardTitle>
                            <CardDescription>{designerSubmissions.length} designs</CardDescription>
                          </CardHeader>
                          <CardContent className="pt-4">
                            <div className="grid grid-cols-2 gap-2">
                              {designerSubmissions.slice(0, 4).map((submission, index) => (
                                <div 
                                  key={submission.id} 
                                  className="aspect-square bg-gray-100 rounded-md flex items-center justify-center relative overflow-hidden"
                                >
                                  {submission.image_url ? (
                                    <img 
                                      src={submission.image_url} 
                                      alt="Design submission" 
                                      className="object-cover w-full h-full"
                                    />
                                  ) : (
                                    <Palette className="h-10 w-10 text-gray-300" />
                                  )}
                                </div>
                              ))}
                            </div>
                          </CardContent>
                          <CardFooter className="pt-0">
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="w-full"
                              onClick={() => openDesignerGallery(designer.id)}
                            >
                              View All Designs
                            </Button>
                          </CardFooter>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="performance">
            <Card>
              <CardHeader>
                <CardTitle>Performance Metrics</CardTitle>
                <CardDescription>
                  Track designer productivity and metrics
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex justify-center py-10">
                    <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary"></div>
                  </div>
                ) : filteredDesigners.length === 0 ? (
                  <div className="text-center py-10">
                    <p className="text-muted-foreground">No designers found</p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Designer</TableHead>
                        <TableHead>Total Designs</TableHead>
                        <TableHead>Completed</TableHead>
                        <TableHead>Completion Rate</TableHead>
                        <TableHead>Avg. Time (days)</TableHead>
                        <TableHead>Earnings</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredDesigners.map((designer) => {
                        const metrics = getDesignerMetrics(designer.id);
                        const designerSubmissions = designSubmissions.filter(s => s.designer_id === designer.id);
                        const totalEarnings = designer.rate_per_design * designerSubmissions.length;
                        
                        return (
                          <TableRow key={designer.id}>
                            <TableCell className="font-medium">{designer.name}</TableCell>
                            <TableCell>{metrics.totalAssignments}</TableCell>
                            <TableCell>{metrics.completedAssignments}</TableCell>
                            <TableCell>{metrics.completionRate}%</TableCell>
                            <TableCell>{metrics.avgTimeToComplete}</TableCell>
                            <TableCell>${totalEarnings.toFixed(2)}</TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Designer Gallery Dialog */}
      <Dialog open={isGalleryOpen} onOpenChange={setIsGalleryOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>{selectedDesignerGallery?.name}'s Design Gallery</DialogTitle>
            <DialogDescription>
              View all designs submitted by this designer
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {selectedDesignerGallery?.submissions?.length === 0 ? (
              <div className="text-center py-10">
                <p className="text-muted-foreground">No designs have been submitted yet</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {selectedDesignerGallery?.submissions?.map((submission: any) => (
                  <div key={submission.id} className="rounded-md overflow-hidden border">
                    <div className="aspect-video bg-gray-100 relative">
                      {submission.image_url ? (
                        <img 
                          src={submission.image_url} 
                          alt="Design submission" 
                          className="object-cover w-full h-full"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Palette className="h-12 w-12 text-gray-300" />
                        </div>
                      )}
                    </div>
                    <div className="p-3">
                      <h3 className="font-medium">{submission.design_type}</h3>
                      <div className="flex justify-between items-center mt-1">
                        <span className="text-sm text-muted-foreground">
                          {new Date(submission.submission_date).toLocaleDateString()}
                        </span>
                        {getStatusBadge(submission.status)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminDesignTeam;
