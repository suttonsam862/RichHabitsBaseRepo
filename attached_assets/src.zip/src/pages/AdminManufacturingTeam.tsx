
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, Edit, Trash2, CheckCircle, AlertCircle, Factory, Truck, Clock } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { manufacturingService } from "@/services/manufacturingService";

// Form validation schemas
const manufacturingVendorSchema = z.object({
  name: z.string().min(1, "Vendor name is required"),
  contact_person: z.string().optional(),
  email: z.string().email("Invalid email").optional().or(z.literal("")),
  phone: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  zip: z.string().optional(),
  country: z.string().optional(),
  company_size: z.number().int().positive().optional().or(z.literal("")),
  region: z.string().optional(),
  specialties: z.array(z.string()).optional(),
  cost_per_unit: z.number().positive().optional().or(z.literal("")),
  lead_time: z.number().int().positive().optional().or(z.literal("")),
  minimum_order: z.number().int().positive().optional().or(z.literal("")),
  average_turnaround_time: z.number().int().positive().optional().or(z.literal("")),
  notes: z.string().optional(),
  active: z.boolean().default(true),
});

const AdminManufacturingTeam = () => {
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("staff");
  const [searchTerm, setSearchTerm] = useState("");
  const [manufacturingStaff, setManufacturingStaff] = useState<any[]>([]);
  const [manufacturingVendors, setManufacturingVendors] = useState<any[]>([]);
  const [isAddVendorOpen, setIsAddVendorOpen] = useState(false);
  const [isEditVendorOpen, setIsEditVendorOpen] = useState(false);
  const [selectedVendor, setSelectedVendor] = useState<any>(null);

  // Form for adding/editing vendors
  const vendorForm = useForm<z.infer<typeof manufacturingVendorSchema>>({
    resolver: zodResolver(manufacturingVendorSchema),
    defaultValues: {
      name: "",
      contact_person: "",
      email: "",
      phone: "",
      address: "",
      city: "",
      state: "",
      zip: "",
      country: "",
      company_size: undefined,
      region: "",
      specialties: [],
      cost_per_unit: undefined,
      lead_time: undefined,
      minimum_order: undefined,
      average_turnaround_time: undefined,
      notes: "",
      active: true,
    },
  });

  useEffect(() => {
    // Redirect if not admin
    if (!isAdmin) {
      toast.error("Admin access required");
      navigate("/");
      return;
    }

    const fetchData = async () => {
      setIsLoading(true);
      try {
        // Fetch manufacturing staff
        const staffData = await manufacturingService.getManufacturingStaff();
        setManufacturingStaff(staffData);
        
        // Fetch manufacturing vendors
        const { data: vendorData, error } = await supabase
          .from('manufacturing_vendors')
          .select('*')
          .order('name');
          
        if (error) throw error;
        setManufacturingVendors(vendorData || []);
      } catch (error) {
        console.error("Error fetching manufacturing data:", error);
        toast.error("Failed to load manufacturing team data");
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, [isAdmin, navigate]);

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    setSearchTerm("");
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const filteredStaff = manufacturingStaff.filter(staff => 
    staff.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    staff.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    staff.role.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredVendors = manufacturingVendors.filter(vendor => 
    vendor.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    vendor.contact_person?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    vendor.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    vendor.region?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const openAddVendorDialog = () => {
    vendorForm.reset({
      name: "",
      contact_person: "",
      email: "",
      phone: "",
      address: "",
      city: "",
      state: "",
      zip: "",
      country: "",
      company_size: undefined,
      region: "",
      specialties: [],
      cost_per_unit: undefined,
      lead_time: undefined,
      minimum_order: undefined,
      average_turnaround_time: undefined,
      notes: "",
      active: true,
    });
    setIsAddVendorOpen(true);
  };

  const openEditVendorDialog = (vendor: any) => {
    setSelectedVendor(vendor);
    vendorForm.reset({
      name: vendor.name || "",
      contact_person: vendor.contact_person || "",
      email: vendor.email || "",
      phone: vendor.phone || "",
      address: vendor.address || "",
      city: vendor.city || "",
      state: vendor.state || "",
      zip: vendor.zip || "",
      country: vendor.country || "",
      company_size: vendor.company_size || undefined,
      region: vendor.region || "",
      specialties: vendor.specialties || [],
      cost_per_unit: vendor.cost_per_unit || undefined,
      lead_time: vendor.lead_time || undefined,
      minimum_order: vendor.minimum_order || undefined,
      average_turnaround_time: vendor.average_turnaround_time || undefined,
      notes: vendor.notes || "",
      active: vendor.active !== false,
    });
    setIsEditVendorOpen(true);
  };

  const handleAddVendor = async (data: z.infer<typeof manufacturingVendorSchema>) => {
    try {
      const { error } = await supabase
        .from('manufacturing_vendors')
        .insert([{
          name: data.name,
          contact_person: data.contact_person,
          email: data.email,
          phone: data.phone,
          address: data.address,
          city: data.city,
          state: data.state,
          zip: data.zip,
          country: data.country,
          company_size: data.company_size === "" ? null : data.company_size,
          region: data.region,
          specialties: data.specialties,
          cost_per_unit: data.cost_per_unit === "" ? null : data.cost_per_unit,
          lead_time: data.lead_time === "" ? null : data.lead_time,
          minimum_order: data.minimum_order === "" ? null : data.minimum_order,
          average_turnaround_time: data.average_turnaround_time === "" ? null : data.average_turnaround_time,
          notes: data.notes,
          active: data.active
        }]);
        
      if (error) throw error;
      
      toast.success("Manufacturing vendor added successfully");
      setIsAddVendorOpen(false);
      
      // Refresh vendor list
      const { data: refreshedData } = await supabase
        .from('manufacturing_vendors')
        .select('*')
        .order('name');
        
      setManufacturingVendors(refreshedData || []);
    } catch (error) {
      console.error("Error adding manufacturing vendor:", error);
      toast.error("Failed to add manufacturing vendor");
    }
  };

  const handleUpdateVendor = async (data: z.infer<typeof manufacturingVendorSchema>) => {
    if (!selectedVendor) return;
    
    try {
      const { error } = await supabase
        .from('manufacturing_vendors')
        .update({
          name: data.name,
          contact_person: data.contact_person,
          email: data.email,
          phone: data.phone,
          address: data.address,
          city: data.city,
          state: data.state,
          zip: data.zip,
          country: data.country,
          company_size: data.company_size === "" ? null : data.company_size,
          region: data.region,
          specialties: data.specialties,
          cost_per_unit: data.cost_per_unit === "" ? null : data.cost_per_unit,
          lead_time: data.lead_time === "" ? null : data.lead_time,
          minimum_order: data.minimum_order === "" ? null : data.minimum_order,
          average_turnaround_time: data.average_turnaround_time === "" ? null : data.average_turnaround_time,
          notes: data.notes,
          active: data.active
        })
        .eq('id', selectedVendor.id);
        
      if (error) throw error;
      
      toast.success("Manufacturing vendor updated successfully");
      setIsEditVendorOpen(false);
      
      // Refresh vendor list
      const { data: refreshedData } = await supabase
        .from('manufacturing_vendors')
        .select('*')
        .order('name');
        
      setManufacturingVendors(refreshedData || []);
    } catch (error) {
      console.error("Error updating manufacturing vendor:", error);
      toast.error("Failed to update manufacturing vendor");
    }
  };

  const handleDeleteVendor = async (id: string) => {
    if (!confirm("Are you sure you want to delete this vendor?")) return;
    
    try {
      const { error } = await supabase
        .from('manufacturing_vendors')
        .delete()
        .eq('id', id);
        
      if (error) throw error;
      
      toast.success("Manufacturing vendor deleted successfully");
      
      // Update local state by filtering out the deleted vendor
      setManufacturingVendors(prevVendors => prevVendors.filter(vendor => vendor.id !== id));
    } catch (error) {
      console.error("Error deleting manufacturing vendor:", error);
      toast.error("Failed to delete manufacturing vendor");
    }
  };

  if (!isAdmin) {
    return null; // Component will redirect in useEffect
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Manufacturing Team Management</h1>
            <p className="text-muted-foreground">
              Manage your manufacturing team and vendor partnerships
            </p>
          </div>
          <div className="flex space-x-2">
            <Button onClick={() => navigate("/manufacturing")}>
              <Factory className="mr-2 h-4 w-4" />
              View Manufacturing Dashboard
            </Button>
          </div>
        </div>
        
        <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="staff">Manufacturing Staff</TabsTrigger>
            <TabsTrigger value="vendors">Manufacturing Vendors</TabsTrigger>
          </TabsList>
          
          <TabsContent value="staff">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                  <CardTitle>Manufacturing Staff</CardTitle>
                  <div className="mt-3 md:mt-0 relative w-full md:w-auto max-w-sm">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search staff..."
                      className="pl-8 w-full md:w-64"
                      value={searchTerm}
                      onChange={handleSearch}
                    />
                  </div>
                </div>
                <CardDescription>
                  Manage your manufacturing team members, skills, and certifications
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex justify-center py-10">
                    <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary"></div>
                  </div>
                ) : filteredStaff.length === 0 ? (
                  <div className="text-center py-10">
                    <Factory className="mx-auto h-12 w-12 text-muted-foreground opacity-30 mb-4" />
                    <h3 className="text-lg font-medium">No manufacturing staff found</h3>
                    <p className="text-muted-foreground">
                      {searchTerm ? "Try a different search term" : "Add staff members to your manufacturing team"}
                    </p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Role</TableHead>
                          <TableHead>Contact</TableHead>
                          <TableHead>Skills</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredStaff.map((staff) => (
                          <TableRow key={staff.id}>
                            <TableCell className="font-medium">{staff.name}</TableCell>
                            <TableCell>{staff.role || "N/A"}</TableCell>
                            <TableCell>
                              <div className="flex flex-col">
                                <span className="text-sm">{staff.email}</span>
                                {staff.phone && <span className="text-xs text-muted-foreground">{staff.phone}</span>}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex flex-wrap gap-1">
                                {staff.skills && staff.skills.length > 0 ? (
                                  staff.skills.map((skill: string, index: number) => (
                                    <Badge key={index} variant="outline" className="text-xs">
                                      {skill}
                                    </Badge>
                                  ))
                                ) : (
                                  <span className="text-xs text-muted-foreground">No skills listed</span>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant={staff.active !== false ? "success" : "secondary"}>
                                {staff.active !== false ? "Active" : "Inactive"}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end space-x-2">
                                <Button variant="outline" size="sm" onClick={() => toast.info("Edit staff member functionality coming soon")}>
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button variant="outline" size="sm" onClick={() => toast.info("View staff details functionality coming soon")}>
                                  View Details
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
                
                <div className="mt-6 flex justify-end">
                  <Button onClick={() => toast.info("Create manufacturing staff functionality coming soon")}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Staff Member
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="vendors">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                  <CardTitle>Manufacturing Vendors</CardTitle>
                  <div className="mt-3 md:mt-0 relative w-full md:w-auto max-w-sm">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search vendors..."
                      className="pl-8 w-full md:w-64"
                      value={searchTerm}
                      onChange={handleSearch}
                    />
                  </div>
                </div>
                <CardDescription>
                  Manage your manufacturing vendor partnerships and production capabilities
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex justify-center py-10">
                    <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary"></div>
                  </div>
                ) : filteredVendors.length === 0 ? (
                  <div className="text-center py-10">
                    <Truck className="mx-auto h-12 w-12 text-muted-foreground opacity-30 mb-4" />
                    <h3 className="text-lg font-medium">No manufacturing vendors found</h3>
                    <p className="text-muted-foreground">
                      {searchTerm ? "Try a different search term" : "Add vendor partnerships to your manufacturing network"}
                    </p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Vendor Name</TableHead>
                          <TableHead>Contact</TableHead>
                          <TableHead>Location</TableHead>
                          <TableHead>Production Info</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredVendors.map((vendor) => (
                          <TableRow key={vendor.id}>
                            <TableCell className="font-medium">{vendor.name}</TableCell>
                            <TableCell>
                              <div className="flex flex-col">
                                {vendor.contact_person && <span className="text-sm">{vendor.contact_person}</span>}
                                {vendor.email && <span className="text-xs">{vendor.email}</span>}
                                {vendor.phone && <span className="text-xs text-muted-foreground">{vendor.phone}</span>}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex flex-col">
                                {vendor.city && vendor.state && (
                                  <span className="text-sm">{vendor.city}, {vendor.state}</span>
                                )}
                                {vendor.country && <span className="text-xs text-muted-foreground">{vendor.country}</span>}
                                {vendor.region && <span className="text-xs text-muted-foreground">Region: {vendor.region}</span>}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex flex-col text-xs">
                                {vendor.cost_per_unit && <span>Cost: ${vendor.cost_per_unit}/unit</span>}
                                {vendor.lead_time && <span>Lead time: {vendor.lead_time} days</span>}
                                {vendor.average_turnaround_time && (
                                  <span>Avg. turnaround: {vendor.average_turnaround_time} days</span>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant={vendor.active ? "success" : "secondary"}>
                                {vendor.active ? "Active" : "Inactive"}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end space-x-2">
                                <Button variant="outline" size="sm" onClick={() => openEditVendorDialog(vendor)}>
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button variant="outline" size="sm" onClick={() => handleDeleteVendor(vendor.id)}>
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
                
                <div className="mt-6 flex justify-end">
                  <Button onClick={openAddVendorDialog}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Manufacturing Vendor
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        {/* Add Manufacturing Vendor Dialog */}
        <Dialog open={isAddVendorOpen} onOpenChange={setIsAddVendorOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Add Manufacturing Vendor</DialogTitle>
              <DialogDescription>
                Add a new manufacturing vendor to your production network
              </DialogDescription>
            </DialogHeader>
            
            <Form {...vendorForm}>
              <form onSubmit={vendorForm.handleSubmit(handleAddVendor)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={vendorForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Vendor Name*</FormLabel>
                        <FormControl>
                          <Input placeholder="Vendor name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={vendorForm.control}
                    name="contact_person"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contact Person</FormLabel>
                        <FormControl>
                          <Input placeholder="Contact person" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={vendorForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input placeholder="Email" type="email" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={vendorForm.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone</FormLabel>
                        <FormControl>
                          <Input placeholder="Phone number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                
                  <FormField
                    control={vendorForm.control}
                    name="city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>City</FormLabel>
                        <FormControl>
                          <Input placeholder="City" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={vendorForm.control}
                    name="state"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>State</FormLabel>
                        <FormControl>
                          <Input placeholder="State/Province" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={vendorForm.control}
                    name="country"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Country</FormLabel>
                        <FormControl>
                          <Input placeholder="Country" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={vendorForm.control}
                    name="region"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Region</FormLabel>
                        <FormControl>
                          <Input placeholder="Region" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                
                  <FormField
                    control={vendorForm.control}
                    name="cost_per_unit"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cost per Unit ($)</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Cost per unit" 
                            type="number" 
                            min="0" 
                            step="0.01"
                            onChange={(e) => field.onChange(e.target.value === "" ? "" : parseFloat(e.target.value))}
                            value={field.value === undefined ? "" : field.value}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={vendorForm.control}
                    name="lead_time"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Lead Time (days)</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Lead time in days" 
                            type="number"
                            min="1"
                            onChange={(e) => field.onChange(e.target.value === "" ? "" : parseInt(e.target.value))}
                            value={field.value === undefined ? "" : field.value}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                
                  <FormField
                    control={vendorForm.control}
                    name="minimum_order"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Minimum Order Quantity</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Minimum order quantity" 
                            type="number"
                            min="1"
                            onChange={(e) => field.onChange(e.target.value === "" ? "" : parseInt(e.target.value))}
                            value={field.value === undefined ? "" : field.value}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={vendorForm.control}
                    name="average_turnaround_time"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Average Turnaround Time (days)</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Average turnaround time in days" 
                            type="number"
                            min="1"
                            onChange={(e) => field.onChange(e.target.value === "" ? "" : parseInt(e.target.value))}
                            value={field.value === undefined ? "" : field.value}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={vendorForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Additional notes about the vendor" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={vendorForm.control}
                  name="active"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Active Vendor</FormLabel>
                        <FormDescription>
                          Vendor is currently active and available for production
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch 
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsAddVendorOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">Add Vendor</Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
        
        {/* Edit Manufacturing Vendor Dialog */}
        <Dialog open={isEditVendorOpen} onOpenChange={setIsEditVendorOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Edit Manufacturing Vendor</DialogTitle>
              <DialogDescription>
                Update manufacturing vendor details
              </DialogDescription>
            </DialogHeader>
            
            <Form {...vendorForm}>
              <form onSubmit={vendorForm.handleSubmit(handleUpdateVendor)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={vendorForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Vendor Name*</FormLabel>
                        <FormControl>
                          <Input placeholder="Vendor name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={vendorForm.control}
                    name="contact_person"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contact Person</FormLabel>
                        <FormControl>
                          <Input placeholder="Contact person" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={vendorForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input placeholder="Email" type="email" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={vendorForm.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone</FormLabel>
                        <FormControl>
                          <Input placeholder="Phone number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                
                  <FormField
                    control={vendorForm.control}
                    name="city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>City</FormLabel>
                        <FormControl>
                          <Input placeholder="City" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={vendorForm.control}
                    name="state"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>State</FormLabel>
                        <FormControl>
                          <Input placeholder="State/Province" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={vendorForm.control}
                    name="country"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Country</FormLabel>
                        <FormControl>
                          <Input placeholder="Country" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={vendorForm.control}
                    name="region"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Region</FormLabel>
                        <FormControl>
                          <Input placeholder="Region" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                
                  <FormField
                    control={vendorForm.control}
                    name="cost_per_unit"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cost per Unit ($)</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Cost per unit" 
                            type="number" 
                            min="0" 
                            step="0.01"
                            onChange={(e) => field.onChange(e.target.value === "" ? "" : parseFloat(e.target.value))}
                            value={field.value === undefined ? "" : field.value}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={vendorForm.control}
                    name="lead_time"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Lead Time (days)</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Lead time in days" 
                            type="number"
                            min="1"
                            onChange={(e) => field.onChange(e.target.value === "" ? "" : parseInt(e.target.value))}
                            value={field.value === undefined ? "" : field.value}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                
                  <FormField
                    control={vendorForm.control}
                    name="minimum_order"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Minimum Order Quantity</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Minimum order quantity" 
                            type="number"
                            min="1"
                            onChange={(e) => field.onChange(e.target.value === "" ? "" : parseInt(e.target.value))}
                            value={field.value === undefined ? "" : field.value}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={vendorForm.control}
                    name="average_turnaround_time"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Average Turnaround Time (days)</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Average turnaround time in days" 
                            type="number"
                            min="1"
                            onChange={(e) => field.onChange(e.target.value === "" ? "" : parseInt(e.target.value))}
                            value={field.value === undefined ? "" : field.value}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={vendorForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Additional notes about the vendor" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={vendorForm.control}
                  name="active"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Active Vendor</FormLabel>
                        <FormDescription>
                          Vendor is currently active and available for production
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch 
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsEditVendorOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">Update Vendor</Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default AdminManufacturingTeam;
