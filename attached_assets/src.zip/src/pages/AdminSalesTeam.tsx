
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Plus, Edit, Trash, Users, BarChart, DollarSign, MapPin } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";

const AdminSalesTeam = () => {
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [salesTeam, setSalesTeam] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("team");
  
  // Sales person dialog state
  const [isAddSalesPersonDialogOpen, setIsAddSalesPersonDialogOpen] = useState(false);
  const [selectedSalesPerson, setSelectedSalesPerson] = useState<any>(null);
  const [salesPersonFormData, setPersonFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    commissionRate: "",
    address: "",
    city: "",
    state: "",
    zip: "",
    bankAccount: "",
    taxId: "",
    monthlySalesTarget: "",
    quarterlyTarget: "",
    annualTarget: "",
    notes: "",
    username: "",
    password: ""
  });

  useEffect(() => {
    // Redirect if not admin
    if (!isAdmin) {
      toast.error("Admin access required");
      navigate("/");
      return;
    }

    const fetchSalesTeam = async () => {
      setIsLoading(true);
      try {
        // Fetch sales team data
        const { data, error } = await supabase
          .from('sales_people')
          .select('*')
          .order('name');
          
        if (error) throw error;
        
        setSalesTeam(data || []);
      } catch (error) {
        console.error("Error fetching sales team data:", error);
        toast.error("Failed to load sales team data");
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchSalesTeam();
  }, [isAdmin, navigate]);

  const filteredSalesTeam = salesTeam.filter(person => 
    person.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    person.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleAddSalesPerson = async () => {
    try {
      // Create the full name from first and last name
      const fullName = `${salesPersonFormData.firstName} ${salesPersonFormData.lastName}`.trim();
      
      const salesPersonData = {
        name: fullName,
        email: salesPersonFormData.email,
        phone: salesPersonFormData.phone,
        commission_rate: parseFloat(salesPersonFormData.commissionRate) || 0,
        address: salesPersonFormData.address,
        city: salesPersonFormData.city,
        state: salesPersonFormData.state,
        zip: salesPersonFormData.zip,
        bank_account: salesPersonFormData.bankAccount,
        tax_id: salesPersonFormData.taxId,
        monthly_target: parseFloat(salesPersonFormData.monthlySalesTarget) || null,
        quarterly_target: parseFloat(salesPersonFormData.quarterlyTarget) || null,
        annual_target: parseFloat(salesPersonFormData.annualTarget) || null,
        notes: salesPersonFormData.notes
      };
      
      if (selectedSalesPerson) {
        // Update existing sales person
        const { data: updatedPerson, error } = await supabase
          .from('sales_people')
          .update(salesPersonData)
          .eq('id', selectedSalesPerson.id)
          .select()
          .single();
          
        if (error) throw error;
        
        toast.success("Sales person updated successfully");
        setSalesTeam(prev => prev.map(person => 
          person.id === selectedSalesPerson.id ? updatedPerson : person
        ));
      } else {
        // Create new sales person
        const { data: newPerson, error } = await supabase
          .from('sales_people')
          .insert([salesPersonData])
          .select()
          .single();
          
        if (error) throw error;
        
        // Here you would add code to create their user account
        console.log("Would create user account with:", salesPersonFormData.username, salesPersonFormData.password);
        
        toast.success("Sales person added successfully");
        setSalesTeam(prev => [...prev, newPerson]);
      }
      
      setIsAddSalesPersonDialogOpen(false);
      resetForm();
    } catch (error) {
      console.error("Error adding/updating sales person:", error);
      toast.error("Failed to add/update sales person");
    }
  };

  const handleEditSalesPerson = (id: string) => {
    const person = salesTeam.find(p => p.id === id);
    if (person) {
      // Split the name into first and last name (best effort)
      const nameParts = person.name ? person.name.split(' ') : ['', ''];
      const firstName = nameParts[0] || '';
      const lastName = nameParts.slice(1).join(' ') || '';
      
      setSelectedSalesPerson(person);
      setPersonFormData({
        firstName,
        lastName,
        email: person.email || "",
        phone: person.phone || "",
        commissionRate: person.commission_rate?.toString() || "",
        address: person.address || "",
        city: person.city || "",
        state: person.state || "",
        zip: person.zip || "",
        bankAccount: person.bank_account || "",
        taxId: person.tax_id || "",
        monthlySalesTarget: person.monthly_target?.toString() || "",
        quarterlyTarget: person.quarterly_target?.toString() || "",
        annualTarget: person.annual_target?.toString() || "",
        notes: person.notes || "",
        username: "",
        password: ""
      });
      
      setIsAddSalesPersonDialogOpen(true);
    }
  };

  const handleDeleteSalesPerson = async (id: string) => {
    try {
      const { error } = await supabase
        .from('sales_people')
        .delete()
        .eq('id', id);
        
      if (error) throw error;
      
      toast.success("Sales person deleted successfully");
      setSalesTeam(prev => prev.filter(person => person.id !== id));
    } catch (error) {
      console.error("Error deleting sales person:", error);
      toast.error("Failed to delete sales person");
    }
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };
  
  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setPersonFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const resetForm = () => {
    setPersonFormData({
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      commissionRate: "",
      address: "",
      city: "",
      state: "",
      zip: "",
      bankAccount: "",
      taxId: "",
      monthlySalesTarget: "",
      quarterlyTarget: "",
      annualTarget: "",
      notes: "",
      username: "",
      password: ""
    });
    setSelectedSalesPerson(null);
  };

  if (!isAdmin) {
    return null; // Component will redirect in useEffect
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Sales Team Management</h1>
            <p className="text-muted-foreground">
              Manage sales team members, performance, and commissions
            </p>
          </div>
          <Dialog open={isAddSalesPersonDialogOpen} onOpenChange={setIsAddSalesPersonDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Sales Person
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>{selectedSalesPerson ? 'Edit Sales Person' : 'Add Sales Person'}</DialogTitle>
                <DialogDescription>
                  {selectedSalesPerson
                    ? 'Update sales person information and account details.'
                    : 'Add a new sales person to the team and create their account.'}
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-3">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      name="firstName"
                      value={salesPersonFormData.firstName}
                      onChange={handleFormChange}
                      placeholder="First name"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      name="lastName"
                      value={salesPersonFormData.lastName}
                      onChange={handleFormChange}
                      placeholder="Last name"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={salesPersonFormData.email}
                      onChange={handleFormChange}
                      placeholder="Email address"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      name="phone"
                      value={salesPersonFormData.phone}
                      onChange={handleFormChange}
                      placeholder="Phone number"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="commissionRate">Commission Rate (%)</Label>
                    <Input
                      id="commissionRate"
                      name="commissionRate"
                      type="number"
                      value={salesPersonFormData.commissionRate}
                      onChange={handleFormChange}
                      placeholder="0.0"
                    />
                  </div>
                  
                  <div className="col-span-2">
                    <Label>Sales Targets ($)</Label>
                    <div className="grid grid-cols-3 gap-2 mt-2">
                      <div>
                        <Input
                          name="monthlySalesTarget"
                          placeholder="Monthly"
                          value={salesPersonFormData.monthlySalesTarget}
                          onChange={handleFormChange}
                        />
                        <div className="text-xs text-muted-foreground mt-1 text-center">Monthly</div>
                      </div>
                      <div>
                        <Input
                          name="quarterlyTarget"
                          placeholder="Quarterly"
                          value={salesPersonFormData.quarterlyTarget}
                          onChange={handleFormChange}
                        />
                        <div className="text-xs text-muted-foreground mt-1 text-center">Quarterly</div>
                      </div>
                      <div>
                        <Input
                          name="annualTarget"
                          placeholder="Annual"
                          value={salesPersonFormData.annualTarget}
                          onChange={handleFormChange}
                        />
                        <div className="text-xs text-muted-foreground mt-1 text-center">Annual</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="col-span-2">
                    <Label>Address</Label>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      <Input
                        className="col-span-2"
                        name="address"
                        placeholder="Street Address"
                        value={salesPersonFormData.address}
                        onChange={handleFormChange}
                      />
                      <Input
                        name="city"
                        placeholder="City"
                        value={salesPersonFormData.city}
                        onChange={handleFormChange}
                      />
                      <div className="flex space-x-2">
                        <Input
                          name="state"
                          placeholder="State"
                          value={salesPersonFormData.state}
                          onChange={handleFormChange}
                          className="w-1/2"
                        />
                        <Input
                          name="zip"
                          placeholder="ZIP"
                          value={salesPersonFormData.zip}
                          onChange={handleFormChange}
                          className="w-1/2"
                        />
                      </div>
                    </div>
                  </div>
                  
                  {!selectedSalesPerson && (
                    <div className="col-span-2">
                      <Label>Account Information</Label>
                      <div className="grid grid-cols-2 gap-2 mt-2">
                        <Input
                          name="username"
                          placeholder="Username"
                          value={salesPersonFormData.username}
                          onChange={handleFormChange}
                        />
                        <Input
                          name="password"
                          type="password"
                          placeholder="Password"
                          value={salesPersonFormData.password}
                          onChange={handleFormChange}
                        />
                      </div>
                    </div>
                  )}
                  
                  <div>
                    <Label htmlFor="bankAccount">Bank Account</Label>
                    <Input
                      id="bankAccount"
                      name="bankAccount"
                      value={salesPersonFormData.bankAccount}
                      onChange={handleFormChange}
                      placeholder="Bank account details"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="taxId">Tax ID</Label>
                    <Input
                      id="taxId"
                      name="taxId"
                      value={salesPersonFormData.taxId}
                      onChange={handleFormChange}
                      placeholder="Tax ID/SSN"
                    />
                  </div>
                  
                  <div className="col-span-2">
                    <Label htmlFor="notes">Notes</Label>
                    <Textarea
                      id="notes"
                      name="notes"
                      placeholder="Additional notes about this sales person"
                      value={salesPersonFormData.notes}
                      onChange={handleFormChange}
                      rows={3}
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => {
                  setIsAddSalesPersonDialogOpen(false);
                  resetForm();
                }}>
                  Cancel
                </Button>
                <Button onClick={handleAddSalesPerson}>
                  {selectedSalesPerson ? 'Update Sales Person' : 'Add Sales Person & Create Account'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
        
        <Tabs value={activeTab} onValueChange={handleTabChange}>
          <TabsList className="mb-4">
            <TabsTrigger value="team">Team Members</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="commissions">Commissions</TabsTrigger>
            <TabsTrigger value="territories">Territories</TabsTrigger>
          </TabsList>
          
          <TabsContent value="team">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                  <CardTitle className="flex items-center">
                    <Users className="mr-2 h-5 w-5" />
                    Sales Team
                  </CardTitle>
                  <div className="mt-3 md:mt-0 relative w-full md:w-auto max-w-sm">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search sales team..."
                      className="pl-8 w-full md:w-64"
                      value={searchTerm}
                      onChange={handleSearch}
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex justify-center py-10">
                    <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary"></div>
                  </div>
                ) : filteredSalesTeam.length === 0 ? (
                  <div className="text-center py-10">
                    <p className="text-muted-foreground">No sales team members found</p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Phone</TableHead>
                        <TableHead>Commission Rate</TableHead>
                        <TableHead>Annual Target</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredSalesTeam.map((person) => (
                        <TableRow key={person.id}>
                          <TableCell className="font-medium">{person.name}</TableCell>
                          <TableCell>{person.email}</TableCell>
                          <TableCell>{person.phone || 'N/A'}</TableCell>
                          <TableCell>{person.commission_rate}%</TableCell>
                          <TableCell>
                            {person.annual_target 
                              ? `$${person.annual_target.toLocaleString()}`
                              : 'Not set'}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end space-x-2">
                              <Button variant="outline" size="icon" onClick={() => handleEditSalesPerson(person.id)}>
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button variant="outline" size="icon" onClick={() => handleDeleteSalesPerson(person.id)}>
                                <Trash className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="performance">
            <Card>
              <CardHeader>
                <CardTitle>Sales Team Performance</CardTitle>
                <CardDescription>
                  Monitor sales performance metrics and goals
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-white p-4 rounded-lg border">
                      <div className="text-sm font-medium text-muted-foreground">Monthly Sales</div>
                      <div className="text-3xl font-bold mt-1">$124,850</div>
                      <div className="text-sm text-green-500 mt-1">+8.2% from last month</div>
                    </div>
                    <div className="bg-white p-4 rounded-lg border">
                      <div className="text-sm font-medium text-muted-foreground">Leads Converted</div>
                      <div className="text-3xl font-bold mt-1">43</div>
                      <div className="text-sm text-green-500 mt-1">+12% from last month</div>
                    </div>
                    <div className="bg-white p-4 rounded-lg border">
                      <div className="text-sm font-medium text-muted-foreground">Avg Deal Size</div>
                      <div className="text-3xl font-bold mt-1">$2,905</div>
                      <div className="text-sm text-red-500 mt-1">-3.5% from last month</div>
                    </div>
                  </div>
                  
                  <h3 className="text-lg font-medium">Performance By Sales Rep</h3>
                  
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Sales Rep</TableHead>
                        <TableHead>Monthly Sales</TableHead>
                        <TableHead>Leads Assigned</TableHead>
                        <TableHead>Conversion Rate</TableHead>
                        <TableHead>Target Achievement</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredSalesTeam.slice(0, 5).map((person) => (
                        <TableRow key={person.id}>
                          <TableCell className="font-medium">{person.name}</TableCell>
                          <TableCell>${(Math.random() * 50000 + 10000).toFixed(2)}</TableCell>
                          <TableCell>{Math.floor(Math.random() * 30 + 5)}</TableCell>
                          <TableCell>{(Math.random() * 40 + 10).toFixed(1)}%</TableCell>
                          <TableCell>
                            <div className="w-full bg-gray-200 rounded-full h-2.5">
                              <div 
                                className="bg-primary h-2.5 rounded-full" 
                                style={{ width: `${Math.floor(Math.random() * 100)}%` }}
                              ></div>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="commissions">
            <Card>
              <CardHeader>
                <CardTitle>Sales Commissions</CardTitle>
                <CardDescription>
                  Manage commission structures and payouts
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-medium">Commission Payouts (April 2025)</h3>
                    <Button variant="outline" className="flex items-center gap-2">
                      <DollarSign className="h-4 w-4" />
                      Process Payouts
                    </Button>
                  </div>
                  
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Sales Rep</TableHead>
                        <TableHead>Total Sales</TableHead>
                        <TableHead>Commission Rate</TableHead>
                        <TableHead>Commission Amount</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredSalesTeam.slice(0, 5).map((person) => {
                        const sales = Math.random() * 50000 + 10000;
                        const commission = sales * (person.commission_rate / 100);
                        
                        return (
                          <TableRow key={person.id}>
                            <TableCell className="font-medium">{person.name}</TableCell>
                            <TableCell>${sales.toFixed(2)}</TableCell>
                            <TableCell>{person.commission_rate}%</TableCell>
                            <TableCell>${commission.toFixed(2)}</TableCell>
                            <TableCell>
                              <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="territories">
            <Card>
              <CardHeader>
                <CardTitle>Sales Territories</CardTitle>
                <CardDescription>
                  Manage geographic sales territories and assignments
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Territory Assignments</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Rep</TableHead>
                            <TableHead>Territory</TableHead>
                            <TableHead>Schools</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredSalesTeam.slice(0, 4).map((person, index) => {
                            const territories = [
                              'Northeast',
                              'Southeast',
                              'Midwest',
                              'West Coast',
                              'Southwest',
                              'Northwest'
                            ];
                            
                            return (
                              <TableRow key={person.id}>
                                <TableCell className="font-medium">{person.name}</TableCell>
                                <TableCell>
                                  <div className="flex items-center">
                                    <MapPin className="mr-1 h-4 w-4 text-muted-foreground" />
                                    {territories[index % territories.length]}
                                  </div>
                                </TableCell>
                                <TableCell>{Math.floor(Math.random() * 200) + 50}</TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Territory Performance</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <div className="text-sm font-medium">Northeast</div>
                            <div className="text-sm font-medium">$89,450</div>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className="bg-green-500 h-2 rounded-full" style={{ width: "76%" }}></div>
                          </div>
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <div className="text-sm font-medium">Southeast</div>
                            <div className="text-sm font-medium">$67,230</div>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className="bg-blue-500 h-2 rounded-full" style={{ width: "58%" }}></div>
                          </div>
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <div className="text-sm font-medium">Midwest</div>
                            <div className="text-sm font-medium">$104,780</div>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className="bg-purple-500 h-2 rounded-full" style={{ width: "89%" }}></div>
                          </div>
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <div className="text-sm font-medium">West Coast</div>
                            <div className="text-sm font-medium">$92,320</div>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className="bg-yellow-500 h-2 rounded-full" style={{ width: "79%" }}></div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminSalesTeam;
