
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Sidebar from "@/components/Sidebar";
import { 
  Calendar, 
  Users, 
  DollarSign, 
  ClipboardList, 
  Home, 
  FileText, 
  Trash2, 
  Download,
  Upload,
  Link2,
  ExternalLink,
  Mail,
  Tag,
  Clock,
  MapPin,
  Utensils,
  ShoppingCart,
  Book,
  Award,
  Truck,
  Plus
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import CampCostCategory, { CostItem } from "@/components/camp/CampCostCategory";
import AccommodationItem, { Accommodation } from "@/components/camp/AccommodationItem";
import IntegrationButton from "@/components/camp/IntegrationButton";
import { v4 as uuidv4 } from "uuid";
import { toast } from "sonner";

// Define cost categories
const COST_CATEGORIES = [
  { id: "clinician", title: "Clinician Contracts" },
  { id: "supplies", title: "Supplies" },
  { id: "gear", title: "Gear & Equipment" },
  { id: "food", title: "Food & Beverages" },
  { id: "venue", title: "Venue Rental" },
  { id: "transportation", title: "Transportation" },
  { id: "marketing", title: "Marketing & Promotion" },
  { id: "insurance", title: "Insurance" },
  { id: "staff", title: "Staff Compensation" },
  { id: "misc", title: "Miscellaneous" },
  { id: "accommodations", title: "Accommodations" },
];

const CampManagement = () => {
  const [activeTab, setActiveTab] = useState("overview");
  
  // State for notes
  const [noteTitle, setNoteTitle] = useState("");
  const [noteContent, setNoteContent] = useState("");
  const [savedNotes, setSavedNotes] = useState([
    { id: "1", title: "Summer Camp Planning", content: "Initial ideas for summer basketball camp curriculum and activities." },
    { id: "2", title: "Fall Clinic Locations", content: "Research on potential facilities for fall clinic series." }
  ]);

  // State for budget categories and items - initialize with empty objects for each category
  const [costItems, setCostItems] = useState<Record<string, CostItem[]>>({});

  // State for accommodations
  const [accommodations, setAccommodations] = useState<Accommodation[]>([]);

  // Initialize cost categories
  useEffect(() => {
    const initialCostItems: Record<string, CostItem[]> = {};
    COST_CATEGORIES.forEach(category => {
      initialCostItems[category.id] = [];
    });
    setCostItems(initialCostItems);
  }, []);

  // Save a new note
  const handleSaveNote = () => {
    if (!noteTitle.trim()) {
      toast.error("Please enter a note title");
      return;
    }
    
    const newNote = {
      id: uuidv4(),
      title: noteTitle,
      content: noteContent
    };
    
    setSavedNotes([...savedNotes, newNote]);
    setNoteTitle("");
    setNoteContent("");
    toast.success("Note saved successfully");
  };

  // Delete a note
  const handleDeleteNote = (id: string) => {
    setSavedNotes(savedNotes.filter(note => note.id !== id));
    toast.success("Note deleted successfully");
  };

  // Add a cost item to a category
  const handleAddCostItem = (categoryId: string) => {
    const newItem: CostItem = {
      id: uuidv4(),
      description: "",
      amount: 0
    };
    
    setCostItems(prev => {
      // Make sure the category exists in the state
      const updatedItems = { ...prev };
      if (!updatedItems[categoryId]) {
        updatedItems[categoryId] = [];
      }
      updatedItems[categoryId] = [...updatedItems[categoryId], newItem];
      return updatedItems;
    });
  };

  // Update a cost item
  const handleUpdateCostItem = (categoryId: string, updatedItem: CostItem) => {
    setCostItems(prev => {
      // Make sure the category exists in the state
      const updatedItems = { ...prev };
      if (!updatedItems[categoryId]) {
        updatedItems[categoryId] = [];
        return updatedItems;
      }
      
      updatedItems[categoryId] = updatedItems[categoryId].map(item => 
        item.id === updatedItem.id ? updatedItem : item
      );
      return updatedItems;
    });
  };

  // Remove a cost item
  const handleRemoveCostItem = (categoryId: string, itemId: string) => {
    setCostItems(prev => {
      // Make sure the category exists in the state
      const updatedItems = { ...prev };
      if (!updatedItems[categoryId]) {
        return prev;
      }
      
      updatedItems[categoryId] = updatedItems[categoryId].filter(item => item.id !== itemId);
      return updatedItems;
    });
  };

  // Calculate total budget
  const calculateTotalBudget = () => {
    let total = 0;
    Object.values(costItems).forEach(categoryItems => {
      if (categoryItems && Array.isArray(categoryItems)) {
        categoryItems.forEach(item => {
          total += item.amount;
        });
      }
    });
    return total;
  };

  // Add a new accommodation
  const handleAddAccommodation = () => {
    const newAccommodation: Accommodation = {
      id: uuidv4(),
      name: "",
      location: "",
      capacity: 0,
      costPerNight: 0,
      totalNights: 0,
      notes: "",
      addedToBudget: false
    };
    
    setAccommodations([...accommodations, newAccommodation]);
  };

  // Update accommodation
  const handleUpdateAccommodation = (updatedAccommodation: Accommodation) => {
    setAccommodations(prev => 
      prev.map(accommodation => 
        accommodation.id === updatedAccommodation.id ? updatedAccommodation : accommodation
      )
    );
  };

  // Delete accommodation
  const handleDeleteAccommodation = (id: string) => {
    setAccommodations(prev => prev.filter(accommodation => accommodation.id !== id));
  };

  // Add accommodation to budget
  const handleAddToBudget = (accommodation: Accommodation) => {
    // Add to budget as cost item
    const totalCost = accommodation.costPerNight * accommodation.totalNights;
    const newCostItem: CostItem = {
      id: uuidv4(),
      description: `${accommodation.name} (${accommodation.totalNights} nights)`,
      amount: totalCost
    };
    
    setCostItems(prev => {
      const updatedItems = { ...prev };
      if (!updatedItems["accommodations"]) {
        updatedItems["accommodations"] = [];
      }
      updatedItems["accommodations"] = [...updatedItems["accommodations"], newCostItem];
      return updatedItems;
    });
    
    // Mark accommodation as added to budget
    setAccommodations(prev => 
      prev.map(item => 
        item.id === accommodation.id ? { ...item, addedToBudget: true } : item
      )
    );
    
    toast.success(`Added ${accommodation.name} to budget`);
  };

  // Handle external site connection
  const handleExternalSiteConnection = (url: string) => {
    console.log("Connecting to external site:", url);
    toast.success("Connection initiated. Waiting for authorization from the external site.");
    // In a real app, this would initiate a connection flow with the external service
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold">Camp Management</h1>
          <p className="text-muted-foreground">
            Organize and manage sports camps and events
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="bg-muted/50">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="events">Events</TabsTrigger>
            <TabsTrigger value="signups">Signups</TabsTrigger>
            <TabsTrigger value="budget">Budget</TabsTrigger>
            <TabsTrigger value="accommodations">Accommodations</TabsTrigger>
            <TabsTrigger value="materials">Materials</TabsTrigger>
            <TabsTrigger value="notes">Notes & Planning</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">
                    Upcoming Camps
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">3</div>
                  <p className="text-xs text-muted-foreground">
                    Next event: Summer Basketball Camp (June 15)
                  </p>
                </CardContent>
                <CardFooter className="pt-0">
                  <IntegrationButton 
                    title="Connect Calendar" 
                    description="Connect your external calendar to sync camp events"
                    icon={<Calendar className="mr-2 h-4 w-4" />}
                  />
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">
                    Total Registrations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">247</div>
                  <p className="text-xs text-muted-foreground">
                    Across all upcoming events
                  </p>
                </CardContent>
                <CardFooter className="pt-0">
                  <IntegrationButton 
                    title="Connect Registration System" 
                    description="Connect your external registration system to automatically track signups"
                    icon={<Users className="mr-2 h-4 w-4" />}
                  />
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">
                    Budget Status
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">${calculateTotalBudget().toFixed(2)}</div>
                  <p className="text-xs text-muted-foreground">
                    Total allocated for upcoming events
                  </p>
                </CardContent>
                <CardFooter className="pt-0">
                  <Button variant="outline" className="w-full justify-start" onClick={() => setActiveTab("budget")}>
                    <DollarSign className="mr-2 h-4 w-4" />
                    Manage Budget
                  </Button>
                </CardFooter>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>
                  Common camp management tasks
                </CardDescription>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Button className="justify-start" onClick={() => setActiveTab("events")}>
                  <Calendar className="mr-2 h-4 w-4" />
                  Manage Events
                </Button>
                <Button className="justify-start" onClick={() => setActiveTab("signups")}>
                  <Users className="mr-2 h-4 w-4" />
                  Track Registrations
                </Button>
                <Button className="justify-start" onClick={() => setActiveTab("budget")}>
                  <DollarSign className="mr-2 h-4 w-4" />
                  Budget Planning
                </Button>
                <Button className="justify-start" onClick={() => setActiveTab("accommodations")}>
                  <Home className="mr-2 h-4 w-4" />
                  Accommodations
                </Button>
                <Button className="justify-start" onClick={() => setActiveTab("materials")}>
                  <ClipboardList className="mr-2 h-4 w-4" />
                  Equipment & Materials
                </Button>
                <Button className="justify-start" onClick={() => setActiveTab("notes")}>
                  <FileText className="mr-2 h-4 w-4" />
                  Notes & Planning
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="events" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>Event Management</CardTitle>
                    <CardDescription>
                      Create and manage camp events
                    </CardDescription>
                  </div>
                  <div className="flex space-x-2">
                    <IntegrationButton 
                      title="Connect External Events" 
                      description="Connect to an external events management system"
                      icon={<ExternalLink className="mr-2 h-4 w-4" />}
                      variant="default"
                    />
                    <Button variant="outline">
                      <Plus className="mr-2 h-4 w-4" /> Add Event
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  This section will contain a calendar and event management interface.
                </p>
                <div className="h-64 border-2 border-dashed rounded-md flex items-center justify-center bg-muted/50">
                  <p className="text-muted-foreground">Event Calendar Placeholder</p>
                </div>
                <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                  <IntegrationButton 
                    title="Sync with Google Calendar" 
                    description="Connect and sync your events with Google Calendar"
                    icon={<Calendar className="mr-2 h-4 w-4" />}
                  />
                  <IntegrationButton 
                    title="Export Events" 
                    description="Export your events to external systems"
                    icon={<Download className="mr-2 h-4 w-4" />}
                  />
                  <IntegrationButton 
                    title="Import Events" 
                    description="Import events from external systems"
                    icon={<Upload className="mr-2 h-4 w-4" />}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="signups" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>Registration Tracking</CardTitle>
                    <CardDescription>
                      Track and manage participant registrations
                    </CardDescription>
                  </div>
                  <div className="flex space-x-2">
                    <IntegrationButton 
                      title="Connect Registration System" 
                      description="Connect to your external registration system"
                      icon={<Link2 className="mr-2 h-4 w-4" />}
                      variant="default"
                    />
                    <Button variant="outline">
                      <Plus className="mr-2 h-4 w-4" /> Add Participant
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  This section will contain participant registration data and management tools.
                </p>
                <div className="h-64 border-2 border-dashed rounded-md flex items-center justify-center bg-muted/50">
                  <p className="text-muted-foreground">Registration Table Placeholder</p>
                </div>
                <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                  <IntegrationButton 
                    title="Email Communications" 
                    description="Connect to your email communication system"
                    icon={<Mail className="mr-2 h-4 w-4" />}
                  />
                  <IntegrationButton 
                    title="Export Registrations" 
                    description="Export your registration data"
                    icon={<Download className="mr-2 h-4 w-4" />}
                  />
                  <IntegrationButton 
                    title="Import Registrations" 
                    description="Import registration data from other systems"
                    icon={<Upload className="mr-2 h-4 w-4" />}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="budget" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>Budget Planning</CardTitle>
                    <CardDescription>
                      Manage expenses and revenue for camp events
                    </CardDescription>
                  </div>
                  <div className="flex space-x-2">
                    <IntegrationButton 
                      title="Connect Accounting System" 
                      description="Connect to your external accounting system"
                      icon={<Link2 className="mr-2 h-4 w-4" />}
                      variant="default"
                    />
                    <Button variant="outline">
                      <Download className="mr-2 h-4 w-4" /> Export Budget
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="mb-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-lg font-semibold">Budget Summary</h3>
                    <span className="text-xl font-bold">${calculateTotalBudget().toFixed(2)}</span>
                  </div>
                  <p className="text-sm text-gray-500">
                    Total budget for all categories. Add items to categories below to track expenses.
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {COST_CATEGORIES.map(category => (
                    <CampCostCategory
                      key={category.id}
                      title={category.title}
                      items={costItems[category.id] || []}
                      onAddItem={() => handleAddCostItem(category.id)}
                      onUpdateItem={handleUpdateCostItem}
                      onRemoveItem={handleRemoveCostItem}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="accommodations" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>Accommodations</CardTitle>
                    <CardDescription>
                      Manage hotels, rentals and housing for events
                    </CardDescription>
                  </div>
                  <div className="flex space-x-2">
                    <IntegrationButton 
                      title="Connect Booking System" 
                      description="Connect to your external hotel booking system"
                      icon={<Link2 className="mr-2 h-4 w-4" />}
                      variant="default"
                    />
                    <Button variant="default" onClick={handleAddAccommodation}>
                      <Plus className="mr-2 h-4 w-4" /> Add Accommodation
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {accommodations.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-10">
                    <Home className="h-16 w-16 text-gray-300 mb-4" />
                    <h3 className="text-lg font-medium mb-2">No accommodations added yet</h3>
                    <p className="text-sm text-gray-500 mb-4">Add hotels, dorms, and other accommodations here</p>
                    <Button onClick={handleAddAccommodation}>
                      <Plus className="mr-2 h-4 w-4" /> Add Accommodation
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {accommodations.map(accommodation => (
                      <AccommodationItem
                        key={accommodation.id}
                        accommodation={accommodation}
                        onUpdate={handleUpdateAccommodation}
                        onDelete={handleDeleteAccommodation}
                        onAddToBudget={handleAddToBudget}
                      />
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="materials" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>Equipment & Materials</CardTitle>
                    <CardDescription>
                      Track equipment, apparel, and materials needed for camps
                    </CardDescription>
                  </div>
                  <div className="flex space-x-2">
                    <IntegrationButton 
                      title="Connect Inventory System" 
                      description="Connect to your external inventory management system"
                      icon={<Link2 className="mr-2 h-4 w-4" />}
                      variant="default"
                    />
                    <Button variant="outline">
                      <Plus className="mr-2 h-4 w-4" /> Add Item
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  This section will help manage equipment and materials for events.
                </p>
                <div className="h-64 border-2 border-dashed rounded-md flex items-center justify-center bg-muted/50">
                  <p className="text-muted-foreground">Materials Inventory Placeholder</p>
                </div>
                <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button variant="outline" className="justify-start">
                    <Tag className="mr-2 h-4 w-4" />
                    Tag Equipment
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <Truck className="mr-2 h-4 w-4" />
                    Request Shipping
                  </Button>
                  <Button variant="outline" className="justify-start" onClick={() => setActiveTab("budget")}>
                    <DollarSign className="mr-2 h-4 w-4" />
                    Add to Budget
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notes" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Notes & Planning</CardTitle>
                <CardDescription>
                  Brainstorming and planning for camps and events
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="note-title">Note Title</Label>
                    <Input 
                      id="note-title" 
                      placeholder="Enter note title" 
                      value={noteTitle}
                      onChange={(e) => setNoteTitle(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="note-content">Note Content</Label>
                    <Textarea
                      id="note-content"
                      placeholder="Enter your notes, ideas, and plans here..."
                      className="min-h-32"
                      value={noteContent}
                      onChange={(e) => setNoteContent(e.target.value)}
                    />
                  </div>
                  <div className="flex justify-end">
                    <Button onClick={handleSaveNote}>Save Note</Button>
                  </div>
                  
                  <div className="mt-6">
                    <h3 className="text-sm font-medium mb-2">Saved Notes</h3>
                    <div className="space-y-2">
                      {savedNotes.map(note => (
                        <Card key={note.id}>
                          <CardHeader className="py-3">
                            <div className="flex justify-between items-start">
                              <CardTitle className="text-sm">{note.title}</CardTitle>
                              <Button 
                                variant="ghost" 
                                size="icon"
                                onClick={() => handleDeleteNote(note.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </CardHeader>
                          <CardContent className="py-2">
                            <p className="text-sm">{note.content}</p>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default CampManagement;
