
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, Product } from "@/lib/api";
import ProductCard from "@/components/ProductCard";
import AdminProductCard from "@/components/AdminProductCard";
import Sidebar from "@/components/Sidebar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Filter, PenSquare } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/context/AuthContext";
import { adminService } from "@/services/adminService";
import { toast } from "sonner";

const Catalog = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [adminMode, setAdminMode] = useState(false);
  
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSport, setSelectedSport] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [sports, setSports] = useState<string[]>([]);
  const [categories, setCategories] = useState<string[]>([]);

  useEffect(() => {
    const fetchProducts = async () => {
      setIsLoading(true);
      try {
        const productsData = await api.getProducts();
        
        // If admin, load any edited products from localStorage and merge
        if (isAdmin) {
          const adminProducts = await adminService.getAdminProducts();
          
          // Merge admin products with API products (overriding API data with admin edits)
          if (adminProducts.length > 0) {
            const mergedProducts = [...productsData];
            
            for (const adminProduct of adminProducts) {
              const index = mergedProducts.findIndex(p => p.id === adminProduct.id);
              if (index >= 0) {
                mergedProducts[index] = adminProduct;
              }
            }
            
            setProducts(mergedProducts);
            setFilteredProducts(mergedProducts);
          } else {
            setProducts(productsData);
            setFilteredProducts(productsData);
          }
        } else {
          setProducts(productsData);
          setFilteredProducts(productsData);
        }
        
        // Extract unique sports and categories
        const uniqueSports = Array.from(new Set(productsData.map(p => p.sport)));
        const uniqueCategories = Array.from(new Set(productsData.map(p => p.category)));
        
        setSports(uniqueSports);
        setCategories(uniqueCategories);
      } catch (error) {
        console.error("Error fetching products:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchProducts();
  }, [isAdmin]);

  useEffect(() => {
    // Apply filters whenever they change
    let result = products;
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        product => 
          product.name.toLowerCase().includes(query) || 
          product.description.toLowerCase().includes(query)
      );
    }
    
    if (selectedSport) {
      result = result.filter(product => product.sport === selectedSport);
    }
    
    if (selectedCategory) {
      result = result.filter(product => product.category === selectedCategory);
    }
    
    setFilteredProducts(result);
  }, [searchQuery, selectedSport, selectedCategory, products]);

  const handleAddToOrder = (product: Product) => {
    // In a real application, this would either add to an existing draft order
    // or start a new order. For now, we'll just navigate to the orders page.
    navigate("/orders/new", { state: { product } });
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  const handleSportFilter = (sport: string | null) => {
    setSelectedSport(sport === selectedSport ? null : sport);
  };

  const handleCategoryFilter = (category: string | null) => {
    setSelectedCategory(category === selectedCategory ? null : category);
  };

  const clearFilters = () => {
    setSearchQuery("");
    setSelectedSport(null);
    setSelectedCategory(null);
  };

  const handleSaveProduct = async (updatedProduct: Product) => {
    try {
      await adminService.updateProduct(updatedProduct);
      
      // Update the products list with the edited product
      setProducts(prevProducts => 
        prevProducts.map(p => p.id === updatedProduct.id ? updatedProduct : p)
      );
      
      toast.success("Product updated successfully");
    } catch (error) {
      console.error("Error saving product:", error);
      toast.error("Failed to update product");
    }
  };

  const toggleAdminMode = () => {
    setAdminMode(prev => !prev);
  };

  const isFiltering = !!searchQuery || !!selectedSport || !!selectedCategory;

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="mb-6 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold neon-text">Product Catalog</h1>
            <p className="text-muted-foreground">
              Browse all products and add items to orders
            </p>
          </div>
          
          {isAdmin && (
            <Button 
              variant={adminMode ? "default" : "outline"} 
              onClick={toggleAdminMode}
              className="flex items-center gap-2"
            >
              <PenSquare className="h-4 w-4" />
              {adminMode ? "Exit Admin Mode" : "Enter Admin Mode"}
            </Button>
          )}
        </div>

        <Card className="mb-6 neon-card">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search products..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={handleSearch}
                />
              </div>
              <div className="flex items-center gap-2">
                {isFiltering && (
                  <Button variant="ghost" onClick={clearFilters} size="sm">
                    Clear filters
                  </Button>
                )}
                <div className="relative">
                  <Tabs defaultValue="sports">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center">
                        <Filter className="mr-2 h-4 w-4" />
                        <span className="text-sm font-medium">Filter by:</span>
                      </div>
                      <TabsList>
                        <TabsTrigger value="sports">Sports</TabsTrigger>
                        <TabsTrigger value="categories">Categories</TabsTrigger>
                      </TabsList>
                    </div>
                    <TabsContent value="sports" className="absolute z-10 mt-2 bg-white p-4 rounded-md shadow-md border">
                      <div className="flex flex-wrap gap-2 max-w-xl">
                        {sports.map((sport) => (
                          <Badge
                            key={sport}
                            variant={selectedSport === sport ? "default" : "outline"}
                            className="cursor-pointer"
                            onClick={() => handleSportFilter(sport)}
                          >
                            {sport}
                          </Badge>
                        ))}
                      </div>
                    </TabsContent>
                    <TabsContent value="categories" className="absolute z-10 mt-2 bg-white p-4 rounded-md shadow-md border">
                      <div className="flex flex-wrap gap-2 max-w-xl">
                        {categories.map((category) => (
                          <Badge
                            key={category}
                            variant={selectedCategory === category ? "default" : "outline"}
                            className="cursor-pointer"
                            onClick={() => handleCategoryFilter(category)}
                          >
                            {category}
                          </Badge>
                        ))}
                      </div>
                    </TabsContent>
                  </Tabs>
                </div>
              </div>
            </div>

            {isFiltering && (
              <div className="flex gap-2 mt-4 flex-wrap">
                {selectedSport && (
                  <Badge variant="secondary" className="flex items-center gap-1">
                    Sport: {selectedSport}
                    <button 
                      onClick={() => setSelectedSport(null)}
                      className="ml-1 text-xs hover:bg-gray-200 rounded-full h-4 w-4 inline-flex items-center justify-center"
                    >
                      ×
                    </button>
                  </Badge>
                )}
                {selectedCategory && (
                  <Badge variant="secondary" className="flex items-center gap-1">
                    Category: {selectedCategory}
                    <button 
                      onClick={() => setSelectedCategory(null)}
                      className="ml-1 text-xs hover:bg-gray-200 rounded-full h-4 w-4 inline-flex items-center justify-center"
                    >
                      ×
                    </button>
                  </Badge>
                )}
                {searchQuery && (
                  <Badge variant="secondary" className="flex items-center gap-1">
                    Search: {searchQuery}
                    <button 
                      onClick={() => setSearchQuery("")}
                      className="ml-1 text-xs hover:bg-gray-200 rounded-full h-4 w-4 inline-flex items-center justify-center"
                    >
                      ×
                    </button>
                  </Badge>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="h-48 w-full" />
                <CardContent className="p-4">
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/2 mb-4" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-full mb-4" />
                  <Skeleton className="h-8 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div>
            {filteredProducts.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-lg text-muted-foreground">No products found matching your filters</p>
                <Button variant="outline" onClick={clearFilters} className="mt-4">
                  Clear All Filters
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {filteredProducts.map((product) => (
                  isAdmin && adminMode ? (
                    <AdminProductCard
                      key={product.id}
                      product={product}
                      onSave={handleSaveProduct}
                    />
                  ) : (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onAddToOrder={handleAddToOrder}
                    />
                  )
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Catalog;
