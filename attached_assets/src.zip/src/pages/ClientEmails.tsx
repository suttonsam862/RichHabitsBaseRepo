
import { useState, useEffect } from "react";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Mail, Search, User, Calendar, Inbox, Star, AlertTriangle, ExternalLink } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

// Email interface
interface Email {
  id: string;
  subject: string;
  sender: string;
  senderEmail: string;
  preview: string;
  date: string;
  isRead: boolean;
  isStarred: boolean;
  category?: string;
}

const ClientEmails = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [isConnected, setIsConnected] = useState(false);
  const [emails, setEmails] = useState<Email[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [outlookEmail, setOutlookEmail] = useState("");
  const [outlookPassword, setOutlookPassword] = useState("");

  // Filter emails based on search
  const filteredEmails = emails.filter(
    (email) =>
      email.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
      email.sender.toLowerCase().includes(searchTerm.toLowerCase()) ||
      email.senderEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
      email.preview.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Simulated connect to Outlook
  const handleConnectOutlook = () => {
    if (!outlookEmail || !outlookPassword) {
      toast.error("Please enter your Outlook email and password");
      return;
    }
    
    setIsLoading(true);
    // Simulate connection delay
    setTimeout(() => {
      setIsConnected(true);
      setIsLoading(false);
      localStorage.setItem("outlook_connected", "true");
      localStorage.setItem("outlook_email", outlookEmail);
      toast.success("Connected to Outlook successfully");
      loadMockEmails();
    }, 1500);
  };

  // Load mock email data
  const loadMockEmails = () => {
    // Empty array - no sample data as requested
    setEmails([]);
    setIsLoading(false);
  };

  // Check if already connected on component mount
  useEffect(() => {
    const connected = localStorage.getItem("outlook_connected") === "true";
    const email = localStorage.getItem("outlook_email");
    
    if (connected && email) {
      setIsConnected(true);
      setOutlookEmail(email);
      loadMockEmails();
    } else {
      setIsLoading(false);
    }
  }, []);

  // Handle disconnect
  const handleDisconnect = () => {
    setIsConnected(false);
    setEmails([]);
    localStorage.removeItem("outlook_connected");
    localStorage.removeItem("outlook_email");
    toast.success("Disconnected from Outlook");
  };

  // Handle compose new email
  const handleComposeEmail = () => {
    window.open("https://outlook.live.com/mail/0/deeplink/compose", "_blank");
    toast.success("Opening Outlook compose window");
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Client Emails</h1>
            <p className="text-muted-foreground">
              Manage all client communications in one place
            </p>
          </div>
          
          {isConnected && (
            <Button onClick={handleComposeEmail}>
              <Mail className="mr-2 h-4 w-4" />
              Compose New Email
            </Button>
          )}
        </div>

        {!isConnected ? (
          <Card>
            <CardHeader>
              <CardTitle>Connect to Outlook</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="outlook_email" className="block text-sm font-medium">
                    Outlook Email
                  </label>
                  <Input
                    id="outlook_email"
                    type="email"
                    value={outlookEmail}
                    onChange={(e) => setOutlookEmail(e.target.value)}
                    placeholder="your.email@outlook.com"
                  />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="outlook_password" className="block text-sm font-medium">
                    Password
                  </label>
                  <Input
                    id="outlook_password"
                    type="password"
                    value={outlookPassword}
                    onChange={(e) => setOutlookPassword(e.target.value)}
                    placeholder="Enter your password"
                  />
                </div>
                
                <div className="pt-2">
                  <Button 
                    onClick={handleConnectOutlook} 
                    disabled={isLoading}
                    className="w-full"
                  >
                    {isLoading ? (
                      <>
                        <span className="animate-spin mr-2">⋯</span>
                        Connecting...
                      </>
                    ) : (
                      <>
                        <Mail className="mr-2 h-4 w-4" />
                        Connect to Outlook
                      </>
                    )}
                  </Button>
                </div>
                
                <div className="pt-2 text-sm text-muted-foreground">
                  <p>
                    This will connect to your Outlook account to display client communications.
                    Your credentials are stored locally and never sent to our servers.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <>
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search emails..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground">
                    Connected as: {outlookEmail}
                  </span>
                  <Button variant="outline" size="sm" onClick={handleDisconnect}>
                    Disconnect
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => window.open("https://outlook.live.com/mail/0/", "_blank")}>
                    <ExternalLink className="h-4 w-4 mr-1" />
                    Open in Outlook
                  </Button>
                </div>
              </div>
              
              <Tabs defaultValue="inbox">
                <TabsList>
                  <TabsTrigger value="inbox">
                    <Inbox className="h-4 w-4 mr-2" />
                    Inbox
                  </TabsTrigger>
                  <TabsTrigger value="starred">
                    <Star className="h-4 w-4 mr-2" />
                    Starred
                  </TabsTrigger>
                  <TabsTrigger value="sent">
                    <Mail className="h-4 w-4 mr-2" />
                    Sent
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="inbox" className="mt-4">
                  {isLoading ? (
                    <div className="space-y-4">
                      {[...Array(5)].map((_, i) => (
                        <Card key={i}>
                          <CardContent className="p-4">
                            <Skeleton className="h-5 w-3/4 mb-2" />
                            <Skeleton className="h-4 w-1/2 mb-2" />
                            <Skeleton className="h-4 w-full" />
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : filteredEmails.length > 0 ? (
                    <div className="space-y-4">
                      {filteredEmails.map((email) => (
                        <Card key={email.id} className={email.isRead ? "bg-gray-50" : "bg-white"}>
                          <CardContent className="p-4">
                            <div className="flex justify-between items-start">
                              <div className="flex items-center mb-2">
                                <div className="bg-gray-200 rounded-full h-8 w-8 flex items-center justify-center mr-2">
                                  <User className="h-4 w-4 text-gray-600" />
                                </div>
                                <div>
                                  <p className="font-medium">{email.sender}</p>
                                  <p className="text-xs text-gray-500">{email.senderEmail}</p>
                                </div>
                              </div>
                              <div className="flex items-center space-x-2">
                                <span className="text-xs text-gray-500">{email.date}</span>
                                {email.isStarred && <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />}
                              </div>
                            </div>
                            <h3 className="font-medium mb-1">{email.subject}</h3>
                            <p className="text-sm text-gray-600">{email.preview}</p>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Mail className="mx-auto h-12 w-12 text-gray-400 mb-3" />
                      <h3 className="text-lg font-medium">No emails found</h3>
                      <p className="text-gray-500 mt-1 mb-4">
                        {searchTerm ? (
                          `No results for "${searchTerm}". Try a different search term.`
                        ) : (
                          "Your inbox is empty. New emails will appear here."
                        )}
                      </p>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="starred" className="mt-4">
                  <div className="text-center py-12">
                    <Star className="mx-auto h-12 w-12 text-gray-400 mb-3" />
                    <h3 className="text-lg font-medium">No starred emails</h3>
                    <p className="text-gray-500 mt-1">
                      Star important emails to find them quickly here.
                    </p>
                  </div>
                </TabsContent>
                
                <TabsContent value="sent" className="mt-4">
                  <div className="text-center py-12">
                    <Mail className="mx-auto h-12 w-12 text-gray-400 mb-3" />
                    <h3 className="text-lg font-medium">No sent emails</h3>
                    <p className="text-gray-500 mt-1">
                      Emails you send will appear here.
                    </p>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default ClientEmails;
