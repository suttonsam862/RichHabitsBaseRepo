
import { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Send, RefreshCw, User, Users } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";

interface Client {
  id: string;
  name: string;
  email: string;
  company: string;
  status: "active" | "inactive";
  lastContact: string;
}

interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  body: string;
}

const ClientPortal = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("send-email");
  const [loading, setLoading] = useState(false);
  
  // Form states
  const [selectedClients, setSelectedClients] = useState<string[]>([]);
  const [subject, setSubject] = useState("");
  const [emailBody, setEmailBody] = useState("");
  const [selectedTemplate, setSelectedTemplate] = useState("");
  
  // Demo data
  const clients: Client[] = [
    {
      id: "1",
      name: "John Smith",
      email: "john.smith@example.com",
      company: "ABC Corp",
      status: "active",
      lastContact: "2023-09-15"
    },
    {
      id: "2",
      name: "Jane Doe",
      email: "jane.doe@example.com",
      company: "XYZ Inc",
      status: "active",
      lastContact: "2023-09-10"
    },
    {
      id: "3",
      name: "Michael Johnson",
      email: "michael@example.com",
      company: "Johnson LLC",
      status: "inactive",
      lastContact: "2023-08-25"
    },
    {
      id: "4",
      name: "Sarah Williams",
      email: "sarah@example.com",
      company: "Williams Group",
      status: "active",
      lastContact: "2023-09-18"
    }
  ];
  
  const emailTemplates: EmailTemplate[] = [
    {
      id: "1",
      name: "Welcome",
      subject: "Welcome to Rich Habits!",
      body: "Dear [Client Name],\n\nWelcome to Rich Habits! We're excited to have you on board. Please let us know if you have any questions.\n\nBest regards,\nThe Rich Habits Team"
    },
    {
      id: "2",
      name: "Follow-up",
      subject: "Following up on our conversation",
      body: "Dear [Client Name],\n\nI wanted to follow up on our conversation from last week. Did you have a chance to review the proposal?\n\nBest regards,\n[Your Name]"
    },
    {
      id: "3",
      name: "New Product",
      subject: "New products now available!",
      body: "Dear [Client Name],\n\nWe're excited to announce new products in our catalog! Check them out and let us know if you'd like to place an order.\n\nBest regards,\nThe Rich Habits Team"
    }
  ];
  
  const handleSelectClient = (clientId: string) => {
    setSelectedClients(prev => {
      if (prev.includes(clientId)) {
        return prev.filter(id => id !== clientId);
      } else {
        return [...prev, clientId];
      }
    });
  };
  
  const handleSelectAll = (select: boolean) => {
    if (select) {
      setSelectedClients(clients.map(client => client.id));
    } else {
      setSelectedClients([]);
    }
  };
  
  const handleApplyTemplate = (templateId: string) => {
    const template = emailTemplates.find(t => t.id === templateId);
    if (template) {
      setSubject(template.subject);
      setEmailBody(template.body);
      setSelectedTemplate(templateId);
    }
  };
  
  const handleSendEmail = () => {
    if (selectedClients.length === 0) {
      toast.error("Please select at least one client");
      return;
    }
    
    if (!subject.trim()) {
      toast.error("Please enter a subject");
      return;
    }
    
    if (!emailBody.trim()) {
      toast.error("Please enter email content");
      return;
    }
    
    setLoading(true);
    
    // Simulate sending email
    setTimeout(() => {
      const selectedClientNames = clients
        .filter(client => selectedClients.includes(client.id))
        .map(client => client.name)
        .join(", ");
      
      toast.success(`Email sent to ${selectedClientNames}`);
      setLoading(false);
      setSubject("");
      setEmailBody("");
      setSelectedClients([]);
      setSelectedTemplate("");
    }, 1500);
  };
  
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 ml-64 p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold neon-text">Client Portal</h1>
          <p className="text-muted-foreground">
            Communicate with your clients and manage client relationships
          </p>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="bg-secondary mb-4 neon-border">
            <TabsTrigger value="send-email" className="data-[state=active]:bg-white data-[state=active]:text-black">
              <Send className="h-4 w-4 mr-2" />
              Send Email
            </TabsTrigger>
            <TabsTrigger value="clients" className="data-[state=active]:bg-white data-[state=active]:text-black">
              <Users className="h-4 w-4 mr-2" />
              Client List
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="send-email" className="space-y-4">
            <Card className="neon-card">
              <CardHeader>
                <CardTitle className="neon-text">Send Email to Clients</CardTitle>
                <CardDescription>
                  Compose and send emails to one or multiple clients
                </CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="space-y-1">
                  <Label htmlFor="template">Email Template</Label>
                  <div className="flex space-x-2">
                    <select 
                      id="template"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      value={selectedTemplate}
                      onChange={(e) => handleApplyTemplate(e.target.value)}
                    >
                      <option value="">Select a template</option>
                      {emailTemplates.map(template => (
                        <option key={template.id} value={template.id}>
                          {template.name}
                        </option>
                      ))}
                    </select>
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        setSubject("");
                        setEmailBody("");
                        setSelectedTemplate("");
                      }}
                    >
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Clear
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-1">
                  <Label htmlFor="recipients">Recipients</Label>
                  <div className="border rounded-md p-4 max-h-40 overflow-y-auto">
                    <div className="flex items-center mb-2">
                      <Checkbox 
                        id="select-all" 
                        checked={selectedClients.length === clients.length} 
                        onCheckedChange={(checked) => handleSelectAll(checked === true)}
                      />
                      <label htmlFor="select-all" className="ml-2 text-sm font-medium">
                        Select All
                      </label>
                    </div>
                    <div className="space-y-2">
                      {clients.map(client => (
                        <div key={client.id} className="flex items-center">
                          <Checkbox 
                            id={`client-${client.id}`} 
                            checked={selectedClients.includes(client.id)} 
                            onCheckedChange={() => handleSelectClient(client.id)}
                          />
                          <label htmlFor={`client-${client.id}`} className="ml-2 text-sm">
                            {client.name} ({client.email}) - {client.company}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                
                <div className="space-y-1">
                  <Label htmlFor="subject">Subject</Label>
                  <Input 
                    id="subject" 
                    value={subject} 
                    onChange={(e) => setSubject(e.target.value)} 
                    placeholder="Email subject"
                  />
                </div>
                
                <div className="space-y-1">
                  <Label htmlFor="content">Email Content</Label>
                  <Textarea 
                    id="content" 
                    value={emailBody} 
                    onChange={(e) => setEmailBody(e.target.value)} 
                    placeholder="Write your email content here..." 
                    className="min-h-[200px]"
                  />
                </div>
              </CardContent>
              
              <CardFooter>
                <Button 
                  onClick={handleSendEmail} 
                  disabled={loading}
                  className="ml-auto"
                >
                  {loading ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4 mr-2" />
                      Send Email
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="clients" className="space-y-4">
            <Card className="neon-card">
              <CardHeader>
                <CardTitle className="neon-text">Client List</CardTitle>
                <CardDescription>
                  View and manage your clients
                </CardDescription>
              </CardHeader>
              
              <CardContent>
                <div className="rounded-md border">
                  <table className="w-full caption-bottom text-sm">
                    <thead className="border-b">
                      <tr className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                        <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Name</th>
                        <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Email</th>
                        <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Company</th>
                        <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Status</th>
                        <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Last Contact</th>
                        <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {clients.map(client => (
                        <tr key={client.id} className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                          <td className="p-4 align-middle">
                            <div className="flex items-center">
                              <User className="h-4 w-4 mr-2 text-gray-500" />
                              {client.name}
                            </div>
                          </td>
                          <td className="p-4 align-middle">{client.email}</td>
                          <td className="p-4 align-middle">{client.company}</td>
                          <td className="p-4 align-middle">
                            <span className={`px-2 py-1 rounded-full text-xs ${client.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                              {client.status === 'active' ? 'Active' : 'Inactive'}
                            </span>
                          </td>
                          <td className="p-4 align-middle">{client.lastContact}</td>
                          <td className="p-4 align-middle">
                            <Button 
                              variant="outline" 
                              size="sm" 
                              onClick={() => {
                                setActiveTab("send-email");
                                setSelectedClients([client.id]);
                              }}
                            >
                              <Send className="h-3 w-3 mr-1" />
                              Email
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default ClientPortal;
