
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { PlusCircle, Users } from "lucide-react";
import ClientsList from "@/components/clients/ClientsList";
import AddClientDialog from "@/components/clients/AddClientDialog";
import Sidebar from "@/components/Sidebar";
import { useClientData, NewClientData } from "@/hooks/useClientData";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import { useAuth } from "@/context/AuthContext";

const Clients = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [showAddClientDialog, setShowAddClientDialog] = useState(false);
  const { clients, isLoading, addClient } = useClientData();
  const { user } = useAuth();

  // Filter clients based on search term
  const filteredClients = clients.filter((client) =>
    client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (client.email && client.email.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleAddClient = () => {
    setShowAddClientDialog(true);
  };

  const handleSubmitClient = async (clientData: NewClientData) => {
    await addClient(clientData);
  };

  const handleViewClient = (client: any) => {
    console.log("View client:", client.id);
    // In a real implementation, this would navigate to the client details page
  };

  const handleEditClient = (client: any) => {
    console.log("Edit client:", client.id);
    // In a real implementation, this would open an edit dialog
  };

  const handleDeleteClient = (id: string) => {
    console.log("Delete client:", id);
    // In a real implementation, this would confirm deletion and delete the client
  };

  const handleContactClient = (client: any) => {
    console.log("Contact client:", client.id);
    // In a real implementation, this would open a contact dialog
  };

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold">Client Database</h1>
          <p className="text-muted-foreground">
            Manage your client relationships
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
          <div className="relative w-full sm:w-auto max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search clients..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <Button 
            onClick={handleAddClient}
            className="w-full sm:w-auto"
          >
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Client
          </Button>
        </div>
        
        {isLoading ? (
          <div className="space-y-4">
            {Array.from({ length: 5 }).map((_, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <Skeleton className="h-6 w-48 mb-2" />
                <Skeleton className="h-4 w-72 mb-1" />
                <Skeleton className="h-4 w-60" />
              </div>
            ))}
          </div>
        ) : filteredClients.length > 0 ? (
          <ClientsList 
            clients={filteredClients} 
            isLoading={isLoading}
            searchQuery={searchTerm}
            onViewClient={handleViewClient}
            onEdit={handleEditClient}
            onDelete={handleDeleteClient}
            onContactClient={handleContactClient}
            onAddClient={handleAddClient}
          />
        ) : (
          <div className="text-center py-12 border rounded-lg">
            <Users className="mx-auto h-12 w-12 text-gray-400 mb-3" />
            <h3 className="text-lg font-medium">No clients found</h3>
            <p className="text-gray-500 mt-1 mb-4">
              {searchTerm 
                ? `No results for "${searchTerm}". Try a different search term.`
                : "Get started by adding your first client."}
            </p>
            <Button onClick={handleAddClient}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Add Client
            </Button>
          </div>
        )}
        
        <AddClientDialog 
          open={showAddClientDialog}
          onOpenChange={setShowAddClientDialog}
          onSubmit={handleSubmitClient}
        />
      </div>
    </div>
  );
};

export default Clients;
