
import { useState } from "react";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Database, ListOrdered, List, Beaker } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { isSupabaseConfigured } from "@/lib/supabase";

const Data = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("leads");
  const [isLoading, setIsLoading] = useState(false);
  const [isCreatingTestData, setIsCreatingTestData] = useState(false);
  const [testDataResults, setTestDataResults] = useState<{
    success: boolean;
    messages: {
      leads?: string;
      orders?: string;
      products?: string;
      organizations?: string;
    };
  } | null>(null);

  // Check if Supabase is configured
  const isSupabaseEnabled = isSupabaseConfigured();

  const handleNavigation = (route: string) => {
    navigate(route);
  };

  const refreshData = () => {
    setIsLoading(true);
    toast.promise(
      new Promise((resolve) => {
        // Simulate refresh
        setTimeout(() => {
          resolve(true);
          setIsLoading(false);
        }, 1000);
      }),
      {
        loading: "Refreshing data...",
        success: "Data refreshed successfully",
        error: "Failed to refresh data",
      }
    );
  };

  const createTestData = async () => {
    if (!isSupabaseEnabled) {
      toast.error("Please configure Supabase integration first");
      return;
    }

    setIsCreatingTestData(true);
    setTestDataResults(null);

    try {
      toast.loading("Creating test data...", { id: "create-test-data" });
      
      // Add mock test data creation logic here
      const results = {
        success: true,
        messages: {
          leads: "5 test leads created successfully",
          orders: "3 test orders created successfully",
          products: "10 test products created successfully",
          organizations: "2 test organizations created successfully"
        }
      };
      
      setTestDataResults(results);
      toast.success("Test data created successfully", { id: "create-test-data" });
    } catch (error) {
      console.error("Error creating test data:", error);
      toast.error("Failed to create test data", { id: "create-test-data" });
    } finally {
      setIsCreatingTestData(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Data Management</h1>
            <p className="text-muted-foreground">
              View and manage your database data
            </p>
          </div>
          <div className="flex space-x-2">
            <Button
              variant="outline"
              onClick={refreshData}
              disabled={isLoading || !isSupabaseEnabled}
            >
              Refresh Data
            </Button>
            <Button
              onClick={createTestData}
              disabled={isCreatingTestData || !isSupabaseEnabled}
              variant="secondary"
            >
              <Beaker className="h-4 w-4 mr-2" />
              {isCreatingTestData ? "Creating..." : "Create Test Data"}
            </Button>
          </div>
        </div>

        {testDataResults && (
          <Alert className="mb-6 border-white/20 backdrop-blur-xl shadow-[0_8px_32px_rgba(0,0,0,0.15)]" variant={testDataResults.success ? "success" : "warning"}>
            <AlertCircle className="h-5 w-5" />
            <AlertTitle className="text-lg font-medium mb-2">Test Data Creation Results</AlertTitle>
            <AlertDescription>
              <div className="space-y-2 mt-2">
                {Object.entries(testDataResults.messages).map(([key, message]) => (
                  <div key={key} className="flex items-start">
                    <span className="font-semibold capitalize">{key}:</span>
                    <span className="ml-2">{message}</span>
                  </div>
                ))}
              </div>
            </AlertDescription>
          </Alert>
        )}

        {!isSupabaseEnabled ? (
          <Card>
            <CardHeader>
              <CardTitle>Database Integration Required</CardTitle>
              <CardDescription>
                Please configure your Supabase integration before using this feature.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => handleNavigation("/settings")}>
                Go to Settings
              </Button>
            </CardContent>
          </Card>
        ) : (
          <>
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>
                  Create new records or manage your data
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="bg-white/10 hover:bg-white/20 cursor-pointer transition-colors backdrop-blur-xl shadow-[0_8px_24px_rgba(0,0,0,0.2)]" onClick={() => handleNavigation("/leads")}>
                    <CardContent className="pt-6">
                      <div className="flex items-center">
                        <div className="p-2 bg-blue-500/10 rounded-md mr-4">
                          <List className="h-6 w-6 text-blue-500" />
                        </div>
                        <div>
                          <h3 className="font-medium">Manage Leads</h3>
                          <p className="text-sm text-muted-foreground">View and create leads</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-white/10 hover:bg-white/20 cursor-pointer transition-colors backdrop-blur-xl shadow-[0_8px_24px_rgba(0,0,0,0.2)]" onClick={() => handleNavigation("/orders")}>
                    <CardContent className="pt-6">
                      <div className="flex items-center">
                        <div className="p-2 bg-green-500/10 rounded-md mr-4">
                          <ListOrdered className="h-6 w-6 text-green-500" />
                        </div>
                        <div>
                          <h3 className="font-medium">Manage Orders</h3>
                          <p className="text-sm text-muted-foreground">View and create orders</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-white/10 hover:bg-white/20 cursor-pointer transition-colors backdrop-blur-xl shadow-[0_8px_24px_rgba(0,0,0,0.2)]" onClick={() => handleNavigation("/settings")}>
                    <CardContent className="pt-6">
                      <div className="flex items-center">
                        <div className="p-2 bg-purple-500/10 rounded-md mr-4">
                          <Database className="h-6 w-6 text-purple-500" />
                        </div>
                        <div>
                          <h3 className="font-medium">Database Settings</h3>
                          <p className="text-sm text-muted-foreground">Configure integration</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-xl bg-white/5 border-white/10 shadow-[0_12px_36px_rgba(0,0,0,0.25)]">
              <CardHeader>
                <CardTitle>Database Data</CardTitle>
                <CardDescription>
                  View and manage your database tables
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="mb-4">
                    <TabsTrigger value="leads">Leads</TabsTrigger>
                    <TabsTrigger value="orders">Orders</TabsTrigger>
                    <TabsTrigger value="products">Products</TabsTrigger>
                    <TabsTrigger value="organizations">Organizations</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="leads" className="border border-white/10 rounded-md p-4 bg-white/5 backdrop-blur-xl">
                    <div className="mb-4 flex justify-between items-center">
                      <h3 className="text-lg font-medium">Leads Table</h3>
                      <Button 
                        size="sm" 
                        onClick={() => handleNavigation("/leads")}
                      >
                        Go to Leads
                      </Button>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Manage your sales leads and track their progress through your sales pipeline.
                    </p>
                  </TabsContent>
                  
                  <TabsContent value="orders" className="border border-white/10 rounded-md p-4 bg-white/5 backdrop-blur-xl">
                    <div className="mb-4 flex justify-between items-center">
                      <h3 className="text-lg font-medium">Orders Table</h3>
                      <Button 
                        size="sm" 
                        onClick={() => handleNavigation("/orders")}
                      >
                        Go to Orders
                      </Button>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Track customer orders, invoices, and fulfillment status.
                    </p>
                  </TabsContent>
                  
                  <TabsContent value="products" className="border border-white/10 rounded-md p-4 bg-white/5 backdrop-blur-xl">
                    <div className="mb-4 flex justify-between items-center">
                      <h3 className="text-lg font-medium">Products Table</h3>
                      <Button 
                        size="sm" 
                        onClick={() => handleNavigation("/catalog")}
                      >
                        Go to Catalog
                      </Button>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Manage your product catalog, inventory, and pricing.
                    </p>
                  </TabsContent>
                  
                  <TabsContent value="organizations" className="border border-white/10 rounded-md p-4 bg-white/5 backdrop-blur-xl">
                    <div className="mb-4 flex justify-between items-center">
                      <h3 className="text-lg font-medium">Organizations Table</h3>
                      <Button 
                        size="sm" 
                        onClick={() => handleNavigation("/client-portal")}
                      >
                        Go to Clients
                      </Button>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Manage customer organizations and their contact information.
                    </p>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
};

export default Data;
