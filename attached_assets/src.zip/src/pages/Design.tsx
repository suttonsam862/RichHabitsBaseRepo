
import { useState, useEffect } from "react";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Palette, FileUp, Clock, CheckCircle, X } from "lucide-react";
import { useUserProfiles, UserProfile } from "@/hooks/useUserProfiles";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import TeamGrid from "@/components/teams/TeamGrid";
import { api, Order } from "@/lib/api";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

const Design = () => {
  const { userRole, isAdmin } = useAuth();
  const { getDesignTeam, isLoading } = useUserProfiles();
  const [searchTerm, setSearchTerm] = useState("");
  const [designTeam, setDesignTeam] = useState<UserProfile[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [ordersLoading, setOrdersLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("pending");

  useEffect(() => {
    const team = getDesignTeam();
    setDesignTeam(team);
  }, [getDesignTeam]);

  useEffect(() => {
    const fetchOrders = async () => {
      setOrdersLoading(true);
      try {
        const allOrders = await api.getOrders();
        const designOrders = allOrders.filter(order => order.status === 'design');
        setOrders(designOrders);
      } catch (error) {
        console.error("Error fetching design orders:", error);
        toast.error("Failed to load design orders");
      } finally {
        setOrdersLoading(false);
      }
    };

    fetchOrders();
  }, []);

  // Filter designers based on search term
  const filteredDesigners = designTeam.filter(
    (person) =>
      person.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      person.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Filter orders based on active tab
  const filteredOrders = orders.filter(order => {
    if (activeTab === "pending") return !order.design_status || order.design_status === "pending";
    if (activeTab === "in-progress") return order.design_status === "in-progress";
    if (activeTab === "completed") return order.design_status === "completed";
    return true;
  });

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  const handleEdit = (user: UserProfile) => {
    toast.info(`Edit functionality for ${user.name || user.email} coming soon`);
  };

  const handleContact = (user: UserProfile) => {
    toast.info(`Contact functionality for ${user.name || user.email} coming soon`);
  };

  // Only designers and admins can access this page
  if (userRole !== 'designer' && userRole !== 'admin') {
    return (
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar />
        <div className="flex-1 ml-64 p-6 flex items-center justify-center">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle>Access Restricted</CardTitle>
              <CardDescription>
                Only designers and administrators can access the design dashboard.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                If you believe you should have access to this page, please contact your administrator.
              </p>
              <Button onClick={() => window.history.back()}>Go Back</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Design Dashboard</h1>
            <p className="text-muted-foreground">
              Manage design team and track design orders
            </p>
          </div>
        </div>

        <Tabs defaultValue="pending" value={activeTab} onValueChange={handleTabChange} className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <TabsList>
              <TabsTrigger value="pending">Pending Designs</TabsTrigger>
              <TabsTrigger value="in-progress">In Progress</TabsTrigger>
              <TabsTrigger value="completed">Completed</TabsTrigger>
              <TabsTrigger value="all">All Design Orders</TabsTrigger>
            </TabsList>
          </div>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Design Orders</CardTitle>
              <CardDescription>
                {activeTab === "pending" ? "Orders waiting for design work to begin" :
                 activeTab === "in-progress" ? "Orders currently being designed" :
                 activeTab === "completed" ? "Orders with completed designs" :
                 "All orders needing design work"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {ordersLoading ? (
                <div className="w-full flex justify-center py-10">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                </div>
              ) : filteredOrders.length === 0 ? (
                <div className="text-center py-10">
                  <Palette className="mx-auto h-12 w-12 text-gray-300 mb-2" />
                  <h3 className="text-lg font-medium mb-1">No design orders found</h3>
                  <p className="text-muted-foreground">
                    {activeTab === "pending" ? "There are no pending design orders at the moment" :
                     activeTab === "in-progress" ? "No designs are currently in progress" :
                     activeTab === "completed" ? "No designs have been completed yet" :
                     "There are no design orders in the system"}
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredOrders.map((order) => (
                    <div key={order.id} className="border rounded-lg p-4 flex flex-col md:flex-row justify-between">
                      <div>
                        <div className="flex items-center mb-2">
                          <h3 className="font-medium">{order.customerName}</h3>
                          <Badge className="ml-2" variant={
                            !order.design_status || order.design_status === "pending" ? "outline" :
                            order.design_status === "in-progress" ? "secondary" :
                            "success"
                          }>
                            {!order.design_status || order.design_status === "pending" ? "Pending" :
                             order.design_status === "in-progress" ? "In Progress" :
                             "Completed"}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">Order #{order.id.substring(0, 8)} • Created on {new Date(order.date).toLocaleDateString()}</p>
                        <p className="text-sm">{order.notes || "No additional notes"}</p>
                      </div>
                      <div className="flex items-center mt-4 md:mt-0 space-x-2">
                        <Button size="sm" variant="outline" onClick={() => toast.info("View details functionality coming soon")}>
                          View Details
                        </Button>
                        {(!order.design_status || order.design_status === "pending") && (
                          <Button size="sm" variant="default" onClick={() => toast.info("Start design functionality coming soon")}>
                            <Clock className="h-4 w-4 mr-2" />
                            Start Design
                          </Button>
                        )}
                        {order.design_status === "in-progress" && (
                          <Button size="sm" variant="default" onClick={() => toast.info("Upload design functionality coming soon")}>
                            <FileUp className="h-4 w-4 mr-2" />
                            Upload Design
                          </Button>
                        )}
                        {order.design_status === "completed" && (
                          <Button size="sm" variant="outline" onClick={() => toast.info("Revise design functionality coming soon")}>
                            <Palette className="h-4 w-4 mr-2" />
                            Revise Design
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </Tabs>

        {isAdmin && (
          <Card className="mb-6">
            <CardHeader className="pb-3">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                <CardTitle>Design Team</CardTitle>
                <div className="mt-3 md:mt-0 relative w-full md:w-auto max-w-sm">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search designers..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={handleSearch}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <TeamGrid 
                team={filteredDesigners} 
                loading={isLoading}
                onEdit={handleEdit}
                onContact={handleContact}
              />
            </CardContent>
            {filteredDesigners.length > 0 && (
              <CardFooter className="border-t pt-4 pb-4">
                <p className="text-sm text-muted-foreground">
                  Showing {filteredDesigners.length} of {designTeam.length} designers
                </p>
              </CardFooter>
            )}
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Design Resources</CardTitle>
            <CardDescription>
              Access design templates and resources
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Templates</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">Access design templates for different products</p>
                  <Button variant="outline" size="sm" className="w-full" onClick={() => toast.info("Templates feature coming soon")}>
                    Browse Templates
                  </Button>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Brand Guidelines</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">Access the brand guidelines and assets</p>
                  <Button variant="outline" size="sm" className="w-full" onClick={() => toast.info("Brand guidelines feature coming soon")}>
                    View Guidelines
                  </Button>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Training Materials</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">Access training resources and tutorials</p>
                  <Button variant="outline" size="sm" className="w-full" onClick={() => toast.info("Training materials feature coming soon")}>
                    View Training
                  </Button>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Design;
