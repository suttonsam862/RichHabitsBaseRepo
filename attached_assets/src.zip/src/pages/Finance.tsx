
import { useEffect } from "react";
import SidebarWithTutorial from "@/components/SidebarWithTutorial";
import FinanceDashboard from "@/components/finance/FinanceDashboard";

const Finance = () => {
  useEffect(() => {
    // Set page title
    document.title = "Finance & QuickBooks Integration";
  }, []);

  return (
    <div className="flex min-h-screen bg-gray-50">
      <SidebarWithTutorial>
        <div className="flex-1 ml-64 p-6">
          <FinanceDashboard />
        </div>
      </SidebarWithTutorial>
    </div>
  );
};

export default Finance;
