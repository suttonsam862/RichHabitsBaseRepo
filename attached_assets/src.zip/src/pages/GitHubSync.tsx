
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { TabsContent, Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Github, FileJson, CloudUpload } from "lucide-react";
import GitHubIntegration from "@/components/GitHubIntegration";
import SupabaseSync from "@/components/SupabaseSync";

const GitHubSync = () => {
  const { isAdmin } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    // Redirect if not admin
    if (!isAdmin) {
      toast.error("Admin access required");
      navigate("/");
    }
  }, [isAdmin, navigate]);

  if (!isAdmin) {
    return null; // Component will redirect in useEffect
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Integration & Sync</h1>
            <p className="text-muted-foreground">
              Connect and sync your data with external services
            </p>
          </div>
          <Button onClick={() => window.open('https://github.com', '_blank')}>
            <Github className="mr-2 h-4 w-4" />
            View on GitHub
          </Button>
        </div>

        <Tabs defaultValue="github">
          <TabsList className="mb-4">
            <TabsTrigger value="github">
              <Github className="h-4 w-4 mr-2" />
              GitHub
            </TabsTrigger>
            <TabsTrigger value="supabase">
              <FileJson className="h-4 w-4 mr-2" />
              Supabase
            </TabsTrigger>
            <TabsTrigger value="export" disabled>
              <CloudUpload className="h-4 w-4 mr-2" />
              Export
            </TabsTrigger>
          </TabsList>

          <TabsContent value="github">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2">
                <GitHubIntegration />
              </div>
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle>About GitHub Integration</CardTitle>
                    <CardDescription>
                      How to use the GitHub sync feature
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h3 className="text-sm font-medium">What gets synced?</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        The following data will be synced to your GitHub repository:
                      </p>
                      <ul className="mt-2 space-y-2 text-sm">
                        <li className="flex items-start">
                          <span className="bg-blue-100 text-blue-800 rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">
                            1
                          </span>
                          <span>Leads - Your sales leads will be saved as JSON</span>
                        </li>
                        <li className="flex items-start">
                          <span className="bg-blue-100 text-blue-800 rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">
                            2
                          </span>
                          <span>Orders - Your customer orders will be saved as JSON</span>
                        </li>
                      </ul>
                    </div>
                    
                    <div>
                      <h3 className="text-sm font-medium">Data Storage</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        Files are stored in the '/data' directory of your selected repository.
                        This provides a convenient backup of your application data.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="supabase">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2">
                <SupabaseSync />
              </div>
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle>About Supabase Sync</CardTitle>
                    <CardDescription>
                      How to use the Supabase sync feature
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      The Supabase synchronization ensures your local data stays in sync with your Supabase database.
                      This is particularly useful when testing offline scenarios or when making bulk changes.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default GitHubSync;
