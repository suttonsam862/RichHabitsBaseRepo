
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { leadService } from '@/services/leadService';
import { LogOut } from 'lucide-react';
import AdminDashboard from '@/components/dashboards/AdminDashboard';
import SalesUserDashboard from '@/components/dashboards/SalesUserDashboard';
import DesignerUserDashboard from '@/components/dashboards/DesignerUserDashboard';
import ManufacturingUserDashboard from '@/components/dashboards/ManufacturingUserDashboard';

const Index = () => {
  const { user, isAuthenticated, isAdmin, userRole, logout } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (isAuthenticated) {
      // No redirects needed, we'll render the appropriate dashboard below
    }
  }, [isAuthenticated, user, navigate]);

  const handleLogin = () => {
    navigate('/login');
  };

  const handleLogout = () => {
    logout();
  };

  const createDemoLead = async () => {
    try {
      toast.loading('Creating demo lead...', { id: 'create-lead' });
      const lead = await leadService.createDemoLead(
        'Eric Mountain', 
        'Cane Nation Wrestling Club', 
        'coach.eric@cane-nation.org',
        '555-123-4567'
      );
      
      if (lead) {
        toast.success('Demo lead created successfully!', { id: 'create-lead' });
        toast('Log in as Laird or Colin to see and interact with the lead', {
          duration: 6000,
          action: {
            label: 'Go to Login',
            onClick: () => navigate('/login')
          }
        });
      }
    } catch (error) {
      console.error('Error creating demo lead:', error);
      toast.error('Failed to create demo lead', { id: 'create-lead' });
    }
  };

  // If user is authenticated, show the role-specific dashboard
  if (isAuthenticated) {
    if (isAdmin) {
      return <AdminDashboard />;
    } else if (userRole === 'sales') {
      return <SalesUserDashboard />;
    } else if (userRole === 'designer') {
      return <DesignerUserDashboard />;
    } else if (userRole === 'manufacturing') {
      return <ManufacturingUserDashboard />;
    }
  }

  // If not authenticated, show the landing page
  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-1 flex flex-col items-center justify-center p-6 bg-gradient-to-b from-background to-secondary/20">
        <div className="flex flex-col items-center text-center max-w-3xl">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-4">
            SportSales Pro
          </h1>
          <p className="text-xl text-muted-foreground mb-8">
            The complete sales, design, and manufacturing platform for sports apparel
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 w-full justify-center">
            {isAuthenticated ? (
              <>
                {isAdmin && (
                  <Button variant="outline" size="lg" onClick={createDemoLead}>
                    Create Demo Lead
                  </Button>
                )}
                <Button size="lg" onClick={handleLogout} variant="destructive">
                  <LogOut className="h-4 w-4 mr-2" />
                  Log Out
                </Button>
              </>
            ) : (
              <Button size="lg" onClick={handleLogin}>
                Log In
              </Button>
            )}
          </div>
        </div>
      </main>
      
      <footer className="border-t py-4 px-6 text-center text-sm text-muted-foreground">
        &copy; {new Date().getFullYear()} SportSales Pro. All rights reserved.
      </footer>
    </div>
  );
};

export default Index;
