import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { api, Lead as ApiLead } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import Sidebar from "@/components/Sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { MoreVertical, Edit, Trash2, UserPlus } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { leadService, LeadStatus } from "@/services/leadService";
import { organizationService } from "@/services/organizationService";
import { mapSupabaseLeadToApiLead } from "@/utils/dataMappers";
import { organizationService as organizationServiceAlias } from "@/services/organizationService";
import { leadToOrderService } from "@/services/leadToOrderService";

const Leads = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [leads, setLeads] = useState<ApiLead[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedLead, setSelectedLead] = useState<ApiLead | null>(null);
  const [open, setOpen] = useState(false);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isConvertingToOrder, setIsConvertingToOrder] = useState(false);
  const [isLeadClaimed, setIsLeadClaimed] = useState(false);
  const [isLeadUnclaimed, setIsLeadUnclaimed] = useState(false);
  const [isLeadConvertedToOrder, setIsLeadConvertedToOrder] = useState(false);
  const [isLeadDeleted, setIsLeadDeleted] = useState(false);
  const [isLeadStatusUpdated, setIsLeadStatusUpdated] = useState(false);
  const [isLeadCreated, setIsLeadCreated] = useState(false);
  const [isLeadUpdated, setIsLeadUpdated] = useState(false);
  const [isLeadStatusUpdatedDialogOpen, setIsLeadStatusUpdatedDialogOpen] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState<LeadStatus>("prospect");

  const form = useForm({
    defaultValues: {
      name: "",
      organization: "",
      email: "",
      phone: "",
      status: "prospect",
      notes: "",
      estimatedValue: 0,
      owner: "",
      assignedTo: "",
    },
  });

  const fetchLeads = useCallback(async () => {
    setLoading(true);
    try {
      const leadsData = await leadService.getAll();
      setLeads(leadsData);
    } catch (error) {
      console.error("Error fetching leads:", error);
      toast.error("Failed to load leads");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchLeads();
  }, [fetchLeads]);

  const handleOpenCreateDialog = () => {
    setIsCreateDialogOpen(true);
  };

  const handleCloseCreateDialog = () => {
    setIsCreateDialogOpen(false);
  };

  const handleOpenEditDialog = (lead: ApiLead) => {
    setSelectedLead(lead);
    form.reset({
      name: lead.name,
      organization: lead.organization,
      email: lead.email || "",
      phone: lead.phone || "",
      status: lead.status,
      notes: lead.notes || "",
      estimatedValue: lead.estimatedValue || 0,
      owner: lead.owner || "",
      assignedTo: lead.assignedTo || "",
    });
    setIsEditDialogOpen(true);
  };

  const handleCloseEditDialog = () => {
    setIsEditDialogOpen(false);
    setSelectedLead(null);
  };

  const handleOpenDeleteDialog = (lead: ApiLead) => {
    setSelectedLead(lead);
    setIsDeleteDialogOpen(true);
  };

  const handleCloseDeleteDialog = () => {
    setIsDeleteDialogOpen(false);
    setSelectedLead(null);
  };

  const handleOpenStatusUpdateDialog = (lead: ApiLead) => {
    setSelectedLead(lead);
    setSelectedStatus(lead.status as LeadStatus);
    setIsLeadStatusUpdatedDialogOpen(true);
  };

  const handleCloseStatusUpdateDialog = () => {
    setIsLeadStatusUpdatedDialogOpen(false);
    setSelectedLead(null);
  };

  const handleClaimLead = async (lead: ApiLead) => {
    if (!user?.email) {
      toast.error("You must be logged in to claim a lead");
      return;
    }

    try {
      setIsLeadClaimed(true);
      const updatedLead = await leadService.claimLead(lead.id, user.email);

      if (updatedLead) {
        setLeads((prevLeads) =>
          prevLeads.map((l) => (l.id === lead.id ? updatedLead : l))
        );
        toast.success("Lead claimed successfully");
      } else {
        toast.error("Failed to claim lead");
      }
    } catch (error) {
      console.error("Error claiming lead:", error);
      toast.error("Failed to claim lead");
    } finally {
      setIsLeadClaimed(false);
    }
  };

  const handleUnclaimLead = async (lead: ApiLead) => {
    try {
      setIsLeadUnclaimed(true);
      const updatedLead = await leadService.claimLead(lead.id, null);

      if (updatedLead) {
        setLeads((prevLeads) =>
          prevLeads.map((l) => (l.id === lead.id ? updatedLead : l))
        );
        toast.success("Lead unclaimed successfully");
      } else {
        toast.error("Failed to unclaim lead");
      }
    } catch (error) {
      console.error("Error unclaiming lead:", error);
      toast.error("Failed to unclaim lead");
    } finally {
      setIsLeadUnclaimed(false);
    }
  };

  const handleConvertToOrder = async (lead: ApiLead) => {
    try {
      setIsConvertingToOrder(true);
      const success = await leadToOrderService.convertLeadToOrder(lead);

      if (success) {
        setIsLeadConvertedToOrder(true);
        toast.success("Lead converted to order successfully");
      } else {
        toast.error("Failed to convert lead to order");
      }
    } catch (error) {
      console.error("Error converting lead to order:", error);
      toast.error("Failed to convert lead to order");
    } finally {
      setIsConvertingToOrder(false);
    }
  };

  const handleDeleteLead = async () => {
    if (!selectedLead) return;

    try {
      setIsDeleteDialogOpen(true);
      const success = await leadService.deleteLead(selectedLead.id);

      if (success) {
        setLeads((prevLeads) =>
          prevLeads.filter((lead) => lead.id !== selectedLead.id)
        );
        toast.success("Lead deleted successfully");
      } else {
        toast.error("Failed to delete lead");
      }
    } catch (error) {
      console.error("Error deleting lead:", error);
      toast.error("Failed to delete lead");
    } finally {
      setIsDeleteDialogOpen(false);
      handleCloseDeleteDialog();
    }
  };

  const handleUpdateStatus = async () => {
    if (!selectedLead) return;

    try {
      setIsLeadStatusUpdated(true);
      const updatedLead = await leadService.updateStatus(selectedLead.id, selectedStatus);

      if (updatedLead) {
        setLeads((prevLeads) =>
          prevLeads.map((lead) =>
            lead.id === selectedLead.id ? updatedLead : lead
          )
        );
        toast.success("Lead status updated successfully");
      } else {
        toast.error("Failed to update lead status");
      }
    } catch (error) {
      console.error("Error updating lead status:", error);
      toast.error("Failed to update lead status");
    } finally {
      setIsLeadStatusUpdated(false);
      handleCloseStatusUpdateDialog();
    }
  };

  const createLeadFromForm = async (values: any) => {
    try {
      setIsLeadCreated(true);
      const newLead = await leadService.createLead(values);

      if (newLead) {
        setLeads((prevLeads) => [...prevLeads, newLead]);
        toast.success("Lead created successfully");
      } else {
        toast.error("Failed to create lead");
      }
    } catch (error) {
      console.error("Error creating lead:", error);
      toast.error("Failed to create lead");
    } finally {
      setIsLeadCreated(false);
      handleCloseCreateDialog();
    }
  };

  const updateLeadFromForm = async (values: any) => {
    if (!selectedLead) return;

    try {
      setIsLeadUpdated(true);
      const updatedLead: Partial<ApiLead> = {
        id: selectedLead.id,
        name: values.name,
        organization: values.organization,
        email: values.email,
        phone: values.phone,
        status: values.status,
        notes: values.notes,
        estimated_value: values.estimatedValue,
        estimatedValue: values.estimatedValue,
        owner: values.owner,
        owner_id: selectedLead.owner_id,
        assigned_to: values.assignedTo,
        assigned_user_id: selectedLead.assigned_user_id,
        dateCreated: selectedLead.dateCreated,
        created_at: selectedLead.created_at,
        dateUpdated: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      const updatedLeadResult = await leadService.updateLead(updatedLead as ApiLead);

      if (updatedLeadResult) {
        setLeads((prevLeads) =>
          prevLeads.map((lead) =>
            lead.id === selectedLead.id ? updatedLeadResult : lead
          )
        );
        toast.success("Lead updated successfully");
      } else {
        toast.error("Failed to update lead");
      }
    } catch (error) {
      console.error("Error updating lead:", error);
      toast.error("Failed to update lead");
    } finally {
      setIsLeadUpdated(false);
      handleCloseEditDialog();
    }
  };

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="mb-6 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold neon-text">Leads</h1>
            <p className="text-muted-foreground">
              Manage leads and convert them into orders
            </p>
          </div>
          <Button onClick={handleOpenCreateDialog}>
            <UserPlus className="mr-2 h-4 w-4" />
            Create Lead
          </Button>
        </div>

        <Card className="neon-card">
          <CardHeader>
            <CardTitle>Leads List</CardTitle>
            <CardDescription>
              View and manage your leads. Click on a lead to view more details.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Organization</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center">
                      Loading leads...
                    </TableCell>
                  </TableRow>
                ) : leads.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center">
                      No leads found.
                    </TableCell>
                  </TableRow>
                ) : (
                  leads.map((lead) => (
                    <TableRow key={lead.id}>
                      <TableCell>{lead.name}</TableCell>
                      <TableCell>{lead.organization}</TableCell>
                      <TableCell>{lead.email}</TableCell>
                      <TableCell>{lead.phone}</TableCell>
                      <TableCell>{lead.status}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">Open menu</span>
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem
                              onClick={() => handleOpenEditDialog(lead)}
                            >
                              <Edit className="mr-2 h-4 w-4" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => handleOpenStatusUpdateDialog(lead)}
                            >
                              Update Status
                            </DropdownMenuItem>
                            {isAdmin && (
                              <DropdownMenuItem
                                onClick={() => handleOpenDeleteDialog(lead)}
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete
                              </DropdownMenuItem>
                            )}
                            {user?.email !== lead.assignedTo ? (
                              <DropdownMenuItem onClick={() => handleClaimLead(lead)}>
                                Claim Lead
                              </DropdownMenuItem>
                            ) : (
                              <DropdownMenuItem onClick={() => handleUnclaimLead(lead)}>
                                Unclaim Lead
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={() => handleConvertToOrder(lead)}
                            >
                              Convert to Order
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Create Lead Dialog */}
      <AlertDialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Create Lead</AlertDialogTitle>
            <AlertDialogDescription>
              Enter the details for the new lead.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(createLeadFromForm)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <Label htmlFor="name">Name</Label>
                    <FormControl>
                      <Input id="name" placeholder="Lead Name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="organization"
                render={({ field }) => (
                  <FormItem>
                    <Label htmlFor="organization">Organization</Label>
                    <FormControl>
                      <Input id="organization" placeholder="Organization Name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <Label htmlFor="email">Email</Label>
                    <FormControl>
                      <Input
                        id="email"
                        type="email"
                        placeholder="email@example.com"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <Label htmlFor="phone">Phone</Label>
                    <FormControl>
                      <Input id="phone" placeholder="555-555-5555" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <Label htmlFor="status">Status</Label>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="prospect">Prospect</SelectItem>
                        <SelectItem value="discovery">Discovery</SelectItem>
                        <SelectItem value="qualified">Qualified</SelectItem>
                        <SelectItem value="negotiation">Negotiation</SelectItem>
                        <SelectItem value="closed-won">Closed Won</SelectItem>
                        <SelectItem value="closed-lost">Closed Lost</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <Label htmlFor="notes">Notes</Label>
                    <FormControl>
                      <Textarea
                        id="notes"
                        placeholder="Additional notes"
                        className="resize-none"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="estimatedValue"
                render={({ field }) => (
                  <FormItem>
                    <Label htmlFor="estimatedValue">Estimated Value</Label>
                    <FormControl>
                      <Input
                        id="estimatedValue"
                        type="number"
                        placeholder="0"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <AlertDialogFooter>
                <AlertDialogCancel onClick={handleCloseCreateDialog}>
                  Cancel
                </AlertDialogCancel>
                <AlertDialogAction disabled={isLeadCreated}>
                  {isLeadCreated ? "Creating..." : "Create"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </form>
          </Form>
        </AlertDialogContent>
      </AlertDialog>

      {/* Edit Lead Dialog */}
      <AlertDialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Edit Lead</AlertDialogTitle>
            <AlertDialogDescription>
              Edit the details for the selected lead.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(updateLeadFromForm)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <Label htmlFor="name">Name</Label>
                    <FormControl>
                      <Input id="name" placeholder="Lead Name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="organization"
                render={({ field }) => (
                  <FormItem>
                    <Label htmlFor="organization">Organization</Label>
                    <FormControl>
                      <Input id="organization" placeholder="Organization Name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <Label htmlFor="email">Email</Label>
                    <FormControl>
                      <Input
                        id="email"
                        type="email"
                        placeholder="email@example.com"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <Label htmlFor="phone">Phone</Label>
                    <FormControl>
                      <Input id="phone" placeholder="555-555-5555" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <Label htmlFor="status">Status</Label>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="prospect">Prospect</SelectItem>
                        <SelectItem value="discovery">Discovery</SelectItem>
                        <SelectItem value="qualified">Qualified</SelectItem>
                        <SelectItem value="negotiation">Negotiation</SelectItem>
                        <SelectItem value="closed-won">Closed Won</SelectItem>
                        <SelectItem value="closed-lost">Closed Lost</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <Label htmlFor="notes">Notes</Label>
                    <FormControl>
                      <Textarea
                        id="notes"
                        placeholder="Additional notes"
                        className="resize-none"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="estimatedValue"
                render={({ field }) => (
                  <FormItem>
                    <Label htmlFor="estimatedValue">Estimated Value</Label>
                    <FormControl>
                      <Input
                        id="estimatedValue"
                        type="number"
                        placeholder="0"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <AlertDialogFooter>
                <AlertDialogCancel onClick={handleCloseEditDialog}>
                  Cancel
                </AlertDialogCancel>
                <AlertDialogAction disabled={isLeadUpdated}>
                  {isLeadUpdated ? "Updating..." : "Update"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </form>
          </Form>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Lead Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Lead</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this lead? This action cannot be
              undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={handleCloseDeleteDialog}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction disabled={isDeleteDialogOpen} onClick={handleDeleteLead}>
              {isLeadDeleted ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Update Lead Status Dialog */}
      <AlertDialog open={isLeadStatusUpdatedDialogOpen} onOpenChange={setIsLeadStatusUpdatedDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Update Lead Status</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to update the status for this lead?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="grid gap-2">
            <Label htmlFor="status">Status</Label>
            <Select value={selectedStatus} onValueChange={(value) => setSelectedStatus(value as LeadStatus)}>
              <SelectTrigger id="status">
                <SelectValue placeholder="Select a status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="prospect">Prospect</SelectItem>
                <SelectItem value="discovery">Discovery</SelectItem>
                <SelectItem value="qualified">Qualified</SelectItem>
                <SelectItem value="negotiation">Negotiation</SelectItem>
                <SelectItem value="closed-won">Closed Won</SelectItem>
                <SelectItem value="closed-lost">Closed Lost</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={handleCloseStatusUpdateDialog}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction disabled={isLeadStatusUpdated} onClick={handleUpdateStatus}>
              {isLeadStatusUpdated ? "Updating..." : "Update"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Leads;
