
import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { supabase } from "@/lib/supabase";
import { useUserProfileManagement } from "@/hooks/useUserProfileManagement";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const { login } = useAuth();
  const { ensureUserProfile } = useUserProfileManagement();

  // Setup special profile accounts
  useEffect(() => {
    const setupSpecialAccounts = async () => {
      // These are just placeholder IDs for the demo accounts
      const colinId = "colin-vasquez-id";
      const lairdId = "laird-rich-habits-id";
      const adminId = "admin-rich-habits-id";
      const carterId = "carter-rich-habits-id";
      
      // Ensure all special accounts have profiles with appropriate roles
      await ensureUserProfile(colinId, "colinvasquez@rich-habits.com", "sales");
      await ensureUserProfile(lairdId, "laird@rich-habits.com", "sales");
      await ensureUserProfile(adminId, "admin@rich-habits.com", "admin");
      await ensureUserProfile(carterId, "cartervail@rich-habits.com", "admin");
    };
    
    setupSpecialAccounts();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setLoginError(null);
    
    try {
      console.log("Login form submitted with:", email);
      await login(email, password);
      // Navigation is now handled in the AuthContext login function
    } catch (error: any) {
      console.error("Login error:", error);
      setLoginError(error.message || "Invalid credentials");
      toast.error(`Login failed: ${error.message || "Invalid credentials"}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50">
      <div className="max-w-md w-full px-4">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-brand-700">Rich Habits Dashboard</h1>
          <p className="text-gray-600 mt-2">Sports Apparel Sales Platform</p>
        </div>

        <Card className="shadow-lg border-gray-200">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl text-center">Login</CardTitle>
            <CardDescription className="text-center">
              Enter your credentials to access the dashboard
            </CardDescription>
          </CardHeader>
          
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              {loginError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{loginError}</AlertDescription>
                </Alert>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="email@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="focus:ring-brand-500 focus:border-brand-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="focus:ring-brand-500 focus:border-brand-500"
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button 
                type="submit" 
                className="w-full bg-brand-600 hover:bg-brand-700 transition-colors" 
                disabled={isLoading}
              >
                {isLoading ? "Logging in..." : "Login"}
              </Button>
            </CardFooter>
          </form>
        </Card>

        <div className="mt-6 text-center text-sm text-gray-500">
          <p>Login accounts:</p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-2">
            <div className="border rounded p-2 hover:bg-gray-50 transition-colors">
              <p className="font-medium">Admin - Sam</p>
              <p className="text-xs">samsutton@rich-habits.com</p>
              <p className="text-xs truncate">Arlodog2013!</p>
            </div>
            <div className="border rounded p-2 hover:bg-gray-50 transition-colors">
              <p className="font-medium">Admin - New</p>
              <p className="text-xs">admin@rich-habits.com</p>
              <p className="text-xs truncate">FridayHarbor123!</p>
            </div>
            <div className="border rounded p-2 hover:bg-gray-50 transition-colors">
              <p className="font-medium">Admin - Carter</p>
              <p className="text-xs">cartervail@rich-habits.com</p>
              <p className="text-xs truncate">Wildcat1234!</p>
            </div>
            <div className="border rounded p-2 hover:bg-gray-50 transition-colors">
              <p className="font-medium">Sales - Colin</p>
              <p className="text-xs">colinvasquez@rich-habits.com</p>
              <p className="text-xs truncate">bigchungus$!Afro</p>
            </div>
            <div className="border rounded p-2 hover:bg-gray-50 transition-colors">
              <p className="font-medium">Sales - Laird</p>
              <p className="text-xs">laird@rich-habits.com</p>
              <p className="text-xs truncate">tinyCOCK420##!</p>
            </div>
            <div className="border rounded p-2 hover:bg-gray-50 transition-colors">
              <p className="font-medium">Demo Sales</p>
              <p className="text-xs">sales@example.com</p>
              <p className="text-xs">password</p>
            </div>
            <div className="border rounded p-2 hover:bg-gray-50 transition-colors">
              <p className="font-medium">Demo Designer</p>
              <p className="text-xs">designer@example.com</p>
              <p className="text-xs">password</p>
            </div>
            <div className="border rounded p-2 hover:bg-gray-50 transition-colors">
              <p className="font-medium">Demo Manufacturing</p>
              <p className="text-xs">manufacturing@example.com</p>
              <p className="text-xs">password</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
