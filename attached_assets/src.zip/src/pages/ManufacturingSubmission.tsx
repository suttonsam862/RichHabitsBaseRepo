
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import Sidebar from "@/components/Sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { Order, ManufacturingFormData } from "@/types/manufacturing";
import ManufacturingForm from "@/components/manufacturing/ManufacturingForm";
import OrderSummaryCard from "@/components/manufacturing/OrderSummaryCard";

const ManufacturingSubmission = () => {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [order, setOrder] = useState<Order | null>(null);
  const [formData, setFormData] = useState<ManufacturingFormData>({
    trackingNumber: "",
    notes: "",
  });

  useEffect(() => {
    const fetchOrderDetails = async () => {
      setIsLoading(true);
      try {
        const { data, error } = await supabase
          .from("orders")
          .select(`
            *,
            organizations(*),
            line_items(*)
          `)
          .eq("id", orderId)
          .single();

        if (error) throw error;
        setOrder(data);
        
        if (data?.tracking_number) {
          setFormData(prev => ({
            ...prev,
            trackingNumber: data.tracking_number,
            notes: data.notes || ""
          }));
        }
      } catch (error) {
        console.error("Error fetching order details:", error);
        toast.error("Failed to load order details");
      } finally {
        setIsLoading(false);
      }
    };

    if (orderId) {
      fetchOrderDetails();
    }
  }, [orderId]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Update the order with tracking info and set to manufacturing status
      const { error } = await supabase
        .from("orders")
        .update({
          tracking_number: formData.trackingNumber,
          notes: formData.notes,
          status: 'manufacturing' // Update status to manufacturing
        })
        .eq("id", orderId);

      if (error) throw error;

      // Log this action
      console.log(`Order ${orderId} submitted to manufacturing by ${user?.email}`);
      
      toast.success("Order successfully submitted to manufacturing");
      navigate("/sales-manufacturing-management");
    } catch (error) {
      console.error("Error submitting to manufacturing:", error);
      toast.error("Failed to submit order to manufacturing");
    }
  };

  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar />
        <div className="flex-1 ml-64 p-6 flex justify-center items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar />
        <div className="flex-1 ml-64 p-6">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <AlertTriangle className="mx-auto h-12 w-12 text-amber-500 mb-4" />
                <h2 className="text-2xl font-bold mb-2">Order Not Found</h2>
                <p className="text-muted-foreground mb-4">
                  The order you&apos;re looking for could not be found.
                </p>
                <Button onClick={() => navigate("/sales-manufacturing-management")}>
                  Return to Manufacturing Management
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Submit Order to Manufacturing</h1>
            <p className="text-muted-foreground">
              Complete manufacturing submission for order #{orderId?.substring(0, 8)}
            </p>
          </div>
          <Button variant="outline" onClick={() => navigate("/sales-manufacturing-management")}>
            Back to Manufacturing
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <ManufacturingForm 
              formData={formData}
              onChange={handleChange}
              onSubmit={handleSubmit}
            />
          </div>

          <div>
            <OrderSummaryCard order={order} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManufacturingSubmission;
