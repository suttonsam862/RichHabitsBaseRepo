import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { api, Product, Organization, LineItem } from "@/lib/api";
import Sidebar from "@/components/Sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Plus, Trash, Save, ArrowLeft } from "lucide-react";
import { airtableService } from "@/services/airtableService";
import { mapClientToDatabaseLineItem } from "@/utils/apiTypeMappers";

const OrderCreate = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const leadData = location.state || {};
  
  const [isLoading, setIsLoading] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [selectedOrganization, setSelectedOrganization] = useState<string>("");
  const [orderItems, setOrderItems] = useState<Array<{
    productId: string;
    productName: string;
    quantity: number;
    unitPrice: number;
    size: string;
    color: string;
    notes: string;
  }>>([]);
  const [orderDetails, setOrderDetails] = useState({
    status: "draft" as const,
    notes: "",
    assignedTo: "",
  });

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        // Fetch products and organizations in parallel
        const [productsData, organizationsData] = await Promise.all([
          api.getProducts(),
          api.getOrganizations()
        ]);
        
        setProducts(productsData);
        setOrganizations(organizationsData);
        
        // If we have lead data, pre-select the organization
        if (leadData.customerName) {
          const matchingOrg = organizationsData.find(org => 
            org.name.toLowerCase() === leadData.customerName.toLowerCase()
          );
          
          if (matchingOrg) {
            setSelectedOrganization(matchingOrg.id);
          }
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        toast.error("Failed to load products or organizations");
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [leadData]);

  const handleAddOrderItem = () => {
    if (products.length === 0) {
      toast.error("No products available");
      return;
    }

    const defaultProduct = products[0];
    setOrderItems([
      ...orderItems,
      {
        productId: defaultProduct.id,
        productName: defaultProduct.name,
        quantity: 1,
        unitPrice: defaultProduct.price,
        size: defaultProduct.sizes[0] || "",
        color: defaultProduct.colors[0] || "",
        notes: ""
      }
    ]);
  };

  const handleRemoveOrderItem = (index: number) => {
    setOrderItems(orderItems.filter((_, i) => i !== index));
  };

  const handleOrderItemChange = (index: number, field: string, value: any) => {
    const newOrderItems = [...orderItems];
    newOrderItems[index] = { ...newOrderItems[index], [field]: value };

    // If product changes, update related fields
    if (field === "productId") {
      const selectedProduct = products.find(p => p.id === value);
      if (selectedProduct) {
        newOrderItems[index].productName = selectedProduct.name;
        newOrderItems[index].unitPrice = selectedProduct.price;
        newOrderItems[index].size = selectedProduct.sizes[0] || "";
        newOrderItems[index].color = selectedProduct.colors[0] || "";
      }
    }

    setOrderItems(newOrderItems);
  };

  const calculateTotal = () => {
    return orderItems.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedOrganization) {
      toast.error("Please select a customer");
      return;
    }

    if (orderItems.length === 0) {
      toast.error("Please add at least one product to the order");
      return;
    }

    setIsLoading(true);
    
    try {
      const selectedOrg = organizations.find(org => org.id === selectedOrganization);
      
      // Convert order items to line items with the correct database field format
      const lineItems = orderItems.map(item => {
        return {
          id: `li-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          product_id: item.productId,
          order_id: '', // This will be set by the backend
          quantity: item.quantity,
          unit_price: item.unitPrice,
          size: item.size,
          color: item.color,
          notes: item.notes
        } as LineItem;
      });

      // Create the order
      const newOrder = await api.createOrder({
        customer_id: selectedOrganization,
        customerName: selectedOrg?.name || "",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        status: orderDetails.status,
        total: calculateTotal(),
        items: lineItems,
        assigned_to: orderDetails.assignedTo,
        notes: orderDetails.notes,
      });

      // If we came from a lead, update the lead status
      if (leadData.leadId) {
        await api.updateLead(leadData.leadId, { status: "closed-won" });
      }
      
      // Sync with Airtable if configured
      if (airtableService.isInitialized()) {
        try {
          await airtableService.syncOrders([newOrder]);
          toast.success("Order synced to Airtable");
        } catch (error) {
          console.error("Error syncing to Airtable:", error);
          toast.error("Order created but failed to sync to Airtable");
        }
      }

      toast.success("Order created successfully");
      navigate(`/orders/${newOrder.id}`);
    } catch (error) {
      console.error("Error creating order:", error);
      toast.error("Failed to create order");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <Button 
              variant="ghost" 
              onClick={() => navigate("/orders")} 
              className="mb-2"
            >
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Orders
            </Button>
            <h1 className="text-2xl font-bold">Create New Order</h1>
            <p className="text-muted-foreground">
              {leadData.fromLead 
                ? `Creating order for ${leadData.customerName || 'lead'}`
                : "Create a new order for your customer"}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Customer Information */}
            <Card className="lg:col-span-1 backdrop-blur-xl bg-white/5 border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.15)]">
              <CardHeader>
                <CardTitle>Customer Information</CardTitle>
                <CardDescription>
                  {leadData.fromLead 
                    ? "Customer information from lead" 
                    : "Select the customer for this order"}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="organization">Customer</Label>
                  <Select 
                    value={selectedOrganization} 
                    onValueChange={setSelectedOrganization}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select customer" />
                    </SelectTrigger>
                    <SelectContent>
                      {organizations.map(org => (
                        <SelectItem key={org.id} value={org.id}>
                          {org.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedOrganization && (
                  <div className="mt-4 pt-4 border-t space-y-2">
                    <Label>Order Details</Label>
                    
                    <div className="space-y-2">
                      <Label htmlFor="status">Status</Label>
                      <Select 
                        value={orderDetails.status} 
                        onValueChange={(value: any) => setOrderDetails({...orderDetails, status: value})}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="draft">Draft</SelectItem>
                          <SelectItem value="submitted">Submitted</SelectItem>
                          <SelectItem value="design">Design</SelectItem>
                          <SelectItem value="manufacturing">Manufacturing</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="assignedTo">Assigned To</Label>
                      <Input 
                        id="assignedTo" 
                        value={orderDetails.assignedTo}
                        onChange={(e) => setOrderDetails({...orderDetails, assignedTo: e.target.value})}
                        placeholder="Sales rep name"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="notes">Order Notes</Label>
                      <Textarea 
                        id="notes" 
                        value={orderDetails.notes}
                        onChange={(e) => setOrderDetails({...orderDetails, notes: e.target.value})}
                        placeholder="Add any notes about this order"
                        rows={3}
                      />
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Right Column - Order Items */}
            <Card className="lg:col-span-2 backdrop-blur-xl bg-white/5 border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.15)]">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Order Items</CardTitle>
                  <CardDescription>
                    Add products to this order
                  </CardDescription>
                </div>
                <Button type="button" onClick={handleAddOrderItem}>
                  <Plus className="h-4 w-4 mr-2" /> Add Item
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                {orderItems.length === 0 ? (
                  <div className="flex justify-center items-center p-8 border border-dashed rounded-lg backdrop-blur-xl bg-white/5 border-white/10">
                    <p className="text-muted-foreground">
                      No items added. Click "Add Item" to start building your order.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {orderItems.map((item, index) => (
                      <div key={index} className="p-4 border rounded-lg relative backdrop-blur-xl bg-white/5 border-white/10 shadow-[0_8px_24px_rgba(0,0,0,0.2)]">
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="absolute top-2 right-2"
                          onClick={() => handleRemoveOrderItem(index)}
                        >
                          <Trash className="h-4 w-4 text-red-500" />
                        </Button>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label>Product</Label>
                            <Select 
                              value={item.productId} 
                              onValueChange={(value) => handleOrderItemChange(index, 'productId', value)}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Select product" />
                              </SelectTrigger>
                              <SelectContent>
                                {products.map(product => (
                                  <SelectItem key={product.id} value={product.id}>
                                    {product.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          
                          <div className="space-y-2">
                            <Label>Quantity</Label>
                            <Input 
                              type="number" 
                              min="1" 
                              value={item.quantity}
                              onChange={(e) => handleOrderItemChange(index, 'quantity', parseInt(e.target.value) || 1)}
                            />
                          </div>
                          
                          <div className="space-y-2">
                            <Label>Size</Label>
                            <Select 
                              value={item.size} 
                              onValueChange={(value) => handleOrderItemChange(index, 'size', value)}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Select size" />
                              </SelectTrigger>
                              <SelectContent>
                                {products.find(p => p.id === item.productId)?.sizes.map(size => (
                                  <SelectItem key={size} value={size}>
                                    {size}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          
                          <div className="space-y-2">
                            <Label>Color</Label>
                            <Select 
                              value={item.color} 
                              onValueChange={(value) => handleOrderItemChange(index, 'color', value)}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Select color" />
                              </SelectTrigger>
                              <SelectContent>
                                {products.find(p => p.id === item.productId)?.colors.map(color => (
                                  <SelectItem key={color} value={color}>
                                    {color}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          
                          <div className="space-y-2">
                            <Label>Unit Price</Label>
                            <Input 
                              type="number" 
                              min="0" 
                              step="0.01" 
                              value={item.unitPrice}
                              onChange={(e) => handleOrderItemChange(index, 'unitPrice', parseFloat(e.target.value) || 0)}
                            />
                          </div>
                          
                          <div className="space-y-2">
                            <Label>Item Total</Label>
                            <Input 
                              value={`$${(item.quantity * item.unitPrice).toFixed(2)}`}
                              readOnly
                              className="bg-gray-50"
                            />
                          </div>
                          
                          <div className="md:col-span-2 space-y-2">
                            <Label>Item Notes</Label>
                            <Textarea 
                              rows={2} 
                              value={item.notes}
                              onChange={(e) => handleOrderItemChange(index, 'notes', e.target.value)}
                              placeholder="Add any notes about this item"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {orderItems.length > 0 && (
                  <div className="mt-6 pt-4 border-t">
                    <div className="flex justify-between text-xl font-bold">
                      <span>Total:</span>
                      <span>${calculateTotal().toFixed(2)}</span>
                    </div>
                  </div>
                )}
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button 
                  type="button"
                  variant="outline"
                  onClick={() => navigate("/orders")}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={isLoading || orderItems.length === 0 || !selectedOrganization}
                >
                  <Save className="h-4 w-4 mr-2" />
                  {isLoading ? "Creating..." : "Create Order"}
                </Button>
              </CardFooter>
            </Card>
          </div>
        </form>
      </div>
    </div>
  );
};

export default OrderCreate;
