
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Sidebar from "@/components/Sidebar";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import OrderEditForm from "@/components/orders/edit/OrderEditForm";
import OrderEditLoadingState from "@/components/orders/edit/LoadingState";

const OrderEdit = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [products, setProducts] = useState<any[]>([]);
  const [organizations, setOrganizations] = useState<any[]>([]);
  const [order, setOrder] = useState<any | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        // Fetch order data
        const { data: orderData, error: orderError } = await supabase
          .from('orders')
          .select('*')
          .eq('id', id)
          .single();
          
        if (orderError) throw orderError;
        
        // Fetch products
        const { data: productsData, error: productsError } = await supabase
          .from('products')
          .select('*');
          
        if (productsError) throw productsError;
        
        // Fetch organizations
        const { data: orgsData, error: orgsError } = await supabase
          .from('organizations')
          .select('*');
          
        if (orgsError) throw orgsError;
        
        // Fetch line items for this order
        const { data: lineItemsData, error: lineItemsError } = await supabase
          .from('line_items')
          .select('*, products(*)')
          .eq('order_id', id);
          
        if (lineItemsError) throw lineItemsError;
        
        // Enhance order with line items
        const enhancedOrder = {
          ...orderData,
          lineItems: lineItemsData.map(item => ({
            id: item.id,
            productId: item.product_id,
            productName: item.products?.name || "Unknown Product",
            quantity: item.quantity,
            unitPrice: item.unit_price,
            price: item.unit_price,
            size: item.size || "",
            color: item.color || "",
            notes: item.notes || ""
          }))
        };
        
        setOrder(enhancedOrder);
        setProducts(productsData);
        setOrganizations(orgsData);
      } catch (error) {
        console.error("Error fetching data:", error);
        toast.error("Failed to load order data");
      } finally {
        setIsLoading(false);
      }
    };

    if (id) {
      fetchData();
    } else {
      navigate("/orders");
    }
  }, [id, navigate]);

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <Button 
              variant="ghost" 
              onClick={() => navigate("/orders")} 
              className="mb-2"
            >
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Orders
            </Button>
            <h1 className="text-2xl font-bold">Edit Order {order?.id ? `#${order.id.substring(0, 8)}` : ""}</h1>
            <p className="text-muted-foreground">
              Update the details of this order
            </p>
          </div>
        </div>

        {isLoading ? (
          <OrderEditLoadingState />
        ) : (
          <OrderEditForm 
            id={id!}
            order={order}
            products={products}
            organizations={organizations}
            isLoading={isLoading}
          />
        )}
      </div>
    </div>
  );
};

export default OrderEdit;
