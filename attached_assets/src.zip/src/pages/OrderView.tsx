import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Sidebar from "@/components/Sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { 
  ArrowLeft, 
  Edit, 
  Trash, 
  FileText, 
  Truck, 
  ClipboardCheck, 
  PackageCheck, 
  ShoppingBag, 
  Clock 
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import InvoiceGenerator from "@/components/InvoiceGenerator";
import { orderService } from "@/services";
import { Order } from "@/lib/api";
import { mapServiceOrderToApiOrder } from "@/utils/serviceTypeMappers";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

const OrderView = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [isDeleting, setIsDeleting] = useState(false);
  const [order, setOrder] = useState<Order | null>(null);
  const [invoiceDialogOpen, setInvoiceDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  useEffect(() => {
    const fetchOrder = async () => {
      setIsLoading(true);
      try {
        if (!id) {
          toast.error("Order ID is required");
          navigate("/orders");
          return;
        }
        
        const orderData = await orderService.getById(id);
        if (orderData) {
          // Convert from service order to API order
          const apiOrder = mapServiceOrderToApiOrder(orderData);
          setOrder(apiOrder);
        } else {
          toast.error("Order not found");
          navigate("/orders");
        }
      } catch (error) {
        console.error("Error fetching order:", error);
        toast.error("Failed to load order details");
        navigate("/orders");
      } finally {
        setIsLoading(false);
      }
    };

    if (id) {
      fetchOrder();
    }
  }, [id, navigate]);

  const handleEditOrder = () => {
    navigate(`/orders/${id}/edit`);
  };

  const handleDeleteOrder = async () => {
    setIsDeleting(true);
    try {
      if (!id) {
        toast.error("Order ID is required");
        return;
      }
      
      const success = await orderService.delete(id);
      if (success) {
        toast.success("Order deleted successfully");
        navigate("/orders");
      }
    } catch (error) {
      console.error("Error deleting order:", error);
      toast.error("Failed to delete order");
    } finally {
      setIsDeleting(false);
      setDeleteDialogOpen(false);
    }
  };

  const handleGenerateInvoice = () => {
    setInvoiceDialogOpen(true);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "draft":
        return <Clock className="h-4 w-4 mr-2" />;
      case "submitted":
        return <ShoppingBag className="h-4 w-4 mr-2" />;
      case "design":
        return <FileText className="h-4 w-4 mr-2" />;
      case "manufacturing":
        return <PackageCheck className="h-4 w-4 mr-2" />;
      case "completed":
        return <ClipboardCheck className="h-4 w-4 mr-2" />;
      case "shipped":
        return <Truck className="h-4 w-4 mr-2" />;
      default:
        return <Clock className="h-4 w-4 mr-2" />;
    }
  };

  const getStatusColor = (status: string): string => {
    switch (status) {
      case "draft":
        return "bg-gray-200 text-gray-800";
      case "submitted":
        return "bg-blue-100 text-blue-800";
      case "design":
        return "bg-purple-100 text-purple-800";
      case "manufacturing":
        return "bg-amber-100 text-amber-800";
      case "completed":
        return "bg-green-100 text-green-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar />
        <div className="flex-1 ml-64 p-6">
          <div className="flex justify-between items-center mb-6">
            <div>
              <Button 
                variant="ghost" 
                onClick={() => navigate("/orders")} 
                className="mb-2"
              >
                <ArrowLeft className="mr-2 h-4 w-4" /> Back to Orders
              </Button>
              <Skeleton className="h-8 w-48" />
              <Skeleton className="h-4 w-64 mt-2" />
            </div>
            <div className="flex space-x-2">
              <Skeleton className="h-10 w-24" />
              <Skeleton className="h-10 w-24" />
              <Skeleton className="h-10 w-24" />
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-1">
              <CardHeader>
                <Skeleton className="h-6 w-40" />
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <Skeleton className="h-6 w-40" />
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar />
        <div className="flex-1 ml-64 p-6">
          <div className="flex justify-between items-center mb-6">
            <Button 
              variant="ghost" 
              onClick={() => navigate("/orders")} 
              className="mb-2"
            >
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Orders
            </Button>
          </div>
          <Card>
            <CardContent className="flex flex-col items-center justify-center p-12">
              <h2 className="text-2xl font-bold text-center">Order Not Found</h2>
              <p className="text-muted-foreground text-center mt-2">
                The order you're looking for doesn't exist or has been deleted.
              </p>
              <Button 
                onClick={() => navigate("/orders")} 
                className="mt-6"
              >
                Return to Orders
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
          <div>
            <Button 
              variant="ghost" 
              onClick={() => navigate("/orders")} 
              className="mb-2"
            >
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Orders
            </Button>
            <h1 className="text-2xl font-bold">Order #{order?.id}</h1>
            <p className="text-muted-foreground">
              Created on {new Date(order?.created_at || Date.now()).toLocaleDateString()}
            </p>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" onClick={handleEditOrder}>
              <Edit className="h-4 w-4 mr-2" />
              Edit
            </Button>
            <Button variant="outline" onClick={handleGenerateInvoice}>
              <FileText className="h-4 w-4 mr-2" />
              Invoice
            </Button>
            <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
              <AlertDialogTrigger asChild>
                <Button variant="destructive">
                  <Trash className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete the order and all associated data.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction 
                    onClick={handleDeleteOrder}
                    disabled={isDeleting}
                    className="bg-red-600 hover:bg-red-700"
                  >
                    {isDeleting ? "Deleting..." : "Delete"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Order Info Card */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Order Information</CardTitle>
            </CardHeader>
            <CardContent>
              <dl className="space-y-4">
                <div>
                  <dt className="text-sm font-medium text-muted-foreground">Status</dt>
                  <dd className="mt-1">
                    <Badge className={getStatusColor(order?.status || '')} variant="outline">
                      <div className="flex items-center">
                        {getStatusIcon(order?.status || '')}
                        {order?.status?.charAt(0).toUpperCase() + order?.status?.slice(1)}
                      </div>
                    </Badge>
                  </dd>
                </div>
                
                <div>
                  <dt className="text-sm font-medium text-muted-foreground">Customer</dt>
                  <dd className="mt-1 font-medium">{order?.customer_id || 'Unknown Customer'}</dd>
                </div>
                
                <div>
                  <dt className="text-sm font-medium text-muted-foreground">Total</dt>
                  <dd className="mt-1 font-medium text-lg">${order?.total?.toFixed(2) || '0.00'}</dd>
                </div>
                
                {order?.assigned_to && (
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Assigned To</dt>
                    <dd className="mt-1">{order.assigned_to}</dd>
                  </div>
                )}
                
                <div>
                  <dt className="text-sm font-medium text-muted-foreground">Last Updated</dt>
                  <dd className="mt-1">{new Date(order?.updated_at || Date.now()).toLocaleDateString()}</dd>
                </div>
                
                {order?.notes && (
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Notes</dt>
                    <dd className="mt-1 break-words">{order.notes}</dd>
                  </div>
                )}
              </dl>
            </CardContent>
          </Card>

          {/* Order Items Card */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Order Items</CardTitle>
              <CardDescription>
                Items in this order
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product</TableHead>
                      <TableHead>Size/Color</TableHead>
                      <TableHead className="text-right">Qty</TableHead>
                      <TableHead className="text-right">Price</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-4 text-muted-foreground">
                        No items in this order
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell colSpan={4} className="text-right font-bold">
                        Total
                      </TableCell>
                      <TableCell className="text-right font-bold">
                        ${order?.total?.toFixed(2) || '0.00'}
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Invoice Dialog */}
      {order && (
        <InvoiceGenerator 
          order={order}
          isOpen={invoiceDialogOpen}
          onClose={() => setInvoiceDialogOpen(false)}
        />
      )}
    </div>
  );
};

export default OrderView;
