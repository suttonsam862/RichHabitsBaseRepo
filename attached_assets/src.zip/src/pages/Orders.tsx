
import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import OrderTable from "@/components/OrderTable";
import Sidebar from "@/components/Sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Search, Plus, RefreshCw } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { orderService } from "@/services/orderService";
import { Order } from "@/lib/api";
import { mapServiceOrdersToApiOrders } from "@/utils/serviceTypeMappers";

const Orders = () => {
  const navigate = useNavigate();
  const { userRole } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [filteredOrders, setFilteredOrders] = useState<Order[]>([]);
  const [activeTab, setActiveTab] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchOrders = useCallback(async () => {
    setIsLoading(true);
    try {
      const serviceOrders = await orderService.getAll();
      const apiOrders = mapServiceOrdersToApiOrders(serviceOrders);
      console.log("Orders fetched:", apiOrders.length);
      setOrders(apiOrders);
      setFilteredOrders(apiOrders);
    } catch (error) {
      console.error("Error fetching orders:", error);
      toast.error("Failed to load orders");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchOrders();
  }, [fetchOrders]);

  useEffect(() => {
    // Apply filters based on active tab and search query
    let filtered = [...orders];
    
    // Filter by status
    if (activeTab !== "all") {
      filtered = filtered.filter(order => order.status === activeTab);
    }
    
    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        order => 
          (order.id && order.id.toLowerCase().includes(query)) || 
          (order.assigned_to && order.assigned_to.toLowerCase().includes(query))
      );
    }
    
    setFilteredOrders(filtered);
  }, [activeTab, searchQuery, orders]);

  const handleCreateOrder = () => {
    navigate("/orders/new");
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchOrders();
    setRefreshing(false);
    toast.success("Orders refreshed");
  };

  const handleOrderClick = (orderId: string) => {
    navigate(`/orders/${orderId}`);
  };

  // Get order status description for tooltips
  const getOrderStatusDescription = (status: string): string => {
    switch (status) {
      case "draft":
        return "Orders that are being prepared and not yet submitted";
      case "submitted":
        return "Orders that have been submitted but not yet in design";
      case "design":
        return "Orders currently in the design phase";
      case "manufacturing":
        return "Orders currently in the manufacturing phase";
      case "completed":
        return "Orders that have been completed and delivered";
      default:
        return "All orders regardless of status";
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Orders</h1>
            <p className="text-muted-foreground">
              Manage and track all customer orders
            </p>
          </div>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="icon" 
              onClick={handleRefresh} 
              disabled={refreshing}
            >
              <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
            </Button>
            <Button onClick={handleCreateOrder}>
              <Plus className="h-4 w-4 mr-2" />
              Create Order
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader className="pb-3">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
              <div>
                <CardTitle>Order Management</CardTitle>
                <CardDescription>
                  View and manage all orders in the system
                </CardDescription>
              </div>
              <div className="mt-3 md:mt-0 relative w-full md:w-auto max-w-sm">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search orders..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={handleSearch}
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all" value={activeTab} onValueChange={handleTabChange}>
              <TooltipProvider>
                <TabsList className="mb-4">
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <TabsTrigger value="all">All Orders</TabsTrigger>
                    </TooltipTrigger>
                    <TooltipContent side="bottom">
                      <p>{getOrderStatusDescription("all")}</p>
                    </TooltipContent>
                  </Tooltip>
                  
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <TabsTrigger value="draft">Draft</TabsTrigger>
                    </TooltipTrigger>
                    <TooltipContent side="bottom">
                      <p>{getOrderStatusDescription("draft")}</p>
                    </TooltipContent>
                  </Tooltip>
                  
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <TabsTrigger value="submitted">Submitted</TabsTrigger>
                    </TooltipTrigger>
                    <TooltipContent side="bottom">
                      <p>{getOrderStatusDescription("submitted")}</p>
                    </TooltipContent>
                  </Tooltip>
                  
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <TabsTrigger value="design">Design</TabsTrigger>
                    </TooltipTrigger>
                    <TooltipContent side="bottom">
                      <p>{getOrderStatusDescription("design")}</p>
                    </TooltipContent>
                  </Tooltip>
                  
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <TabsTrigger value="manufacturing">Manufacturing</TabsTrigger>
                    </TooltipTrigger>
                    <TooltipContent side="bottom">
                      <p>{getOrderStatusDescription("manufacturing")}</p>
                    </TooltipContent>
                  </Tooltip>
                  
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <TabsTrigger value="completed">Completed</TabsTrigger>
                    </TooltipTrigger>
                    <TooltipContent side="bottom">
                      <p>{getOrderStatusDescription("completed")}</p>
                    </TooltipContent>
                  </Tooltip>
                </TabsList>
              </TooltipProvider>
              
              <TabsContent value={activeTab}>
                <OrderTable 
                  orders={filteredOrders} 
                  isLoading={isLoading} 
                  onRefresh={handleRefresh}
                  onOrderClick={handleOrderClick}
                />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Orders;
