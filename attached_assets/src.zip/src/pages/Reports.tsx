
import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from "recharts";
import { Calendar, CalendarCheck, FileBarChart } from "lucide-react";

import { api } from "@/lib/api";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  ChartContainer, 
  ChartTooltip, 
  ChartTooltipContent 
} from "@/components/ui/chart";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatCurrency } from "@/lib/utils";

// Custom types for reports
type TimeFrame = "week" | "month" | "quarter" | "year";
type ChartType = "bar" | "line" | "pie";

const Reports = () => {
  const [timeFrame, setTimeFrame] = useState<TimeFrame>("month");
  const currentDate = new Date();
  const currentMonth = currentDate.toLocaleString('default', { month: 'long' });
  const currentYear = currentDate.getFullYear();
  
  // Fetch dashboard stats from API
  const { data: statsData, isLoading } = useQuery({
    queryKey: ["dashboardStats", timeFrame],
    queryFn: api.getDashboardStats,
  });

  // Generate report data based on timeframe
  const getSalesData = () => {
    if (timeFrame === "week") {
      return [
        { name: "Mon", sales: 2400 },
        { name: "Tue", sales: 1600 },
        { name: "Wed", sales: 3200 },
        { name: "Thu", sales: 2800 },
        { name: "Fri", sales: 3600 },
        { name: "Sat", sales: 1400 },
        { name: "Sun", sales: 800 },
      ];
    } else if (timeFrame === "month" && statsData?.salesPerformance) {
      // Make sure salesPerformance exists and has the expected properties
      if (statsData.salesPerformance.labels && statsData.salesPerformance.data) {
        return statsData.salesPerformance.labels.map((label, index) => ({
          name: label,
          sales: statsData.salesPerformance.data[index] || 0,
        }));
      } else {
        // Fallback data if salesPerformance exists but is missing properties
        return [
          { name: "Week 1", sales: 5200 },
          { name: "Week 2", sales: 4800 },
          { name: "Week 3", sales: 6300 },
          { name: "Week 4", sales: 5600 },
        ];
      }
    } else if (timeFrame === "quarter") {
      const currentQuarter = Math.floor((new Date().getMonth() / 3)) + 1;
      const months = [];
      
      for (let i = 0; i < 3; i++) {
        const month = new Date(currentYear, (currentQuarter - 1) * 3 + i, 1);
        months.push({
          name: month.toLocaleString('default', { month: 'short' }),
          sales: 7000 + Math.floor(Math.random() * 5000)
        });
      }
      
      return months;
    } else {
      return [
        { name: `Q1 ${currentYear}`, sales: 25500 },
        { name: `Q2 ${currentYear}`, sales: 30600 },
        { name: `Q3 ${currentYear}`, sales: 28400 },
        { name: `Q4 ${currentYear}`, sales: currentDate.getMonth() >= 9 ? 32200 : null },
      ].filter(q => q.sales !== null);
    }
  };

  // Color schemes for charts
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

  // Product category sales data
  const categoryData = [
    { name: 'Jerseys', value: 35 },
    { name: 'Shorts', value: 25 },
    { name: 'Outerwear', value: 15 },
    { name: 'Base Layers', value: 10 },
    { name: 'Accessories', value: 15 },
  ];

  // Sport type sales data
  const sportData = [
    { name: 'Soccer', value: 40 },
    { name: 'Basketball', value: 30 },
    { name: 'Track', value: 10 },
    { name: 'Football', value: 15 },
    { name: 'Baseball', value: 5 },
  ];

  // Monthly recurring revenue data
  const mrrData = [
    { name: 'Jan', mrr: 12000 },
    { name: 'Feb', mrr: 13500 },
    { name: 'Mar', mrr: 14200 },
    { name: 'Apr', mrr: 15800 },
    { name: 'May', mrr: 16300 },
    { name: 'Jun', mrr: 18000 },
  ];

  if (isLoading) {
    return (
      <div className="flex min-h-screen">
        <Sidebar />
        <div className="flex-1 p-8 pt-6 ml-64">
          <div className="flex items-center justify-center h-full">
            <p className="text-lg">Loading reports data...</p>
          </div>
        </div>
      </div>
    );
  }

  // Handle the case where statsData might be undefined
  const topProducts = statsData?.topProducts || [
    { name: "Custom Soccer Jersey", sales: 12500 },
    { name: "Basketball Uniform Set", sales: 9800 },
    { name: "Track Team Jacket", sales: 7600 },
    { name: "Football Practice Jersey", sales: 6900 },
    { name: "Custom Team Socks", sales: 5200 }
  ];

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 p-8 pt-6 ml-64">
        <div className="flex flex-col space-y-8">
          <div className="flex items-center justify-between">
            <h2 className="text-3xl font-bold tracking-tight">Reports & Analytics</h2>
            <div className="flex items-center gap-4">
              <Select value={timeFrame} onValueChange={(value: TimeFrame) => setTimeFrame(value)}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select timeframe" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectLabel>Timeframe</SelectLabel>
                    <SelectItem value="week">This Week</SelectItem>
                    <SelectItem value="month">This Month ({currentMonth})</SelectItem>
                    <SelectItem value="quarter">This Quarter (Q{Math.floor(currentDate.getMonth() / 3) + 1})</SelectItem>
                    <SelectItem value="year">This Year ({currentYear})</SelectItem>
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Sales Overview */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Sales Performance</CardTitle>
                <CardDescription>
                  {timeFrame === "week" ? "Week of " + new Date().toLocaleDateString() : 
                   timeFrame === "month" ? `${currentMonth} ${currentYear}` : 
                   timeFrame === "quarter" ? `Q${Math.floor(currentDate.getMonth() / 3) + 1} ${currentYear}` : 
                   `Year ${currentYear}`}
                </CardDescription>
              </div>
              <FileBarChart className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={getSalesData()}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis tickFormatter={(value) => formatCurrency(value)} />
                    <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="sales"
                      stroke="#0284c7"
                      activeDot={{ r: 8 }}
                      strokeWidth={2}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Product Category Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Product Category Distribution</CardTitle>
                <CardDescription>Sales by product category</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={categoryData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {categoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => `${value}%`} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Sport Type Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Sport Type Distribution</CardTitle>
                <CardDescription>Sales by sport type</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={sportData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {sportData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => `${value}%`} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Top Products */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Top Products</CardTitle>
                <CardDescription>Best performing products by sales volume</CardDescription>
              </div>
              <Calendar className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={topProducts}
                    layout="vertical"
                    margin={{ top: 20, right: 30, left: 80, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" tickFormatter={(value) => formatCurrency(value)} />
                    <YAxis dataKey="name" type="category" />
                    <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                    <Legend />
                    <Bar dataKey="sales" fill="#0ea5e9" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Monthly Recurring Revenue */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Monthly Recurring Revenue</CardTitle>
                <CardDescription>
                  Revenue trends over the last 6 months
                </CardDescription>
              </div>
              <CalendarCheck className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={mrrData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis tickFormatter={(value) => formatCurrency(value)} />
                    <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                    <Legend />
                    <Bar dataKey="mrr" fill="#0284c7" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Reports;
