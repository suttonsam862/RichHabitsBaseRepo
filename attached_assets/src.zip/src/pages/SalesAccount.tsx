
import { useState, useEffect } from "react";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/context/AuthContext";
import { leadService } from "@/services/leadService";
import { orderService } from "@/services/orderService";
import { Users, Package, Wallet, TrendingUp, PhoneCall } from "lucide-react";
import { Link } from "react-router-dom";

const SalesAccount = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    totalLeads: 0,
    totalOrders: 0,
    orderValue: 0,
    pendingDesigns: 0,
    pendingManufacturing: 0
  });

  useEffect(() => {
    const fetchSalesStats = async () => {
      if (!user?.email) return;
      
      try {
        // Fetch leads assigned to this sales person
        const leads = await leadService.getAll();
        const myLeads = leads.filter(lead => lead.owner === user.email);
        
        // Fetch orders assigned to this sales person
        const orders = await orderService.getAll();
        const myOrders = orders.filter(order => order.assigned_to === user.email);
        
        // Calculate order value
        const orderValue = myOrders.reduce((sum, order) => sum + (order.total || 0), 0);
        
        // Count orders by status
        const pendingDesigns = myOrders.filter(order => order.status === 'design').length;
        const pendingManufacturing = myOrders.filter(order => order.status === 'manufacturing').length;
        
        setStats({
          totalLeads: myLeads.length,
          totalOrders: myOrders.length,
          orderValue,
          pendingDesigns,
          pendingManufacturing
        });
      } catch (error) {
        console.error("Error fetching sales stats:", error);
      }
    };
    
    fetchSalesStats();
  }, [user]);

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Sales Account</h1>
            <p className="text-muted-foreground">
              Welcome, {user?.email}
            </p>
          </div>
          <div className="flex space-x-2 mt-4 md:mt-0">
            <Button asChild>
              <Link to="/leads">
                <Users className="h-4 w-4 mr-2" />
                Manage Leads
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link to="/sales-orders">
                <Package className="h-4 w-4 mr-2" />
                View Orders
              </Link>
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="py-3">
              <CardTitle className="text-sm font-medium text-gray-500">Total Leads</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Users className="h-8 w-8 text-blue-500 mr-3" />
                <div>
                  <p className="text-2xl font-bold">{stats.totalLeads}</p>
                  <p className="text-xs text-muted-foreground">Assigned leads</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="py-3">
              <CardTitle className="text-sm font-medium text-gray-500">Total Orders</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Package className="h-8 w-8 text-green-500 mr-3" />
                <div>
                  <p className="text-2xl font-bold">{stats.totalOrders}</p>
                  <p className="text-xs text-muted-foreground">Processed orders</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="py-3">
              <CardTitle className="text-sm font-medium text-gray-500">Order Value</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Wallet className="h-8 w-8 text-purple-500 mr-3" />
                <div>
                  <p className="text-2xl font-bold">${stats.orderValue.toLocaleString()}</p>
                  <p className="text-xs text-muted-foreground">Total sales value</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="py-3">
              <CardTitle className="text-sm font-medium text-gray-500">Pending</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <TrendingUp className="h-8 w-8 text-orange-500 mr-3" />
                <div>
                  <p className="text-2xl font-bold">{stats.pendingDesigns + stats.pendingManufacturing}</p>
                  <p className="text-xs text-muted-foreground">In progress orders</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Your latest sales actions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border rounded-lg p-4">
                  <div className="flex items-center">
                    <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center mr-3">
                      <Users className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium">Lead claimed</p>
                      <p className="text-sm text-muted-foreground">You claimed a new lead from Central High School</p>
                    </div>
                    <div className="ml-auto text-sm text-muted-foreground">
                      Today
                    </div>
                  </div>
                </div>
                
                <div className="border rounded-lg p-4">
                  <div className="flex items-center">
                    <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                      <Package className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium">Order created</p>
                      <p className="text-sm text-muted-foreground">You created a new order for Westside Elementary</p>
                    </div>
                    <div className="ml-auto text-sm text-muted-foreground">
                      Yesterday
                    </div>
                  </div>
                </div>
                
                <div className="border rounded-lg p-4">
                  <div className="flex items-center">
                    <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                      <PhoneCall className="h-5 w-5 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-medium">Lead follow-up</p>
                      <p className="text-sm text-muted-foreground">You marked a follow-up call complete for Madison High</p>
                    </div>
                    <div className="ml-auto text-sm text-muted-foreground">
                      2 days ago
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Sales Performance</CardTitle>
              <CardDescription>Your sales metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm font-medium">Lead Conversion Rate</p>
                    <p className="text-sm font-medium">64%</p>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full">
                    <div className="h-full bg-green-500 rounded-full" style={{ width: '64%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm font-medium">Monthly Sales Goal</p>
                    <p className="text-sm font-medium">$15,000 / $20,000</p>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full">
                    <div className="h-full bg-blue-500 rounded-full" style={{ width: '75%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm font-medium">Average Order Value</p>
                    <p className="text-sm font-medium">$4,250</p>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full">
                    <div className="h-full bg-purple-500 rounded-full" style={{ width: '85%' }}></div>
                  </div>
                </div>
                
                <div className="pt-4">
                  <Link 
                    to="/reports" 
                    className="text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center"
                  >
                    View detailed reports
                    <svg className="ml-1 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default SalesAccount;
