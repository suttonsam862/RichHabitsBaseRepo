
import { useState, useEffect } from "react";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Filter, CheckCircle, XCircle, Clock, ArrowUpRight } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

interface DesignJob {
  id: string;
  order_id: string;
  customer_name?: string;
  design_type: string;
  assigned_at: string;
  due_date: string | null;
  status: string;
  notes: string | null;
}

const SalesDesignManagement = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [designJobs, setDesignJobs] = useState<DesignJob[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");

  useEffect(() => {
    fetchDesignJobs();
  }, [user]);

  const fetchDesignJobs = async () => {
    if (!user?.email) return;
    
    setIsLoading(true);
    try {
      // First get orders assigned to this sales person
      const { data: orders, error: ordersError } = await supabase
        .from('orders')
        .select('id, customer_id, status, design_status')
        .eq('assigned_to', user.email);
      
      if (ordersError) throw ordersError;
      
      if (orders && orders.length > 0) {
        // Get design assignments for these orders
        const orderIds = orders.map(order => order.id);
        
        const { data: designs, error: designsError } = await supabase
          .from('design_assignments')
          .select(`
            id, order_id, design_type, assigned_at, due_date, status, notes,
            orders!inner(customer_id)
          `)
          .in('order_id', orderIds);
        
        if (designsError) throw designsError;
        
        // Get customer names for these designs
        if (designs && designs.length > 0) {
          const customerIds = designs.map(design => design.orders.customer_id);
          const { data: customers, error: customersError } = await supabase
            .from('organizations')
            .select('id, name')
            .in('id', customerIds);
          
          if (customersError) throw customersError;
          
          // Combine data
          const enhancedDesigns = designs.map(design => {
            const customer = customers?.find(c => c.id === design.orders.customer_id);
            return {
              ...design,
              customer_name: customer?.name || 'Unknown Customer'
            };
          });
          
          setDesignJobs(enhancedDesigns);
        } else {
          setDesignJobs([]);
        }
      } else {
        setDesignJobs([]);
      }
    } catch (error) {
      console.error("Error fetching design jobs:", error);
      toast.error("Failed to load design jobs");
    } finally {
      setIsLoading(false);
    }
  };

  const getFilteredDesigns = () => {
    let filtered = [...designJobs];
    
    // Apply tab filter
    if (activeTab === "pending") {
      filtered = filtered.filter(job => job.status === "pending" || job.status === "assigned");
    } else if (activeTab === "completed") {
      filtered = filtered.filter(job => job.status === "completed");
    } else if (activeTab === "rejected") {
      filtered = filtered.filter(job => job.status === "rejected");
    }
    
    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        job => job.customer_name?.toLowerCase().includes(query) || 
              job.design_type.toLowerCase().includes(query)
      );
    }
    
    return filtered;
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "assigned":
        return <Badge className="bg-blue-100 text-blue-800">Assigned</Badge>;
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800">In Progress</Badge>;
      case "completed":
        return <Badge className="bg-green-100 text-green-800">Completed</Badge>;
      case "rejected":
        return <Badge className="bg-red-100 text-red-800">Rejected</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "Not set";
    return new Date(dateString).toLocaleDateString();
  };

  const viewDesignDetails = (designId: string) => {
    navigate(`/sales-design/${designId}`);
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Design Management</h1>
            <p className="text-muted-foreground">
              Track and manage your design jobs
            </p>
          </div>
          <div className="mt-4 md:mt-0 flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                type="text"
                placeholder="Search designs..."
                className="pl-8 w-[250px]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Design Jobs</CardTitle>
            <CardDescription>
              View all design jobs assigned to your orders
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-4">
                <TabsTrigger value="all">All Designs</TabsTrigger>
                <TabsTrigger value="pending">In Progress</TabsTrigger>
                <TabsTrigger value="completed">Completed</TabsTrigger>
                <TabsTrigger value="rejected">Rejected</TabsTrigger>
              </TabsList>
              
              <TabsContent value={activeTab} className="mt-0">
                {isLoading ? (
                  <div className="space-y-3">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="border rounded-lg p-4 animate-pulse">
                        <div className="h-4 bg-gray-200 rounded w-1/4 mb-3"></div>
                        <div className="h-3 bg-gray-200 rounded w-3/4 mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                      </div>
                    ))}
                  </div>
                ) : getFilteredDesigns().length > 0 ? (
                  <div className="space-y-3">
                    {getFilteredDesigns().map((job) => (
                      <div 
                        key={job.id} 
                        className="border rounded-lg p-4 hover:border-blue-500 transition-colors cursor-pointer"
                        onClick={() => viewDesignDetails(job.id)}
                      >
                        <div className="flex flex-col md:flex-row md:items-center justify-between mb-2">
                          <div>
                            <h3 className="font-medium">{job.customer_name || 'Unknown Customer'}</h3>
                            <p className="text-sm text-muted-foreground">{job.design_type}</p>
                          </div>
                          <div className="mt-2 md:mt-0 flex flex-col md:items-end">
                            {getStatusBadge(job.status)}
                            <span className="text-xs text-muted-foreground mt-1">
                              {job.due_date ? (
                                <>Due: {formatDate(job.due_date)}</>
                              ) : (
                                <>Assigned: {formatDate(job.assigned_at)}</>
                              )}
                            </span>
                          </div>
                        </div>
                        <div className="flex justify-between items-center mt-2 pt-2 border-t border-gray-100">
                          <div className="flex items-center text-sm text-muted-foreground">
                            <Clock className="h-3 w-3 mr-1" />
                            <span>Assigned: {formatDate(job.assigned_at)}</span>
                          </div>
                          <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-800 p-0">
                            View Details <ArrowUpRight className="ml-1 h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 border rounded-lg">
                    <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-gray-100 mb-3">
                      {activeTab === "completed" ? (
                        <CheckCircle className="h-6 w-6 text-gray-400" />
                      ) : activeTab === "rejected" ? (
                        <XCircle className="h-6 w-6 text-gray-400" />
                      ) : (
                        <Clock className="h-6 w-6 text-gray-400" />
                      )}
                    </div>
                    <h3 className="text-lg font-medium mb-1">No design jobs found</h3>
                    <p className="text-muted-foreground mb-4">
                      {searchQuery 
                        ? "Try adjusting your search terms"
                        : activeTab === "all" 
                          ? "You haven't submitted any designs for your orders yet"
                          : `No ${activeTab} design jobs found`
                      }
                    </p>
                    {searchQuery && (
                      <Button 
                        variant="outline" 
                        onClick={() => setSearchQuery("")}
                      >
                        Clear Search
                      </Button>
                    )}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SalesDesignManagement;
