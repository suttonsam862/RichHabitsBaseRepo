
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertCircle, Calendar, CheckCircle, Download, Eye, File, ThumbsDown, ThumbsUp, Truck, User, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";

interface DesignAssignment {
  id: string;
  order_id: string;
  designer_id: string | null;
  design_type: string;
  status: string;
  notes: string | null;
  assigned_at: string;
  due_date: string | null;
}

interface DesignSubmission {
  id: string;
  order_id: string;
  designer_id: string | null;
  design_type: string;
  status: string;
  notes: string | null;
  image_url: string | null;
  feedback: string | null;
  submission_date: string;
}

interface Designer {
  id: string;
  name: string;
  email: string;
}

interface Order {
  id: string;
  customer_id: string;
  status: string;
  design_status: string | null;
}

interface Customer {
  id: string;
  name: string;
}

const SalesDesignView = () => {
  const { designId } = useParams<{ designId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [assignment, setAssignment] = useState<DesignAssignment | null>(null);
  const [submissions, setSubmissions] = useState<DesignSubmission[]>([]);
  const [designer, setDesigner] = useState<Designer | null>(null);
  const [order, setOrder] = useState<Order | null>(null);
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [feedback, setFeedback] = useState("");
  const [activeTab, setActiveTab] = useState("design");

  useEffect(() => {
    if (designId) {
      fetchDesignDetails();
    }
  }, [designId]);

  const fetchDesignDetails = async () => {
    setIsLoading(true);
    try {
      // Get design assignment
      const { data: assignmentData, error: assignmentError } = await supabase
        .from('design_assignments')
        .select('*')
        .eq('id', designId)
        .single();
      
      if (assignmentError) throw assignmentError;
      setAssignment(assignmentData);
      
      // Get order details
      if (assignmentData?.order_id) {
        const { data: orderData, error: orderError } = await supabase
          .from('orders')
          .select('*')
          .eq('id', assignmentData.order_id)
          .single();
        
        if (orderError) throw orderError;
        setOrder(orderData);
        
        // Get customer details
        if (orderData?.customer_id) {
          const { data: customerData, error: customerError } = await supabase
            .from('organizations')
            .select('id, name')
            .eq('id', orderData.customer_id)
            .single();
          
          if (customerError) throw customerError;
          setCustomer(customerData);
        }
      }
      
      // Get designer details
      if (assignmentData?.designer_id) {
        const { data: designerData, error: designerError } = await supabase
          .from('designers')
          .select('id, name, email')
          .eq('id', assignmentData.designer_id)
          .single();
        
        if (designerError) throw designerError;
        setDesigner(designerData);
      }
      
      // Get design submissions
      if (assignmentData?.order_id) {
        const { data: submissionsData, error: submissionsError } = await supabase
          .from('design_submissions')
          .select('*')
          .eq('order_id', assignmentData.order_id)
          .eq('design_type', assignmentData.design_type)
          .order('submission_date', { ascending: false });
        
        if (submissionsError) throw submissionsError;
        setSubmissions(submissionsData || []);
      }
    } catch (error) {
      console.error("Error fetching design details:", error);
      toast.error("Failed to load design details");
    } finally {
      setIsLoading(false);
    }
  };

  const approveDesign = async (submissionId: string) => {
    try {
      // Update submission status
      const { error: submissionError } = await supabase
        .from('design_submissions')
        .update({ status: 'approved', feedback })
        .eq('id', submissionId);
      
      if (submissionError) throw submissionError;
      
      // Update design assignment status
      const { error: assignmentError } = await supabase
        .from('design_assignments')
        .update({ status: 'completed' })
        .eq('id', designId);
      
      if (assignmentError) throw assignmentError;
      
      // Update order design status
      if (order?.id) {
        const { error: orderError } = await supabase
          .from('orders')
          .update({ design_status: 'approved' })
          .eq('id', order.id);
        
        if (orderError) throw orderError;
      }
      
      toast.success("Design approved successfully");
      fetchDesignDetails();
    } catch (error) {
      console.error("Error approving design:", error);
      toast.error("Failed to approve design");
    }
  };

  const rejectDesign = async (submissionId: string) => {
    if (!feedback) {
      toast.error("Please provide feedback before rejecting");
      return;
    }
    
    try {
      // Update submission status
      const { error: submissionError } = await supabase
        .from('design_submissions')
        .update({ status: 'rejected', feedback })
        .eq('id', submissionId);
      
      if (submissionError) throw submissionError;
      
      toast.success("Design rejected with feedback");
      fetchDesignDetails();
    } catch (error) {
      console.error("Error rejecting design:", error);
      toast.error("Failed to reject design");
    }
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "Not set";
    return new Date(dateString).toLocaleDateString();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "assigned":
        return <Badge className="bg-blue-100 text-blue-800">Assigned</Badge>;
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800">In Progress</Badge>;
      case "completed":
        return <Badge className="bg-green-100 text-green-800">Completed</Badge>;
      case "approved":
        return <Badge className="bg-green-100 text-green-800">Approved</Badge>;
      case "rejected":
        return <Badge className="bg-red-100 text-red-800">Rejected</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const submitToManufacturing = () => {
    if (order?.id) {
      navigate(`/manufacturing-submission/${order.id}`);
    }
  };

  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar />
        <div className="flex-1 ml-64 p-6">
          <div className="flex justify-center items-center h-full">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            <span className="ml-2">Loading design details...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
          <div>
            <div className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => navigate('/sales-design-management')}
                className="p-0 h-auto"
              >
                <X className="h-4 w-4 mr-1" />
              </Button>
              <h1 className="text-2xl font-bold">{customer?.name} - {assignment?.design_type}</h1>
              {assignment?.status && getStatusBadge(assignment.status)}
            </div>
            <p className="text-muted-foreground mt-1">
              Order ID: {order?.id?.substring(0, 8) || "Unknown"}
            </p>
          </div>
          <div className="mt-4 md:mt-0 space-x-2">
            {assignment?.status === 'completed' && (
              <Button onClick={submitToManufacturing}>
                <Truck className="h-4 w-4 mr-2" />
                Submit to Manufacturing
              </Button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Design Preview</CardTitle>
                <CardDescription>
                  Review submitted designs
                </CardDescription>
              </CardHeader>
              <CardContent>
                {submissions.length > 0 ? (
                  <Tabs defaultValue="latest">
                    <TabsList className="mb-4">
                      <TabsTrigger value="latest">Latest Submission</TabsTrigger>
                      <TabsTrigger value="history">History ({submissions.length})</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="latest" className="space-y-4">
                      <div className="border rounded-lg overflow-hidden">
                        {submissions[0].image_url ? (
                          <div className="relative">
                            <img 
                              src={submissions[0].image_url} 
                              alt="Design submission" 
                              className="w-full h-auto object-contain max-h-[400px]"
                            />
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button 
                                  variant="secondary" 
                                  size="sm" 
                                  className="absolute bottom-3 right-3"
                                >
                                  <Eye className="h-4 w-4 mr-1" />
                                  View Full Size
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-4xl">
                                <DialogHeader>
                                  <DialogTitle>Design Preview</DialogTitle>
                                  <DialogDescription>
                                    Submitted on {formatDate(submissions[0].submission_date)}
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="mt-4 flex justify-center">
                                  <img 
                                    src={submissions[0].image_url} 
                                    alt="Design submission" 
                                    className="max-w-full h-auto"
                                  />
                                </div>
                              </DialogContent>
                            </Dialog>
                          </div>
                        ) : (
                          <div className="flex items-center justify-center h-48 bg-gray-100">
                            <div className="text-center">
                              <File className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                              <p className="text-muted-foreground">No image submitted</p>
                            </div>
                          </div>
                        )}
                        
                        <div className="p-4 border-t">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-medium">Submission #{submissions.length}</h3>
                              <p className="text-sm text-muted-foreground">
                                Submitted on {formatDate(submissions[0].submission_date)}
                              </p>
                            </div>
                            <div>{getStatusBadge(submissions[0].status)}</div>
                          </div>
                          
                          {submissions[0].notes && (
                            <div className="mt-3">
                              <h4 className="text-sm font-medium">Designer Notes</h4>
                              <p className="text-sm mt-1 p-2 bg-gray-50 rounded-lg">
                                {submissions[0].notes}
                              </p>
                            </div>
                          )}
                          
                          {submissions[0].feedback && (
                            <div className="mt-3">
                              <h4 className="text-sm font-medium">Your Feedback</h4>
                              <p className="text-sm mt-1 p-2 bg-gray-50 rounded-lg">
                                {submissions[0].feedback}
                              </p>
                            </div>
                          )}
                          
                          {submissions[0].status === 'pending' && (
                            <div className="mt-4">
                              <Label htmlFor="feedback">Provide Feedback</Label>
                              <Textarea
                                id="feedback"
                                placeholder="Enter your feedback for the designer..."
                                className="mt-1"
                                value={feedback}
                                onChange={(e) => setFeedback(e.target.value)}
                              />
                              <div className="flex justify-end gap-2 mt-2">
                                <Button
                                  variant="outline"
                                  onClick={() => rejectDesign(submissions[0].id)}
                                >
                                  <ThumbsDown className="h-4 w-4 mr-2" />
                                  Reject
                                </Button>
                                <Button
                                  onClick={() => approveDesign(submissions[0].id)}
                                >
                                  <ThumbsUp className="h-4 w-4 mr-2" />
                                  Approve
                                </Button>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="history" className="space-y-4">
                      {submissions.map((submission, index) => (
                        <div key={submission.id} className="border rounded-lg overflow-hidden">
                          <div className="p-4 flex justify-between items-start">
                            <div>
                              <h3 className="font-medium">Submission #{submissions.length - index}</h3>
                              <p className="text-sm text-muted-foreground">
                                Submitted on {formatDate(submission.submission_date)}
                              </p>
                            </div>
                            <div>{getStatusBadge(submission.status)}</div>
                          </div>
                          
                          {submission.image_url && (
                            <div className="border-t border-b">
                              <img 
                                src={submission.image_url} 
                                alt={`Design submission ${submissions.length - index}`} 
                                className="w-full h-auto object-contain max-h-[200px]"
                              />
                            </div>
                          )}
                          
                          <div className="p-4">
                            {submission.notes && (
                              <div className="mb-3">
                                <h4 className="text-sm font-medium">Designer Notes</h4>
                                <p className="text-sm mt-1 p-2 bg-gray-50 rounded-lg">
                                  {submission.notes}
                                </p>
                              </div>
                            )}
                            
                            {submission.feedback && (
                              <div>
                                <h4 className="text-sm font-medium">Your Feedback</h4>
                                <p className="text-sm mt-1 p-2 bg-gray-50 rounded-lg">
                                  {submission.feedback}
                                </p>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </TabsContent>
                  </Tabs>
                ) : (
                  <div className="text-center py-8 border rounded-lg">
                    <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-gray-100 mb-3">
                      <File className="h-6 w-6 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-medium mb-1">No design submissions yet</h3>
                    <p className="text-muted-foreground">
                      The designer hasn't submitted any designs for this job yet
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
          
          <div>
            <Tabs defaultValue={activeTab} onValueChange={setActiveTab}>
              <TabsList className="w-full">
                <TabsTrigger value="design" className="flex-1">Design Details</TabsTrigger>
                <TabsTrigger value="order" className="flex-1">Order Info</TabsTrigger>
              </TabsList>
              
              <TabsContent value="design" className="mt-4 space-y-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Assignment Details</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <Label className="text-muted-foreground text-sm">Design Type</Label>
                        <p>{assignment?.design_type}</p>
                      </div>
                      <div>
                        <Label className="text-muted-foreground text-sm">Status</Label>
                        <p>{getStatusBadge(assignment?.status || "unknown")}</p>
                      </div>
                      <div>
                        <Label className="text-muted-foreground text-sm">Assigned Date</Label>
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
                          <p>{formatDate(assignment?.assigned_at || null)}</p>
                        </div>
                      </div>
                      {assignment?.due_date && (
                        <div>
                          <Label className="text-muted-foreground text-sm">Due Date</Label>
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
                            <p>{formatDate(assignment.due_date)}</p>
                          </div>
                        </div>
                      )}
                      {assignment?.notes && (
                        <div>
                          <Label className="text-muted-foreground text-sm">Notes</Label>
                          <p className="text-sm p-2 bg-gray-50 rounded-lg mt-1">
                            {assignment.notes}
                          </p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Designer Information</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {designer ? (
                      <div className="space-y-3">
                        <div className="flex items-center">
                          <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center mr-3">
                            <User className="h-5 w-5 text-gray-500" />
                          </div>
                          <div>
                            <p className="font-medium">{designer.name}</p>
                            <p className="text-sm text-muted-foreground">{designer.email}</p>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-4">
                        <p className="text-muted-foreground">No designer assigned yet</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                {assignment?.status === 'completed' && submissions.some(s => s.status === 'approved') && (
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Next Steps</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Alert className="mb-3">
                        <CheckCircle className="h-4 w-4" />
                        <AlertDescription>
                          Design has been approved! Ready for manufacturing.
                        </AlertDescription>
                      </Alert>
                      <Button 
                        className="w-full" 
                        onClick={submitToManufacturing}
                      >
                        <Truck className="h-4 w-4 mr-2" />
                        Submit to Manufacturing
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
              
              <TabsContent value="order" className="mt-4 space-y-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Order Information</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <Label className="text-muted-foreground text-sm">Order ID</Label>
                        <p>{order?.id || "Unknown"}</p>
                      </div>
                      <div>
                        <Label className="text-muted-foreground text-sm">Customer</Label>
                        <p>{customer?.name || "Unknown"}</p>
                      </div>
                      <div>
                        <Label className="text-muted-foreground text-sm">Status</Label>
                        <p>{getStatusBadge(order?.status || "unknown")}</p>
                      </div>
                      <Separator />
                      <div>
                        <Label className="text-muted-foreground text-sm">Design Status</Label>
                        <p>{getStatusBadge(order?.design_status || "unknown")}</p>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => navigate(`/orders/${order?.id}`)}
                    >
                      View Complete Order
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SalesDesignView;
