import { useState, useEffect } from "react";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { CreditCard, DollarSign, Wallet, Building, AlertCircle, ChevronRight, CheckCircle, XCircle, FileText } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";

const SalesFinance = () => {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("earnings");
  const [payouts, setPayouts] = useState([]);
  const [earnings, setEarnings] = useState({
    total: 0,
    available: 0,
    pending: 0,
    lastMonth: 0
  });
  const [bankInfo, setBankInfo] = useState({
    accountName: "",
    accountNumber: "",
    routingNumber: "",
    bankName: ""
  });
  const [payoutRequest, setPayoutRequest] = useState({
    amount: "",
    notes: ""
  });

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      try {
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        setEarnings({
          total: 12450.75,
          available: 3250.50,
          pending: 1875.25,
          lastMonth: 4320.00
        });
        
        setBankInfo({
          accountName: "John Doe",
          accountNumber: "****4567",
          routingNumber: "****1234",
          bankName: "Chase Bank"
        });
        
        setPayouts([
          {
            id: "payout-1",
            date: "2023-05-15",
            amount: 1200.00,
            status: "completed",
            reference: "REF-12345"
          },
          {
            id: "payout-2",
            date: "2023-04-01",
            amount: 950.50,
            status: "completed",
            reference: "REF-12344"
          },
          {
            id: "payout-3",
            date: "2023-03-15",
            amount: 1500.00,
            status: "completed",
            reference: "REF-12343"
          },
          {
            id: "payout-4",
            date: "2023-02-28",
            amount: 750.25,
            status: "completed",
            reference: "REF-12342"
          }
        ]);
      } catch (error) {
        console.error("Error loading finance data:", error);
        toast.error("Failed to load financial information");
      } finally {
        setIsLoading(false);
      }
    };
    
    loadData();
  }, [user]);

  const handleRequestPayout = () => {
    if (!payoutRequest.amount || parseFloat(payoutRequest.amount) <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }
    
    if (parseFloat(payoutRequest.amount) > earnings.available) {
      toast.error("Requested amount exceeds available balance");
      return;
    }
    
    toast.success("Payout request submitted successfully");
    setPayoutRequest({
      amount: "",
      notes: ""
    });
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-100 text-green-800">Completed</Badge>;
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>;
      case "failed":
        return <Badge className="bg-red-100 text-red-800">Failed</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Finance & Payouts</h1>
            <p className="text-muted-foreground">
              Manage your earnings and request payouts
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Total Earnings
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <DollarSign className="h-5 w-5 text-green-500 mr-2" />
                {isLoading ? (
                  <div className="h-8 w-24 bg-gray-200 rounded animate-pulse"></div>
                ) : (
                  <span className="text-2xl font-bold">{formatCurrency(earnings.total)}</span>
                )}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Lifetime earnings from all orders
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Available for Payout
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Wallet className="h-5 w-5 text-blue-500 mr-2" />
                {isLoading ? (
                  <div className="h-8 w-24 bg-gray-200 rounded animate-pulse"></div>
                ) : (
                  <span className="text-2xl font-bold">{formatCurrency(earnings.available)}</span>
                )}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Amount available to withdraw
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Pending Earnings
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <CreditCard className="h-5 w-5 text-yellow-500 mr-2" />
                {isLoading ? (
                  <div className="h-8 w-24 bg-gray-200 rounded animate-pulse"></div>
                ) : (
                  <span className="text-2xl font-bold">{formatCurrency(earnings.pending)}</span>
                )}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Will be available after order completion
              </p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="earnings" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="earnings">Earnings & Payouts</TabsTrigger>
            <TabsTrigger value="banking">Banking Information</TabsTrigger>
          </TabsList>
          
          <TabsContent value="earnings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Request Payout</CardTitle>
                <CardDescription>
                  Request a payout of your available earnings
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <label htmlFor="amount" className="block text-sm font-medium mb-1">
                      Amount to Withdraw
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                      <Input 
                        id="amount"
                        type="number"
                        placeholder="0.00"
                        className="pl-8"
                        value={payoutRequest.amount}
                        onChange={(e) => setPayoutRequest({...payoutRequest, amount: e.target.value})}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      Maximum available: {formatCurrency(earnings.available)}
                    </p>
                  </div>
                  
                  <div>
                    <label htmlFor="notes" className="block text-sm font-medium mb-1">
                      Notes (Optional)
                    </label>
                    <Textarea 
                      id="notes"
                      placeholder="Add any notes for this payout request..."
                      rows={3}
                      value={payoutRequest.notes}
                      onChange={(e) => setPayoutRequest({...payoutRequest, notes: e.target.value})}
                    />
                  </div>
                  
                  <Button 
                    onClick={handleRequestPayout}
                    disabled={isLoading || !payoutRequest.amount || parseFloat(payoutRequest.amount) <= 0 || parseFloat(payoutRequest.amount) > earnings.available}
                  >
                    Request Payout
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Payout History</CardTitle>
                <CardDescription>
                  View your past payout requests and their status
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="border rounded-lg p-4 animate-pulse">
                        <div className="flex justify-between">
                          <div className="h-5 w-32 bg-gray-200 rounded"></div>
                          <div className="h-5 w-24 bg-gray-200 rounded"></div>
                        </div>
                        <div className="h-4 w-48 bg-gray-200 rounded mt-2"></div>
                      </div>
                    ))}
                  </div>
                ) : payouts.length === 0 ? (
                  <div className="text-center py-8 border rounded-lg">
                    <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                    <h3 className="text-lg font-medium mb-1">No payouts yet</h3>
                    <p className="text-muted-foreground mb-4">
                      You haven't requested any payouts yet
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {payouts.map((payout) => (
                      <div key={payout.id} className="border rounded-lg p-4 hover:border-blue-500 transition-colors">
                        <div className="flex flex-col md:flex-row md:items-center justify-between">
                          <div>
                            <div className="flex items-center">
                              <span className="font-medium">{formatCurrency(payout.amount)}</span>
                              <ChevronRight className="h-4 w-4 text-gray-400 mx-2" />
                              <span className="text-sm text-muted-foreground">{formatDate(payout.date)}</span>
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">
                              Reference: {payout.reference}
                            </p>
                          </div>
                          <div className="mt-2 md:mt-0">
                            {getStatusBadge(payout.status)}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="banking" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Banking Information</CardTitle>
                <CardDescription>
                  Your bank account details for receiving payouts
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-4">
                    <div className="h-6 w-48 bg-gray-200 rounded"></div>
                    <div className="h-24 w-full bg-gray-200 rounded"></div>
                  </div>
                ) : (
                  <div>
                    <div className="p-4 bg-blue-50 border border-blue-100 rounded-lg mb-6">
                      <div className="flex items-start">
                        <Building className="h-5 w-5 text-blue-500 mr-2 mt-0.5" />
                        <div>
                          <h3 className="font-medium text-blue-800">Current Banking Information</h3>
                          <p className="text-sm text-blue-700 mt-1">
                            This is where your payouts will be sent. Contact support if you need to update this information.
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <dl className="space-y-4">
                      <div>
                        <dt className="text-sm font-medium text-muted-foreground">Account Holder Name</dt>
                        <dd className="mt-1 font-medium">{bankInfo.accountName}</dd>
                      </div>
                      
                      <div>
                        <dt className="text-sm font-medium text-muted-foreground">Bank Name</dt>
                        <dd className="mt-1 font-medium">{bankInfo.bankName}</dd>
                      </div>
                      
                      <div>
                        <dt className="text-sm font-medium text-muted-foreground">Account Number</dt>
                        <dd className="mt-1 font-medium">{bankInfo.accountNumber}</dd>
                      </div>
                      
                      <div>
                        <dt className="text-sm font-medium text-muted-foreground">Routing Number</dt>
                        <dd className="mt-1 font-medium">{bankInfo.routingNumber}</dd>
                      </div>
                    </dl>
                    
                    <div className="mt-6">
                      <Button variant="outline">
                        <FileText className="h-4 w-4 mr-2" />
                        Request Banking Information Update
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Tax Information</CardTitle>
                <CardDescription>
                  Manage your tax documents and information
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg flex items-start">
                    <div className="mr-4 mt-1">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    </div>
                    <div>
                      <h3 className="font-medium">W-9 Form</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        Your W-9 form has been submitted and verified.
                      </p>
                    </div>
                  </div>
                  
                  <div className="p-4 border rounded-lg flex items-start">
                    <div className="mr-4 mt-1">
                      <XCircle className="h-5 w-5 text-red-500" />
                    </div>
                    <div>
                      <h3 className="font-medium">1099-MISC Form</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        Your 1099-MISC form for 2023 will be available in January 2024.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default SalesFinance;
