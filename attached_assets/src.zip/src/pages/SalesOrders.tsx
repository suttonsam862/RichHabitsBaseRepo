
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Package, PlusCircle, FileText, Truck, AlertCircle } from "lucide-react";
import { orderService } from "@/services/orderService";
import { useAuth } from "@/context/AuthContext";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

const SalesOrders = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [orders, setOrders] = useState<any[]>([]);
  const [filteredOrders, setFilteredOrders] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");

  useEffect(() => {
    const fetchOrders = async () => {
      setIsLoading(true);
      try {
        // Fetch all orders
        const allOrders = await orderService.getAll();
        
        // Filter to only show this sales person's orders
        if (user?.email) {
          const mySalesOrders = allOrders.filter(order => order.assigned_to === user.email);
          setOrders(mySalesOrders);
          setFilteredOrders(mySalesOrders);
        } else {
          setOrders([]);
          setFilteredOrders([]);
        }
      } catch (error) {
        console.error("Error fetching orders:", error);
        toast.error("Failed to load orders");
      } finally {
        setIsLoading(false);
      }
    };

    fetchOrders();
  }, [user]);

  useEffect(() => {
    // Filter orders based on search query and active tab
    let filtered = [...orders];
    
    // Apply tab filter
    if (activeTab === "draft") {
      filtered = filtered.filter(order => order.status === "draft");
    } else if (activeTab === "design") {
      filtered = filtered.filter(order => order.status === "design");
    } else if (activeTab === "manufacturing") {
      filtered = filtered.filter(order => order.status === "manufacturing");
    } else if (activeTab === "completed") {
      filtered = filtered.filter(order => order.status === "completed");
    }
    
    // Apply search filter
    if (searchQuery.trim() !== "") {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(order => 
        order.id.toLowerCase().includes(query) ||
        (order.customer_name && order.customer_name.toLowerCase().includes(query))
      );
    }
    
    setFilteredOrders(filtered);
  }, [orders, searchQuery, activeTab]);

  const handleCreateOrder = () => {
    navigate("/orders/new");
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  const handleOrderClick = (orderId: string) => {
    navigate(`/orders/${orderId}`);
  };

  const handleSubmitToManufacturing = (orderId: string) => {
    navigate(`/manufacturing-submission/${orderId}`);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "draft":
        return <Badge variant="outline" className="bg-gray-100">Draft</Badge>;
      case "design":
        return <Badge className="bg-blue-100 text-blue-800">Design</Badge>;
      case "manufacturing":
        return <Badge className="bg-yellow-100 text-yellow-800">Manufacturing</Badge>;
      case "completed":
        return <Badge className="bg-green-100 text-green-800">Completed</Badge>;
      case "cancelled":
        return <Badge className="bg-red-100 text-red-800">Cancelled</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const renderOrderCard = (order: any) => {
    return (
      <div key={order.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleOrderClick(order.id)}>
        <div className="flex justify-between items-start">
          <div>
            <h3 className="font-medium text-lg">{order.customer_name || "Customer #" + order.customer_id.substring(0, 8)}</h3>
            <p className="text-sm text-muted-foreground">Order ID: {order.id.substring(0, 8)}</p>
          </div>
          <div>
            {getStatusBadge(order.status)}
          </div>
        </div>
        
        <div className="mt-3 flex items-center text-sm text-muted-foreground">
          <FileText className="h-4 w-4 mr-1" />
          <span>{order.line_item_count || 0} items</span>
          <span className="mx-2">•</span>
          <span>${order.total?.toLocaleString() || "0"}</span>
        </div>
        
        <div className="mt-4 flex justify-between items-center">
          <span className="text-xs text-gray-500">
            Created: {new Date(order.created_at).toLocaleDateString()}
          </span>
          
          {order.status === "design" && order.design_status === "approved" && (
            <Button 
              size="sm" 
              variant="ghost" 
              className="text-blue-600 hover:text-blue-800 hover:bg-blue-50"
              onClick={(e) => {
                e.stopPropagation();
                handleSubmitToManufacturing(order.id);
              }}
            >
              <Truck className="h-3 w-3 mr-1" />
              Submit to Manufacturing
            </Button>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Sales Orders</h1>
            <p className="text-muted-foreground">
              Manage and track your customer orders
            </p>
          </div>
          <div className="mt-4 md:mt-0">
            <Button onClick={handleCreateOrder}>
              <PlusCircle className="h-4 w-4 mr-2" />
              Create Order
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader className="pb-3">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
              <div>
                <CardTitle>Orders</CardTitle>
                <CardDescription>
                  View and manage your orders
                </CardDescription>
              </div>
              <div className="w-full md:w-auto mt-4 md:mt-0">
                <Input 
                  placeholder="Search orders..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="max-w-xs"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all" value={activeTab} onValueChange={handleTabChange}>
              <TabsList className="mb-4">
                <TabsTrigger value="all">All Orders</TabsTrigger>
                <TabsTrigger value="draft">Draft</TabsTrigger>
                <TabsTrigger value="design">Design</TabsTrigger>
                <TabsTrigger value="manufacturing">Manufacturing</TabsTrigger>
                <TabsTrigger value="completed">Completed</TabsTrigger>
              </TabsList>
              
              <TabsContent value="all" className="mt-0">
                {isLoading ? (
                  <div className="text-center py-8">
                    <Package className="h-8 w-8 mx-auto text-gray-400 animate-pulse" />
                    <p className="mt-2 text-muted-foreground">Loading orders...</p>
                  </div>
                ) : filteredOrders.length > 0 ? (
                  <div className="grid grid-cols-1 gap-4">
                    {filteredOrders.map(order => renderOrderCard(order))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <AlertCircle className="h-8 w-8 mx-auto text-gray-400" />
                    <p className="mt-2 text-muted-foreground">No orders found</p>
                    {searchQuery && (
                      <Button 
                        variant="link" 
                        onClick={() => setSearchQuery("")}
                        className="mt-2"
                      >
                        Clear search
                      </Button>
                    )}
                    {!searchQuery && (
                      <Button 
                        variant="outline" 
                        onClick={handleCreateOrder}
                        className="mt-4"
                      >
                        <PlusCircle className="h-4 w-4 mr-2" />
                        Create your first order
                      </Button>
                    )}
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="draft" className="mt-0">
                {/* Same content structure as "all" tab but with filtered orders */}
                {isLoading ? (
                  <div className="text-center py-8">
                    <Package className="h-8 w-8 mx-auto text-gray-400 animate-pulse" />
                    <p className="mt-2 text-muted-foreground">Loading orders...</p>
                  </div>
                ) : filteredOrders.length > 0 ? (
                  <div className="grid grid-cols-1 gap-4">
                    {filteredOrders.map(order => renderOrderCard(order))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <AlertCircle className="h-8 w-8 mx-auto text-gray-400" />
                    <p className="mt-2 text-muted-foreground">No draft orders found</p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="design" className="mt-0">
                {/* Same structure for design tab */}
                {isLoading ? (
                  <div className="text-center py-8">
                    <Package className="h-8 w-8 mx-auto text-gray-400 animate-pulse" />
                    <p className="mt-2 text-muted-foreground">Loading orders...</p>
                  </div>
                ) : filteredOrders.length > 0 ? (
                  <div className="grid grid-cols-1 gap-4">
                    {filteredOrders.map(order => renderOrderCard(order))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <AlertCircle className="h-8 w-8 mx-auto text-gray-400" />
                    <p className="mt-2 text-muted-foreground">No orders in design phase</p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="manufacturing" className="mt-0">
                {/* Same structure for manufacturing tab */}
                {isLoading ? (
                  <div className="text-center py-8">
                    <Package className="h-8 w-8 mx-auto text-gray-400 animate-pulse" />
                    <p className="mt-2 text-muted-foreground">Loading orders...</p>
                  </div>
                ) : filteredOrders.length > 0 ? (
                  <div className="grid grid-cols-1 gap-4">
                    {filteredOrders.map(order => renderOrderCard(order))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <AlertCircle className="h-8 w-8 mx-auto text-gray-400" />
                    <p className="mt-2 text-muted-foreground">No orders in manufacturing</p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="completed" className="mt-0">
                {/* Same structure for completed tab */}
                {isLoading ? (
                  <div className="text-center py-8">
                    <Package className="h-8 w-8 mx-auto text-gray-400 animate-pulse" />
                    <p className="mt-2 text-muted-foreground">Loading orders...</p>
                  </div>
                ) : filteredOrders.length > 0 ? (
                  <div className="grid grid-cols-1 gap-4">
                    {filteredOrders.map(order => renderOrderCard(order))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <AlertCircle className="h-8 w-8 mx-auto text-gray-400" />
                    <p className="mt-2 text-muted-foreground">No completed orders</p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SalesOrders;
