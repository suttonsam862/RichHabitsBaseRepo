
import { useState, useEffect } from "react";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Search, Users, Plus } from "lucide-react";
import { useUserProfiles, UserProfile } from "@/hooks/useUserProfiles";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import TeamGrid from "@/components/teams/TeamGrid";

const SalesPeople = () => {
  const { isAdmin } = useAuth();
  const { userProfiles, getSalesTeam, isLoading, refetch } = useUserProfiles();
  const [searchTerm, setSearchTerm] = useState("");
  const [salesTeam, setSalesTeam] = useState<UserProfile[]>([]);

  useEffect(() => {
    const team = getSalesTeam();
    setSalesTeam(team);
  }, [userProfiles, getSalesTeam]);

  // Filter sales people based on search term
  const filteredSalesPeople = salesTeam.filter(
    (person) =>
      person.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      person.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleEdit = (user: UserProfile) => {
    toast.info(`Edit functionality for ${user.name || user.email} coming soon`);
  };

  const handleRemove = (user: UserProfile) => {
    toast.info(`Remove functionality for ${user.name || user.email} coming soon`);
  };

  const handleContact = (user: UserProfile) => {
    toast.info(`Contact functionality for ${user.name || user.email} coming soon`);
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Sales Team</h1>
            <p className="text-muted-foreground">
              Manage sales representatives and their accounts
            </p>
          </div>
          {isAdmin && (
            <Dialog>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Sales Person
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>Add Sales Person</DialogTitle>
                  <DialogDescription>
                    Enter the details of the new sales team member.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="name">Name</Label>
                    <Input id="name" placeholder="John Doe" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" placeholder="john.doe@example.com" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="phone">Phone</Label>
                    <Input id="phone" placeholder="(555) 123-4567" />
                  </div>
                </div>
                <Button className="w-full" onClick={() => toast.info("Feature coming soon")}>
                  Add Sales Person
                </Button>
              </DialogContent>
            </Dialog>
          )}
        </div>

        <Card className="mb-6">
          <CardHeader className="pb-3">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
              <CardTitle>Sales Team Management</CardTitle>
              <div className="mt-3 md:mt-0 relative w-full md:w-auto max-w-sm">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search sales people..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={handleSearch}
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <TeamGrid team={[]} loading={true} />
            ) : filteredSalesPeople.length === 0 ? (
              <div className="text-center py-10">
                <Users className="mx-auto h-12 w-12 text-gray-300 mb-2" />
                <h3 className="text-lg font-medium mb-1">No sales people found</h3>
                <p className="text-muted-foreground mb-4">
                  {searchTerm ? "Try a different search term" : "Add your first sales person to get started"}
                </p>
                {isAdmin && (
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="h-4 w-4 mr-2" />
                        Add Sales Person
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px]">
                      <DialogHeader>
                        <DialogTitle>Add Sales Person</DialogTitle>
                        <DialogDescription>
                          Enter the details of the new sales team member.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid gap-2">
                          <Label htmlFor="name2">Name</Label>
                          <Input id="name2" placeholder="John Doe" />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="email2">Email</Label>
                          <Input id="email2" type="email" placeholder="john.doe@example.com" />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="phone2">Phone</Label>
                          <Input id="phone2" placeholder="(555) 123-4567" />
                        </div>
                      </div>
                      <Button className="w-full" onClick={() => toast.info("Feature coming soon")}>
                        Add Sales Person
                      </Button>
                    </DialogContent>
                  </Dialog>
                )}
              </div>
            ) : (
              <TeamGrid 
                team={filteredSalesPeople} 
                onEdit={handleEdit}
                onRemove={handleRemove}
                onContact={handleContact}
              />
            )}
          </CardContent>
          {filteredSalesPeople.length > 0 && (
            <CardFooter className="border-t pt-4 pb-4">
              <p className="text-sm text-muted-foreground">
                Showing {filteredSalesPeople.length} of {salesTeam.length} sales representatives
              </p>
            </CardFooter>
          )}
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Sales Team Performance</CardTitle>
            <CardDescription>
              View the performance metrics of your sales team
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border p-4 text-center">
              <h3 className="font-medium mb-2">Performance Analytics Dashboard</h3>
              <p className="text-muted-foreground mb-4">
                Detailed performance analytics will be available soon.
              </p>
              <Button variant="outline" onClick={() => toast.info("Feature coming soon")}>
                View Reports
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SalesPeople;
