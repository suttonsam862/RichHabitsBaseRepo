
import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Info, Database, Shield, ExternalLink, ArrowLeft, HelpCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import SupabaseStatus from "@/components/SupabaseStatus";
import { useTutorial } from "@/components/tutorial/TutorialContext";
import { TutorialButton } from "@/components/tutorial/TutorialButton";

interface SettingsProps {}

const Settings = ({}: SettingsProps) => {
  const [activeTab, setActiveTab] = useState("general");
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem("darkMode") === "true");
  const [notifications, setNotifications] = useState(true);
  const [autoSave, setAutoSave] = useState(true);
  const { isTutorialActive, setIsTutorialActive } = useTutorial();
  
  const handleDarkModeToggle = (checked: boolean) => {
    setDarkMode(checked);
    localStorage.setItem("darkMode", String(checked));
    document.documentElement.classList.toggle("dark", checked);
    toast.success(`${checked ? "Dark" : "Light"} mode activated`);
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    
    // Add tab to URL for direct linking
    const url = new URL(window.location.href);
    url.searchParams.set("tab", value);
    window.history.replaceState({}, "", url.toString());
  };

  // Get initial tab from URL if available
  useEffect(() => {
    const url = new URL(window.location.href);
    const tabParam = url.searchParams.get("tab");
    if (tabParam) {
      setActiveTab(tabParam);
    }
  }, []);
  
  return (
    <div className="container mx-auto py-8">
      {/* Back to Dashboard Button */}
      <div className="flex justify-between items-center mb-4">
        <Link to="/" className="flex items-center text-gray-600 hover:text-gray-900">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Dashboard
        </Link>
        <TutorialButton className="tutorial-button" />
      </div>
      
      <h1 className="text-3xl font-bold mb-6">Settings</h1>
      
      <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-4">
        <TabsList className="grid grid-cols-3 w-full max-w-md">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="database">Database</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
        </TabsList>
        
        {/* General Tab */}
        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Appearance</CardTitle>
              <CardDescription>
                Customize the look and feel of the application
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="dark-mode">Dark Mode</Label>
                  <p className="text-sm text-muted-foreground">
                    Enable dark mode for a comfortable viewing experience in low light
                  </p>
                </div>
                <Switch 
                  id="dark-mode" 
                  checked={darkMode} 
                  onCheckedChange={handleDarkModeToggle} 
                />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Notifications</CardTitle>
              <CardDescription>
                Configure how you receive notifications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="notifications">In-App Notifications</Label>
                  <p className="text-sm text-muted-foreground">
                    Receive notifications about important events
                  </p>
                </div>
                <Switch 
                  id="notifications" 
                  checked={notifications} 
                  onCheckedChange={setNotifications} 
                />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Data Management</CardTitle>
              <CardDescription>
                Control how your data is saved and managed
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="auto-save">Auto Save</Label>
                  <p className="text-sm text-muted-foreground">
                    Automatically save changes as you make them
                  </p>
                </div>
                <Switch 
                  id="auto-save" 
                  checked={autoSave} 
                  onCheckedChange={setAutoSave} 
                />
              </div>
            </CardContent>
          </Card>
          
          {/* Tutorial Settings Card */}
          <Card className="border-blue-200">
            <CardHeader className="bg-blue-50">
              <CardTitle className="flex items-center">
                <HelpCircle className="h-5 w-5 mr-2 text-blue-500" />
                Tutorial System
              </CardTitle>
              <CardDescription>
                Control the interactive tutorial system for all pages
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="enable-tutorial">Enable Tutorials</Label>
                  <p className="text-sm text-muted-foreground">
                    Show interactive tutorials that guide you through each page
                  </p>
                </div>
                <Switch 
                  id="enable-tutorial" 
                  checked={isTutorialActive} 
                  onCheckedChange={setIsTutorialActive}
                />
              </div>
              <Alert className="bg-blue-50 border-blue-200">
                <Info className="h-4 w-4 text-blue-500" />
                <AlertTitle className="text-blue-700">Tutorial Tips</AlertTitle>
                <AlertDescription className="text-blue-600">
                  <p>When tutorials are enabled, you'll see guided popups on each page explaining key features.</p>
                  <p className="mt-2">You can also toggle tutorials on/off using the help button in the top right corner of any page.</p>
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Database Tab */}
        <TabsContent value="database" className="space-y-4">
          <SupabaseStatus />
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="h-5 w-5 mr-2" />
                Data Policies
              </CardTitle>
              <CardDescription>
                Control how your data is accessed and managed
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Alert>
                <Info className="h-4 w-4" />
                <AlertTitle>Database Security</AlertTitle>
                <AlertDescription>
                  Your data is secured using Supabase Row Level Security (RLS) policies.
                  For more information on how to customize these policies, refer to the Supabase documentation.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Integrations Tab */}
        <TabsContent value="integrations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Available Integrations</CardTitle>
              <CardDescription>
                Connect your app with third-party services
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-md border p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-medium">Supabase</h3>
                    <p className="text-sm text-muted-foreground">
                      Database, Authentication, and Storage
                    </p>
                  </div>
                  <Badge variant="success">Connected</Badge>
                </div>
              </div>
              
              <Alert className="bg-amber-50 border-amber-200">
                <AlertTriangle className="h-4 w-4 text-amber-600" />
                <AlertTitle className="text-amber-800">Need more integrations?</AlertTitle>
                <AlertDescription className="text-amber-700">
                  You can add additional integrations like Stripe, SendGrid, or OAuth providers
                  through the Supabase dashboard.
                </AlertDescription>
              </Alert>
            </CardContent>
            <CardFooter>
              <Button 
                variant="outline" 
                className="w-full" 
                onClick={() => window.open("https://supabase.com/dashboard", "_blank")}
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                Open Supabase Dashboard
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Settings;
