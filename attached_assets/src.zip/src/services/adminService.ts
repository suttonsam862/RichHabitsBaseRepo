
import { Product } from "@/lib/api";
import { toast } from "sonner";

class AdminService {
  private readonly STORAGE_KEY = 'adminProducts';
  
  // Update a product
  async updateProduct(product: Product): Promise<Product> {
    // In a real app, this would make an API call to the backend
    // For now, we'll update localStorage to persist changes
    
    try {
      // Get current products from localStorage or use empty array
      const storedProducts = localStorage.getItem(this.STORAGE_KEY);
      let products: Product[] = storedProducts ? JSON.parse(storedProducts) : [];
      
      // Find and update the product
      const index = products.findIndex(p => p.id === product.id);
      
      if (index >= 0) {
        // Update existing product
        products[index] = product;
      } else {
        // Add to stored products
        products.push(product);
      }
      
      // Save back to localStorage
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(products));
      
      console.log(`Admin product ${product.id} (${product.name}) updated successfully`);
      toast.success(`Product "${product.name}" updated successfully`);
      return product;
    } catch (error) {
      console.error("Error updating product:", error);
      toast.error("Failed to update product");
      throw new Error("Failed to update product");
    }
  }
  
  // Get all admin-edited products
  async getAdminProducts(): Promise<Product[]> {
    try {
      const storedProducts = localStorage.getItem(this.STORAGE_KEY);
      const products = storedProducts ? JSON.parse(storedProducts) : [];
      console.log(`Retrieved ${products.length} admin-edited products from local storage`);
      return products;
    } catch (error) {
      console.error("Error getting admin products:", error);
      toast.error("Failed to retrieve admin products");
      return [];
    }
  }
  
  // Delete an admin-edited product
  async deleteAdminProduct(productId: string): Promise<boolean> {
    try {
      const storedProducts = localStorage.getItem(this.STORAGE_KEY);
      if (!storedProducts) return false;
      
      let products: Product[] = JSON.parse(storedProducts);
      const initialLength = products.length;
      
      // Filter out the product to delete
      products = products.filter(p => p.id !== productId);
      
      if (products.length === initialLength) {
        // No product was removed
        toast.error("Product not found");
        return false;
      }
      
      // Save back to localStorage
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(products));
      console.log(`Admin product ${productId} deleted successfully`);
      toast.success("Product deleted successfully");
      return true;
    } catch (error) {
      console.error("Error deleting admin product:", error);
      toast.error("Failed to delete product");
      return false;
    }
  }
  
  // Clear all admin products
  async clearAllAdminProducts(): Promise<boolean> {
    try {
      localStorage.removeItem(this.STORAGE_KEY);
      console.log("All admin products cleared successfully");
      toast.success("All admin-edited products cleared");
      return true;
    } catch (error) {
      console.error("Error clearing admin products:", error);
      toast.error("Failed to clear admin products");
      return false;
    }
  }
  
  // Export admin products as JSON string
  exportAdminProducts(): string | null {
    try {
      const storedProducts = localStorage.getItem(this.STORAGE_KEY);
      if (!storedProducts) {
        toast.info("No admin products to export");
        return null;
      }
      
      console.log("Admin products exported successfully");
      return storedProducts;
    } catch (error) {
      console.error("Error exporting admin products:", error);
      toast.error("Failed to export admin products");
      return null;
    }
  }
  
  // Import admin products from JSON string
  async importAdminProducts(jsonData: string): Promise<boolean> {
    try {
      // Validate the JSON data
      const products = JSON.parse(jsonData);
      
      if (!Array.isArray(products)) {
        toast.error("Invalid data format");
        return false;
      }
      
      // Save to localStorage
      localStorage.setItem(this.STORAGE_KEY, jsonData);
      console.log(`Imported ${products.length} admin products successfully`);
      toast.success(`Imported ${products.length} products successfully`);
      return true;
    } catch (error) {
      console.error("Error importing admin products:", error);
      toast.error("Failed to import admin products");
      return false;
    }
  }
}

// Export as singleton
export const adminService = new AdminService();
