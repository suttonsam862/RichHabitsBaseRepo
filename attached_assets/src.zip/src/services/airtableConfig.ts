
/**
 * Configuration and mapping for Airtable integration
 */

// Default table names in Airtable based on user's tables
export const defaultTableMapping = {
  leads: 'Leads',
  products: 'Product Management',
  orders: 'Orders',
  statistics: 'Sales Statistics',
  lineItems: 'Line Item Management',
  organizations: 'Organization Client Database'
};

// Interfaces for Airtable integration
export interface AirtableConfig {
  personalAccessToken: string;
  baseId: string;
}

// Adding index signature to fix type compatibility with Record<string, string>
export interface TableMapping {
  leads?: string;
  products?: string;
  orders?: string;
  statistics?: string;
  lineItems?: string;
  organizations?: string;
  [key: string]: string | undefined;
}

// Known computed fields to avoid writing to
export const knownComputedFields = {
  leads: ['Lead ID', 'Last Modified Time Column'],
  products: ['Item SKU'],
  orders: ['Order ID', 'Last Modified Time Column'],
  organizations: ['Organization ID']
};

// Field mappings for bidirectional sync between app and Airtable
export const fieldMappings = {
  leads: {
    // App field name: Airtable field name
    id: 'Lead ID',
    name: 'Contact Name',
    organization: 'Lead Name', // Updated to match Airtable
    email: 'Contact Email',
    phone: 'Contact Phone',
    status: 'Status',
    dateCreated: 'Date Received',
    dateUpdated: 'Last Modified Time Column',
    assignedTo: 'Assigned To:',  // Updated to match Airtable (with colon)
    notes: 'Lead Details',
    estimatedValue: 'Order Total',  // Using Order Total as the closest match
    source: 'Lead Source',
    followUpDate: 'Follow-Up Date'
  },
  products: {
    id: 'Item SKU',
    name: 'Item Name',
    category: 'Category',
    sport: 'Sport',
    price: 'Wholesale Price',  // Updated to match Airtable
    description: 'Item',  // Updated to match Airtable
    imageUrl: 'Image Attachments',  // Updated to match Airtable
    inventory: 'Total QTY',  // Updated to match Airtable
    sizes: 'Fabric Options',  // Using Fabric Options as a proxy for sizes
    colors: 'Fabric Option'   // Using Fabric Option as a proxy for colors
  },
  orders: {
    id: 'Order ID',
    customerId: 'Organization ID',  // Updated to match Airtable reference
    customerName: 'Organization Name',  // Updated to match Airtable reference
    dateCreated: 'Date Received',
    dateUpdated: 'Last Modified Time Column',
    status: 'Order Status',
    total: 'Order Total',
    assignedTo: 'Sales Rep Field',
    notes: 'Lead Details',
    trackingNumber: 'Tracking Number',
    designStatus: 'Design Status',
    designFiles: 'Design Files',
    invoiceStatus: 'Invoice Status',
    invoiceId: 'Invoice ID'
  },
  organizations: {
    id: 'Organization ID',
    name: 'Organization Name',
    phone: 'Phone',
    email: 'Email',
    billingAddress: 'Billing Address (Street Address)',
    billingAddressLine2: 'Billing Address Secondary Line',
    billingCity: 'Billing Address City',
    billingState: 'Billing Address State',
    billingZip: 'Billing Address Zip Code',
    shippingAddress: 'Shipping Address (Street Address)',
    shippingAddressLine2: 'Shipping Address Secondary Line',
    shippingCity: 'Shipping Address City',
    shippingState: 'Shipping Address State',
    shippingZip: 'Shipping Address Zip Code',
    contactFirstName: 'Client Contact First Name',
    contactLastName: 'Client Contact Last Name'
  }
};

// Field types that require special formatting for Airtable
export const fieldTypeMap = {
  products: {
    'Image Attachments': 'attachment'
  },
  orders: {
    'Design Files': 'attachment'
  }
};

// Helper function to format attachment fields for Airtable
export function formatAttachmentField(url: string): { url: string }[] {
  if (!url) return [];
  return [{ url }];
}

// Helper function to load table mapping from localStorage
export function loadTableMappingFromLocalStorage(): TableMapping {
  return {
    leads: localStorage.getItem('airtableLeadsTable') || defaultTableMapping.leads,
    products: localStorage.getItem('airtableProductsTable') || defaultTableMapping.products,
    orders: localStorage.getItem('airtableOrdersTable') || defaultTableMapping.orders,
    statistics: localStorage.getItem('airtableStatsTable') || defaultTableMapping.statistics,
    lineItems: localStorage.getItem('airtableLineItemsTable') || defaultTableMapping.lineItems,
    organizations: localStorage.getItem('airtableOrganizationsTable') || defaultTableMapping.organizations
  };
}
