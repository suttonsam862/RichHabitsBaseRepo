import Airtable from 'airtable';
import { AirtableConfig, TableMapping, loadTableMappingFromLocalStorage } from './airtableConfig';
import { getErrorMessage } from './airtableUtils';
import { fieldMappings } from './airtableConfig';
import { syncLeads, syncOrders, syncProducts, createTestData } from './airtableSync';

/**
 * Service class for interacting with Airtable
 */
class AirtableService {
  private config: AirtableConfig | null = null;
  private tableMapping: TableMapping = {};
  private lastSyncError: { [key: string]: string | null } = {};
  private detectedComputedFields: Record<string, string[]> = {};

  constructor() {
    this.loadConfigFromLocalStorage();
    this.tableMapping = loadTableMappingFromLocalStorage();
  }

  /**
   * Initialize Airtable configuration
   * @param personalAccessToken Airtable Personal Access Token
   * @param baseId Airtable Base ID
   * @returns boolean indicating successful initialization
   */
  public initialize(personalAccessToken: string, baseId: string): boolean {
    if (!personalAccessToken || !baseId) {
      console.error("Personal Access Token and Base ID are required to initialize Airtable");
      return false;
    }

    try {
      this.config = { personalAccessToken, baseId };
      Airtable.configure({ apiKey: personalAccessToken });
      localStorage.setItem('airtablePersonalAccessToken', personalAccessToken);
      localStorage.setItem('airtableBaseId', baseId);
      console.info("Airtable service initialized successfully");
      return true;
    } catch (error) {
      console.error("Error initializing Airtable:", error);
      return false;
    }
  }

  /**
   * Check if Airtable service is initialized
   * @returns boolean indicating initialization status
   */
  public isInitialized(): boolean {
    return !!this.config;
  }

  /**
   * Get Airtable configuration
   * @returns AirtableConfig or null if not initialized
   */
  public getConfig(): AirtableConfig | null {
    return this.config;
  }

  /**
   * Load Airtable configuration from localStorage
   */
  private loadConfigFromLocalStorage(): void {
    const personalAccessToken = localStorage.getItem('airtablePersonalAccessToken');
    const baseId = localStorage.getItem('airtableBaseId');

    if (personalAccessToken && baseId) {
      this.config = { personalAccessToken, baseId };
      Airtable.configure({ apiKey: personalAccessToken });
      console.info("Airtable configuration loaded from localStorage");
    } else {
      console.warn("Airtable configuration not found in localStorage");
    }
  }

  /**
   * Validate Airtable connection
   * @returns Promise<object> with connection status
   */
  public async validateConnection(): Promise<{ success: boolean; message: string; details?: any }> {
    if (!this.config) {
      return { success: false, message: "Airtable not configured. Please provide credentials." };
    }

    try {
      const base = this.getAirtableBase();
      await base('Leads').select({ maxRecords: 1 }).firstPage();
      return { success: true, message: "Successfully connected to Airtable" };
    } catch (error: any) {
      console.error("Error validating Airtable connection:", error);
      return { success: false, message: getErrorMessage(error), details: error };
    }
  }

  /**
   * Get Airtable base instance
   * @returns Airtable base instance
   * @throws Error if Airtable is not initialized
   */
  public getAirtableBase(): Airtable.Base {
    if (!this.config) {
      throw new Error("Airtable not configured. Please initialize with Personal Access Token and Base ID.");
    }
    return Airtable.base(this.config.baseId);
  }

  /**
   * Get table mapping
   * @returns TableMapping
   */
  public getTableMapping(): TableMapping {
    return this.tableMapping;
  }

  /**
   * Get field mappings
   * @returns any
   */
  public getFieldMappings(): any {
    return fieldMappings;
  }

  /**
   * Update table mapping
   * @param mapping TableMapping
   */
  public updateTableMapping(mapping: TableMapping): void {
    this.tableMapping = { ...this.tableMapping, ...mapping };
    
    // Persist to localStorage
    localStorage.setItem('airtableLeadsTable', mapping.leads || '');
    localStorage.setItem('airtableProductsTable', mapping.products || '');
    localStorage.setItem('airtableOrdersTable', mapping.orders || '');
    localStorage.setItem('airtableStatsTable', mapping.statistics || '');
    localStorage.setItem('airtableLineItemsTable', mapping.lineItems || '');
    localStorage.setItem('airtableOrganizationsTable', mapping.organizations || '');
    
    console.info("Airtable table mapping updated:", this.tableMapping);
  }

  /**
   * Set last sync error for a specific table
   * @param tableType Table type (e.g., 'leads', 'products')
   * @param error Error message
   */
  public setLastSyncError(tableType: string, error: string | null): void {
    this.lastSyncError[tableType] = error;
    console.error(`Sync error for ${tableType}:`, error);
  }

  /**
   * Get last sync error for a specific table
   * @param tableType Table type
   * @returns Last sync error message or null if no error
   */
  public getLastSyncError(tableType?: string): string | null | { [key: string]: string | null } {
    return tableType ? this.lastSyncError[tableType] || null : this.lastSyncError;
  }
  
  /**
   * Clear last sync error for a specific table
   * @param tableType Table type
   */
  public clearLastSyncError(tableType: string): void {
    delete this.lastSyncError[tableType];
  }

  /**
   * Set detected computed fields for a specific table
   * @param tableType Table type (e.g., 'leads', 'products')
   * @param fields Array of computed field names
   */
  public setDetectedComputedFields(tableType: string, fields: string[]): void {
    this.detectedComputedFields[tableType] = fields;
    console.info(`Detected computed fields for ${tableType}:`, fields);
  }

  /**
   * Get detected computed fields for a specific table or all tables
   * @param tableType Optional table type
   * @returns Record of table types to computed field arrays, or array of computed fields for specific table
   */
  public getDetectedComputedFields(tableType?: string): Record<string, string[]> | string[] {
    if (tableType) {
      return this.detectedComputedFields[tableType] || [];
    }
    return this.detectedComputedFields;
  }

  /**
   * Validate if a table exists in Airtable
   * @param tableName Table name
   * @returns Promise<object> with validation status
   */
  public async validateTableExists(tableName: string): Promise<{ success: boolean; message: string; details?: any }> {
    if (!this.config) {
      return { success: false, message: "Airtable not configured. Please provide credentials." };
    }

    try {
      const base = this.getAirtableBase();
      await base(tableName).select({ maxRecords: 1 }).firstPage();
      return { success: true, message: `Table '${tableName}' exists and is accessible` };
    } catch (error: any) {
      console.error(`Error validating table '${tableName}':`, error);
      return { success: false, message: getErrorMessage(error), details: error };
    }
  }

  /**
   * Sync leads with Airtable
   */
  public async syncLeads(leads: any[]): Promise<{ success: boolean; message: string; computedFields?: string[] }> {
    if (!this.isInitialized()) {
      console.error("Airtable service not initialized");
      return { success: false, message: "Airtable service not initialized" };
    }
    
    const tableName = this.getTableMapping().leads;
    
    if (!tableName) {
      console.error("Leads table not configured");
      return { success: false, message: "Leads table not configured" };
    }
    
    try {
      const result = await syncLeads(leads, tableName);
      this.clearLastSyncError('leads');
      return { success: true, message: "Leads synced successfully", computedFields: result.computedFields };
    } catch (error: any) {
      const message = getErrorMessage(error);
      this.setLastSyncError('leads', message);
      return { success: false, message };
    }
  }

  /**
   * Sync products with Airtable
   */
  public syncProducts(products: any[]): Promise<boolean> {
    if (!this.isInitialized()) {
      console.error("Airtable service not initialized");
      return Promise.resolve(false);
    }
    
    const tableName = this.getTableMapping().products;
    
    if (!tableName) {
      console.error("Products table not configured");
      return Promise.resolve(false);
    }
    
    try {
      // Pass products with images already formatted properly
      return syncProducts(products, tableName)
        .then(() => true)
        .catch((error: any) => {
          this.setLastSyncError('products', getErrorMessage(error));
          return false;
        });
    } catch (error) {
      this.setLastSyncError('products', getErrorMessage(error));
      return Promise.resolve(false);
    }
  }

  /**
   * Sync orders with Airtable
   */
  public async syncOrders(orders: any[]): Promise<boolean> {
    if (!this.isInitialized()) {
      console.error("Airtable service not initialized");
      return false;
    }
    
    const tableName = this.getTableMapping().orders;
    
    if (!tableName) {
      console.error("Orders table not configured");
      return false;
    }
    
    try {
      await syncOrders(orders, tableName);
      this.clearLastSyncError('orders');
      return true;
    } catch (error: any) {
      this.setLastSyncError('orders', getErrorMessage(error));
      return false;
    }
  }
  
  /**
   * Create and sync test data to Airtable
   * @returns Promise<object> with success status and messages for each type
   */
  public async createAndSyncTestData(): Promise<{
    success: boolean;
    messages: {
      leads?: string;
      orders?: string;
      products?: string;
      organizations?: string;
    };
  }> {
    if (!this.isInitialized()) {
      return {
        success: false,
        messages: {
          leads: "Airtable service not initialized",
          orders: "Airtable service not initialized",
          products: "Airtable service not initialized",
          organizations: "Airtable service not initialized"
        }
      };
    }
    
    const messages: {
      leads?: string;
      orders?: string;
      products?: string;
      organizations?: string;
    } = {};
    
    let overallSuccess = true;
    
    // Generate test data
    const { testLeads, testOrders, testProducts, testOrganizations } = createTestData();
    
    // Sync leads
    if (this.getTableMapping().leads) {
      try {
        const result = await this.syncLeads(testLeads);
        if (!result.success) {
          overallSuccess = false;
          messages.leads = "Failed to sync test leads";
        } else {
          messages.leads = `Successfully synced ${testLeads.length} test leads`;
        }
      } catch (error) {
        overallSuccess = false;
        messages.leads = getErrorMessage(error);
      }
    } else {
      messages.leads = "Leads table not configured";
    }
    
    // Sync products
    if (this.getTableMapping().products) {
      try {
        const success = await this.syncProducts(testProducts);
        if (!success) {
          overallSuccess = false;
          messages.products = "Failed to sync test products";
        } else {
          messages.products = `Successfully synced ${testProducts.length} test products`;
        }
      } catch (error) {
        overallSuccess = false;
        messages.products = getErrorMessage(error);
      }
    } else {
      messages.products = "Products table not configured";
    }
    
    // Sync orders
    if (this.getTableMapping().orders) {
      try {
        const success = await this.syncOrders(testOrders);
        if (!success) {
          overallSuccess = false;
          messages.orders = "Failed to sync test orders";
        } else {
          messages.orders = `Successfully synced ${testOrders.length} test orders`;
        }
      } catch (error) {
        overallSuccess = false;
        messages.orders = getErrorMessage(error);
      }
    } else {
      messages.orders = "Orders table not configured";
    }
    
    // Sync organizations
    if (this.getTableMapping().organizations) {
      try {
        // For organizations, let's use a similar approach as other entities
        const tableName = this.getTableMapping().organizations;
        const base = this.getAirtableBase();
        const table = base(tableName);
        
        // Create organizations records
        const orgRecords = testOrganizations.map(org => ({
          fields: {
            "Organization Name": org.name,
            "Phone": org.phone,
            "Email": org.email,
            "Billing Address": org.billingAddress,
            "Billing City": org.billingCity,
            "Billing State": org.billingState,
            "Billing Zip": org.billingZip,
            "Contact First Name": org.contactFirstName,
            "Contact Last Name": org.contactLastName,
            "Notes": "[TEST DATA] Organization created for Airtable sync testing"
          }
        }));
        
        await table.create(orgRecords);
        messages.organizations = `Successfully synced ${testOrganizations.length} test organizations`;
      } catch (error) {
        overallSuccess = false;
        messages.organizations = getErrorMessage(error);
      }
    } else {
      messages.organizations = "Organizations table not configured";
    }
    
    return {
      success: overallSuccess,
      messages
    };
  }
}

export const airtableService = new AirtableService();
