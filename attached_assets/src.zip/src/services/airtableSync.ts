import Airtable from 'airtable';
import { fieldMappings, knownComputedFields } from './airtableConfig';
import { getErrorMessage } from './airtableUtils';

// Initialize Airtable
function getAirtableBase() {
  const apiKey = localStorage.getItem('airtablePersonalAccessToken');
  const baseId = localStorage.getItem('airtableBaseId');

  if (!apiKey || !baseId) {
    throw new Error('Airtable API key or base ID not found in localStorage');
  }

  return new Airtable({ apiKey }).base(baseId);
}

/**
 * Discover existing fields in a table
 */
async function discoverTableFields(table: any): Promise<string[]> {
  try {
    const fields: string[] = [];
    const records = await table.select({ maxRecords: 1 }).firstPage();
    if (records && records.length > 0) {
      const record = records[0];
      fields.push(...Object.keys(record.fields));
    }
    return fields;
  } catch (error) {
    console.error(`Error discovering table fields: ${getErrorMessage(error)}`);
    return [];
  }
}

/**
 * Identify computed fields by checking existing records
 */
async function identifyComputedFields(table: any, knownComputedFieldsArr: string[]): Promise<string[]> {
  try {
    const computedFields: string[] = [...knownComputedFieldsArr];
    
    // Always add "Lead ID" to computed fields list since we know it's computed
    if (!computedFields.includes("Lead ID")) {
      computedFields.push("Lead ID");
    }
    
    const records = await table.select({ maxRecords: 10 }).firstPage();

    if (records && records.length > 0) {
      records.forEach(record => {
        Object.keys(record.fields).forEach(field => {
          if (record.fields[field] === null && !computedFields.includes(field)) {
            computedFields.push(field);
          }
        });
      });
    }

    return computedFields;
  } catch (error) {
    console.error(`Error identifying computed fields: ${getErrorMessage(error)}`);
    // Return at least the known computed fields
    return knownComputedFieldsArr.includes("Lead ID") ? knownComputedFieldsArr : [...knownComputedFieldsArr, "Lead ID"];
  }
}

/**
 * Cleanup existing records in a table
 */
async function cleanupExistingRecords(table: any): Promise<void> {
  try {
    const records = await table.select({}).firstPage();
    if (records && records.length > 0) {
      const recordIds = records.map(record => record.id);

      // Delete records in batches of 10
      const batchSize = 10;
      for (let i = 0; i < recordIds.length; i += batchSize) {
        const batch = recordIds.slice(i, i + batchSize);
        await table.destroy(batch);
      }

      console.info(`Successfully cleaned up ${recordIds.length} existing records`);
    } else {
      console.info('No existing records to cleanup');
    }
  } catch (error) {
    console.error(`Error cleaning up existing records: ${getErrorMessage(error)}`);
    throw error;
  }
}

/**
 * Sync leads with Airtable
 */
export async function syncLeads(leads: any[], tableName: string): Promise<{ success: boolean; computedFields?: string[] }> {
  console.info(`Starting sync of ${leads.length} leads to Airtable table: ${tableName}`);
  
  try {
    // Get the base and table
    const base = getAirtableBase();
    const table = base(tableName);
    
    // Get field mappings
    const fieldMappingsForLeads = fieldMappings.leads;
    const knownComputedFieldsForLeads = knownComputedFields.leads || [];
    
    // Add "Lead ID" to known computed fields if not already there
    if (!knownComputedFieldsForLeads.includes("Lead ID")) {
      knownComputedFieldsForLeads.push("Lead ID");
    }
    
    // Discover existing fields to avoid writing to computed fields
    const existingFields = await discoverTableFields(table);
    console.info(`Discovered existing fields in ${tableName}: ${JSON.stringify(existingFields)}`);
    
    // Identify computed fields from existing records
    const computedFields = await identifyComputedFields(table, knownComputedFieldsForLeads);
    console.info(`Identified computed fields in ${tableName}: ${JSON.stringify(computedFields)}`);
    
    // First, clear any existing records
    await cleanupExistingRecords(table);
    
    // Prepare records for Airtable
    const records = leads.map(lead => {
      // Create a new record object for Airtable
      const fields: Record<string, any> = {};
      
      // Map each lead field to Airtable field
      Object.entries(fieldMappingsForLeads).forEach(([appField, airtableField]) => {
        // Skip computed fields (especially "Lead ID")
        if (computedFields.includes(String(airtableField)) || String(airtableField) === "Lead ID") {
          console.info(`Skipping computed field: ${airtableField}`);
          return;
        }
        
        // Check if the field is defined in the lead
        if (lead[appField] !== undefined) {
          fields[String(airtableField)] = lead[appField];
        }
      });
      
      return { fields };
    });
    
    // If no records to sync, return success
    if (records.length === 0) {
      console.info(`No leads to sync to ${tableName}`);
      return { success: true, computedFields };
    }
    
    // Create records in batches of 10
    const batchSize = 10;
    for (let i = 0; i < records.length; i += batchSize) {
      const batch = records.slice(i, i + batchSize);
      await table.create(batch);
    }
    
    console.info(`Successfully synced ${records.length} leads to ${tableName}`);
    return { success: true, computedFields };
  } catch (error) {
    console.error(`Failed to sync leads to Airtable: ${getErrorMessage(error)}`);
    throw error;
  }
}

// Update the syncProducts method to handle formatted fields
export async function syncProducts(products: any[], tableName: string): Promise<boolean> {
  console.info(`Starting sync of ${products.length} products to Airtable table: ${tableName}`);
  
  try {
    // Get the base and table
    const base = getAirtableBase();
    const table = base(tableName);
    
    // Get field mappings
    const fieldMappingsForProducts = fieldMappings.products;
    const knownComputedFieldsForProducts = knownComputedFields.products || [];
    
    // Discover existing fields to avoid writing to computed fields
    const existingFields = await discoverTableFields(table);
    console.info(`Discovered existing fields in ${tableName}: ${JSON.stringify(existingFields)}`);
    
    // Identify computed fields from existing records
    const computedFields = await identifyComputedFields(table, knownComputedFieldsForProducts);
    console.info(`Identified computed fields in ${tableName}: ${JSON.stringify(computedFields)}`);
    
    // First, clear any existing records
    await cleanupExistingRecords(table);
    
    // Prepare records for Airtable
    const records = products.map(product => {
      // Create a new record object for Airtable
      const fields: Record<string, any> = {};
      
      // Map each product field to Airtable field
      Object.entries(fieldMappingsForProducts).forEach(([appField, airtableField]) => {
        // Skip computed fields
        if (computedFields.includes(String(airtableField))) {
          console.info(`Skipping computed field: ${airtableField}`);
          return;
        }
        
        // Check if the field is defined in the product
        if (product[appField] !== undefined) {
          // If the field is already properly formatted (as an object with proper structure),
          // use it directly, otherwise treat it as a regular field
          if (typeof product[appField] === 'object' && appField === 'imageUrl') {
            fields[String(airtableField)] = product[appField];
          } else {
            fields[String(airtableField)] = product[appField];
          }
        }
      });
      
      return { fields };
    });
    
    // If no records to sync, return true
    if (records.length === 0) {
      console.info(`No products to sync to ${tableName}`);
      return true;
    }
    
    // Create records in batches of 10
    const batchSize = 10;
    for (let i = 0; i < records.length; i += batchSize) {
      const batch = records.slice(i, i + batchSize);
      await table.create(batch);
    }
    
    console.info(`Successfully synced ${records.length} products to ${tableName}`);
    return true;
  } catch (error) {
    console.error(`Failed to sync products to Airtable: ${getErrorMessage(error)}`);
    throw error;
  }
}

/**
 * Sync orders with Airtable
 */
export async function syncOrders(orders: any[], tableName: string): Promise<boolean> {
  console.info(`Starting sync of ${orders.length} orders to Airtable table: ${tableName}`);
  
  try {
    // Get the base and table
    const base = getAirtableBase();
    const table = base(tableName);
    
    // Get field mappings
    const fieldMappingsForOrders = fieldMappings.orders;
    const knownComputedFieldsForOrders = knownComputedFields.orders || [];
    
    // Discover existing fields to avoid writing to computed fields
    const existingFields = await discoverTableFields(table);
    console.info(`Discovered existing fields in ${tableName}: ${JSON.stringify(existingFields)}`);
    
    // Identify computed fields from existing records
    const computedFields = await identifyComputedFields(table, knownComputedFieldsForOrders);
    console.info(`Identified computed fields in ${tableName}: ${JSON.stringify(computedFields)}`);
    
    // First, clear any existing records
    await cleanupExistingRecords(table);
    
    // Prepare records for Airtable
    const records = orders.map(order => {
      // Create a new record object for Airtable
      const fields: Record<string, any> = {};
      
      // Map each order field to Airtable field
      Object.entries(fieldMappingsForOrders).forEach(([appField, airtableField]) => {
        // Skip computed fields
        if (computedFields.includes(String(airtableField))) {
          console.info(`Skipping computed field: ${airtableField}`);
          return;
        }
        
        // Check if the field is defined in the order
        if (order[appField] !== undefined) {
          fields[String(airtableField)] = order[appField];
        }
      });
      
      return { fields };
    });
    
    // If no records to sync, return true
    if (records.length === 0) {
      console.info(`No orders to sync to ${tableName}`);
      return true;
    }
    
    // Create records in batches of 10
    const batchSize = 10;
    for (let i = 0; i < records.length; i += batchSize) {
      const batch = records.slice(i, i + batchSize);
      await table.create(batch);
    }
    
    console.info(`Successfully synced ${records.length} orders to ${tableName}`);
    return true;
  } catch (error) {
    console.error(`Failed to sync orders to Airtable: ${getErrorMessage(error)}`);
    throw error;
  }
}

/**
 * Create test data for leads, orders, and organizations
 */
export function createTestData() {
  // Create test leads
  const testLeads = [
    {
      id: `test-lead-${Date.now()}-1`,
      name: "Test Lead 1",
      organization: "Test Organization Alpha",
      email: "test1@example.com",
      phone: "555-111-2222",
      status: "prospect",
      dateCreated: new Date().toISOString().split('T')[0],
      dateUpdated: new Date().toISOString().split('T')[0],
      notes: "[TEST DATA] This is a test lead created for Airtable sync testing",
      estimatedValue: 5000
    },
    {
      id: `test-lead-${Date.now()}-2`,
      name: "Test Lead 2",
      organization: "Test Organization Beta",
      email: "test2@example.com",
      phone: "555-333-4444",
      status: "discovery",
      dateCreated: new Date().toISOString().split('T')[0],
      dateUpdated: new Date().toISOString().split('T')[0],
      notes: "[TEST DATA] Another test lead for Airtable sync testing",
      estimatedValue: 7500,
      assignedTo: "Test Sales Rep"
    }
  ];
  
  // Create test orders
  const testOrders = [
    {
      id: `test-order-${Date.now()}-1`,
      customerId: `test-customer-${Date.now()}-1`,
      customerName: "Test Organization Alpha",
      dateCreated: new Date().toISOString().split('T')[0],
      dateUpdated: new Date().toISOString().split('T')[0],
      status: "design",
      lineItems: [
        {
          id: `test-item-${Date.now()}-1`,
          productId: "p1",
          productName: "Test Product 1",
          quantity: 10,
          price: 59.99,
          size: "M",
          color: "Red",
          notes: "[TEST] Test line item note"
        }
      ],
      total: 599.90,
      notes: "[TEST DATA] This is a test order created for Airtable sync testing"
    },
    {
      id: `test-order-${Date.now()}-2`,
      customerId: `test-customer-${Date.now()}-2`,
      customerName: "Test Organization Beta",
      dateCreated: new Date().toISOString().split('T')[0],
      dateUpdated: new Date().toISOString().split('T')[0],
      status: "submitted",
      lineItems: [
        {
          id: `test-item-${Date.now()}-2`,
          productId: "p2",
          productName: "Test Product 2",
          quantity: 15,
          price: 29.99,
          size: "L",
          color: "Blue",
          notes: "[TEST] Test line item note 2"
        }
      ],
      total: 449.85,
      notes: "[TEST DATA] Another test order for Airtable sync testing"
    }
  ];
  
  // Create test organizations
  const testOrganizations = [
    {
      id: `test-org-${Date.now()}-1`,
      name: "Test Organization Alpha",
      phone: "555-111-2222",
      email: "org1@example.com",
      billingAddress: "123 Test St",
      billingCity: "Test City",
      billingState: "TS",
      billingZip: "12345",
      contactFirstName: "Test",
      contactLastName: "Contact"
    },
    {
      id: `test-org-${Date.now()}-2`,
      name: "Test Organization Beta",
      phone: "555-333-4444",
      email: "org2@example.com",
      billingAddress: "456 Test Ave",
      billingCity: "Test Town",
      billingState: "TS",
      billingZip: "67890",
      contactFirstName: "Beta",
      contactLastName: "Tester"
    }
  ];
  
  // Create test products
  const testProducts = [
    {
      id: `test-product-${Date.now()}-1`,
      name: "Test Product Alpha",
      category: "Test Category",
      sport: "Test Sport",
      price: 59.99,
      description: "[TEST] This is a test product for Airtable sync testing",
      imageUrl: "https://images.unsplash.com/photo-1517466787929-bc90951d0974",
      inventory: 100,
      sizes: ["S", "M", "L"],
      colors: ["Red", "Blue"]
    },
    {
      id: `test-product-${Date.now()}-2`,
      name: "Test Product Beta",
      category: "Test Category 2",
      sport: "Test Sport 2",
      price: 79.99,
      description: "[TEST] Another test product for Airtable sync testing",
      imageUrl: "https://images.unsplash.com/photo-1515186913263-765fdce3ec6c",
      inventory: 75,
      sizes: ["M", "L", "XL"],
      colors: ["Green", "Black"]
    }
  ];
  
  return {
    testLeads,
    testOrders,
    testOrganizations,
    testProducts
  };
}
