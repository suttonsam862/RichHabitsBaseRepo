
import { AirtableConfig } from "./airtableConfig";
import Airtable from 'airtable';
import { fieldMappings, fieldTypeMap, knownComputedFields } from './airtableConfig';

/**
 * Utility functions for Airtable integration
 */

/**
 * Get Airtable configuration from localStorage
 */
export function getAirtableConfig(): AirtableConfig {
  const personalAccessToken = localStorage.getItem('airtablePersonalAccessToken') || '';
  const baseId = localStorage.getItem('airtableBaseId') || '';

  return {
    personalAccessToken,
    baseId,
  };
}

/**
 * Get Airtable base instance
 */
export function getAirtableBase(): any {
  const { personalAccessToken, baseId } = getAirtableConfig();

  if (!personalAccessToken || !baseId) {
    throw new Error('Airtable personal access token and base ID must be configured.');
  }

  return new Airtable({ apiKey: personalAccessToken }).base(baseId);
}

/**
 * Get field mappings for a specific table
 */
export function getFieldMappings(tableType: string): Record<string, string> | undefined {
  return fieldMappings[tableType];
}

/**
 * Get known computed fields for a specific table
 */
export function getKnownComputedFields(tableType: string): string[] {
  return knownComputedFields[tableType] || [];
}

/**
 * Get debug information for Airtable integration
 */
export function getDebugInfo(): any {
  return {
    config: getAirtableConfig(),
    fieldMappings: getFieldMappings('leads'),
    knownComputedFields: getKnownComputedFields('leads'),
    localStorage: { ...localStorage },
  };
}

/**
 * Discover table fields
 */
export async function discoverTableFields(table: any): Promise<string[]> {
  try {
    const records = await table.select({ maxRecords: 1 }).firstPage();
    if (records && records[0]) {
      return Object.keys(records[0].fields);
    }
    return [];
  } catch (error) {
    console.error("Error discovering table fields:", error);
    return [];
  }
}

/**
 * Identify computed fields
 */
export async function identifyComputedFields(table: any, knownComputedFields: string[]): Promise<string[]> {
  try {
    const records = await table.select({ maxRecords: 1 }).firstPage();
    if (records && records[0]) {
      const allFields = Object.keys(records[0].fields);
      const computedFields = allFields.filter(field => !knownComputedFields.includes(field));
      return computedFields;
    }
    return [];
  } catch (error) {
    console.error("Error identifying computed fields:", error);
    return [];
  }
}

/**
 * Cleanup existing records
 */
export async function cleanupExistingRecords(table: any): Promise<void> {
  try {
    const records = await table.select({}).firstPage();
    if (records && records.length > 0) {
      const recordIds = records.map(record => record.id);

      // Delete records in batches of 10
      const batchSize = 10;
      for (let i = 0; i < recordIds.length; i += batchSize) {
        const batch = recordIds.slice(i, i + batchSize);
        await table.destroy(batch);
      }

      console.log(`Successfully cleaned up ${recordIds.length} existing records.`);
    } else {
      console.log('No existing records to cleanup.');
    }
  } catch (error) {
    console.error("Error cleaning up existing records:", error);
    throw error;
  }
}

/**
 * Get error message
 */
export function getErrorMessage(error: any): string {
  return error instanceof Error ? error.message : JSON.stringify(error);
}

/**
 * Format fields for Airtable based on field type
 */
export function formatFieldsForAirtable(tableType: string, data: Record<string, any>): Record<string, any> {
  const result: Record<string, any> = {};
  const mappings = fieldMappings[tableType];
  const typeMap = fieldTypeMap[tableType];
  
  if (!mappings) return data;
  
  // Reverse the field mappings to go from app field to Airtable field
  const reverseMappings: Record<string, string> = {};
  Object.entries(mappings).forEach(([appField, airtableField]) => {
    reverseMappings[appField] = String(airtableField);
  });
  
  // Map each field in the data to its Airtable equivalent
  Object.entries(data).forEach(([appField, value]) => {
    const airtableField = reverseMappings[appField];
    
    if (!airtableField) return; // Skip fields that don't have a mapping
    
    // Format the value based on field type
    if (typeMap && typeMap[airtableField] === 'attachment' && typeof value === 'string' && value) {
      // Handle attachment fields (convert URL string to attachment object array)
      result[airtableField] = [{ url: value }];
    } else {
      // Handle all other field types normally
      result[airtableField] = value;
    }
  });
  
  return result;
}

/**
 * Get field type mappings for a specific table
 */
export function getFieldTypeMap(tableType: string): Record<string, string> {
  return fieldTypeMap[tableType] || {};
}
