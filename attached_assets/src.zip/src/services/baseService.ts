
import { supabase } from '@/lib/supabase';
import { handleSupabaseError } from '@/lib/supabase';
import { toast } from 'sonner';
import type { Database } from '@/lib/database.types';

// Type definitions
export type Lead = Database['public']['Tables']['leads']['Row'];
export type Organization = Database['public']['Tables']['organizations']['Row'];
export type Product = Database['public']['Tables']['products']['Row'];
export type Order = Database['public']['Tables']['orders']['Row'];
export type LineItem = Database['public']['Tables']['line_items']['Row'];

export type LeadStatus = Database['public']['Enums']['lead_status'];
export type OrderStatus = Database['public']['Enums']['order_status'];

export type NewLead = Database['public']['Tables']['leads']['Insert'];
export type NewOrganization = Database['public']['Tables']['organizations']['Insert'];
export type NewOrder = Database['public']['Tables']['orders']['Insert'];
export type NewLineItem = Database['public']['Tables']['line_items']['Insert'];

// Export the supabase client for use in service files
export { supabase, handleSupabaseError };
