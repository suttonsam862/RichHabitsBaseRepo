
import { supabase } from "@/lib/supabase";
import { toast } from "sonner";

export interface Designer {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  rate_per_design: number;
  address: string | null;
  city: string | null;
  state: string | null;
  zip: string | null;
  profile_image_url: string | null;
  bank_account: string | null;
  tax_id: string | null;
  notes: string | null;
}

export interface DesignSubmission {
  id: string;
  design_type: string;
  designer_id: string | null;
  order_id: string | null;
  submission_date: string | null;
  status: string;
  feedback: string | null;
  notes: string | null;
  image_url: string | null;
  payment_status: string | null;
  payment_amount: number | null;
  payment_date: string | null;
  created_at: string | null;
  updated_at: string | null;
}

export const designService = {
  // Get all designers
  async getDesigners(): Promise<Designer[]> {
    const { data, error } = await supabase
      .from('designers')
      .select('*')
      .order('name');
    
    if (error) {
      console.error('Error fetching designers:', error);
      toast.error('Failed to load designers');
      return [];
    }
    
    return data || [];
  },
  
  // Get a designer by ID
  async getDesigner(id: string): Promise<Designer | null> {
    const { data, error } = await supabase
      .from('designers')
      .select('*')
      .eq('id', id)
      .single();
      
    if (error) {
      if (error.code !== 'PGRST116') { // No rows returned
        console.error('Error fetching designer:', error);
        toast.error('Failed to load designer details');
      }
      return null;
    }
    
    return data;
  },
  
  // Create a new designer
  async createDesigner(designer: Omit<Designer, 'id'>): Promise<Designer | null> {
    const { data, error } = await supabase
      .from('designers')
      .insert([designer])
      .select()
      .single();
      
    if (error) {
      console.error('Error creating designer:', error);
      toast.error('Failed to create designer');
      return null;
    }
    
    toast.success('Designer created successfully');
    return data;
  },
  
  // Update a designer
  async updateDesigner(id: string, updates: Partial<Designer>): Promise<Designer | null> {
    const { data, error } = await supabase
      .from('designers')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
      
    if (error) {
      console.error('Error updating designer:', error);
      toast.error('Failed to update designer');
      return null;
    }
    
    toast.success('Designer updated successfully');
    return data;
  },
  
  // Delete a designer
  async deleteDesigner(id: string): Promise<boolean> {
    const { error } = await supabase
      .from('designers')
      .delete()
      .eq('id', id);
      
    if (error) {
      console.error('Error deleting designer:', error);
      toast.error('Failed to delete designer');
      return false;
    }
    
    toast.success('Designer deleted successfully');
    return true;
  },

  // Get design submissions
  async getDesignSubmissions(): Promise<DesignSubmission[]> {
    const { data, error } = await supabase
      .from('design_submissions')
      .select('*')
      .order('submission_date', { ascending: false });
    
    if (error) {
      console.error('Error fetching design submissions:', error);
      toast.error('Failed to load design submissions');
      return [];
    }
    
    return data || [];
  },

  // Get design submissions by designer ID
  async getDesignSubmissionsByDesigner(designerId: string): Promise<DesignSubmission[]> {
    const { data, error } = await supabase
      .from('design_submissions')
      .select('*')
      .eq('designer_id', designerId)
      .order('submission_date', { ascending: false });
    
    if (error) {
      console.error('Error fetching design submissions by designer:', error);
      toast.error('Failed to load design submissions');
      return [];
    }
    
    return data || [];
  },

  // Sync designer users from auth context to designers table
  async syncDesignerUsers(): Promise<boolean> {
    try {
      // Demo designer user from AuthContext
      const designerUsers = [
        {
          id: "2",
          name: "Designer User",
          email: "designer@example.com",
          rate_per_design: 75
        }
      ];

      for (const user of designerUsers) {
        // Check if user already exists in designers
        const { data: existingDesigner } = await supabase
          .from('designers')
          .select('id')
          .eq('email', user.email)
          .maybeSingle();

        if (!existingDesigner) {
          // Create new designer record if doesn't exist
          await this.createDesigner({
            name: user.name,
            email: user.email,
            phone: null,
            rate_per_design: user.rate_per_design,
            address: null,
            city: null,
            state: null,
            zip: null,
            profile_image_url: null,
            bank_account: null,
            tax_id: null,
            notes: "Auto-created from user account"
          });
        }
      }
      
      return true;
    } catch (error) {
      console.error("Error syncing designer users:", error);
      toast.error(`Error syncing designer users: ${error.message}`);
      return false;
    }
  }
};
