
import { supabase, handleSupabaseError } from '@/lib/supabase';
import { toast } from 'sonner';

// Define GitHub-related types
export interface GitHubRepository {
  id: number;
  name: string;
  full_name: string;
  html_url: string;
  description: string | null;
  private: boolean;
  owner: {
    login: string;
    avatar_url: string;
  };
  created_at: string;
  updated_at: string;
  pushed_at: string;
  default_branch: string;
}

export interface GitHubBranch {
  name: string;
  commit: {
    sha: string;
    url: string;
  };
  protected: boolean;
}

export interface GitHubCommit {
  sha: string;
  commit: {
    author: {
      name: string;
      email: string;
      date: string;
    };
    message: string;
  };
  html_url: string;
  author: {
    login: string;
    avatar_url: string;
  } | null;
}

export interface GitHubUser {
  login: string;
  id: number;
  avatar_url: string;
  html_url: string;
  name: string | null;
  company: string | null;
  email: string | null;
  bio: string | null;
}

// Define the GitHub connection state
export interface GitHubConnection {
  id: string;
  user_id: string;
  access_token: string;
  github_username: string;
  connected_at: string;
  repositories: GitHubRepository[];
  selected_repository?: string;
  sync_status: 'active' | 'paused' | 'error';
  last_synced_at?: string;
  error_message?: string;
}

export const githubService = {
  // Store GitHub access token and connection info
  async storeConnection(accessToken: string, username: string): Promise<boolean> {
    console.log('Storing GitHub connection for user:', username);
    try {
      const user = supabase.auth.getUser();
      const userId = (await user).data.user?.id;
      
      if (!userId) {
        toast.error('User not authenticated');
        return false;
      }
      
      // Store the connection in the database
      const { error } = await supabase
        .from('github_connections')
        .upsert({
          user_id: userId,
          access_token: accessToken,
          github_username: username,
          connected_at: new Date().toISOString(),
          sync_status: 'active'
        }, {
          onConflict: 'user_id'
        });
      
      if (error) {
        toast.error(`Error storing GitHub connection: ${handleSupabaseError(error)}`);
        console.error('Error storing GitHub connection:', error);
        return false;
      }
      
      toast.success('GitHub connection stored successfully');
      return true;
    } catch (error) {
      console.error('Error in storeConnection:', error);
      toast.error('Failed to store GitHub connection');
      return false;
    }
  },
  
  // Get GitHub connection for current user
  async getConnection(): Promise<GitHubConnection | null> {
    console.log('Getting GitHub connection for current user');
    try {
      const user = supabase.auth.getUser();
      const userId = (await user).data.user?.id;
      
      if (!userId) {
        console.log('User not authenticated');
        return null;
      }
      
      const { data, error } = await supabase
        .from('github_connections')
        .select('*')
        .eq('user_id', userId)
        .single();
      
      if (error) {
        console.error('Error fetching GitHub connection:', error);
        return null;
      }
      
      return data as GitHubConnection;
    } catch (error) {
      console.error('Error in getConnection:', error);
      return null;
    }
  },
  
  // Disconnect GitHub integration
  async disconnect(): Promise<boolean> {
    console.log('Disconnecting GitHub integration');
    try {
      const user = supabase.auth.getUser();
      const userId = (await user).data.user?.id;
      
      if (!userId) {
        toast.error('User not authenticated');
        return false;
      }
      
      const { error } = await supabase
        .from('github_connections')
        .delete()
        .eq('user_id', userId);
      
      if (error) {
        toast.error(`Error disconnecting GitHub: ${handleSupabaseError(error)}`);
        console.error('Error disconnecting GitHub:', error);
        return false;
      }
      
      toast.success('GitHub disconnected successfully');
      return true;
    } catch (error) {
      console.error('Error in disconnect:', error);
      toast.error('Failed to disconnect GitHub');
      return false;
    }
  },
  
  // Fetch repositories from GitHub
  async fetchRepositories(): Promise<GitHubRepository[]> {
    console.log('Fetching GitHub repositories');
    try {
      const connection = await this.getConnection();
      
      if (!connection || !connection.access_token) {
        toast.error('GitHub not connected');
        return [];
      }
      
      const response = await fetch('https://api.github.com/user/repos?sort=updated', {
        headers: {
          'Authorization': `token ${connection.access_token}`,
          'Accept': 'application/vnd.github.v3+json'
        }
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        console.error('GitHub API error:', errorData);
        toast.error(`GitHub API error: ${errorData.message || 'Unknown error'}`);
        return [];
      }
      
      const repositories = await response.json();
      
      // Update the connection with the fetched repositories
      await supabase
        .from('github_connections')
        .update({
          repositories: repositories,
          last_synced_at: new Date().toISOString()
        })
        .eq('user_id', connection.user_id);
      
      return repositories;
    } catch (error) {
      console.error('Error fetching repositories:', error);
      toast.error('Failed to fetch GitHub repositories');
      return [];
    }
  },
  
  // Export data to GitHub (creates a new file or updates existing file)
  async exportDataToGitHub(
    repoName: string, 
    path: string, 
    content: string, 
    message: string = 'Update from app'
  ): Promise<boolean> {
    console.log(`Exporting data to GitHub repo: ${repoName}, path: ${path}`);
    try {
      const connection = await this.getConnection();
      
      if (!connection || !connection.access_token) {
        toast.error('GitHub not connected');
        return false;
      }
      
      // First check if the file already exists to get the SHA
      const checkResponse = await fetch(`https://api.github.com/repos/${connection.github_username}/${repoName}/contents/${path}`, {
        headers: {
          'Authorization': `token ${connection.access_token}`,
          'Accept': 'application/vnd.github.v3+json'
        }
      });
      
      let sha: string | undefined;
      
      if (checkResponse.status === 200) {
        const fileData = await checkResponse.json();
        sha = fileData.sha;
      }
      
      // Create or update the file
      const response = await fetch(`https://api.github.com/repos/${connection.github_username}/${repoName}/contents/${path}`, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${connection.access_token}`,
          'Accept': 'application/vnd.github.v3+json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message,
          content: btoa(unescape(encodeURIComponent(content))), // Base64 encode content
          sha: sha // Include if updating an existing file
        })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        console.error('GitHub API error:', errorData);
        toast.error(`GitHub API error: ${errorData.message || 'Unknown error'}`);
        return false;
      }
      
      toast.success(`Data exported to GitHub: ${path}`);
      return true;
    } catch (error) {
      console.error('Error exporting data to GitHub:', error);
      toast.error('Failed to export data to GitHub');
      return false;
    }
  },
  
  // Sync Leads to GitHub
  async syncLeadsToGitHub(repoName: string): Promise<boolean> {
    console.log(`Syncing leads to GitHub repo: ${repoName}`);
    try {
      // Import from services index to avoid circular dependencies
      const { leadService } = await import('@/services');
      
      // Get all leads
      const leads = await leadService.getAll();
      
      // Format leads as JSON
      const content = JSON.stringify(leads, null, 2);
      
      // Export to GitHub
      return await this.exportDataToGitHub(
        repoName,
        'data/leads.json',
        content,
        'Update leads from application'
      );
    } catch (error) {
      console.error('Error syncing leads to GitHub:', error);
      toast.error('Failed to sync leads to GitHub');
      return false;
    }
  },
  
  // Sync Orders to GitHub
  async syncOrdersToGitHub(repoName: string): Promise<boolean> {
    console.log(`Syncing orders to GitHub repo: ${repoName}`);
    try {
      // Import from services index to avoid circular dependencies
      const { orderService } = await import('@/services');
      
      // Get all orders
      const orders = await orderService.getAll();
      
      // Format orders as JSON
      const content = JSON.stringify(orders, null, 2);
      
      // Export to GitHub
      return await this.exportDataToGitHub(
        repoName,
        'data/orders.json',
        content,
        'Update orders from application'
      );
    } catch (error) {
      console.error('Error syncing orders to GitHub:', error);
      toast.error('Failed to sync orders to GitHub');
      return false;
    }
  },
  
  // Sync all data to GitHub
  async syncAllDataToGitHub(repoName: string): Promise<boolean> {
    console.log(`Syncing all data to GitHub repo: ${repoName}`);
    try {
      const leadsSuccess = await this.syncLeadsToGitHub(repoName);
      const ordersSuccess = await this.syncOrdersToGitHub(repoName);
      
      // Update last synced timestamp
      const connection = await this.getConnection();
      if (connection) {
        await supabase
          .from('github_connections')
          .update({
            last_synced_at: new Date().toISOString(),
            sync_status: leadsSuccess && ordersSuccess ? 'active' : 'error',
            error_message: !leadsSuccess || !ordersSuccess ? 'Partial sync failure' : null
          })
          .eq('user_id', connection.user_id);
      }
      
      if (leadsSuccess && ordersSuccess) {
        toast.success('All data synced to GitHub successfully');
        return true;
      } else {
        toast.warning('Some data failed to sync to GitHub');
        return false;
      }
    } catch (error) {
      console.error('Error syncing all data to GitHub:', error);
      toast.error('Failed to sync data to GitHub');
      return false;
    }
  }
};

// Export the GitHub service
export default githubService;
