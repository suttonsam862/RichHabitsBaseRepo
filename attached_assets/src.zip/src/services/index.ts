
// Re-export all services
export * from './baseService';
// Export leadService explicitly without re-exporting duplicate types
export { leadService } from './leadService';
export type { Lead, NewLead, LeadStatus } from './leadService';
// Export orderService explicitly without re-exporting duplicate types
export { orderService } from './orderService';
export type { Order as OrderServiceOrder, NewOrder as OrderServiceNewOrder, OrderStatus as OrderServiceStatus } from './orderService';
export * from './organizationService';
export * from './productService';
// Export lineItemService explicitly without re-exporting LineItem type
export { lineItemService } from './lineItemService';
export * from './leadToOrderService';
export * from './designService';
export * from './salesPersonService';
export * from './manufacturingService';
export * from './quickbooksService';
export * from './githubService';
