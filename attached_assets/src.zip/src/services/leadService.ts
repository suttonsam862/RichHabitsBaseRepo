
import { supabase, handleSupabaseError } from '@/lib/supabase';
import { toast } from 'sonner';
import { mapSupabaseLeadToApiLead } from '@/utils/dataMappers';
import { Lead as ApiLead } from '@/lib/api';

export type LeadStatus = 'prospect' | 'discovery' | 'qualified' | 'negotiation' | 'closed-won' | 'closed-lost';

export interface Lead {
  id: string;
  name: string;
  organization: string;
  email?: string | null;
  phone?: string | null;
  status: LeadStatus;
  notes?: string | null;
  owner?: string | null;
  owner_id?: string | null;
  assigned_to?: string | null;
  assigned_user_id?: string | null;
  estimated_value?: number | null;
  created_at: string;
  updated_at: string;
  organization_id?: string | null;
}

export interface NewLead {
  name: string;
  organization: string;
  email?: string | null;
  phone?: string | null;
  status: LeadStatus;
  notes?: string | null;
  owner?: string | null;
  estimated_value?: number | null;
  organization_id?: string | null;
}

export const leadService = {
  // Get all leads
  async getAll(): Promise<ApiLead[]> {
    console.log('Fetching all leads');
    const { data, error } = await supabase
      .from('leads')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) {
      toast.error(`Error fetching leads: ${handleSupabaseError(error)}`);
      console.error('Error fetching leads:', error);
      return [];
    }
    
    console.log('Leads fetched successfully:', data?.length || 0);
    return data ? data.map(mapSupabaseLeadToApiLead) : [];
  },
  
  // Create a new lead
  async create(lead: NewLead): Promise<ApiLead | null> {
    console.log('Creating new lead:', lead);
    const { data, error } = await supabase
      .from('leads')
      .insert([lead])
      .select()
      .single();
    
    if (error) {
      toast.error(`Error creating lead: ${handleSupabaseError(error)}`);
      console.error('Error creating lead:', error);
      return null;
    }
    
    toast.success('Lead created successfully');
    return mapSupabaseLeadToApiLead(data);
  },
  
  // Create a demo lead - method used from Index.tsx
  async createDemoLead(
    name: string, 
    organization: string, 
    email: string, 
    phone: string
  ): Promise<ApiLead | null> {
    const newLead: NewLead = {
      name,
      organization,
      email,
      phone,
      status: 'prospect',
      notes: 'This is a demo lead created for testing purposes.',
      estimated_value: 5000
    };
    
    return await this.create(newLead);
  },
  
  // Get a lead by ID
  async getById(id: string): Promise<ApiLead | null> {
    console.log(`Fetching lead with ID: ${id}`);
    const { data, error } = await supabase
      .from('leads')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      toast.error(`Error fetching lead: ${handleSupabaseError(error)}`);
      console.error('Error fetching lead:', error);
      return null;
    }
    
    return mapSupabaseLeadToApiLead(data);
  },
  
  // Update a lead
  async update(leadUpdate: Partial<ApiLead>): Promise<ApiLead | null> {
    console.log('Updating lead:', leadUpdate);
    const { data, error } = await supabase
      .from('leads')
      .update(leadUpdate)
      .eq('id', leadUpdate.id)
      .select()
      .single();
    
    if (error) {
      toast.error(`Error updating lead: ${handleSupabaseError(error)}`);
      console.error('Error updating lead:', error);
      return null;
    }
    
    toast.success('Lead updated successfully');
    return mapSupabaseLeadToApiLead(data);
  },
  
  // Delete a lead
  async delete(id: string): Promise<boolean> {
    console.log(`Deleting lead with ID: ${id}`);
    const { error } = await supabase
      .from('leads')
      .delete()
      .eq('id', id);
    
    if (error) {
      toast.error(`Error deleting lead: ${handleSupabaseError(error)}`);
      console.error('Error deleting lead:', error);
      return false;
    }
    
    toast.success('Lead deleted successfully');
    return true;
  },
  
  // Update a lead's status
  async updateStatus(id: string, status: LeadStatus): Promise<ApiLead | null> {
    console.log(`Updating lead ${id} status to ${status}`);
    return await this.update({ id, status });
  },
  
  // Claim a lead (assign to the current user)
  async claim(id: string, ownerEmail: string): Promise<ApiLead | null> {
    console.log(`Claiming lead ${id} for user ${ownerEmail}`);
    return await this.update({ 
      id, 
      owner: ownerEmail,
      assigned_to: ownerEmail,
      claimed_at: new Date().toISOString()
    });
  },
  
  // Alias methods to match function calls in Leads.tsx
  async claimLead(id: string, ownerEmail: string): Promise<ApiLead | null> {
    return await this.claim(id, ownerEmail);
  },
  
  async createLead(leadData: any): Promise<ApiLead | null> {
    return await this.create(leadData);
  },
  
  async updateLead(leadData: Partial<ApiLead>): Promise<ApiLead | null> {
    return await this.update(leadData);
  },
  
  async deleteLead(id: string): Promise<boolean> {
    return await this.delete(id);
  }
};
