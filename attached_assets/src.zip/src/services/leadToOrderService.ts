
import { orderService } from './orderService';
import { organizationService } from './organizationService';
import { Lead as ApiLead } from '@/lib/api';
import { toast } from 'sonner';
import { LeadStatus } from './baseService';

export const leadToOrderService = {
  /**
   * Convert a lead to an order
   * This creates an organization and an order
   */
  async convertLeadToOrder(lead: ApiLead): Promise<boolean> {
    try {
      // Create organization from lead
      const organization = await organizationService.createFromLead({
        name: lead.name,
        organization: lead.organization,
        email: lead.email,
        phone: lead.phone,
        status: lead.status as LeadStatus,
        notes: lead.notes,
        estimated_value: lead.estimatedValue,
        owner: lead.owner || null,
        assigned_to: lead.assignedTo || null,
        id: lead.id,
        created_at: lead.dateCreated,
        updated_at: lead.dateUpdated,
        claimed_at: null,
        organization_id: null
      });
      
      if (!organization) {
        toast.error('Failed to create organization from lead');
        return false;
      }
      
      // Create order from lead and link to organization
      const order = await orderService.createFromLead({
        id: lead.id,
        name: lead.name,
        organization: lead.organization,
        email: lead.email,
        phone: lead.phone,
        status: lead.status as LeadStatus,
        notes: lead.notes,
        estimated_value: lead.estimatedValue,
        owner: lead.owner,
        assigned_to: lead.assignedTo,
        created_at: lead.dateCreated,
        updated_at: lead.dateUpdated,
        claimed_at: null,
        organization_id: null
      }, organization.id);
      
      if (!order) {
        toast.error('Failed to create order from lead');
        return false;
      }
      
      toast.success('Successfully converted lead to order');
      return true;
    } catch (error) {
      console.error('Error converting lead to order:', error);
      toast.error('Failed to convert lead to order');
      return false;
    }
  }
};
