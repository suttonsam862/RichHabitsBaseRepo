
import { supabase, handleSupabaseError } from './baseService';
import { toast } from 'sonner';

export interface LineItem {
  id: string;
  order_id: string;
  product_id: string;
  quantity: number;
  unit_price: number;
  size: string | null;
  color: string | null;
  notes: string | null;
  customization: string | null;
  created_at: string;
  updated_at: string;
}

export const lineItemService = {
  // Get all line items
  async getAll(): Promise<LineItem[]> {
    const { data, error } = await supabase
      .from('line_items')
      .select('*');
    
    if (error) {
      toast.error(`Error fetching line items: ${handleSupabaseError(error)}`);
      return [];
    }
    
    return data || [];
  },
  
  // Get line items by order ID
  async getByOrderId(orderId: string): Promise<LineItem[]> {
    const { data, error } = await supabase
      .from('line_items')
      .select('*')
      .eq('order_id', orderId)
      .order('created_at', { ascending: true });
    
    if (error) {
      toast.error(`Error fetching line items: ${handleSupabaseError(error)}`);
      return [];
    }
    
    return data || [];
  },
  
  // Create a new line item
  async create(lineItem: Omit<LineItem, 'id' | 'created_at' | 'updated_at'>): Promise<LineItem | null> {
    const { data, error } = await supabase
      .from('line_items')
      .insert([lineItem])
      .select()
      .single();
    
    if (error) {
      toast.error(`Error creating line item: ${handleSupabaseError(error)}`);
      return null;
    }
    
    toast.success('Line item created successfully');
    return data;
  }
};
