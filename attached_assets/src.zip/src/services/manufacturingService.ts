
import { supabase } from "@/lib/supabase";
import { toast } from "sonner";

export interface ManufacturingStaff {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  role: string;
  department: string | null;
  hire_date: string | null;
  hourly_rate: number | null;
  skills: string[] | null;
  certifications: string[] | null;
  address: string | null;
  city: string | null;
  state: string | null;
  zip: string | null;
  profile_image_url: string | null;
  bank_account: string | null;
  tax_id: string | null;
  notes: string | null;
}

export interface ManufacturingVendor {
  id: string;
  name: string;
  contact_person: string | null;
  email: string | null;
  phone: string | null;
  address: string | null;
  city: string | null;
  state: string | null;
  zip: string | null;
  country: string | null;
  company_size: number | null;
  region: string | null;
  specialties: string[] | null;
  cost_per_unit: number | null;
  lead_time: number | null;
  minimum_order: number | null;
  active: boolean | null;
  notes: string | null;
  average_turnaround_time: number | null;
  created_at: string | null;
  updated_at: string | null;
}

export interface ProductionOrder {
  id: string;
  order_id: string;
  status: string;
  priority: string;
  assigned_to: string | null;
  start_date: string | null;
  due_date: string | null;
  completion_date: string | null;
  notes: string | null;
  created_at: string | null;
  updated_at: string | null;
}

export const manufacturingService = {
  // Get all manufacturing staff
  async getManufacturingStaff(): Promise<ManufacturingStaff[]> {
    const { data, error } = await supabase
      .from('manufacturing_staff')
      .select('*')
      .order('name');
    
    if (error) {
      console.error('Error fetching manufacturing staff:', error);
      toast.error('Failed to load manufacturing staff');
      return [];
    }
    
    return data || [];
  },
  
  // Get a manufacturing staff member by ID
  async getManufacturingStaffMember(id: string): Promise<ManufacturingStaff | null> {
    const { data, error } = await supabase
      .from('manufacturing_staff')
      .select('*')
      .eq('id', id)
      .single();
      
    if (error) {
      if (error.code !== 'PGRST116') { // No rows returned
        console.error('Error fetching manufacturing staff member:', error);
        toast.error('Failed to load manufacturing staff member details');
      }
      return null;
    }
    
    return data;
  },
  
  // Create a new manufacturing staff member
  async createManufacturingStaffMember(
    staffMember: Omit<ManufacturingStaff, 'id'>
  ): Promise<ManufacturingStaff | null> {
    const { data, error } = await supabase
      .from('manufacturing_staff')
      .insert([staffMember])
      .select()
      .single();
      
    if (error) {
      console.error('Error creating manufacturing staff member:', error);
      toast.error('Failed to create manufacturing staff member');
      return null;
    }
    
    toast.success('Manufacturing staff member created successfully');
    return data;
  },
  
  // Update a manufacturing staff member
  async updateManufacturingStaffMember(
    id: string, 
    updates: Partial<ManufacturingStaff>
  ): Promise<ManufacturingStaff | null> {
    const { data, error } = await supabase
      .from('manufacturing_staff')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
      
    if (error) {
      console.error('Error updating manufacturing staff member:', error);
      toast.error('Failed to update manufacturing staff member');
      return null;
    }
    
    toast.success('Manufacturing staff member updated successfully');
    return data;
  },
  
  // Delete a manufacturing staff member
  async deleteManufacturingStaffMember(id: string): Promise<boolean> {
    const { error } = await supabase
      .from('manufacturing_staff')
      .delete()
      .eq('id', id);
      
    if (error) {
      console.error('Error deleting manufacturing staff member:', error);
      toast.error('Failed to delete manufacturing staff member');
      return false;
    }
    
    toast.success('Manufacturing staff member deleted successfully');
    return true;
  },

  // Get all manufacturing vendors
  async getManufacturingVendors(): Promise<ManufacturingVendor[]> {
    const { data, error } = await supabase
      .from('manufacturing_vendors')
      .select('*')
      .order('name');
    
    if (error) {
      console.error('Error fetching manufacturing vendors:', error);
      toast.error('Failed to load manufacturing vendors');
      return [];
    }
    
    return data || [];
  },
  
  // Get a manufacturing vendor by ID
  async getManufacturingVendor(id: string): Promise<ManufacturingVendor | null> {
    const { data, error } = await supabase
      .from('manufacturing_vendors')
      .select('*')
      .eq('id', id)
      .single();
      
    if (error) {
      if (error.code !== 'PGRST116') { // No rows returned
        console.error('Error fetching manufacturing vendor:', error);
        toast.error('Failed to load manufacturing vendor details');
      }
      return null;
    }
    
    return data;
  },
  
  // Create a new manufacturing vendor
  async createManufacturingVendor(
    vendor: Omit<ManufacturingVendor, 'id' | 'created_at' | 'updated_at'>
  ): Promise<ManufacturingVendor | null> {
    const { data, error } = await supabase
      .from('manufacturing_vendors')
      .insert([vendor])
      .select()
      .single();
      
    if (error) {
      console.error('Error creating manufacturing vendor:', error);
      toast.error('Failed to create manufacturing vendor');
      return null;
    }
    
    toast.success('Manufacturing vendor created successfully');
    return data;
  },
  
  // Update a manufacturing vendor
  async updateManufacturingVendor(
    id: string, 
    updates: Partial<ManufacturingVendor>
  ): Promise<ManufacturingVendor | null> {
    const { data, error } = await supabase
      .from('manufacturing_vendors')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
      
    if (error) {
      console.error('Error updating manufacturing vendor:', error);
      toast.error('Failed to update manufacturing vendor');
      return null;
    }
    
    toast.success('Manufacturing vendor updated successfully');
    return data;
  },
  
  // Delete a manufacturing vendor
  async deleteManufacturingVendor(id: string): Promise<boolean> {
    const { error } = await supabase
      .from('manufacturing_vendors')
      .delete()
      .eq('id', id);
      
    if (error) {
      console.error('Error deleting manufacturing vendor:', error);
      toast.error('Failed to delete manufacturing vendor');
      return false;
    }
    
    toast.success('Manufacturing vendor deleted successfully');
    return true;
  },

  // Get production orders
  async getProductionOrders(): Promise<ProductionOrder[]> {
    // Since the production_orders table doesn't exist yet in the database,
    // we'll return mock data instead of trying to query it
    const mockOrders: ProductionOrder[] = [
      {
        id: "1",
        order_id: "ORD-2023-001",
        status: "pending",
        priority: "high",
        assigned_to: "John Smith",
        start_date: null,
        due_date: new Date(Date.now() + 86400000 * 3).toISOString(),
        completion_date: null,
        notes: "High priority jersey order",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: "2",
        order_id: "ORD-2023-002",
        status: "in-progress",
        priority: "normal",
        assigned_to: null,
        start_date: new Date(Date.now() - 86400000).toISOString(),
        due_date: new Date(Date.now() + 86400000 * 7).toISOString(),
        completion_date: null,
        notes: "Basketball uniforms for Springfield High",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: "3",
        order_id: "ORD-2023-003",
        status: "completed",
        priority: "low",
        assigned_to: "Jane Doe",
        start_date: new Date(Date.now() - 86400000 * 3).toISOString(),
        due_date: new Date(Date.now() + 86400000).toISOString(),
        completion_date: new Date().toISOString(),
        notes: "Track & field uniforms",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }
    ];
    
    return mockOrders;
  },

  // Sync manufacturing users from auth context to manufacturing_staff table
  async syncManufacturingUsers(): Promise<boolean> {
    try {
      // Demo manufacturing user from AuthContext
      const manufacturingUsers = [
        {
          id: "3",
          name: "Manufacturing User",
          email: "manufacturing@example.com",
          role: "Production Manager",
          hourly_rate: 25
        }
      ];

      for (const user of manufacturingUsers) {
        // Check if user already exists in manufacturing_staff
        const { data: existingStaff } = await supabase
          .from('manufacturing_staff')
          .select('id')
          .eq('email', user.email)
          .maybeSingle();

        if (!existingStaff) {
          // Create new manufacturing staff record if doesn't exist
          await this.createManufacturingStaffMember({
            name: user.name,
            email: user.email,
            phone: null,
            role: user.role,
            department: "Production",
            hire_date: new Date().toISOString().split('T')[0],
            hourly_rate: user.hourly_rate,
            skills: ["Cutting", "Sewing", "Quality Control"],
            certifications: null,
            address: null,
            city: null,
            state: null,
            zip: null,
            profile_image_url: null,
            bank_account: null,
            tax_id: null,
            notes: "Auto-created from user account"
          });
        }
      }
      
      return true;
    } catch (error) {
      console.error("Error syncing manufacturing users:", error);
      toast.error(`Error syncing manufacturing users: ${error.message}`);
      return false;
    }
  }
};
