
import { supabase, handleSupabaseError } from '@/lib/supabase';
import { toast } from 'sonner';
import { Order as ApiOrder } from '@/lib/api';

// Define types here for better type safety
export type OrderStatus = 'draft' | 'submitted' | 'design' | 'manufacturing' | 'completed' | 'cancelled';

export interface NewOrder {
  customer_id: string;
  lead_id?: string;
  status: OrderStatus;
  total?: number;
  assigned_to?: string | null;
  notes?: string | null;
}

export interface Order {
  id: string;
  customer_id: string;
  status: OrderStatus;
  total: number;
  created_at: string;
  updated_at: string;
  assigned_to?: string | null;
  assigned_user_id?: string | null;
  notes?: string | null;
  lead_id?: string | null;
  design_status?: string | null;
  design_files?: string | null;
  tracking_number?: string | null;
  invoice_id?: string | null;
  invoice_status?: string | null;
  // Add this to match the API Order type
  customerName?: string;
}

export const orderService = {
  // Get all orders
  async getAll(): Promise<ApiOrder[]> {
    console.log('Fetching all orders');
    const { data, error } = await supabase
      .from('orders')
      .select(`
        *,
        organizations:customer_id (name, email, phone)
      `)
      .order('created_at', { ascending: false });
    
    if (error) {
      toast.error(`Error fetching orders: ${handleSupabaseError(error)}`);
      console.error('Error fetching orders:', error);
      return [];
    }
    
    console.log('Orders fetched successfully:', data?.length || 0);
    
    // Map the returned data to include customerName
    const ordersWithCustomerName = data?.map(order => ({
      ...order,
      customerName: order.organizations?.name || 'Unknown Customer',
      customerEmail: order.organizations?.email || undefined,
      customerPhone: order.organizations?.phone || undefined
    })) || [];
    
    return ordersWithCustomerName;
  },
  
  // Create a new order
  async create(order: NewOrder): Promise<ApiOrder | null> {
    console.log('Creating new order:', order);
    const { data, error } = await supabase
      .from('orders')
      .insert([order])
      .select()
      .single();
    
    if (error) {
      toast.error(`Error creating order: ${handleSupabaseError(error)}`);
      console.error('Error creating order:', error);
      return null;
    }
    
    toast.success('Order created successfully');
    
    // Fetch organization to get the customer name
    if (data.customer_id) {
      const { data: orgData } = await supabase
        .from('organizations')
        .select('name')
        .eq('id', data.customer_id)
        .single();
        
      return {
        ...data,
        customerName: orgData?.name || 'Unknown Customer'
      };
    }
    
    return {
      ...data,
      customerName: 'Unknown Customer'
    };
  },
  
  // Update an order's status
  async updateStatus(id: string, status: OrderStatus): Promise<ApiOrder | null> {
    console.log(`Updating order ${id} status to ${status}`);
    // Map in_progress to manufacturing for compatibility
    let mappedStatus = status;
    if (status === "in_progress" as any) {
      mappedStatus = "manufacturing";
    }
    
    const { data, error } = await supabase
      .from('orders')
      .update({ status: mappedStatus, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select(`
        *,
        organizations:customer_id (name, email, phone)
      `)
      .single();
    
    if (error) {
      toast.error(`Error updating order status: ${handleSupabaseError(error)}`);
      console.error('Error updating order status:', error);
      return null;
    }
    
    toast.success(`Order status updated to ${status}`);
    
    return {
      ...data,
      customerName: data.organizations?.name || 'Unknown Customer',
      customerEmail: data.organizations?.email || undefined,
      customerPhone: data.organizations?.phone || undefined
    };
  },
  
  // Get an order by ID
  async getById(id: string): Promise<ApiOrder | null> {
    console.log(`Fetching order with ID: ${id}`);
    const { data, error } = await supabase
      .from('orders')
      .select(`
        *,
        organizations:customer_id (name, email, phone)
      `)
      .eq('id', id)
      .single();
    
    if (error) {
      toast.error(`Error fetching order: ${handleSupabaseError(error)}`);
      console.error('Error fetching order:', error);
      return null;
    }
    
    return {
      ...data,
      customerName: data.organizations?.name || 'Unknown Customer',
      customerEmail: data.organizations?.email || undefined,
      customerPhone: data.organizations?.phone || undefined
    };
  },
  
  // Update an order
  async update(orderUpdate: Partial<ApiOrder>): Promise<ApiOrder | null> {
    console.log('Updating order:', orderUpdate);
    
    // Extract only the properties we can update in the database
    const {
      status, notes, total, assigned_to, design_status,
      design_files, tracking_number, invoice_id, invoice_status
    } = orderUpdate;
    
    const dbUpdate = {
      status, notes, total, assigned_to, design_status,
      design_files, tracking_number, invoice_id, invoice_status,
      updated_at: new Date().toISOString()
    };
    
    const { data, error } = await supabase
      .from('orders')
      .update(dbUpdate)
      .eq('id', orderUpdate.id)
      .select(`
        *,
        organizations:customer_id (name, email, phone)
      `)
      .single();
    
    if (error) {
      toast.error(`Error updating order: ${handleSupabaseError(error)}`);
      console.error('Error updating order:', error);
      return null;
    }
    
    toast.success('Order updated successfully');
    
    return {
      ...data,
      customerName: data.organizations?.name || 'Unknown Customer',
      customerEmail: data.organizations?.email || undefined,
      customerPhone: data.organizations?.phone || undefined
    };
  },
  
  // Delete an order
  async delete(id: string): Promise<boolean> {
    console.log(`Deleting order with ID: ${id}`);
    const { error } = await supabase
      .from('orders')
      .delete()
      .eq('id', id);
    
    if (error) {
      toast.error(`Error deleting order: ${handleSupabaseError(error)}`);
      console.error('Error deleting order:', error);
      return false;
    }
    
    toast.success('Order deleted successfully');
    return true;
  },
  
  // Create order from claimed lead
  async createFromLead(lead: Partial<any>, organizationId: string): Promise<ApiOrder | null> {
    console.log('Creating order from lead:', lead);
    const orderData: NewOrder = {
      customer_id: organizationId,
      lead_id: lead.id as string,
      status: 'draft',
      total: lead.estimated_value || 0,
      assigned_to: lead.owner || null,
      notes: lead.notes || null
    };
    
    return await this.create(orderData);
  }
};
