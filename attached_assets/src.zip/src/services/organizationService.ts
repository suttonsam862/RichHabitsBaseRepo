
import { supabase, handleSupabaseError, Organization, NewOrganization, Lead } from './baseService';
import { toast } from 'sonner';

export const organizationService = {
  // Get all organizations
  async getAll(): Promise<Organization[]> {
    try {
      const { data, error } = await supabase
        .from('organizations')
        .select('*')
        .order('name');
      
      if (error) {
        toast.error(`Error fetching organizations: ${handleSupabaseError(error)}`);
        return [];
      }
      
      return data || [];
    } catch (error) {
      console.error('Error in getAll organizations:', error);
      toast.error(`Error fetching organizations: ${error instanceof Error ? error.message : 'Unknown error'}`);
      return [];
    }
  },
  
  // Create a new organization
  async create(organization: NewOrganization): Promise<Organization | null> {
    try {
      const { data, error } = await supabase
        .from('organizations')
        .insert([organization])
        .select()
        .single();
      
      if (error) {
        toast.error(`Error creating organization: ${handleSupabaseError(error)}`);
        return null;
      }
      
      toast.success('Organization created successfully');
      return data;
    } catch (error) {
      console.error('Error in create organization:', error);
      toast.error(`Error creating organization: ${error instanceof Error ? error.message : 'Unknown error'}`);
      return null;
    }
  },
  
  // Get an organization by ID
  async getById(id: string): Promise<Organization | null> {
    const { data, error } = await supabase
      .from('organizations')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      toast.error(`Error fetching organization: ${handleSupabaseError(error)}`);
      return null;
    }
    
    return data;
  },
  
  // Create organization from lead data
  async createFromLead(lead: Lead): Promise<Organization | null> {
    const organizationData: NewOrganization = {
      name: lead.organization,
      email: lead.email || null,
      phone: lead.phone || null,
      contact_first_name: lead.name.split(' ')[0] || null,
      contact_last_name: lead.name.split(' ').slice(1).join(' ') || null,
      notes: `Created from lead: ${lead.id}`
    };
    
    return await this.create(organizationData);
  }
};
