
import { supabase, handleSupabaseError, Product } from './baseService';
import { toast } from 'sonner';

export const productService = {
  // Get all products
  async getAll(): Promise<Product[]> {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .order('name');
    
    if (error) {
      toast.error(`Error fetching products: ${handleSupabaseError(error)}`);
      return [];
    }
    
    return data || [];
  },
  
  // Get a product by ID
  async getById(id: string): Promise<Product | null> {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      toast.error(`Error fetching product: ${handleSupabaseError(error)}`);
      return null;
    }
    
    return data;
  }
};
