
import { supabase, handleSupabaseError } from './baseService';
import { toast } from 'sonner';

export const salesPersonService = {
  // Get all sales people
  async getAllSalesPeople(): Promise<any[]> {
    const { data, error } = await supabase
      .from('sales_people')
      .select('*');
    
    if (error) {
      toast.error(`Error fetching sales people: ${handleSupabaseError(error)}`);
      return [];
    }
    
    return data || [];
  },
  
  // Get a sales person by ID
  async getById(id: string): Promise<any | null> {
    const { data, error } = await supabase
      .from('sales_people')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      toast.error(`Error fetching sales person: ${handleSupabaseError(error)}`);
      return null;
    }
    
    return data;
  },
  
  // Get a sales person by email
  async getByEmail(email: string): Promise<any | null> {
    const { data, error } = await supabase
      .from('sales_people')
      .select('*')
      .eq('email', email)
      .single();
    
    if (error && error.code !== 'PGRST116') { // PGRST116 is the error code for "no rows returned"
      toast.error(`Error fetching sales person: ${handleSupabaseError(error)}`);
      return null;
    }
    
    return data || null;
  },
  
  // Create a new sales person
  async createSalesPerson(salesPerson: any): Promise<any | null> {
    const { data, error } = await supabase
      .from('sales_people')
      .insert([salesPerson])
      .select()
      .single();
    
    if (error) {
      toast.error(`Error creating sales person: ${handleSupabaseError(error)}`);
      return null;
    }
    
    return data;
  },
  
  // Update a sales person
  async updateSalesPerson(id: string, updates: any): Promise<any | null> {
    const { data, error } = await supabase
      .from('sales_people')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      toast.error(`Error updating sales person: ${handleSupabaseError(error)}`);
      return null;
    }
    
    toast.success("Sales person details updated successfully");
    return data;
  },
  
  // Delete a sales person
  async deleteSalesPerson(id: string): Promise<boolean> {
    const { error } = await supabase
      .from('sales_people')
      .delete()
      .eq('id', id);
    
    if (error) {
      toast.error(`Error deleting sales person: ${handleSupabaseError(error)}`);
      return false;
    }
    
    return true;
  }
};
