
-- Enable the UUID extension for generating unique IDs
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create tables with proper relationships
-- 1. Organizations/Clients table
CREATE TABLE IF NOT EXISTS organizations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  billing_address TEXT,
  billing_address_line2 TEXT,
  billing_city TEXT,
  billing_state TEXT,
  billing_zip TEXT,
  shipping_address TEXT,
  shipping_address_line2 TEXT,
  shipping_city TEXT,
  shipping_state TEXT,
  shipping_zip TEXT,
  contact_first_name TEXT,
  contact_last_name TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Products table
CREATE TABLE IF NOT EXISTS products (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  category TEXT,
  sport TEXT,
  price DECIMAL(10, 2) NOT NULL,
  description TEXT,
  image_url TEXT,
  inventory INTEGER DEFAULT 0,
  sizes TEXT[], -- Array of sizes
  colors TEXT[], -- Array of colors
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Leads table with status enum
CREATE TYPE lead_status AS ENUM (
  'prospect', 
  'discovery', 
  'qualified', 
  'negotiation', 
  'closed-won', 
  'closed-lost'
);

CREATE TABLE IF NOT EXISTS leads (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  organization TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  status lead_status DEFAULT 'prospect',
  assigned_to UUID REFERENCES auth.users(id),
  notes TEXT,
  estimated_value DECIMAL(10, 2),
  owner UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  claimed_at TIMESTAMP WITH TIME ZONE,
  organization_id UUID REFERENCES organizations(id)
);

-- 4. Orders table with status enum
CREATE TYPE order_status AS ENUM (
  'draft', 
  'submitted', 
  'design', 
  'manufacturing', 
  'completed', 
  'cancelled'
);

CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  customer_id UUID REFERENCES organizations(id) NOT NULL,
  status order_status DEFAULT 'draft',
  total DECIMAL(10, 2) DEFAULT 0,
  assigned_to UUID REFERENCES auth.users(id),
  notes TEXT,
  tracking_number TEXT,
  design_status TEXT,
  design_files TEXT,
  invoice_status TEXT,
  invoice_id TEXT,
  lead_id UUID REFERENCES leads(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. Order Line Items table
CREATE TABLE IF NOT EXISTS line_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID REFERENCES orders(id) ON DELETE CASCADE NOT NULL,
  product_id UUID REFERENCES products(id) NOT NULL,
  quantity INTEGER NOT NULL,
  unit_price DECIMAL(10, 2) NOT NULL,
  size TEXT,
  color TEXT,
  notes TEXT,
  customization TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create a function to update the updated_at timestamp
CREATE OR REPLACE FUNCTION update_modified_column()
RETURNS TRIGGER AS $$
BEGIN
   NEW.updated_at = NOW();
   RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers to automatically update the updated_at column
CREATE TRIGGER update_organizations_modtime
BEFORE UPDATE ON organizations
FOR EACH ROW EXECUTE PROCEDURE update_modified_column();

CREATE TRIGGER update_products_modtime
BEFORE UPDATE ON products
FOR EACH ROW EXECUTE PROCEDURE update_modified_column();

CREATE TRIGGER update_leads_modtime
BEFORE UPDATE ON leads
FOR EACH ROW EXECUTE PROCEDURE update_modified_column();

CREATE TRIGGER update_orders_modtime
BEFORE UPDATE ON orders
FOR EACH ROW EXECUTE PROCEDURE update_modified_column();

CREATE TRIGGER update_line_items_modtime
BEFORE UPDATE ON line_items
FOR EACH ROW EXECUTE PROCEDURE update_modified_column();

-- Add RLS (Row Level Security) policies
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE line_items ENABLE ROW LEVEL SECURITY;

-- Create policies for organizations (all authenticated users can view)
CREATE POLICY "Anyone can view organizations"
  ON organizations FOR SELECT
  USING (true);

-- Allow authenticated users to insert and update their own organizations
CREATE POLICY "Users can insert organizations"
  ON organizations FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can update organizations"
  ON organizations FOR UPDATE
  USING (true);

-- Similar policies for other tables
CREATE POLICY "Anyone can view products"
  ON products FOR SELECT
  USING (true);

CREATE POLICY "Users can insert products"
  ON products FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can update products"
  ON products FOR UPDATE
  USING (true);

-- Leads policies
CREATE POLICY "Anyone can view leads"
  ON leads FOR SELECT
  USING (true);

CREATE POLICY "Users can insert leads"
  ON leads FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can update leads"
  ON leads FOR UPDATE
  USING (true);

-- Orders policies
CREATE POLICY "Anyone can view orders"
  ON orders FOR SELECT
  USING (true);

CREATE POLICY "Users can insert orders"
  ON orders FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can update orders"
  ON orders FOR UPDATE
  USING (true);

-- Line items policies
CREATE POLICY "Anyone can view line items"
  ON line_items FOR SELECT
  USING (true);

CREATE POLICY "Users can insert line items"
  ON line_items FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can update line items"
  ON line_items FOR UPDATE
  USING (true);
