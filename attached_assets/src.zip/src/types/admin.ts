
// Admin data types for better type safety
export interface TableEntity {
  name: string;
  displayName: string;
  count?: number;
  error?: boolean;
}

export interface DataTableProps {
  entities: TableEntity[];
  isLoading: boolean;
  onExportData: (tableName: string) => void;
  onImportData: (tableName: string) => void;
  onRefreshData: (tableName: string) => void;
  searchTerm: string;
}
