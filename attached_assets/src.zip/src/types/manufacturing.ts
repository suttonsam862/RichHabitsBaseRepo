
export interface Order {
  id?: string;
  organizations?: {
    name: string;
  };
  status?: string;
  total?: number;
  tracking_number?: string;
  notes?: string;
  line_items?: LineItem[];
}

export interface LineItem {
  id: string;
  quantity: number;
  product_name?: string;
  size?: string;
  color?: string;
}

export interface ManufacturingFormData {
  trackingNumber: string;
  notes: string;
}
