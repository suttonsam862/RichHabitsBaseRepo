
import { Lead, Order, LineItem } from '@/lib/api';

/**
 * Maps database field names to client-side field names to maintain compatibility
 * @param lead Lead object from database
 * @returns Lead with additional client-friendly properties
 */
export const mapDatabaseToClientLead = (lead: Lead): Lead => {
  return {
    ...lead,
    dateCreated: lead.created_at,
    dateUpdated: lead.updated_at,
    estimatedValue: lead.estimated_value,
    assignedTo: lead.assigned_to,
    // Ensure all required properties exist
    owner: lead.owner || null,
    owner_id: lead.owner_id || null,
    assigned_to: lead.assigned_to || null,
    assigned_user_id: lead.assigned_user_id || null,
    estimated_value: lead.estimated_value || null
  };
};

/**
 * Maps client-side field names to database field names for API requests
 * @param lead Lead object from client
 * @returns Lead with database-friendly properties
 */
export const mapClientToDatabaseLead = (lead: Partial<Lead>): Partial<Lead> => {
  const result: Partial<Lead> = { ...lead };
  
  // Map client properties to database properties
  if (lead.estimatedValue !== undefined) {
    result.estimated_value = lead.estimatedValue;
  }
  
  if (lead.assignedTo !== undefined) {
    result.assigned_to = lead.assignedTo;
  }
  
  // Ensure we include both naming conventions for compatibility
  // during the transition period
  result.assigned_to = lead.assigned_to || lead.assignedTo || null;
  result.assigned_user_id = lead.assigned_user_id || null;
  result.estimated_value = lead.estimated_value || lead.estimatedValue || null;
  result.owner = lead.owner || null;
  result.owner_id = lead.owner_id || null;
  
  return result;
};

/**
 * Maps database field names to client-side field names for Orders
 * @param order Order object from database
 * @returns Order with additional client-friendly properties
 */
export const mapDatabaseToClientOrder = (order: Order): Order => {
  return {
    ...order,
    dateCreated: order.created_at,
    dateUpdated: order.updated_at,
    assignedTo: order.assigned_to,
    customerId: order.customer_id,
    lineItems: order.items,
  };
};

/**
 * Maps client-side field names to database field names for API requests
 * @param order Order object from client
 * @returns Order with database-friendly properties
 */
export const mapClientToDatabaseOrder = (order: Partial<Order>): Partial<Order> => {
  const result: Partial<Order> = { ...order };
  
  // Map client properties to database properties
  if (order.assignedTo !== undefined) {
    result.assigned_to = order.assignedTo;
  }
  
  if (order.customerId !== undefined) {
    result.customer_id = order.customerId;
  }
  
  return result;
};

/**
 * Maps database LineItem to client LineItem with additional properties
 */
export const mapDatabaseToClientLineItem = (lineItem: LineItem): LineItem => {
  return {
    ...lineItem,
    price: lineItem.unit_price,
    product: lineItem.product_id,
    // Using proper properties that match the LineItem type
    product_id: lineItem.product_id
  };
};

/**
 * Maps client LineItem to database LineItem format
 */
export const mapClientToDatabaseLineItem = (lineItem: Partial<LineItem>): Partial<LineItem> => {
  const result: Partial<LineItem> = { ...lineItem };
  
  if (lineItem.price !== undefined) {
    result.unit_price = lineItem.price;
  }
  
  // Handle product_id mapping from various client-side property names
  if (lineItem.product_id !== undefined) {
    result.product_id = lineItem.product_id;
  } else if (lineItem.product !== undefined) {
    result.product_id = lineItem.product;
  }
  
  return result;
};
