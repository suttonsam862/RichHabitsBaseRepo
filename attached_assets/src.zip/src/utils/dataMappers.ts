
import { Lead as ApiLead } from "@/lib/api";
import { Lead as SupabaseLead } from "@/services/baseService";
import { LeadStatus } from "@/services/leadService";

/**
 * Maps a Supabase Lead to the API Lead format
 */
export const mapSupabaseLeadToApiLead = (lead: SupabaseLead): ApiLead => {
  return {
    id: lead.id,
    name: lead.name,
    organization: lead.organization,
    email: lead.email || "",
    phone: lead.phone || "",
    status: lead.status,
    dateCreated: lead.created_at,
    dateUpdated: lead.updated_at || lead.created_at,
    notes: lead.notes || "",
    estimatedValue: lead.estimated_value || 0,
    owner: lead.owner || null,
    assignedTo: lead.assigned_to || null,
    // Also include the database field names for compatibility
    created_at: lead.created_at,
    updated_at: lead.updated_at || lead.created_at,
    estimated_value: lead.estimated_value || 0,
    assigned_to: lead.assigned_to || null,
    owner_id: (lead as any).owner_id || null,
    assigned_user_id: (lead as any).assigned_user_id || null
  };
};

/**
 * Maps an API Lead to the Supabase Lead format
 */
export const mapApiLeadToSupabaseLead = (lead: Partial<ApiLead>): Partial<SupabaseLead> => {
  // Ensure at least the required fields are present
  if (!lead.name || !lead.organization) {
    throw new Error("Name and organization are required fields for a lead");
  }
  
  const result: Partial<SupabaseLead> = {
    id: lead.id,
    name: lead.name,
    organization: lead.organization,
    email: lead.email || null,
    phone: lead.phone || null,
    status: (lead.status as LeadStatus) || "prospect",
    created_at: lead.created_at || lead.dateCreated || new Date().toISOString(),
    updated_at: lead.updated_at || lead.dateUpdated || new Date().toISOString(),
    notes: lead.notes || null,
    estimated_value: lead.estimated_value || lead.estimatedValue || null,
    owner: lead.owner || null,
    assigned_to: lead.assigned_to || lead.assignedTo || null,
    claimed_at: null,
    organization_id: null
  };
  
  // Add these fields to make TypeScript happy
  if (lead.owner_id !== undefined) {
    (result as any).owner_id = lead.owner_id;
  }
  
  if (lead.assigned_user_id !== undefined) {
    (result as any).assigned_user_id = lead.assigned_user_id;
  }
  
  return result;
};

/**
 * Maps an array of Supabase Leads to API Lead format
 */
export const mapSupabaseLeadsToApiLeads = (leads: SupabaseLead[]): ApiLead[] => {
  return leads.map(mapSupabaseLeadToApiLead);
};

/**
 * Helper function to ensure a Supabase Lead is valid
 */
export const validateSupabaseLead = (lead: any): lead is SupabaseLead => {
  return (
    lead &&
    typeof lead.id === 'string' &&
    typeof lead.name === 'string' &&
    typeof lead.organization === 'string'
  );
};
