
import { jsPDF } from "jspdf";
import "jspdf-autotable";
import { Order } from "@/lib/api";

// Add the types for jsPDF-autotable
declare module "jspdf" {
  interface jsPDF {
    autoTable: (options: any) => jsPDF;
  }
}

export const generateInvoicePDF = (order: Order, invoiceNumber: string): jsPDF => {
  const doc = new jsPDF();
  
  // Add company logo/header
  doc.setFontSize(20);
  doc.setFont("helvetica", "bold");
  doc.text("SPORTSWEAR PRO", 14, 22);
  
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text("123 Main Street, Anytown, USA", 14, 30);
  doc.text("Phone: (555) 123-4567", 14, 35);
  doc.text("Email: sales@sportswear.pro", 14, 40);
  
  // Add invoice info
  doc.setFontSize(16);
  doc.setFont("helvetica", "bold");
  doc.text("INVOICE", 140, 22);
  
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text(`Invoice #: ${invoiceNumber}`, 140, 30);
  doc.text(`Date: ${new Date().toLocaleDateString()}`, 140, 35);
  doc.text(`Due Date: ${new Date(Date.now() + 30*24*60*60*1000).toLocaleDateString()}`, 140, 40);
  
  // Add customer info
  doc.setFontSize(12);
  doc.setFont("helvetica", "bold");
  doc.text("Bill To:", 14, 55);
  
  doc.setFont("helvetica", "normal");
  doc.text(order.customerName, 14, 62);
  doc.text(`Customer ID: ${order.customerId || 'N/A'}`, 14, 67);
  
  // Add order info
  doc.setFontSize(12);
  doc.setFont("helvetica", "bold");
  doc.text("Order Information:", 140, 55);
  
  doc.setFont("helvetica", "normal");
  doc.text(`Order ID: ${order.id}`, 140, 62);
  doc.text(`Order Date: ${order.dateCreated}`, 140, 67);
  doc.text(`Status: ${order.status}`, 140, 72);
  
  // Add line items table
  const tableColumn = ["Item", "Description", "Quantity", "Price", "Total"];
  const tableRows = order.lineItems.map(item => [
    item.id,
    item.productName,
    item.quantity.toString(),
    `$${item.price.toFixed(2)}`,
    `$${(item.price * item.quantity).toFixed(2)}`
  ]);
  
  doc.autoTable({
    head: [tableColumn],
    body: tableRows,
    startY: 85,
    theme: 'grid',
    styles: { fontSize: 9 },
    headStyles: { fillColor: [41, 128, 185], textColor: 255 },
  });
  
  // Calculate the Y position after the table
  const finalY = (doc as any).lastAutoTable.finalY + 10;
  
  // Add total section
  doc.setFontSize(10);
  doc.setFont("helvetica", "bold");
  doc.text(`Subtotal: $${order.total.toFixed(2)}`, 140, finalY);
  doc.text(`Tax: $${(order.total * 0.1).toFixed(2)}`, 140, finalY + 6);
  doc.text(`Total: $${(order.total * 1.1).toFixed(2)}`, 140, finalY + 12);
  
  // Add footer
  doc.setFontSize(8);
  doc.setFont("helvetica", "normal");
  doc.text("Thank you for your business!", 14, finalY + 25);
  doc.text("Payment is due within 30 days of invoice date.", 14, finalY + 30);
  
  return doc;
};
