
import { Lead as ApiLead, Order as ApiOrder } from '@/lib/api';
import { Lead as ServiceLead } from '@/services/leadService';
import { Order as ServiceOrder } from '@/services/orderService';

/**
 * Maps a Service Lead to an API Lead format
 */
export const mapServiceLeadToApiLead = (lead: ServiceLead): ApiLead => {
  return {
    id: lead.id,
    name: lead.name,
    organization: lead.organization,
    email: lead.email || '',
    phone: lead.phone || '',
    status: lead.status,
    notes: lead.notes || '',
    owner: lead.owner || null,
    owner_id: lead.owner_id || null,
    assigned_to: lead.assigned_to || null,
    assigned_user_id: lead.assigned_user_id || null,
    estimated_value: lead.estimated_value || 0,
    created_at: lead.created_at,
    updated_at: lead.updated_at,
    dateCreated: lead.created_at,
    dateUpdated: lead.updated_at,
    estimatedValue: lead.estimated_value || 0,
    assignedTo: lead.assigned_to || null
  };
};

/**
 * Maps an API Lead to a Service Lead format
 */
export const mapApiLeadToServiceLead = (lead: ApiLead): ServiceLead => {
  return {
    id: lead.id,
    name: lead.name,
    organization: lead.organization,
    email: lead.email,
    phone: lead.phone,
    status: lead.status,
    notes: lead.notes,
    owner: lead.owner,
    owner_id: lead.owner_id,
    assigned_to: lead.assigned_to,
    assigned_user_id: lead.assigned_user_id,
    estimated_value: lead.estimated_value,
    created_at: lead.created_at,
    updated_at: lead.updated_at,
    organization_id: null
  };
};

/**
 * Maps a Service Order to an API Order format
 */
export const mapServiceOrderToApiOrder = (order: ServiceOrder): ApiOrder => {
  return {
    id: order.id,
    customer_id: order.customer_id,
    customerId: order.customer_id,
    customerName: order.customerName || 'Unknown Customer',
    status: order.status,
    total: order.total,
    created_at: order.created_at,
    updated_at: order.updated_at,
    dateCreated: order.created_at,
    dateUpdated: order.updated_at,
    assigned_to: order.assigned_to || null,
    assignedTo: order.assigned_to || null,
    assigned_user_id: order.assigned_user_id || null,
    notes: order.notes || '',
    design_status: order.design_status || null,
    design_files: order.design_files || null,
    tracking_number: order.tracking_number || null,
    invoice_id: order.invoice_id || null,
    invoice_status: order.invoice_status || null
  };
};

/**
 * Maps an API Order to a Service Order format
 */
export const mapApiOrderToServiceOrder = (order: ApiOrder): ServiceOrder => {
  return {
    id: order.id,
    customer_id: order.customer_id || order.customerId || '',
    status: order.status,
    total: order.total,
    created_at: order.created_at,
    updated_at: order.updated_at,
    assigned_to: order.assigned_to || order.assignedTo,
    assigned_user_id: order.assigned_user_id,
    notes: order.notes,
    lead_id: null,
    design_status: order.design_status,
    design_files: order.design_files,
    tracking_number: order.tracking_number,
    invoice_id: order.invoice_id,
    invoice_status: order.invoice_status,
    customerName: order.customerName
  };
};

/**
 * Maps an array of Service Leads to API Lead format
 */
export const mapServiceLeadsToApiLeads = (leads: ServiceLead[]): ApiLead[] => {
  return leads.map(mapServiceLeadToApiLead);
};

/**
 * Maps an array of API Leads to Service Lead format
 */
export const mapApiLeadsToServiceLeads = (leads: ApiLead[]): ServiceLead[] => {
  return leads.map(mapApiLeadToServiceLead);
};

/**
 * Maps an array of Service Orders to API Order format
 */
export const mapServiceOrdersToApiOrders = (orders: ServiceOrder[]): ApiOrder[] => {
  return orders.map(mapServiceOrderToApiOrder);
};

/**
 * Maps an array of API Orders to Service Order format
 */
export const mapApiOrdersToServiceOrders = (orders: ApiOrder[]): ServiceOrder[] => {
  return orders.map(mapApiOrderToServiceOrder);
};
